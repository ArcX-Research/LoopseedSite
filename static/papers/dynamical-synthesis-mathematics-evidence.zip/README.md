# Mathematics evidence for Dynamical Synthesis

Brian Ashiundu · Dilate Technologies · 11 September 2026

This package supports Sections 4 and 5.1 of *Dynamical Synthesis: Learning through
Interaction*. It contains the complete 1,024-cell mathematics comparison,
including the primary setting and all three diagnostic settings. These are
recorded outputs from one study, not independent repetitions of training.

## Inspect the evidence

- `study/protocol.json`: task parameters, prompts, allowed operations, condition
  definitions, exclusions, runtime settings and criteria fixed before evaluation.
- `study/cells.json`: all 1,024 replies, recorded exact-checker grades, length-limit
  flags and experimental condition codes, including unsuccessful replies.
- `study/arm-key.json`: the historical mapping from codes to model conditions.
- `study/audit-bundle.json`: all 155 machine-positive replies and the review rubric.
- `study/external-audit.json`: the corresponding acceptance/veto decisions and reasons.
- `study/verdict.json`: the original result across all prompt/output settings.
- `training/`: candidate and shuffled-control splits, selection records, dataset
  audits and recorded training settings. Six selected target replies were flagged
  for prohibited numerical constants; the original flags are retained. This is
  the selected training dataset, not every rejected example from its earlier collection.
- `code/`: task-generation, checker and experiment Python sources and their local
  Python imports from commit `da445bb8de772f794766ca44a944e8ffff82c09a`, plus
  recorded dependency files and decoding grammars. Seven pinned source hashes
  are checked during export. This code is provided for inspection; it is not a
  self-contained installation of the model runtime.

## Reconstruct the counts

With Python 3.9 or newer, from the extracted directory:

```sh
python3 verify.py
```

The script needs no external libraries, private checkout, model or network. It
checks the file manifest, complete cell coverage, prompt and reply hashes, and
the links between exact-checker successes and AI decisions. It reconstructs all
four prompt/output comparisons from the saved cell records. The primary totals
are 43/64 candidate, 0/64 base model, 0/64 shuffled control and 5/64 previous
prediction adapter. Both training datasets contain 48/6/6 train/validation/test
examples. The verification does not independently judge answer correctness.

## Reproduction limits

Exact checking in the original study used WolframScript and the Wolfram kernel;
running those checks again requires a compatible licensed installation. Training
and inference require the recorded model, dependencies and runtime. Model weights,
adapter binaries, the daemon executable and raw databases are not included. Their
recorded hashes identify the intended artifacts; this export does not rehash them.

The AI review records the name Laplace, a session identifier, a rubric and decisions.
The underlying reviewer model/version and complete invocation are not preserved.
The historical `independent: true` field means a separate review session; it is
not evidence of independent training data or replication. A new review should be
reported separately and must not overwrite the recorded decisions.

The original protocol and report use terms such as "clean", "proved" and
"transfer". The paper explains their limits: six training targets have recorded
constant-rule violations, numerical checks are limited to specified tasks, and
all tested problem types were represented in training. Questions within a problem
type can share errors. Neither 1,024 calls nor 64 primary tasks represent that many
independent training experiments.

## File identity and export changes

`manifest.json` contains hashes of exported files. `source-record.json` records
the original source-file hashes and the recorded code commit. Local filesystem
paths in metadata are replaced with portable labels. Internal database/session/
lease bookkeeping and local log paths are omitted from cell records. Mathematical
prompts, replies, scores and decisions are retained; original training split files
and recorded code are copied unchanged. Hash fields retained inside historical
records refer to the original files, not to transformed JSON exports.

No participant messages, private databases, authentication files or model weights
are included. Files for the other studies remain separate from this package.
Hashes support checking file identity; they do not establish the truth of a result
or a public date of registration.
