#!/usr/bin/env python3
"""Check the exported mathematics records with Python's standard library only.

Run from an extracted evidence package: python3 verify.py
Does not execute the supplied historical experiment code, a model, or Wolfram.
"""
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def check(root):
    def read(name):
        return json.loads((root / name).read_text())
    manifest = read("manifest.json")
    for name, expected in manifest.items():
        path = (root / name).resolve()
        assert path.is_relative_to(root.resolve()), "Path outside package"
        raw = path.read_bytes()
        assert sha(raw) == expected["sha256"] and len(raw) == expected["bytes"], name
    protocol, keys = read("study/protocol.json"), read("study/arm-key.json")
    cases = {case["id"]: case for case in protocol["design"]["cases"]}
    assert len(cases) == 256
    reviews = read("study/external-audit.json")
    decisions = {row["audit_id"]: row for row in reviews["decisions"]}
    entries = {row["audit_id"]: row for row in read("study/audit-bundle.json")["entries"]}
    assert len(decisions) == len(entries) == 155
    assert set(decisions) == set(entries)
    summary = defaultdict(lambda: Counter(tasks=0, exact=0, accepted=0, cap_cuts=0))
    family_counts = defaultdict(Counter)
    outcomes = defaultdict(dict)
    observed, reviewed = set(), set()
    for row in read("study/cells.json"):
        cell = row["cell"]
        assert row["status"] == "complete"
        label, case_id = cell["label"], cell["case_id"]
        assert (label, case_id) not in observed, "Duplicate cell"
        observed.add((label, case_id))
        case = cases[case_id]
        assert sha(case["prompt"].encode()) == cell["prompt_sha256"]
        assert sha(cell["reply"].encode()) == cell["reply_sha256"]
        for field in ("kind", "parameters", "primary_endpoint", "prompt_condition", "grammar_condition", "task_id"):
            assert cell[field] == case[field], field
        arm = keys["mapping"][label]["kind"]
        cut = (cell.get("narration") or {}).get("cut_at_cap") is True
        exact = (cell.get("mechanically_valid") is True and not cut
                 and (cell.get("grade") or {}).get("verdict") == "proved")
        accepted = False
        if exact:
            audit_id = sha((protocol["instrument"] + "\0whole-reply-audit\0" + keys["nonce"]
                            + "\0" + label + "\0" + case_id).encode())
            decision, entry = decisions[audit_id], entries[audit_id]
            assert decision["reply_sha256"] == entry["reply_sha256"] == cell["reply_sha256"]
            assert entry["reply"] == cell["reply"] and entry["prompt"] == case["prompt"]
            assert decision["decision"] in {"accepted", "vetoed"}
            reviewed.add(audit_id)
            accepted = decision["decision"] == "accepted"
        group = (case["prompt_condition"], case["grammar_condition"], arm)
        summary[group].update(tasks=1, exact=int(exact), accepted=int(accepted), cap_cuts=int(cut))
        if case["primary_endpoint"]:
            assert case["prompt_condition"] == "names-only" and case["grammar_condition"] == "loose-v2"
            outcomes[arm][case["task_id"]] = accepted
            family_counts[arm][case["kind"]] += int(accepted)
    assert observed == {(label, case) for label in keys["mapping"] for case in cases}
    assert reviewed == set(decisions), "Unmatched review"
    verdict = read("study/verdict.json")
    for group in verdict["factorial_diagnostics"]:
        for arm, expected in group["arms"].items():
            actual = summary[(group["prompt_condition"], group["grammar_condition"], arm)]
            assert actual == dict(tasks=expected["tasks"], exact=expected["exact_proved"],
                                  accepted=expected["audit_accepted"], cap_cuts=expected["reply_cap_cuts"])
    totals = {arm: sum(rows.values()) for arm, rows in outcomes.items()}
    assert totals == {"candidate": 43, "bare": 0, "placebo": 0, "retained": 5}
    candidate = outcomes["candidate"]
    assert len(candidate) == 64 and sum(value > 0 for value in family_counts["candidate"].values()) == 11
    for control in ("bare", "placebo"):
        other = outcomes[control]
        gains = sum(candidate[key] and not other[key] for key in candidate)
        losses = sum(other[key] and not candidate[key] for key in candidate)
        assert (gains, losses, 64 - gains - losses) == (43, 0, 21)
    for arm in ("candidate", "shuffled-control"):
        for split, count in (("train", 48), ("valid", 6), ("test", 6)):
            lines = (root / f"training/{arm}/{split}.jsonl").read_text().splitlines()
            assert len(lines) == count
            for line in lines:
                json.loads(line)
    print("Verified: 1,024 cells, 155 whole-reply reviews, and both 48/6/6 data splits.")
    print("Primary accepted answers:", totals)
    print("Candidate: 11/16 problem types with a success; 43 gains, 0 losses, 21 ties against each main control.")
    print("Counts reconstruct the saved decisions; no new mathematical or AI review was performed.")


if __name__ == "__main__":
    check(Path(__file__).resolve().parent)
