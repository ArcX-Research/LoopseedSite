"""Versioned exact checker for Fish's bounded typed arithmetic AST.

Version 1 is retained byte-for-byte because the first formal classroom pinned
its digest.  Its infix renderer could concatenate subtraction with a negative
right operand as ``a--b``, which Wolfram reads differently from ``a-(-b)``.
This successor parenthesizes every infix operand before any kernel call.  The
JSON language, bounds, prompt contract, and exact task generator are otherwise
the v1 instrument.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

from fish.lab import claim_probe
from fish.lab import typed_ast_probe as v1

ProposalError = v1.ProposalError


def checker_sha256() -> str:
    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def _render_operation(kind: str, arguments: list[str]) -> str:
    if kind in {"+", "-", "*", "/", "^"}:
        protected = [f"({argument})" for argument in arguments]
        return f"({kind.join(protected)})"
    return f"{kind}[{','.join(arguments)}]"


def _compile_node(
    node: Any,
    expanded: dict[str, str],
    *,
    fact: str,
    depth: int,
    budget: list[int],
) -> str:
    if depth > v1.MAX_DEPTH:
        raise ProposalError(f"{fact}: AST depth cap")
    budget[0] += 1
    if budget[0] > v1.MAX_NODES:
        raise ProposalError(f"{fact}: AST node cap")
    if type(node) is int:
        if abs(node) > v1.MAX_INTEGER:
            raise ProposalError(f"{fact}: integer magnitude cap")
        return str(node)
    if not isinstance(node, dict):
        raise ProposalError(f"{fact}: every node must be an integer or object")
    if set(node) == {"ref"}:
        reference = node["ref"]
        if not isinstance(reference, str) or reference not in expanded:
            shown = reference if isinstance(reference, str) else repr(reference)
            raise ProposalError(f"{fact}: unknown or forward fact reference: {shown}")
        return f"({expanded[reference]})"
    if set(node) != {"op", "args"}:
        raise ProposalError(f"{fact}: node keys must be exactly op/args or ref")
    operation = node["op"]
    arguments = node["args"]
    if not isinstance(operation, str) or operation not in v1.OPERATIONS:
        raise ProposalError(f"{fact}: unknown operation: {operation!r}")
    if not isinstance(arguments, list):
        raise ProposalError(f"{fact}: args must be an array")
    minimum, maximum, kind = v1.OPERATIONS[operation]
    if not minimum <= len(arguments) <= maximum:
        expected = str(minimum) if minimum == maximum else f"{minimum}..{maximum}"
        raise ProposalError(f"{fact}: {operation} expects {expected} args")
    compiled = [
        _compile_node(item, expanded, fact=fact, depth=depth + 1, budget=budget)
        for item in arguments
    ]
    return _render_operation(kind, compiled)


def compile_proposal(reply: str, target: dict[str, Any]) -> tuple[dict[str, Any], dict[str, str]]:
    """Return typed nodes and unambiguous trusted Wolfram expansions."""
    programs = v1._parse_json(reply, target)
    expanded: dict[str, str] = {}
    functions, constants = claim_probe.allowlists()
    budget = [0]
    for name in target["required"]:
        root = programs[name]
        if not isinstance(root, dict):
            raise ProposalError(f"{name}: a fact root must be an operation or reference")
        expression = _compile_node(root, expanded, fact=name, depth=0, budget=budget)
        if len(expression.encode("utf-8")) > v1.JSON_CAP:
            raise ProposalError(f"{name}: expanded expression cap")
        refusal = claim_probe.gate_refusal(expression, functions, constants)
        if refusal is not None:
            raise ProposalError(f"{name}: compiler emitted refused expression: {refusal}")
        expanded[name] = expression
    return programs, expanded


def parse_proposal(reply: str, target: dict[str, Any]) -> dict[str, Any]:
    programs, _expanded = compile_proposal(reply, target)
    return programs


def _base_record(target: dict[str, Any], exchange_id: int | None) -> dict[str, Any]:
    return {
        "exchange_id": exchange_id,
        "spec_sha256": target["spec_sha256"],
        "kind": target["kind"],
        "parameters": target["parameters"],
        "required": list(target["required"]),
        "expressions": {},
        "expanded_expressions": {},
        "results": {},
        "checker": (
            "bounded typed JSON AST + unambiguous trusted compiler + "
            "wolfram kernel + exact generator"
        ),
        "task_checker_sha256": target["checker_sha256"],
        "proposal_checker_sha256": checker_sha256(),
        "language": "fish-formal-ast-v2",
    }


def _finish(
    record: dict[str, Any],
    verdict: str,
    text: str,
    *,
    counterexample: dict[str, Any] | None = None,
    gate_refusal: str | None = None,
) -> dict[str, Any]:
    return {
        **record,
        "verdict": verdict,
        "disposition": claim_probe.disposition(verdict),
        "gate_refusal": gate_refusal,
        "counterexample": counterexample,
        "text": text,
    }


def judge(reply: str, target: dict[str, Any], exchange_id: int | None = None) -> dict[str, Any]:
    target = claim_probe.verify_spec(target)
    record = _base_record(target, exchange_id)
    try:
        programs, expanded = compile_proposal(reply, target)
    except ProposalError as error:
        reason = str(error)
        return _finish(
            record,
            "refused",
            f"refused before compilation: {reason}.",
            gate_refusal=reason,
        )
    record["expressions"] = programs
    record["expanded_expressions"] = expanded
    names = list(target["required"])
    values = claim_probe.evaluate([expanded[name] for name in names])
    record["results"] = dict(zip(names, values, strict=True))
    expected = {fact["name"]: int(fact["expected"]) for fact in target["facts"]}
    for name, value in record["results"].items():
        if not v1.INTEGER.fullmatch(value):
            witness = {"kind": "not_an_integer", "fact": name, "value": value}
            return _finish(
                record,
                "underdetermined",
                f"underdetermined: {name} compiled to `{value}`, not an integer.",
                counterexample=witness,
            )
        actual = int(value)
        if actual != expected[name]:
            witness = {
                "kind": "wrong_value",
                "fact": name,
                "program": programs[name],
                "expanded_expression": expanded[name],
                "expected": expected[name],
                "actual": actual,
            }
            return _finish(
                record,
                "refuted",
                f"refuted: {name} compiles to {actual}, expected {expected[name]}.",
                counterexample=witness,
            )
    return _finish(
        record,
        "proved",
        f"proved: the typed program compiled {', '.join(names)} to exact task values.",
    )


def prompt_contract(target: dict[str, Any]) -> str:
    return v1.prompt_contract(target)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", type=Path, required=True)
    parser.add_argument("--reply", type=Path)
    parser.add_argument("--exchange", type=int)
    parser.add_argument("--prompt", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    target = json.loads(args.spec.read_text(encoding="utf-8"))
    if args.prompt:
        if args.reply is not None:
            raise SystemExit("--prompt and --reply are mutually exclusive")
        print(prompt_contract(target))
        return
    if args.reply is None:
        raise SystemExit("--reply is required unless --prompt is used")
    result = judge(args.reply.read_text(encoding="utf-8"), target, args.exchange)
    if args.json:
        print(json.dumps(result, ensure_ascii=False))
    else:
        print(f"{result['verdict']:15} {result['disposition']:9} {result['text']}")


if __name__ == "__main__":
    main()
