"""One manual Claude turn in a private, visible Fish classroom.

The daemon stays open in a private tmux chair so its conversational window is
preserved. This helper never chooses a prompt and has no loop: ``turn`` sends
exactly one bounded, one-line message supplied by the caller, records the
matching Fish reply, and exits.
"""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import re
import shlex
import shutil
import signal
import sqlite3
import stat
import subprocess
import sys
import tempfile
import time
from collections import Counter
from contextlib import contextmanager, nullcontext
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterator

ROOT = Path(__file__).resolve().parents[2]
MAX_MESSAGE_CHARS = 4096
MAX_AUDIT_REASON_CHARS = 1024
MAX_RECORD_BYTES = 100_000
READY_TIMEOUT_SECONDS = 30.0
TURN_TIMEOUT_SECONDS = 400.0
POLL_SECONDS = 0.1
ROLES = {"teacher", "fish", "ruler", "lesson", "classroom error"}
SESSION = re.compile(r"^[A-Za-z0-9_-]{1,80}$")
DISPOSITIONS = {
    "proved": "eligible",
    "refuted": "pruned",
    "refused": "pruned",
    "drift": "pruned",
    "underdetermined": "held",
}


def utc_now() -> str:
    return datetime.now(UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def read_bounded_bytes(path: Path, *, limit: int = MAX_RECORD_BYTES) -> bytes:
    """Read at most one byte beyond ``limit`` before refusing the file."""
    with path.open("rb") as stream:
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise ValueError(f"record exceeds {limit} bytes")
    return raw


def run_bounded_process(
    command: list[str],
    *,
    cwd: Path,
    timeout: float,
    limit: int = MAX_RECORD_BYTES,
) -> tuple[int, str, str]:
    """Capture a trusted helper without allocating its output before the cap."""
    with tempfile.TemporaryFile() as stdout, tempfile.TemporaryFile() as stderr:
        process = subprocess.Popen(
            command,
            cwd=cwd,
            stdout=stdout,
            stderr=stderr,
            start_new_session=True,
        )
        try:
            returncode = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
            raise
        captured = []
        for name, stream in (("stdout", stdout), ("stderr", stderr)):
            size = stream.tell()
            if size > limit:
                raise RuntimeError(f"helper {name} exceeds {limit} bytes")
            stream.seek(0)
            captured.append(stream.read(limit + 1).decode("utf-8"))
    return returncode, captured[0], captured[1]


@contextmanager
def turn_lock(
    room: Path, *, error_message: str = "another manual turn or ruler check is still active"
) -> Iterator[None]:
    """Hold the room's single non-blocking transaction lock."""
    with (room / "turn.lock").open("a+") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise RuntimeError(error_message) from error
        yield


def load_bounded_json(path: Path, *, limit: int = MAX_RECORD_BYTES) -> dict[str, Any]:
    try:
        loaded = json.loads(read_bounded_bytes(path, limit=limit))
    except ValueError as error:
        if str(error).startswith("record exceeds"):
            raise ValueError(f"JSON {error}") from error
        raise
    if not isinstance(loaded, dict):
        raise ValueError("JSON record must be an object")
    return loaded


def verify_spec(value: dict[str, Any], checker_sha256: str) -> str:
    """Verify the ruler's self-hashed, pre-turn target declaration."""
    if value.get("checker_sha256") != checker_sha256:
        raise ValueError("the target spec was not made by the pinned checker")
    declared = value.get("spec_sha256")
    if not isinstance(declared, str) or not re.fullmatch(r"[0-9a-f]{64}", declared):
        raise ValueError("target spec has no valid sha256")
    body = {key: item for key, item in value.items() if key != "spec_sha256"}
    actual = hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()
    if actual != declared:
        raise ValueError("target spec hash does not match its body")
    required = value.get("required")
    facts = value.get("facts")
    if not isinstance(required, list) or not required:
        raise ValueError("target spec must require at least one fact")
    if not isinstance(facts, list) or not facts:
        raise ValueError("target spec must carry exact generated facts")
    fact_names = {
        fact.get("name")
        for fact in facts
        if isinstance(fact, dict) and isinstance(fact.get("name"), str)
    }
    if any(not isinstance(name, str) or name not in fact_names for name in required):
        raise ValueError("target spec requires a fact it does not define")
    return declared


def atomic_json(path: Path, value: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=1, ensure_ascii=False) + "\n")
    os.replace(temporary, path)


def append_jsonl(path: Path, value: dict[str, Any]) -> None:
    encoded = json.dumps(value, sort_keys=True, ensure_ascii=False)
    with path.open("a", encoding="utf-8") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX)
        stream.write(encoded + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def append_role(log: Path, role: str, text: str) -> None:
    if role not in ROLES:
        raise ValueError(f"unknown classroom role: {role}")
    lines = text.strip().splitlines() or [""]
    rendered = [f"{role} ▸ {lines[0]}"]
    rendered.extend(f"    {line}" if line else "" for line in lines[1:])
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open("a", encoding="utf-8") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX)
        stream.write("\n".join(rendered) + "\n\n")
        stream.flush()
        os.fsync(stream.fileno())


def validate_message(message: str) -> str:
    if not message or message != message.strip():
        raise ValueError("the manual turn must be nonempty with no outer whitespace")
    if len(message) > MAX_MESSAGE_CHARS:
        raise ValueError(f"the manual turn exceeds {MAX_MESSAGE_CHARS} characters")
    if "\n" in message or "\r" in message:
        raise ValueError("the Fish port accepts exactly one line per manual turn")
    if any(ord(character) < 32 or ord(character) == 127 for character in message):
        raise ValueError("the manual turn contains a control character")
    return message


def validate_audit_reason(reason: str) -> str:
    if not reason or reason != reason.strip():
        raise ValueError("the audit reason must be nonempty with no outer whitespace")
    if len(reason) > MAX_AUDIT_REASON_CHARS:
        raise ValueError(f"the audit reason exceeds {MAX_AUDIT_REASON_CHARS} characters")
    if "\n" in reason or "\r" in reason:
        raise ValueError("the audit reason must be one line")
    if any(ord(character) < 32 or ord(character) == 127 for character in reason):
        raise ValueError("the audit reason contains a control character")
    return reason


def prepare_home(root: Path, body: Path, coat: Path, repository: Path = ROOT) -> tuple[Path, Path]:
    home = root / "fish"
    bridge = root / "bridge"
    adapters = home / "water" / "adapters"
    adapters.mkdir(parents=True)
    bridge.mkdir(parents=True)
    copied_body = home / "sediment.db"
    shutil.copy2(body, copied_body)
    copied_body.chmod(copied_body.stat().st_mode | stat.S_IWUSR)
    shutil.copy2(repository / "SOUL.md", home / "SOUL.md")
    (home / "dreamable").write_text("claim-claude\n")
    (home / "water" / "embedders").symlink_to(repository / "fish" / "water" / "embedders")
    (adapters / "worn.gguf").symlink_to(coat.resolve())
    if sha256(copied_body) != sha256(body):
        raise RuntimeError("the disposable body differs from its source snapshot")
    return home, bridge


def initialize_review_schema(body: Path) -> None:
    """The audit ledger lives only in the disposable body's SQLite file."""
    with sqlite3.connect(body) as database:
        database.execute(
            "CREATE TABLE IF NOT EXISTS claim_reviews ("
            "exchange_id INTEGER PRIMARY KEY, "
            "reviewed_at TEXT NOT NULL, "
            "checker TEXT NOT NULL, "
            "checker_sha256 TEXT NOT NULL, "
            "spec_sha256 TEXT NOT NULL, "
            "reply_sha256 TEXT NOT NULL, "
            "verdict TEXT NOT NULL, "
            "disposition TEXT NOT NULL, "
            "record_json TEXT NOT NULL, "
            "finalized_after_grade INTEGER NOT NULL DEFAULT 0, "
            "finalized_at TEXT, "
            "final_state TEXT, "
            "FOREIGN KEY(exchange_id) REFERENCES exchanges(id)"
            ")"
        )
        database.execute(
            "CREATE TABLE IF NOT EXISTS claim_audits ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "exchange_id INTEGER NOT NULL, "
            "audited_at TEXT NOT NULL, "
            "reviewer TEXT NOT NULL, "
            "decision TEXT NOT NULL CHECK(decision IN ('accepted', 'pruned')), "
            "reason TEXT NOT NULL, "
            "reply_sha256 TEXT NOT NULL, "
            "review_sha256 TEXT NOT NULL, "
            "FOREIGN KEY(exchange_id) REFERENCES exchanges(id)"
            ")"
        )


def exchange_state(body: Path, exchange_id: int) -> dict[str, Any]:
    with sqlite3.connect(f"file:{body}?mode=ro", uri=True) as database:
        row = database.execute(
            "SELECT id, you, i, delta, kept, quarantined, speaker, "
            "COALESCE(soul_leak, 0), COALESCE(voice_leak, 0) "
            "FROM exchanges WHERE id = ?",
            (exchange_id,),
        ).fetchone()
    if row is None:
        raise RuntimeError(f"clone exchange #{exchange_id} does not exist")
    return {
        "id": int(row[0]),
        "prompt": str(row[1]),
        "reply": str(row[2] or ""),
        "delta": None if row[3] is None else float(row[3]),
        "kept": bool(row[4]),
        "quarantined": bool(row[5]),
        "speaker": str(row[6]),
        "soul_leak": bool(row[7]),
        "voice_leak": bool(row[8]),
    }


def quarantine_exchange(body: Path, exchange_id: int) -> None:
    """Withhold an unchecked row immediately; only the private clone is passed here."""
    with sqlite3.connect(body) as database:
        changed = database.execute(
            "UPDATE exchanges SET quarantined = 1 WHERE id = ?", (exchange_id,)
        ).rowcount
    if changed != 1:
        raise RuntimeError(f"could not quarantine clone exchange #{exchange_id}")


def _tmux(*arguments: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["tmux", *arguments],
        capture_output=True,
        text=True,
        check=check,
    )


def _pane_alive(target: str) -> bool:
    result = _tmux("display-message", "-p", "-t", target, "#{pane_dead}", check=False)
    return result.returncode == 0 and result.stdout.strip() == "0"


def _capture(target: str) -> str:
    result = _tmux("capture-pane", "-p", "-t", target, "-S", "-80", check=False)
    return result.stdout if result.returncode == 0 else ""


def _chair_command(metadata: dict[str, Any]) -> str:
    environment = {
        "FISH_HOME": str(metadata["clone_home"]),
        "FISH_WATER_LAB": str(metadata["clone_home"]),
        "FISH_BRIDGE": str(metadata["clone_bridge"]),
        "FISH_SPEAKER": str(metadata["speaker"]),
        "FISH_WATER_URL": str(metadata["water_url"]),
        "FISH_WATER_SEED": "1",
        "FISH_WATER_LORA_SCALE": "1",
        "FISH_MAX_REPLY_TOKENS": "768",
        "FISH_WATER_PATIENCE_SECS": "180",
        "FISH_MIRROR": "on",
        "FISH_FIN": "off",
        "FISH_OCEAN": "off",
        "FISH_DEBUG": "1",
    }
    return shlex.join(
        [
            "env",
            *(f"{key}={value}" for key, value in environment.items()),
            str(metadata["binary"]),
        ]
    )


def _start_chair(session: str, command: str, speaker: str) -> str:
    if _tmux("has-session", "-t", session, check=False).returncode == 0:
        raise RuntimeError(f"tmux session already exists: {session}")
    result = _tmux(
        "new-session",
        "-d",
        "-P",
        "-F",
        "#{pane_id}",
        "-s",
        session,
        "-n",
        "claude-fish",
        "-c",
        str(ROOT),
        command,
    )
    target = result.stdout.strip()
    if not target:
        raise RuntimeError("tmux did not return the private Claude pane")
    _tmux("set-option", "-w", "-t", target, "remain-on-exit", "on")
    _tmux("select-pane", "-t", target, "-T", speaker)
    _wait_ready(target)
    return target


def _wait_ready(target: str, timeout: float = READY_TIMEOUT_SECONDS) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not _pane_alive(target):
            raise RuntimeError(f"private Claude chair exited: {target}")
        visible = [line.strip() for line in _capture(target).splitlines() if line.strip()]
        if visible and visible[-1] == "you ▸":
            return
        time.sleep(POLL_SECONDS)
    raise TimeoutError(f"private Claude chair did not become ready: {target}")


def _state(room: Path) -> dict[str, Any]:
    loaded = json.loads((room / "state.json").read_text())
    if not isinstance(loaded, dict):
        raise RuntimeError("claim conversation state must be an object")
    return loaded


def _metadata(room: Path) -> dict[str, Any]:
    loaded = json.loads((room / "conversation.json").read_text())
    if not isinstance(loaded, dict) or loaded.get("mode") != "manual-claude":
        raise RuntimeError("not a manual Claude claim room")
    return loaded


def _assert_checker_unchanged(metadata: dict[str, Any]) -> None:
    checker = Path(str(metadata["checker"]))
    if sha256(checker) != metadata["checker_sha256"]:
        raise RuntimeError("SAFETY STOP: the pinned claim checker changed")


def _assert_living_unchanged(metadata: dict[str, Any]) -> None:
    living = Path(str(metadata["living_body"]))
    if sha256(living) != metadata["living_sha256"]:
        raise RuntimeError("SAFETY STOP: the living body hash changed")


def _nightshift(metadata: dict[str, Any], action: str, exchange_id: int) -> int:
    if action not in {"hold", "release", "prune"}:
        raise ValueError(f"unsupported private night-shift action: {action}")
    environment = os.environ.copy()
    environment.update(
        {
            "FISH_HOME": str(metadata["clone_home"]),
            "FISH_BRIDGE": str(metadata["clone_bridge"]),
        }
    )
    result = subprocess.run(
        [
            sys.executable,
            str(ROOT / "fish/lab/nightshift.py"),
            action,
            str(exchange_id),
        ],
        cwd=ROOT,
        env=environment,
        capture_output=True,
        text=True,
        timeout=60,
        check=False,
    )
    if result.returncode != 0:
        detail = result.stderr.strip() or result.stdout.strip() or "no diagnostic"
        raise RuntimeError(f"private night-shift {action} failed: {detail}")
    match = re.search(r"\b(\d+)\b", result.stdout)
    return int(match.group(1)) if match else 0


def _last_exchange(body: Path, speaker: str) -> int:
    with sqlite3.connect(f"file:{body}?mode=ro", uri=True) as database:
        row = database.execute(
            "SELECT COALESCE(MAX(id), 0) FROM exchanges WHERE speaker = ?",
            (speaker,),
        ).fetchone()
    return int(row[0]) if row else 0


def _next_exchange(body: Path, speaker: str, after_id: int) -> tuple[int, str, str] | None:
    with sqlite3.connect(f"file:{body}?mode=ro", uri=True) as database:
        row = database.execute(
            "SELECT id, you, i FROM exchanges WHERE speaker = ? AND id > ? ORDER BY id LIMIT 1",
            (speaker, after_id),
        ).fetchone()
    if row is None:
        return None
    return int(row[0]), str(row[1]), str(row[2] or "")


def snapshot_spec(room: Path, source: Path, checker_sha: str) -> tuple[dict[str, Any], Path]:
    value = load_bounded_json(source)
    digest = verify_spec(value, checker_sha)
    destination = room / "specs" / f"{digest}.json"
    if destination.exists():
        existing = load_bounded_json(destination)
        if existing != value:
            raise RuntimeError("a different target already uses this spec hash")
    else:
        atomic_json(destination, value)
    return value, destination


def _set_quarantine(body: Path, exchange_id: int, quarantined: bool) -> None:
    with sqlite3.connect(body) as database:
        changed = database.execute(
            "UPDATE exchanges SET quarantined = ? WHERE id = ?",
            (int(quarantined), exchange_id),
        ).rowcount
    if changed != 1:
        raise RuntimeError(f"could not update clone exchange #{exchange_id}")


def finalize_prior_reviews(
    room: Path, metadata: dict[str, Any], after_id: int
) -> list[dict[str, Any]]:
    """Reapply the checked disposition after the daemon's one-turn-late grade."""
    body = Path(str(metadata["clone_body"]))
    with sqlite3.connect(f"file:{body}?mode=ro", uri=True) as database:
        pending = database.execute(
            "SELECT exchange_id, disposition FROM claim_reviews "
            "WHERE finalized_after_grade = 0 AND exchange_id < ? ORDER BY exchange_id",
            (after_id,),
        ).fetchall()
    results: list[dict[str, Any]] = []
    for raw_id, raw_disposition in pending:
        exchange_id = int(raw_id)
        disposition = str(raw_disposition)
        before = exchange_state(body, exchange_id)
        with sqlite3.connect(f"file:{body}?mode=ro", uri=True) as database:
            audit = database.execute(
                "SELECT decision FROM claim_audits WHERE exchange_id = ? ORDER BY id DESC LIMIT 1",
                (exchange_id,),
            ).fetchone()
        if audit is not None and audit[0] == "pruned":
            _nightshift(metadata, "prune", exchange_id)
            final_state = "keeper_pruned_after_audit"
        elif disposition == "pruned":
            _nightshift(metadata, "prune", exchange_id)
            final_state = "pruned_after_grade"
        elif disposition == "held":
            _set_quarantine(body, exchange_id, True)
            _nightshift(metadata, "hold", exchange_id)
            final_state = "held_after_grade"
        elif disposition == "eligible":
            if audit is None or audit[0] != "accepted":
                raise RuntimeError(
                    f"checked success #{exchange_id} lacks Claude's final acceptance"
                )
            if before["kept"] and (before["soul_leak"] or before["voice_leak"]):
                _set_quarantine(body, exchange_id, True)
                final_state = "held_sealed_voice"
            elif before["kept"]:
                _nightshift(metadata, "release", exchange_id)
                final_state = "released_checked_keep"
            else:
                _set_quarantine(body, exchange_id, False)
                final_state = (
                    "checked_but_ungraded" if before["delta"] is None else "checked_sigma_not_kept"
                )
        else:  # a corrupt private review must stop before another word is sent
            raise RuntimeError(f"unknown stored disposition for #{exchange_id}: {disposition}")
        after = exchange_state(body, exchange_id)
        if (disposition == "pruned" or final_state == "keeper_pruned_after_audit") and (
            after["kept"] or not after["quarantined"]
        ):
            raise RuntimeError(f"private prune did not seal exchange #{exchange_id}")
        if disposition == "held" and not after["quarantined"]:
            raise RuntimeError(f"private hold did not seal exchange #{exchange_id}")
        if (
            disposition == "eligible"
            and after["kept"]
            and after["quarantined"]
            and final_state != "held_sealed_voice"
        ):
            raise RuntimeError(f"checked keep #{exchange_id} remained quarantined")
        finalized_at = utc_now()
        with sqlite3.connect(body) as database:
            changed = database.execute(
                "UPDATE claim_reviews SET finalized_after_grade = 1, finalized_at = ?, "
                "final_state = ? WHERE exchange_id = ? AND finalized_after_grade = 0",
                (finalized_at, final_state, exchange_id),
            ).rowcount
        if changed != 1:
            raise RuntimeError(f"private review #{exchange_id} was finalized concurrently")
        result = {
            "type": "review_finalized",
            "at": finalized_at,
            "exchange_id": exchange_id,
            "disposition": disposition,
            "delta": after["delta"],
            "kept": after["kept"],
            "quarantined": after["quarantined"],
            "final_state": final_state,
        }
        append_jsonl(room / "turns.jsonl", result)
        append_role(
            room / "room.log",
            "ruler",
            f"Clone memory finalized #{exchange_id}: {final_state.replace('_', ' ')}.",
        )
        results.append(result)
    return results


def initialize(
    room: Path,
    source_body: Path,
    living_body: Path,
    coat: Path,
    water_url: str,
    session: str,
    pointer: Path,
    binary: Path,
    checker: Path,
) -> dict[str, Any]:
    if not SESSION.fullmatch(session):
        raise ValueError("invalid tmux session name")
    room = room.resolve()
    room.mkdir(parents=True, exist_ok=True)
    if (room / "conversation.json").exists():
        raise FileExistsError(f"claim conversation already initialized: {room}")
    living_sha = sha256(living_body)
    source_sha = sha256(source_body)
    if source_sha != living_sha:
        raise RuntimeError("the read-only source snapshot does not match the living body")
    home, bridge = prepare_home(room / "body", source_body, coat, ROOT)
    checker = checker.resolve()
    checker_sha = sha256(checker)
    initialize_review_schema(home / "sediment.db")
    (room / "specs").mkdir()
    (room / "replies").mkdir()
    (room / "reviews").mkdir()
    speaker = "claim-claude"
    starting_exchange_id = _last_exchange(home / "sediment.db", speaker)
    chair = {
        "clone_home": str(home),
        "clone_bridge": str(bridge),
        "speaker": speaker,
        "water_url": water_url,
        "binary": str(binary.resolve()),
    }
    target = _start_chair(session, _chair_command(chair), speaker)

    created_at = utc_now()
    metadata: dict[str, Any] = {
        "v": 1,
        "mode": "manual-claude",
        "teacher": "claude",
        "speaker": speaker,
        "created_at": created_at,
        "room": str(room),
        "tmux_session": session,
        "tmux_target": target,
        "clone_home": str(home),
        "clone_bridge": str(bridge),
        "clone_body": str(home / "sediment.db"),
        "living_body": str(living_body.resolve()),
        "living_sha256": living_sha,
        "source_body": str(source_body.resolve()),
        "source_sha256": source_sha,
        "coat": str(coat.resolve()),
        "water_url": water_url,
        "binary": str(binary.resolve()),
        "checker": str(checker),
        "checker_sha256": checker_sha,
        "starting_exchange_id": starting_exchange_id,
        "window_index": 1,
        "chair_history": [
            {"window": 1, "session": session, "target": target, "opened_at": created_at}
        ],
    }
    atomic_json(room / "conversation.json", metadata)
    state = {
        "v": 1,
        "room": "claude-claim-conversation",
        "title": "Claude ↔ Fish · manual formal-language conversation",
        "phase": "ready",
        "created_at": created_at,
        "updated_at": created_at,
        "teacher": "claude",
        "metrics": {
            "turns": 0,
            "messages": 0,
            "reviewed": 0,
            "eligible": 0,
            "pruned": 0,
            "held": 0,
        },
        "inference": None,
        "pending_exchange_id": None,
        "pending_spec_sha256": None,
    }
    atomic_json(room / "state.json", state)
    atomic_json(pointer, {"run": str(room), "updated_at": created_at, "mode": "manual-claude"})
    log = room / "room.log"
    with log.open("a", encoding="utf-8") as stream:
        stream.write(f"{created_at}  CLASSROOM 00 · Claude ↔ Fish · manual private conversation\n")
    append_role(
        log,
        "lesson",
        "Claude is the sole teacher. Each message is authored after reading the Fish's "
        "prior reply; no prompt list or automatic loop is running.",
    )
    return metadata


def send_turn(
    room: Path,
    message: str,
    spec_path: Path,
    timeout: float = TURN_TIMEOUT_SECONDS,
    *,
    _lock_held: bool = False,
) -> dict[str, Any]:
    message = validate_message(message)
    room = room.resolve()
    lock_context = (
        nullcontext()
        if _lock_held
        else turn_lock(room, error_message="another manual turn is still active")
    )
    with lock_context:
        metadata = _metadata(room)
        log = room / "room.log"
        _assert_living_unchanged(metadata)
        _assert_checker_unchanged(metadata)
        state = _state(room)
        if state.get("phase") != "ready" or state.get("pending_exchange_id") is not None:
            raise RuntimeError("the prior Fish reply must receive its ruler verdict first")
        target_spec, spec_snapshot = snapshot_spec(
            room, spec_path.resolve(), str(metadata["checker_sha256"])
        )
        spec_sha = str(target_spec["spec_sha256"])
        declared_at = utc_now()
        append_jsonl(
            room / "turns.jsonl",
            {
                "type": "target_declared",
                "at": declared_at,
                "teacher": "claude",
                "message_sha256": sha256_text(message),
                "spec_sha256": spec_sha,
                "spec": str(spec_snapshot),
            },
        )
        target = str(metadata["tmux_target"])
        if not _pane_alive(target):
            raise RuntimeError("the private Claude chair is not alive")
        _wait_ready(target)
        body = Path(str(metadata["clone_body"]))
        speaker = str(metadata["speaker"])
        before = _last_exchange(body, speaker)
        append_role(log, "teacher", message)
        state["phase"] = "fish_turn"
        state["inference"] = {
            "status": "decoding",
            "started_at": utc_now(),
            "spec_sha256": spec_sha,
        }
        state["updated_at"] = utc_now()
        atomic_json(room / "state.json", state)
        _tmux("send-keys", "-t", target, "-l", message)
        _tmux("send-keys", "-t", target, "Enter")
        deadline = time.monotonic() + timeout
        exchange = None
        while time.monotonic() < deadline:
            exchange = _next_exchange(body, speaker, before)
            if exchange is not None:
                break
            if not _pane_alive(target):
                raise RuntimeError("the private Claude chair exited during inference")
            time.sleep(POLL_SECONDS)
        if exchange is None:
            append_role(
                log, "classroom error", "Fish reply timed out; no automatic retry was sent."
            )
            raise TimeoutError("Fish reply timed out")
        exchange_id, recorded_prompt, reply = exchange
        _wait_ready(target, max(1.0, deadline - time.monotonic()))
        quarantine_exchange(body, exchange_id)
        reply_path = room / "replies" / f"{exchange_id}.txt"
        reply_path.write_text(reply, encoding="utf-8")
        reply_sha = sha256_text(reply)
        append_jsonl(
            room / "turns.jsonl",
            {
                "type": "exchange",
                "at": utc_now(),
                "exchange_id": exchange_id,
                "teacher": "claude",
                "prompt": message,
                "prompt_sha256": sha256_text(message),
                "reply": reply,
                "reply_sha256": reply_sha,
                "spec_sha256": spec_sha,
                "spec": str(spec_snapshot),
            },
        )
        if recorded_prompt != message:
            append_role(
                log,
                "classroom error",
                "The recorded prompt differed from Claude's message; the reply is quarantined.",
            )
        append_role(log, "fish", reply or "(reply withheld)")
        finalized = finalize_prior_reviews(room, metadata, exchange_id)
        _assert_living_unchanged(metadata)
        state = _state(room)
        state["phase"] = "awaiting_ruler"
        state["inference"] = None
        state["updated_at"] = utc_now()
        state["metrics"]["turns"] = int(state["metrics"].get("turns", 0)) + 1
        state["metrics"]["messages"] = int(state["metrics"].get("messages", 0)) + 2
        state["last_exchange_id"] = exchange_id
        state["pending_exchange_id"] = exchange_id
        state["pending_spec_sha256"] = spec_sha
        state["pending_reply_sha256"] = reply_sha
        atomic_json(room / "state.json", state)
        if recorded_prompt != message:
            raise RuntimeError("the recorded prompt differs from the manual message")
        return {
            "room": str(room),
            "teacher": "claude",
            "exchange_id": exchange_id,
            "prompt": message,
            "reply": reply,
            "reply_sha256": reply_sha,
            "reply_file": str(reply_path),
            "spec_sha256": spec_sha,
            "spec_file": str(spec_snapshot),
            "finalized_prior_reviews": finalized,
        }


def _run_checker(
    metadata: dict[str, Any], reply_path: Path, spec_path: Path, exchange_id: int
) -> dict[str, Any]:
    returncode, stdout, stderr = run_bounded_process(
        [
            sys.executable,
            str(metadata["checker"]),
            "check",
            "--reply",
            str(reply_path),
            "--spec",
            str(spec_path),
            "--exchange",
            str(exchange_id),
            "--json",
        ],
        cwd=ROOT,
        timeout=180,
    )
    if returncode != 0:
        detail = stderr.strip() or stdout.strip() or "no diagnostic"
        raise RuntimeError(f"pinned claim checker failed: {detail}")
    try:
        record = json.loads(stdout)
    except json.JSONDecodeError as error:
        raise RuntimeError("pinned claim checker did not return one JSON object") from error
    if not isinstance(record, dict):
        raise RuntimeError("pinned claim checker verdict must be an object")
    return record


def apply_ruler(room: Path) -> dict[str, Any]:
    """Run the pinned checker once, then enforce its verdict on the private clone."""
    room = room.resolve()
    metadata = _metadata(room)
    lock_path = room / "turn.lock"
    with lock_path.open("a+") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise RuntimeError("another manual turn or ruler check is still active") from error
        _assert_living_unchanged(metadata)
        _assert_checker_unchanged(metadata)
        state = _state(room)
        if state.get("phase") != "awaiting_ruler":
            raise RuntimeError("there is no unchecked Fish reply awaiting the ruler")
        exchange_id = state.get("pending_exchange_id")
        spec_sha = state.get("pending_spec_sha256")
        reply_sha = state.get("pending_reply_sha256")
        if not isinstance(exchange_id, int) or not isinstance(spec_sha, str):
            raise RuntimeError("the pending ruler state is incomplete")
        body = Path(str(metadata["clone_body"]))
        initialize_review_schema(body)
        row = exchange_state(body, exchange_id)
        if row["speaker"] != metadata["speaker"]:
            raise RuntimeError("pending exchange belongs to a different speaker")
        actual_reply_sha = sha256_text(str(row["reply"]))
        if reply_sha != actual_reply_sha:
            raise RuntimeError("pending Fish reply no longer matches its recorded hash")
        reply_path = room / "replies" / f"{exchange_id}.txt"
        spec_path = room / "specs" / f"{spec_sha}.json"
        if sha256_text(reply_path.read_text(encoding="utf-8")) != actual_reply_sha:
            raise RuntimeError("the saved Fish reply differs from the clone")
        target = load_bounded_json(spec_path)
        if verify_spec(target, str(metadata["checker_sha256"])) != spec_sha:
            raise RuntimeError("pending target spec no longer matches its hash")
        record = _run_checker(metadata, reply_path, spec_path, exchange_id)
        verdict = record.get("verdict")
        disposition = record.get("disposition")
        if not isinstance(verdict, str) or verdict not in DISPOSITIONS:
            raise RuntimeError(f"pinned checker returned an unknown verdict: {verdict!r}")
        if disposition != DISPOSITIONS[verdict]:
            raise RuntimeError("pinned checker returned the wrong disposition for its verdict")
        if record.get("exchange_id") != exchange_id:
            raise RuntimeError("pinned checker verdict names a different exchange")
        if record.get("spec_sha256") != spec_sha:
            raise RuntimeError("pinned checker verdict names a different target spec")
        if record.get("checker_sha256") != metadata["checker_sha256"]:
            raise RuntimeError("pinned checker verdict reports a different checker hash")
        wording = record.get("text")
        if not isinstance(wording, str) or not wording.strip() or len(wording) > MAX_MESSAGE_CHARS:
            raise RuntimeError("pinned checker returned invalid ruler wording")

        if disposition == "pruned":
            _nightshift(metadata, "prune", exchange_id)
            action_text = f"Pruned #{exchange_id} from the private clone's memory."
        elif disposition == "held":
            _set_quarantine(body, exchange_id, True)
            _nightshift(metadata, "hold", exchange_id)
            action_text = f"Held #{exchange_id} apart in the private clone for keeper review."
        else:
            _set_quarantine(body, exchange_id, True)
            action_text = (
                f"Machine-checked #{exchange_id} is provisionally eligible; it remains held "
                "until Claude's final clean-room audit, then the next turn's one-turn-late "
                "σ grade."
            )
        reviewed_at = utc_now()
        audited = {**record, "reply_sha256": actual_reply_sha, "reviewed_at": reviewed_at}
        encoded = json.dumps(audited, sort_keys=True, ensure_ascii=False)
        with sqlite3.connect(body) as database:
            try:
                database.execute(
                    "INSERT INTO claim_reviews "
                    "(exchange_id, reviewed_at, checker, checker_sha256, spec_sha256, "
                    "reply_sha256, verdict, disposition, record_json) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        exchange_id,
                        reviewed_at,
                        str(record.get("checker", "pinned claim checker")),
                        str(metadata["checker_sha256"]),
                        spec_sha,
                        actual_reply_sha,
                        verdict,
                        disposition,
                        encoded,
                    ),
                )
            except sqlite3.IntegrityError as error:
                raise RuntimeError(
                    f"exchange #{exchange_id} already has its one verdict"
                ) from error
        atomic_json(room / "reviews" / f"{exchange_id}.json", audited)
        append_jsonl(
            room / "turns.jsonl",
            {
                "type": "review",
                "at": reviewed_at,
                "exchange_id": exchange_id,
                "reply_sha256": actual_reply_sha,
                "spec_sha256": spec_sha,
                "checker_sha256": str(metadata["checker_sha256"]),
                "verdict": verdict,
                "disposition": disposition,
                "record": audited,
            },
        )
        append_role(room / "room.log", "ruler", wording)
        append_role(room / "room.log", "ruler", action_text)
        state["phase"] = "awaiting_audit" if disposition == "eligible" else "ready"
        state["updated_at"] = reviewed_at
        state["pending_exchange_id"] = None
        state["pending_spec_sha256"] = None
        state["pending_reply_sha256"] = None
        state["pending_audit_exchange_id"] = exchange_id if disposition == "eligible" else None
        state["last_verdict"] = verdict
        state["last_disposition"] = disposition
        state["metrics"]["reviewed"] = int(state["metrics"].get("reviewed", 0)) + 1
        state["metrics"][disposition] = int(state["metrics"].get(disposition, 0)) + 1
        atomic_json(room / "state.json", state)
        _assert_living_unchanged(metadata)
        return audited


def _claim_audit(
    body: Path,
    exchange_id: int,
    decision: str,
    reason: str,
    reply_sha256: str,
    review_json: str,
    *,
    reconsidered: bool = False,
) -> dict[str, Any]:
    audited_at = utc_now()
    event = {
        "type": f"claude_audit_{decision}",
        "at": audited_at,
        "exchange_id": exchange_id,
        "reviewer": "claude",
        "decision": decision,
        "reason": reason,
        "reply_sha256": reply_sha256,
        "review_sha256": sha256_text(review_json),
    }
    if reconsidered:
        if decision != "accepted":
            raise RuntimeError("only an accepted audit can correct a false veto")
        event["reconsidered"] = True
    with sqlite3.connect(body) as database:
        database.execute(
            "INSERT INTO claim_audits "
            "(exchange_id, audited_at, reviewer, decision, reason, reply_sha256, "
            "review_sha256) VALUES (?, ?, 'claude', ?, ?, ?, ?)",
            (
                exchange_id,
                audited_at,
                decision,
                reason,
                reply_sha256,
                event["review_sha256"],
            ),
        )
        if reconsidered:
            changed = database.execute(
                "UPDATE claim_reviews SET final_state = 'audit_reaccepted_pending_grade', "
                "finalized_at = NULL WHERE exchange_id = ? AND finalized_after_grade = 0 "
                "AND final_state = 'audit_pruned_pending_grade'",
                (exchange_id,),
            ).rowcount
            if changed != 1:
                raise RuntimeError(f"false-veto correction lost pending review #{exchange_id}")
    return event


def _assert_required_conjunct_boundary(
    room: Path,
    metadata: dict[str, Any],
    record: dict[str, Any],
    line: str,
) -> None:
    """Require exactly one checked conjunct for every predeclared required fact."""
    spec_sha = record.get("spec_sha256")
    if not isinstance(spec_sha, str) or not re.fullmatch(r"[0-9a-f]{64}", spec_sha):
        raise RuntimeError("clean-room veto: the ruler record has no valid target spec")
    target = load_bounded_json(room / "specs" / f"{spec_sha}.json")
    if verify_spec(target, str(metadata["checker_sha256"])) != spec_sha:
        raise RuntimeError("clean-room veto: the audited target spec no longer matches")
    required = target["required"]
    established = record.get("established")
    if not isinstance(established, dict) or set(established) != set(required):
        raise RuntimeError(
            "clean-room veto: the ruler did not establish exactly the required facts"
        )
    # The pinned parser treats whitespace between formal tokens as insignificant.
    # Compare the same language here while retaining the exact conjunct count, so
    # harmless spaces cannot become a Claude veto and extra true claims still can.
    conjuncts = [re.sub(r"\s+", "", part) for part in line.split("&&") if part.strip()]
    checked = [re.sub(r"\s+", "", str(established[name])) for name in required]
    if Counter(conjuncts) != Counter(checked):
        raise RuntimeError(
            "clean-room veto: the reply must contain exactly one checked conjunct per required fact"
        )


def audit_accept(room: Path, exchange_id: int, reason: str) -> dict[str, Any]:
    """Let Claude accept only a machine-proved, entirely formal reply."""
    room = room.resolve()
    reason = validate_audit_reason(reason)
    metadata = _metadata(room)
    with (room / "turn.lock").open("a+") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise RuntimeError("another manual turn or ruler check is still active") from error
        state = _state(room)
        ordinary_audit = (
            state.get("phase") == "awaiting_audit"
            and state.get("pending_audit_exchange_id") == exchange_id
        )
        possible_reconsideration = (
            state.get("phase") == "ready"
            and state.get("pending_exchange_id") is None
            and state.get("pending_audit_exchange_id") is None
        )
        if not ordinary_audit and not possible_reconsideration:
            raise RuntimeError("there is no matching machine-proved reply awaiting audit")
        _assert_living_unchanged(metadata)
        _assert_checker_unchanged(metadata)
        body = Path(str(metadata["clone_body"]))
        initialize_review_schema(body)
        with sqlite3.connect(f"file:{body}?mode=ro", uri=True) as database:
            review = database.execute(
                "SELECT verdict, disposition, spec_sha256, reply_sha256, record_json, "
                "finalized_after_grade, final_state "
                "FROM claim_reviews "
                "WHERE exchange_id = ?",
                (exchange_id,),
            ).fetchone()
            latest_audit = database.execute(
                "SELECT decision FROM claim_audits WHERE exchange_id = ? ORDER BY id DESC LIMIT 1",
                (exchange_id,),
            ).fetchone()
        if review is None or review[0:2] != ("proved", "eligible"):
            raise RuntimeError(f"exchange #{exchange_id} is not machine-proved")
        reconsidering = possible_reconsideration and (
            not bool(review[5])
            and review[6] == "audit_pruned_pending_grade"
            and latest_audit is not None
            and latest_audit[0] == "pruned"
        )
        if possible_reconsideration and not reconsidering:
            raise RuntimeError("there is no matching false veto awaiting reconsideration")
        record = json.loads(str(review[4]))
        if record.get("spec_sha256") != str(review[2]):
            raise RuntimeError("clean-room veto: the ruler record names another target spec")
        line = record.get("line")
        exchange = exchange_state(body, exchange_id)
        reply = str(exchange["reply"])
        if not isinstance(line, str) or not line or reply != line:
            raise RuntimeError(
                "clean-room veto: the entire Fish reply is not exactly its checked formal line"
            )
        _assert_required_conjunct_boundary(room, metadata, record, line)
        if sha256_text(reply) != str(review[3]):
            raise RuntimeError("the audited Fish reply no longer matches the ruler record")
        event = _claim_audit(
            body,
            exchange_id,
            "accepted",
            reason,
            str(review[3]),
            str(review[4]),
            reconsidered=reconsidering,
        )
        append_jsonl(room / "turns.jsonl", event)
        append_role(
            room / "room.log",
            "ruler",
            f"Claude clean-room audit "
            f"{'corrected a false veto and accepted' if reconsidering else 'accepted'} "
            f"#{exchange_id}: {reason}",
        )
        state["phase"] = "ready"
        state["pending_audit_exchange_id"] = None
        state["updated_at"] = event["at"]
        state["metrics"]["audit_accepted"] = int(state["metrics"].get("audit_accepted", 0)) + 1
        atomic_json(room / "state.json", state)
        _assert_living_unchanged(metadata)
        return event


def restart_chair(room: Path, *, _lock_held: bool = False) -> dict[str, Any]:
    """Rotate only the transient conversation window, preserving the private body."""
    room = room.resolve()
    lock_context = nullcontext() if _lock_held else turn_lock(room)
    with lock_context:
        metadata = _metadata(room)
        state = _state(room)
        if state.get("phase") != "ready" or state.get("pending_exchange_id") is not None:
            raise RuntimeError("cannot rotate the chair with a running or unchecked reply")
        _assert_living_unchanged(metadata)
        _assert_checker_unchanged(metadata)
        old_session = str(metadata["tmux_session"])
        old_target = str(metadata["tmux_target"])
        _tmux("kill-session", "-t", old_session, check=False)
        window = int(metadata.get("window_index", 1)) + 1
        stem = re.sub(r"-w\d+$", "", old_session)
        session = f"{stem}-w{window}"
        if not SESSION.fullmatch(session):
            raise RuntimeError("rotated tmux session name is invalid")
        target = _start_chair(
            session,
            _chair_command(metadata),
            str(metadata["speaker"]),
        )
        opened_at = utc_now()
        history = metadata.get("chair_history")
        if not isinstance(history, list):
            history = [
                {
                    "window": window - 1,
                    "session": old_session,
                    "target": old_target,
                    "opened_at": metadata.get("created_at"),
                }
            ]
        history.append(
            {"window": window, "session": session, "target": target, "opened_at": opened_at}
        )
        metadata["window_index"] = window
        metadata["tmux_session"] = session
        metadata["tmux_target"] = target
        metadata["chair_history"] = history
        atomic_json(room / "conversation.json", metadata)
        state["updated_at"] = opened_at
        state["window_index"] = window
        atomic_json(room / "state.json", state)
        event = {
            "type": "chair_rotated",
            "at": opened_at,
            "window": window,
            "old_session": old_session,
            "session": session,
            "target": target,
        }
        append_jsonl(room / "turns.jsonl", event)
        append_role(
            room / "room.log",
            "lesson",
            f"Conversation window {window} opened on the same private clone; no body, "
            "checker, water, or coat was reset.",
        )
        _assert_living_unchanged(metadata)
        return event


def audit_prune(room: Path, exchange_id: int, reason: str) -> dict[str, Any]:
    """Seal a reviewed false-positive from the private clone and record why."""
    room = room.resolve()
    reason = validate_audit_reason(reason)
    metadata = _metadata(room)
    with (room / "turn.lock").open("a+") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise RuntimeError("another manual turn or ruler check is still active") from error
        state = _state(room)
        phase = state.get("phase")
        if phase not in {"ready", "awaiting_audit"} or state.get("pending_exchange_id") is not None:
            raise RuntimeError("cannot audit-prune a running or unchecked reply")
        if phase == "awaiting_audit" and state.get("pending_audit_exchange_id") != exchange_id:
            raise RuntimeError("a different machine-proved reply is awaiting audit")
        _assert_living_unchanged(metadata)
        _assert_checker_unchanged(metadata)
        body = Path(str(metadata["clone_body"]))
        initialize_review_schema(body)
        with sqlite3.connect(f"file:{body}?mode=ro", uri=True) as database:
            review = database.execute(
                "SELECT verdict, disposition, final_state, finalized_after_grade "
                "FROM claim_reviews WHERE exchange_id = ?",
                (exchange_id,),
            ).fetchone()
        if review is None:
            raise RuntimeError(f"exchange #{exchange_id} has no pinned ruler review")
        if review[2] in {"audit_pruned_pending_grade", "keeper_pruned_after_audit"}:
            raise RuntimeError(f"exchange #{exchange_id} was already audit-pruned")
        before = exchange_state(body, exchange_id)
        _nightshift(metadata, "prune", exchange_id)
        after = exchange_state(body, exchange_id)
        if after["kept"] or not after["quarantined"]:
            raise RuntimeError(f"private audit prune did not seal exchange #{exchange_id}")
        review_json = ""
        with sqlite3.connect(body) as database:
            stored = database.execute(
                "SELECT reply_sha256, record_json FROM claim_reviews WHERE exchange_id = ?",
                (exchange_id,),
            ).fetchone()
            if stored is None:
                raise RuntimeError(f"exchange #{exchange_id} lost its ruler record")
            review_json = str(stored[1])
            audited_at = utc_now()
            finalized_after_grade = int(bool(review[3]))
            finalized_at = audited_at if finalized_after_grade else None
            final_state = (
                "keeper_pruned_after_audit"
                if finalized_after_grade
                else "audit_pruned_pending_grade"
            )
            changed = database.execute(
                "UPDATE claim_reviews SET finalized_after_grade = ?, finalized_at = ?, "
                "final_state = ? WHERE exchange_id = ?",
                (finalized_after_grade, finalized_at, final_state, exchange_id),
            ).rowcount
        if changed != 1:
            raise RuntimeError(f"private audit record #{exchange_id} was not updated")
        event = _claim_audit(
            body,
            exchange_id,
            "pruned",
            reason,
            sha256_text(str(after["reply"])),
            review_json,
        )
        event.update(
            checker_verdict=str(review[0]),
            checker_disposition=str(review[1]),
            before={"kept": before["kept"], "quarantined": before["quarantined"]},
            after={"kept": after["kept"], "quarantined": after["quarantined"]},
        )
        append_jsonl(room / "turns.jsonl", event)
        append_role(
            room / "room.log",
            "ruler",
            f"Claude clean-room audit pruned #{exchange_id}: {reason}",
        )
        state["phase"] = "ready"
        state["pending_audit_exchange_id"] = None
        state["updated_at"] = audited_at
        state["metrics"]["audit_pruned"] = int(state["metrics"].get("audit_pruned", 0)) + 1
        atomic_json(room / "state.json", state)
        _assert_living_unchanged(metadata)
        return event


def room_summary(room: Path, metadata: dict[str, Any]) -> dict[str, Any]:
    body = Path(str(metadata["clone_body"]))
    with sqlite3.connect(f"file:{body}?mode=ro", uri=True) as database:
        has_reviews = database.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='claim_reviews'"
        ).fetchone()
        if has_reviews:
            reviews = database.execute(
                "SELECT exchange_id, verdict, disposition, finalized_after_grade, final_state "
                "FROM claim_reviews ORDER BY exchange_id"
            ).fetchall()
            dreamable = [
                int(row[0])
                for row in database.execute(
                    "SELECT e.id FROM exchanges e JOIN claim_reviews r ON r.exchange_id=e.id "
                    "WHERE e.kept=1 AND e.quarantined=0 ORDER BY e.id"
                ).fetchall()
            ]
        else:  # compatibility for the silent pre-contract room
            reviews, dreamable = [], []
    verdicts = Counter(str(row[1]) for row in reviews)
    dispositions = Counter(str(row[2]) for row in reviews)
    final_states = Counter(str(row[4]) for row in reviews if row[4] is not None)
    return {
        "v": 1,
        "room": str(room),
        "closed_at": utc_now(),
        "turns": len(reviews),
        "verdicts": dict(sorted(verdicts.items())),
        "dispositions": dict(sorted(dispositions.items())),
        "sigma_outcomes": dict(sorted(final_states.items())),
        "proved_and_kept": final_states["released_checked_keep"],
        "proved_but_not_kept": final_states["checked_sigma_not_kept"],
        "held_sealed_voice": final_states["held_sealed_voice"],
        "reviewed_exchange_ids": [int(row[0]) for row in reviews],
        "awaiting_one_turn_late_grade": [int(row[0]) for row in reviews if not bool(row[3])],
        "final_states": {str(int(row[0])): row[4] for row in reviews if row[4] is not None},
        "dreamable_exchange_ids": dreamable,
        "living_body": str(metadata["living_body"]),
        "living_sha256_before": str(metadata["living_sha256"]),
        "living_sha256_after": sha256(Path(str(metadata["living_body"]))),
        "promotion_authorized": False,
    }


def close(room: Path) -> dict[str, Any]:
    room = room.resolve()
    metadata = _metadata(room)
    state = _state(room)
    if state.get("phase") in {"fish_turn", "awaiting_ruler"}:
        raise RuntimeError("cannot close while a Fish reply is running or still unchecked")
    session = str(metadata["tmux_session"])
    _tmux("kill-session", "-t", session, check=False)
    _assert_living_unchanged(metadata)
    summary = room_summary(room, metadata)
    atomic_json(room / "summary.json", summary)
    (room / "living-after.sha256").write_text(summary["living_sha256_after"] + "\n")
    state["phase"] = "closed"
    state["inference"] = None
    state["updated_at"] = utc_now()
    atomic_json(room / "state.json", state)
    append_role(
        log=room / "room.log",
        role="lesson",
        text="The keeper closed the private Claude chair. The living body remained byte-identical.",
    )
    append_role(
        log=room / "room.log",
        role="lesson",
        text=(
            f"Sitting summary: {summary['turns']} checked replies; "
            f"{summary['dispositions'].get('eligible', 0)} eligible, "
            f"{summary['dispositions'].get('pruned', 0)} pruned, "
            f"{summary['dispositions'].get('held', 0)} held. "
            f"Proved and kept: {summary['proved_and_kept']}; "
            f"dreamable checked keeps: {len(summary['dreamable_exchange_ids'])}."
        ),
    )
    append_jsonl(room / "turns.jsonl", {"type": "closed", **summary})
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="action", required=True)
    init = subparsers.add_parser("init")
    init.add_argument("--room", type=Path, required=True)
    init.add_argument("--source-body", type=Path, required=True)
    init.add_argument("--living-body", type=Path, required=True)
    init.add_argument("--coat", type=Path, required=True)
    init.add_argument("--water-url", required=True)
    init.add_argument("--session", required=True)
    init.add_argument("--pointer", type=Path, required=True)
    init.add_argument("--binary", type=Path, required=True)
    init.add_argument("--checker", type=Path, required=True)
    turn = subparsers.add_parser("turn")
    turn.add_argument("--room", type=Path, required=True)
    turn.add_argument("--message", required=True)
    turn.add_argument("--spec", type=Path, required=True)
    turn.add_argument("--timeout", type=float, default=TURN_TIMEOUT_SECONDS)
    ruler = subparsers.add_parser("ruler")
    ruler.add_argument("--room", type=Path, required=True)
    restarting = subparsers.add_parser("restart")
    restarting.add_argument("--room", type=Path, required=True)
    auditing = subparsers.add_parser("audit-prune")
    auditing.add_argument("--room", type=Path, required=True)
    auditing.add_argument("--exchange", type=int, required=True)
    auditing.add_argument("--reason", required=True)
    accepting = subparsers.add_parser("audit-accept")
    accepting.add_argument("--room", type=Path, required=True)
    accepting.add_argument("--exchange", type=int, required=True)
    accepting.add_argument("--reason", required=True)
    closing = subparsers.add_parser("close")
    closing.add_argument("--room", type=Path, required=True)
    args = parser.parse_args()

    if args.action == "init":
        result = initialize(
            args.room,
            args.source_body,
            args.living_body,
            args.coat,
            args.water_url,
            args.session,
            args.pointer,
            args.binary,
            args.checker,
        )
        print(json.dumps(result, indent=1))
    elif args.action == "turn":
        print(json.dumps(send_turn(args.room, args.message, args.spec, args.timeout), indent=1))
    elif args.action == "ruler":
        print(json.dumps(apply_ruler(args.room), indent=1))
    elif args.action == "restart":
        print(json.dumps(restart_chair(args.room), indent=1))
    elif args.action == "audit-prune":
        print(json.dumps(audit_prune(args.room, args.exchange, args.reason), indent=1))
    elif args.action == "audit-accept":
        print(json.dumps(audit_accept(args.room, args.exchange, args.reason), indent=1))
    elif args.action == "close":
        print(json.dumps(close(args.room), indent=1))


if __name__ == "__main__":
    main()
