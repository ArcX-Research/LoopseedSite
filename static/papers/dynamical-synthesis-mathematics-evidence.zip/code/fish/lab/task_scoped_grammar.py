"""Generate the v3a task-scoped GBNF from bounded public task data.

The manifest is the shared, versioned generator contract used by Rust at the
water boundary and Python before the turn.  Neither side accepts grammar text.
The generated grammar fixes the required fact envelope, operation arities, and
earlier-only references.  v3a deliberately leaves integer literals unrestricted
so literal-selection errors remain visible to the exact checker.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
from typing import Any

from fish.lab import claim_conversation as conversation
from fish.lab import claim_probe

ROOT = Path(__file__).resolve().parents[2]
MANIFEST = ROOT / "fish/lab/typed_ast_v3a.json"
NAME = "typed_ast_v3a"
NUMBERED_FACT = re.compile(r"R[1-9][0-9]{0,2}")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _manifest() -> dict[str, Any]:
    value = json.loads(MANIFEST.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError("task grammar manifest must be an object")
    return value


def scope_for(target: dict[str, Any]) -> dict[str, Any]:
    """Return only public, checker-bound scope in canonical field order."""
    target = claim_probe.verify_spec(target)
    manifest = _manifest()
    kind = target.get("kind")
    parameters = target.get("parameters")
    if (
        type(kind) is not str
        or not isinstance(parameters, list)
        or any(type(value) is not int for value in parameters)
    ):
        raise ValueError("task grammar target has untyped kind or parameters")
    _validate_parameters(kind, parameters, manifest)
    generated_facts = [
        {"name": name, "expression": expression, "expected": expected}
        for name, expression, expected in claim_probe.facts_for(kind, parameters)
    ]
    if _canonical_json(target.get("facts")) != _canonical_json(generated_facts):
        raise ValueError("task grammar target facts differ from the exact generator")
    generated = [fact["name"] for fact in generated_facts]
    required = target.get("required")
    if not isinstance(required, list) or any(type(name) is not str for name in required):
        raise ValueError("task grammar requires a string required-fact list")
    if required != generated:
        raise ValueError("task grammar requires every exact-generator fact in generator order")
    return {
        "v": 1,
        "kind": kind,
        "parameters": list(parameters),
        "required": list(required),
    }


def _canonical_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def canonical_scope(scope: dict[str, Any]) -> str:
    ordered = {
        "v": scope.get("v"),
        "kind": scope.get("kind"),
        "parameters": scope.get("parameters"),
        "required": scope.get("required"),
    }
    if set(scope) != set(ordered):
        raise ValueError("task grammar scope keys must be exactly v/kind/parameters/required")
    return json.dumps(ordered, ensure_ascii=False, separators=(",", ":"))


def _validate(scope: dict[str, Any], manifest: dict[str, Any]) -> None:
    if manifest.get("v") != 1 or manifest.get("name") != NAME:
        raise RuntimeError("the task grammar manifest has the wrong identity")
    if (
        manifest.get("max_integer") != claim_probe.MAX_TASK_INTEGER
        or manifest.get("max_work") != claim_probe.MAX_TASK_WORK
        or manifest.get("max_crt_search") != claim_probe.MAX_CRT_SEARCH
    ):
        raise RuntimeError("the task grammar manifest differs from the exact task bounds")
    if scope.get("v") != 1:
        raise ValueError("task grammar scope v must be 1")
    parameters = scope.get("parameters")
    kind_name = scope.get("kind")
    if (
        type(kind_name) is not str
        or not isinstance(parameters, list)
        or any(type(value) is not int for value in parameters)
    ):
        raise ValueError("task grammar scope has an invalid parameter count")
    kind = _validate_parameters(kind_name, parameters, manifest)
    required = scope.get("required")
    if (
        not isinstance(required, list)
        or not 1 <= len(required) <= int(manifest["max_facts"])
        or any(type(name) is not str for name in required)
    ):
        raise ValueError("task grammar scope has an invalid fact count")
    allowed = set(manifest.get("fact_names", []))
    if any(name not in allowed and NUMBERED_FACT.fullmatch(name) is None for name in required):
        raise ValueError("task grammar scope names an unknown fact")
    if len(set(required)) != len(required):
        raise ValueError("task grammar scope repeats a fact")
    expected = _required_for_kind(kind_name, parameters, kind["facts"])
    if required != expected:
        raise ValueError("task grammar scope differs from its kind's required facts")
    operations = manifest.get("operations")
    if not isinstance(operations, list) or not operations:
        raise RuntimeError("task grammar manifest has no operations")
    for operation in operations:
        if not isinstance(operation, dict) or set(operation) != {
            "name",
            "min_args",
            "max_args",
        }:
            raise RuntimeError("task grammar manifest has an invalid operation")
        name = operation["name"]
        minimum = operation["min_args"]
        maximum = operation["max_args"]
        if (
            not isinstance(name, str)
            or not name
            or not name.isascii()
            or not name.islower()
            or type(minimum) is not int
            or type(maximum) is not int
            or minimum < 2
            or maximum < minimum
            or maximum > 16
        ):
            raise RuntimeError("task grammar manifest has an invalid operation")


def _validate_parameters(
    kind_name: str, parameters: list[int], manifest: dict[str, Any]
) -> dict[str, Any]:
    kinds = manifest.get("kinds")
    if not isinstance(kinds, dict) or kind_name not in kinds:
        raise ValueError("task grammar scope names an unknown kind")
    if not 1 <= len(parameters) <= int(manifest["max_parameters"]):
        raise ValueError("task grammar scope has an invalid parameter count")
    if any(abs(value) > int(manifest["max_integer"]) for value in parameters):
        raise ValueError("task grammar scope has an oversized parameter")
    kind = kinds[kind_name]
    if (
        not isinstance(kind, dict)
        or set(kind) != {"parameters", "minimums", "maximums", "facts"}
        or type(kind["parameters"]) is not int
        or kind["parameters"] != len(parameters)
        or not isinstance(kind["minimums"], list)
        or not isinstance(kind["maximums"], list)
        or len(kind["minimums"]) != len(parameters)
        or len(kind["maximums"]) != len(parameters)
        or any(type(value) is not int for value in kind["minimums"])
        or any(type(value) is not int for value in kind["maximums"])
        or not isinstance(kind["facts"], list)
        or any(type(name) is not str for name in kind["facts"])
    ):
        raise ValueError("task grammar scope has the wrong kind shape")
    if any(
        value < minimum or value > maximum
        for value, minimum, maximum in zip(
            parameters, kind["minimums"], kind["maximums"], strict=True
        )
    ):
        raise ValueError("task grammar scope is outside its kind's parameter bounds")
    exact_bounds = claim_probe.TASK_PARAMETER_BOUNDS.get(kind_name)
    if exact_bounds is None or (tuple(kind["minimums"]), tuple(kind["maximums"])) != exact_bounds:
        raise RuntimeError("the task grammar kind differs from the exact task bounds")
    claim_probe.validate_task_parameters(kind_name, parameters)
    return kind


def _required_for_kind(kind: str, parameters: list[int], pattern: list[str]) -> list[str]:
    if kind != "euclidean-recurrence":
        if "R*" in pattern:
            raise RuntimeError("only euclidean recurrence may use a numbered-fact pattern")
        return list(pattern)
    if pattern != ["R*", "GCD"]:
        raise RuntimeError("the euclidean fact pattern is invalid")
    previous, current = parameters
    if previous <= current or current <= 0:
        raise ValueError("euclidean recurrence requires a > b > 0")
    names: list[str] = []
    index = 2
    while current:
        names.append(f"R{index}")
        previous, current = current, previous % current
        index += 1
        if len(names) > 31:
            raise ValueError("euclidean recurrence exceeds the fact bound")
    return [*names, "GCD"]


def _literal(value: str) -> str:
    return f'"\\"{value}\\""'


def _object_literal(value: str) -> str:
    return f'"{value}"'


def _operation_rule(index: int, operation: dict[str, Any]) -> str:
    argument = f"argument-{index}"
    minimum = int(operation["min_args"])
    maximum = int(operation["max_args"])
    arguments = ' "," '.join([argument] * minimum)
    if maximum > minimum:
        arguments += f' ("," {argument}){{0,{maximum - minimum}}}'
    return f'"{{\\"op\\":\\"{operation["name"]}\\",\\"args\\":[" {arguments} "]}}"'


def generate(scope: dict[str, Any]) -> dict[str, Any]:
    """Return exact GBNF plus hashes independently checked after inference."""
    manifest = _manifest()
    canonical = canonical_scope(scope)
    _validate(scope, manifest)
    required = list(scope["required"])

    root = ["root ::= ", _object_literal('{\\"v\\":1,\\"facts\\":{'), " "]
    for index, fact in enumerate(required):
        if index:
            root.extend((_object_literal(","), " "))
        root.extend((_literal(fact), " ", _object_literal(":"), " ", f"node-{index}", " "))
    root.extend((_object_literal("}}"), "\n"))
    lines = ["".join(root)]

    for index, _fact in enumerate(required):
        if index == 0:
            lines.append(f"node-{index} ::= operation-{index}\n")
            lines.append(f"argument-{index} ::= integer | operation-{index}\n")
        else:
            lines.append(f"node-{index} ::= reference-{index} | operation-{index}\n")
            lines.append(f"argument-{index} ::= integer | reference-{index} | operation-{index}\n")
        alternatives = " | ".join(
            _operation_rule(index, operation) for operation in manifest["operations"]
        )
        lines.append(f"operation-{index} ::= {alternatives}\n")
        if index:
            references = " | ".join(
                _object_literal(f'{{\\"ref\\":\\"{fact}\\"}}') for fact in required[:index]
            )
            lines.append(f"reference-{index} ::= {references}\n")
    lines.append('integer ::= "-"? ("0" | [1-9] [0-9]{0,12})\n')
    source = "".join(lines)
    return {
        "name": NAME,
        "source": source,
        "voice_grammar_sha256": sha256_bytes(source.encode()),
        "voice_grammar_scope_sha256": sha256_bytes(canonical.encode()),
        "voice_grammar_generator_sha256": sha256_bytes(MANIFEST.read_bytes()),
        "scope": json.loads(canonical),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", type=Path, required=True)
    parser.add_argument("--source", action="store_true")
    args = parser.parse_args()
    target = conversation.load_bounded_json(args.spec)
    result = generate(scope_for(target))
    if args.source:
        print(result["source"], end="")
    else:
        shown = {key: value for key, value in result.items() if key != "source"}
        print(json.dumps(shown, indent=1, ensure_ascii=False))


if __name__ == "__main__":
    main()
