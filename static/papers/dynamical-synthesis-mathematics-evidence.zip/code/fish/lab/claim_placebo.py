"""Build and train the shuffled-reply control for the formal claim dream.

The control uses exactly the candidate dream's prompts, replies, split sizes,
and fixed training schedule, but pairs every prompt with a reply from a
different task family.  It therefore preserves register and token exposure
without preserving the prompt-to-program relation that could teach a method.

All output stays beneath the existing private claim room.  This module never
changes ``worn.gguf`` and opens the living body only to verify its pinned hash.
Conversion to a GGUF is a separate, staging-only keeper action.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import shutil
import subprocess
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Callable

from fish.lab import claim_dream

ROOT = Path(__file__).resolve().parents[2]
LABS = ROOT / "data/fish/labs"
NIGHT_PYTHON = ROOT / "fish/night/.venv/bin/python"
INSTRUMENT = "private-claim-shuffled-placebo-v1"
PAIRING_SALT = "loopseed-claim-shuffled-placebo-v1"
SPLITS = ("train", "valid", "test")
MAX_JSON_BYTES = 4 * 1024 * 1024
MAX_JSONL_BYTES = 32 * 1024 * 1024
MAX_TEXT_CHARS = 16_384
NUMBER = re.compile(r"(?:nan|-?inf|-?\d+(?:\.\d+)?)")


class PlaceboRefusal(ValueError):
    """The negative control no longer matches its pinned candidate corpus."""


def canonical(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def sha256(path: Path) -> str:
    return claim_dream.sha256(path)


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def _load_object(path: Path, *, cap: int = MAX_JSON_BYTES) -> dict[str, Any]:
    if path.is_symlink() or not path.is_file() or path.stat().st_size > cap:
        raise PlaceboRefusal(f"missing, linked, or oversized JSON artifact: {path}")
    try:
        value = claim_dream._strict_json(path.read_text(encoding="utf-8"))
    except (OSError, claim_dream.DreamRefusal) as error:
        raise PlaceboRefusal(f"invalid JSON artifact: {path}") from error
    if not isinstance(value, dict):
        raise PlaceboRefusal(f"JSON artifact is not an object: {path}")
    return value


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    if path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_JSONL_BYTES:
        raise PlaceboRefusal(f"missing, linked, or oversized JSONL artifact: {path}")
    rows: list[dict[str, Any]] = []
    try:
        for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
            value = claim_dream._strict_json(line)
            if not isinstance(value, dict):
                raise PlaceboRefusal(f"{path}:{line_number} is not an object")
            rows.append(value)
    except (OSError, claim_dream.DreamRefusal) as error:
        raise PlaceboRefusal(f"invalid JSONL artifact: {path}") from error
    return rows


def _write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("x", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def _confined(path: Path, root: Path, label: str, *, exists: bool = True) -> Path:
    try:
        resolved = path.resolve(strict=exists)
    except OSError as error:
        raise PlaceboRefusal(f"missing {label}: {path}") from error
    if not resolved.is_relative_to(root.resolve()):
        raise PlaceboRefusal(f"{label} escapes {root}")
    return resolved


def _messages(row: dict[str, Any], label: str) -> tuple[str, str]:
    messages = row.get("messages")
    if (
        not isinstance(messages, list)
        or len(messages) != 2
        or not all(isinstance(message, dict) for message in messages)
        or messages[0].get("role") != "user"
        or messages[1].get("role") != "assistant"
        or set(messages[0]) != {"role", "content"}
        or set(messages[1]) != {"role", "content"}
    ):
        raise PlaceboRefusal(f"{label} is not one user/assistant pair")
    prompt, reply = messages[0].get("content"), messages[1].get("content")
    if (
        not isinstance(prompt, str)
        or not isinstance(reply, str)
        or not prompt
        or not reply
        or len(prompt) > MAX_TEXT_CHARS
        or len(reply) > MAX_TEXT_CHARS
    ):
        raise PlaceboRefusal(f"{label} contains missing or oversized text")
    return prompt, reply


def _source_rows(source: Path) -> tuple[dict[str, Any], dict[str, list[dict[str, Any]]]]:
    source = _confined(source, LABS, "candidate dream dataset")
    try:
        manifest = claim_dream._verify_dataset(source)
    except (OSError, claim_dream.DreamRefusal) as error:
        raise PlaceboRefusal("candidate dream dataset no longer verifies") from error
    room = _confined(Path(str(manifest.get("room", ""))), LABS, "candidate claim room")
    if not source.is_relative_to((room / "dreams").resolve()):
        raise PlaceboRefusal("candidate dataset is outside its private room")
    provenance = _read_jsonl(source / "provenance.jsonl")
    if len(provenance) != manifest.get("accepted"):
        raise PlaceboRefusal("candidate provenance count differs from its manifest")
    by_split: dict[str, list[dict[str, Any]]] = {split: [] for split in SPLITS}
    exchange_ids: set[int] = set()
    for index, row in enumerate(provenance):
        split = row.get("dataset_split")
        exchange_id = row.get("exchange_id")
        kind = row.get("kind")
        spec_sha = row.get("spec_sha256")
        reply_sha = row.get("reply_sha256")
        prompt, reply = _messages(row, f"candidate provenance row {index + 1}")
        if (
            split not in SPLITS
            or type(exchange_id) is not int
            or exchange_id in exchange_ids
            or not isinstance(kind, str)
            or not kind
            or not isinstance(spec_sha, str)
            or not isinstance(reply_sha, str)
            or reply_sha != sha256_text(reply)
        ):
            raise PlaceboRefusal("candidate provenance identity drift")
        exchange_ids.add(exchange_id)
        normalized = dict(row)
        normalized["_prompt"] = prompt
        normalized["_reply"] = reply
        by_split[str(split)].append(normalized)
    for split in SPLITS:
        bare = [{"messages": row["messages"]} for row in by_split[split]]
        if _read_jsonl(source / f"{split}.jsonl") != bare:
            raise PlaceboRefusal(f"candidate {split} rows differ from provenance")
        if len(bare) != manifest.get("counts", {}).get(split):
            raise PlaceboRefusal(f"candidate {split} count differs from its manifest")
    return manifest, by_split


def _reference_schedule(
    source: Path, manifest: dict[str, Any], reference_dream: Path
) -> dict[str, Any]:
    room = Path(str(manifest["room"])).resolve()
    reference_dream = _confined(
        reference_dream,
        room / "body/fish/water/adapters",
        "reference candidate dream",
    )
    record = _load_object(reference_dream)
    adapter = reference_dream.parent
    lora = _confined(adapter / "lora.gguf", adapter, "reference candidate GGUF")
    schedule: dict[str, Any] = {
        "model": record.get("model"),
        "iters": record.get("iters"),
        "num_layers": record.get("num_layers"),
        "max_seq_length": record.get("max_seq_length"),
        "batch_size": 1,
        "mask_prompt": True,
        "whole_validation_witness": True,
    }
    if (
        record.get("status") != "survived-private-witness"
        or Path(str(record.get("dataset", ""))).resolve() != source
        or record.get("dataset_manifest_sha256") != sha256(source / "manifest.json")
        or not isinstance(schedule["model"], str)
        or not schedule["model"]
        or any(
            type(schedule[name]) is not int or schedule[name] < 1
            for name in (
                "iters",
                "num_layers",
                "max_seq_length",
            )
        )
    ):
        raise PlaceboRefusal("reference candidate dream or training schedule drift")
    return {
        "path": str(reference_dream),
        "sha256": sha256(reference_dream),
        "candidate_lora_path": str(lora),
        "candidate_lora_sha256": sha256(lora),
        "schedule": schedule,
    }


def _order(*parts: object) -> str:
    joined = "\0".join(str(part) for part in parts)
    return sha256_text(f"{PAIRING_SALT}\0{joined}")


def _derangement(rows: list[dict[str, Any]], split: str) -> dict[int, int]:
    """Return target-index -> wrong-family source-index by deterministic matching."""
    if len(rows) < 2:
        raise PlaceboRefusal(f"{split} needs at least two rows for a placebo derangement")
    edges: dict[int, list[int]] = {}
    for target_index, target in enumerate(rows):
        candidates = [
            source_index
            for source_index, source in enumerate(rows)
            if source_index != target_index
            and source["kind"] != target["kind"]
            and source["spec_sha256"] != target["spec_sha256"]
            and source["reply_sha256"] != target["reply_sha256"]
        ]
        candidates.sort(
            key=lambda source_index: _order(
                split,
                target["exchange_id"],
                rows[source_index]["exchange_id"],
            )
        )
        if not candidates:
            raise PlaceboRefusal(f"{split} cannot assign every prompt a wrong-family reply")
        edges[target_index] = candidates

    source_owner: dict[int, int] = {}

    def place(target_index: int, visited_sources: set[int]) -> bool:
        for source_index in edges[target_index]:
            if source_index in visited_sources:
                continue
            visited_sources.add(source_index)
            owner = source_owner.get(source_index)
            if owner is None or place(owner, visited_sources):
                source_owner[source_index] = target_index
                return True
        return False

    target_order = sorted(
        range(len(rows)),
        key=lambda index: (len(edges[index]), _order(split, rows[index]["exchange_id"])),
    )
    for target_index in target_order:
        if not place(target_index, set()):
            raise PlaceboRefusal(f"{split} has no complete wrong-family reply matching")
    pairing = {target: source for source, target in source_owner.items()}
    if set(pairing) != set(range(len(rows))) or len(set(pairing.values())) != len(rows):
        raise PlaceboRefusal(f"{split} placebo matching is incomplete")
    return pairing


def _pair_split(rows: list[dict[str, Any]], split: str) -> list[dict[str, Any]]:
    pairing = _derangement(rows, split)
    result: list[dict[str, Any]] = []
    for target_index, target in enumerate(rows):
        source = rows[pairing[target_index]]
        messages = [
            {"role": "user", "content": target["_prompt"]},
            {"role": "assistant", "content": source["_reply"]},
        ]
        identity = {
            "dataset_split": split,
            "target_exchange_id": target["exchange_id"],
            "target_kind": target["kind"],
            "target_spec_sha256": target["spec_sha256"],
            "target_prompt_sha256": sha256_text(target["_prompt"]),
            "reply_source_exchange_id": source["exchange_id"],
            "reply_source_kind": source["kind"],
            "reply_source_spec_sha256": source["spec_sha256"],
            "reply_sha256": source["reply_sha256"],
            "messages": messages,
        }
        result.append({**identity, "pair_sha256": sha256_text(canonical(identity))})
    return result


def _multiset(rows: list[dict[str, Any]], role: str) -> Counter[str]:
    position = 0 if role == "user" else 1
    return Counter(sha256_text(str(row["messages"][position]["content"])) for row in rows)


def build_dataset(
    source: Path,
    out: Path,
    reference_dream: Path,
    *,
    created_at: str | None = None,
) -> dict[str, Any]:
    """Freeze a deterministic wrong-family pairing of one candidate corpus."""
    source = _confined(source, LABS, "candidate dream dataset")
    manifest, by_split = _source_rows(source)
    room = Path(str(manifest["room"])).resolve()
    out = _confined(out, room / "dreams", "placebo dataset", exists=False)
    if out.exists():
        raise PlaceboRefusal(f"placebo output already exists: {out}")
    reference = _reference_schedule(source, manifest, reference_dream)
    living = _confined(Path(str(manifest["living_body"])), ROOT, "living body")
    living_before = sha256(living)
    if living_before != manifest.get("living_sha256"):
        raise PlaceboRefusal("living body changed before placebo construction")

    out.mkdir(parents=True)
    try:
        paired = {split: _pair_split(by_split[split], split) for split in SPLITS}
        provenance = [row for split in SPLITS for row in paired[split]]
        for split in SPLITS:
            _write_jsonl(
                out / f"{split}.jsonl",
                [{"messages": row["messages"]} for row in paired[split]],
            )
        _write_jsonl(out / "provenance.jsonl", provenance)
        for split in SPLITS:
            source_bare = [{"messages": row["messages"]} for row in by_split[split]]
            if _multiset(paired[split], "user") != _multiset(source_bare, "user"):
                raise PlaceboRefusal(f"{split} prompt multiset changed during pairing")
            if _multiset(paired[split], "assistant") != _multiset(source_bare, "assistant"):
                raise PlaceboRefusal(f"{split} reply multiset changed during pairing")
        if sha256(living) != living_before:
            raise PlaceboRefusal("living body changed during placebo construction")
        made_at = created_at or datetime.now(UTC).isoformat(timespec="seconds")
        record: dict[str, Any] = {
            "version": 1,
            "instrument": INSTRUMENT,
            "objective": "reply-shuffled negative control for audited typed-AST dream",
            "created_at": made_at,
            "room": str(room),
            "source_dataset": str(source),
            "source_manifest_sha256": sha256(source / "manifest.json"),
            "source_provenance_sha256": sha256(source / "provenance.jsonl"),
            "living_body": str(living),
            "living_sha256": living_before,
            "reference_candidate": reference,
            "pairing_salt": PAIRING_SALT,
            "pairing_rule": (
                "deterministic perfect matching within each frozen split; every prompt gets "
                "one different-spec, different-family reply; prompt and reply multisets preserved"
            ),
            "counts": {split: len(paired[split]) for split in SPLITS},
            "pairs": len(provenance),
            "zero_self_pairs": all(
                row["target_exchange_id"] != row["reply_source_exchange_id"] for row in provenance
            ),
            "zero_same_family_pairs": all(
                row["target_kind"] != row["reply_source_kind"] for row in provenance
            ),
            "pairing_sha256": sha256_text(
                canonical(
                    [
                        {
                            "target": row["target_exchange_id"],
                            "source": row["reply_source_exchange_id"],
                        }
                        for row in provenance
                    ]
                )
            ),
            "hashes": {
                name: sha256(out / name)
                for name in (*[f"{split}.jsonl" for split in SPLITS], "provenance.jsonl")
            },
            "scope": "private claim room only; never worn or promoted automatically",
        }
        (out / "manifest.json").write_text(
            json.dumps(record, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        verify_dataset(out)
        for name in (*[f"{split}.jsonl" for split in SPLITS], "provenance.jsonl", "manifest.json"):
            (out / name).chmod(0o444)
        return record
    except BaseException:
        shutil.rmtree(out, ignore_errors=True)
        raise


def verify_dataset(data: Path) -> dict[str, Any]:
    data = _confined(data, LABS, "placebo dataset")
    manifest = _load_object(data / "manifest.json")
    if manifest.get("version") != 1 or manifest.get("instrument") != INSTRUMENT:
        raise PlaceboRefusal("unknown placebo dataset")
    hashes = manifest.get("hashes")
    if not isinstance(hashes, dict) or set(hashes) != {
        "train.jsonl",
        "valid.jsonl",
        "test.jsonl",
        "provenance.jsonl",
    }:
        raise PlaceboRefusal("placebo manifest has the wrong artifact set")
    for name, digest in hashes.items():
        if not isinstance(digest, str) or sha256(data / name) != digest:
            raise PlaceboRefusal(f"placebo artifact hash drift: {name}")
    source = _confined(Path(str(manifest.get("source_dataset", ""))), LABS, "source dataset")
    source_manifest, source_rows = _source_rows(source)
    if sha256(source / "manifest.json") != manifest.get("source_manifest_sha256") or sha256(
        source / "provenance.jsonl"
    ) != manifest.get("source_provenance_sha256"):
        raise PlaceboRefusal("source corpus changed after placebo construction")
    living = Path(str(manifest.get("living_body", "")))
    if sha256(living) != manifest.get("living_sha256") or (
        manifest.get("living_sha256") != source_manifest.get("living_sha256")
    ):
        raise PlaceboRefusal("living body changed after placebo construction")
    reference = manifest.get("reference_candidate")
    if not isinstance(reference, dict):
        raise PlaceboRefusal("placebo has no reference candidate")
    dream = Path(str(reference.get("path", "")))
    lora = Path(str(reference.get("candidate_lora_path", "")))
    if sha256(dream) != reference.get("sha256") or sha256(lora) != reference.get(
        "candidate_lora_sha256"
    ):
        raise PlaceboRefusal("reference candidate changed after placebo construction")
    if canonical(_reference_schedule(source, source_manifest, dream)) != canonical(reference):
        raise PlaceboRefusal("reference candidate schedule changed after placebo construction")

    provenance = _read_jsonl(data / "provenance.jsonl")
    if len(provenance) != manifest.get("pairs"):
        raise PlaceboRefusal("placebo provenance count drift")
    pairing_identity: list[dict[str, int]] = []
    for split in SPLITS:
        paired = [row for row in provenance if row.get("dataset_split") == split]
        bare = [{"messages": row.get("messages")} for row in paired]
        if _read_jsonl(data / f"{split}.jsonl") != bare:
            raise PlaceboRefusal(f"placebo {split} rows differ from provenance")
        if len(paired) != manifest.get("counts", {}).get(split):
            raise PlaceboRefusal(f"placebo {split} count drift")
        source_bare = [{"messages": row["messages"]} for row in source_rows[split]]
        if _multiset(paired, "user") != _multiset(source_bare, "user") or _multiset(
            paired, "assistant"
        ) != _multiset(source_bare, "assistant"):
            raise PlaceboRefusal(f"placebo {split} token-bearing multiset drift")
        source_by_exchange = {row["exchange_id"]: row for row in source_rows[split]}
        targets: set[int] = set()
        reply_sources: set[int] = set()
        for row in paired:
            target_id = row.get("target_exchange_id")
            reply_source_id = row.get("reply_source_exchange_id")
            if (
                not isinstance(target_id, int)
                or isinstance(target_id, bool)
                or not isinstance(reply_source_id, int)
                or isinstance(reply_source_id, bool)
            ):
                raise PlaceboRefusal(f"placebo {split} has an untyped source identity")
            target = source_by_exchange.get(target_id)
            reply_source = source_by_exchange.get(reply_source_id)
            if target is None or reply_source is None:
                raise PlaceboRefusal(f"placebo {split} names a foreign source row")
            if target_id in targets or reply_source_id in reply_sources:
                raise PlaceboRefusal(f"placebo {split} repeats a target or reply source")
            targets.add(target_id)
            reply_sources.add(reply_source_id)
            expected = {
                "dataset_split": split,
                "target_exchange_id": target_id,
                "target_kind": target["kind"],
                "target_spec_sha256": target["spec_sha256"],
                "target_prompt_sha256": sha256_text(target["_prompt"]),
                "reply_source_exchange_id": reply_source_id,
                "reply_source_kind": reply_source["kind"],
                "reply_source_spec_sha256": reply_source["spec_sha256"],
                "reply_sha256": reply_source["reply_sha256"],
                "messages": [
                    {"role": "user", "content": target["_prompt"]},
                    {"role": "assistant", "content": reply_source["_reply"]},
                ],
            }
            if (
                set(row) != {*expected, "pair_sha256"}
                or any(row.get(key) != value for key, value in expected.items())
                or row.get("pair_sha256") != sha256_text(canonical(expected))
            ):
                raise PlaceboRefusal(f"placebo {split} pair differs from its source rows")
            pairing_identity.append({"target": target_id, "source": reply_source_id})
        if targets != set(source_by_exchange) or reply_sources != set(source_by_exchange):
            raise PlaceboRefusal(f"placebo {split} is not a complete permutation")
    if not manifest.get("zero_self_pairs") or not manifest.get("zero_same_family_pairs"):
        raise PlaceboRefusal("placebo pairing retained a source relation")
    if manifest.get("pairing_sha256") != sha256_text(canonical(pairing_identity)):
        raise PlaceboRefusal("placebo pairing digest drift")
    for row in provenance:
        if row.get("target_exchange_id") == row.get("reply_source_exchange_id") or row.get(
            "target_kind"
        ) == row.get("reply_source_kind"):
            raise PlaceboRefusal("placebo pair identity drift")
        _messages(row, "placebo provenance row")
    return manifest


def training_argv(data: Path, adapter: Path, manifest: dict[str, Any]) -> list[str]:
    reference = manifest.get("reference_candidate")
    schedule = reference.get("schedule") if isinstance(reference, dict) else None
    if not isinstance(schedule, dict):
        raise PlaceboRefusal("placebo training schedule is missing")
    return [
        str(NIGHT_PYTHON),
        "-m",
        "mlx_lm.lora",
        "--model",
        str(schedule["model"]),
        "--train",
        "--data",
        str(data),
        "--adapter-path",
        str(adapter),
        "--iters",
        str(schedule["iters"]),
        "--batch-size",
        str(schedule["batch_size"]),
        "--num-layers",
        str(schedule["num_layers"]),
        "--max-seq-length",
        str(schedule["max_seq_length"]),
        "--val-batches",
        "-1",
        "--mask-prompt",
    ]


def _test_argv(data: Path, adapter: Path, manifest: dict[str, Any]) -> list[str]:
    schedule = manifest["reference_candidate"]["schedule"]
    return [
        str(NIGHT_PYTHON),
        "-m",
        "mlx_lm.lora",
        "--model",
        str(schedule["model"]),
        "--data",
        str(data),
        "--test",
        "--adapter-path",
        str(adapter),
        "--batch-size",
        str(schedule["batch_size"]),
        "--max-seq-length",
        str(schedule["max_seq_length"]),
        "--mask-prompt",
    ]


def _validation_losses(output: str) -> list[float]:
    return [
        float(match.group(0)) for match in re.finditer(r"(?<=Val loss )" + NUMBER.pattern, output)
    ]


def _test_perplexity(output: str) -> float | None:
    found = re.search(r"(?<=Test ppl )" + NUMBER.pattern, output)
    if found is None:
        return None
    value = float(found.group(0))
    return value if math.isfinite(value) else None


def train(
    data: Path,
    adapter: Path,
    *,
    process_runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
) -> dict[str, Any]:
    """Run the reference schedule once; never select on placebo loss."""
    data = _confined(data, LABS, "placebo dataset")
    manifest = verify_dataset(data)
    room = Path(str(manifest["room"])).resolve()
    adapter = _confined(
        adapter,
        room / "body/fish/water/adapters",
        "placebo adapter",
        exists=False,
    )
    if adapter.exists():
        raise PlaceboRefusal(f"placebo adapter already exists: {adapter}")
    living = Path(str(manifest["living_body"]))
    living_before = sha256(living)
    adapter.mkdir(parents=True)
    trained = process_runner(
        training_argv(data, adapter, manifest), capture_output=True, text=True, check=False
    )
    training_output = str(trained.stdout) + str(trained.stderr)
    (adapter / "train.log").write_text(training_output, encoding="utf-8")
    expected = (adapter / "adapters.safetensors", adapter / "adapter_config.json")
    training_complete = trained.returncode == 0 and all(path.is_file() for path in expected)
    tested: subprocess.CompletedProcess[str] | None = None
    test_output = ""
    perplexity: float | None = None
    if training_complete:
        tested = process_runner(
            _test_argv(data, adapter, manifest), capture_output=True, text=True, check=False
        )
        test_output = str(tested.stdout) + str(tested.stderr)
        (adapter / "test.log").write_text(test_output, encoding="utf-8")
        perplexity = _test_perplexity(test_output)
    complete = bool(
        training_complete
        and tested is not None
        and tested.returncode == 0
        and perplexity is not None
        and sha256(living) == living_before == manifest["living_sha256"]
    )
    losses = _validation_losses(training_output)
    schedule = manifest["reference_candidate"]["schedule"]
    record: dict[str, Any] = {
        "version": 1,
        "instrument": INSTRUMENT,
        "status": "trained-fixed-schedule-unworn" if complete else "rejected-mechanical-training",
        "objective": "reply-shuffled negative control for audited typed-AST dream",
        "dreamed_at": datetime.now(UTC).isoformat(timespec="microseconds"),
        "dataset": str(data),
        "dataset_manifest_sha256": sha256(data / "manifest.json"),
        "reference_candidate_dream_sha256": manifest["reference_candidate"]["sha256"],
        "schedule": schedule,
        "training_returncode": trained.returncode,
        "test_returncode": tested.returncode if tested is not None else None,
        "validation_losses": losses,
        "validation_contracted": bool(len(losses) >= 2 and losses[-1] < losses[0]),
        "test_perplexity": perplexity,
        "selection_rule": "fixed schedule; placebo loss is measured but never used to select a run",
        "living_body_unchanged": sha256(living) == living_before,
        "scope": "private classroom clone only; no automatic staging, wearing, or promotion",
    }
    (adapter / "dream.json").write_text(
        json.dumps(record, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    if not complete:
        raise RuntimeError("placebo fixed-schedule training did not complete cleanly")
    return record


def _fresh(root: Path, prefix: str) -> Path:
    stamp = datetime.now(UTC).strftime("%Y-%m-%dT%H%M%S.%fZ")
    return root / f"{prefix}-{stamp}"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    build = commands.add_parser("build", help="freeze a wrong-family reply derangement")
    build.add_argument("--source", type=Path, required=True)
    build.add_argument("--reference-dream", type=Path, required=True)
    build.add_argument("--out", type=Path)
    training = commands.add_parser("train", help="train once with the candidate's fixed schedule")
    training.add_argument("dataset", type=Path)
    training.add_argument("--adapter", type=Path)
    verify = commands.add_parser("verify", help="recheck every pinned placebo relation")
    verify.add_argument("dataset", type=Path)
    args = parser.parse_args()

    if args.command == "build":
        source = args.source.resolve()
        manifest = _load_object(source / "manifest.json")
        room = Path(str(manifest["room"]))
        out = args.out or _fresh(room / "dreams", "shuffled-placebo")
        result = build_dataset(source, out, args.reference_dream)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        print(f"private placebo dataset: {out}")
    elif args.command == "train":
        manifest = verify_dataset(args.dataset)
        room = Path(str(manifest["room"]))
        adapter = args.adapter or _fresh(
            room / "body/fish/water/adapters", "claim-shuffled-placebo"
        )
        result = train(args.dataset, adapter)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        print(f"private placebo adapter: {adapter}")
    else:
        print(json.dumps(verify_dataset(args.dataset), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
