"""Ground truth for exact cancellation before multiplication."""

from __future__ import annotations

import hashlib
import math
import re
from dataclasses import dataclass
from fractions import Fraction

from fish.lab.counted_structure import assignment_truth_with_tables

START_CYCLE = 3405
KIND = "exact-cancellation"
METHOD = (
    "For exact A*B/D, set G_LEFT=gcd(A,D), LEFT_REDUCED=A/G_LEFT, and "
    "DEN_AFTER_LEFT=D/G_LEFT; then set G_RIGHT=gcd(B,DEN_AFTER_LEFT), "
    "RIGHT_REDUCED=B/G_RIGHT, and DEN_FINAL=DEN_AFTER_LEFT/G_RIGHT. "
    "When DEN_FINAL=1, RESULT=LEFT_REDUCED*RIGHT_REDUCED"
)


@dataclass(frozen=True)
class Problem:
    parameters: tuple[int, int, int]

    @property
    def assignments(self) -> dict[str, int]:
        return states(self.parameters)

    def _label_contract(self) -> str:
        return "; ".join(f"{label} = integer" for label in self.assignments)

    def prompt(self) -> str:
        left, right, divisor = self.parameters
        return (
            f"Exact cancellation question: ({left} times {right}) divided by {divisor} is an "
            "integer. Cancel against the left factor first and then the right factor. What "
            f"values belong to these states: {self._label_contract()}? A short labeled table is "
            "enough."
        )

    def nudge(self) -> str:
        left, right, divisor = self.parameters
        return (
            f"Exact cancellation question: ({left} times {right}) divided by {divisor}. "
            f"Use this relation: {METHOD}. What values belong to these states: "
            f"{self._label_contract()}? A short labeled table is enough."
        )

    def record(self) -> str:
        return "; ".join(f"{label} = {value}" for label, value in self.assignments.items())

    @property
    def method(self) -> str:
        return METHOD


def states(parameters: tuple[int, int, int]) -> dict[str, int]:
    left, right, divisor = parameters
    if min(left, right, divisor) <= 0:
        raise ValueError("cancellation parameters must be positive")
    g_left = math.gcd(left, divisor)
    left_reduced = left // g_left
    den_after_left = divisor // g_left
    g_right = math.gcd(right, den_after_left)
    right_reduced = right // g_right
    den_final = den_after_left // g_right
    if den_final != 1:
        raise ValueError("the product is not exactly divisible")
    return {
        "G_LEFT": g_left,
        "LEFT_REDUCED": left_reduced,
        "DEN_AFTER_LEFT": den_after_left,
        "G_RIGHT": g_right,
        "RIGHT_REDUCED": right_reduced,
        "DEN_FINAL": den_final,
        "RESULT": left_reduced * right_reduced,
    }


def problem_from_prompt(prompt: str) -> Problem | None:
    match = re.search(
        r"Exact cancellation question: \((\d+) times (\d+)\) divided by (\d+)",
        prompt,
    )
    if match is None:
        return None
    left, right, divisor = (int(value) for value in match.groups())
    return Problem((left, right, divisor))


def _normalized_math(reply: str) -> str:
    text = reply.translate(str.maketrans("₀₁₂₃₄₅₆₇₈₉", "0123456789")).casefold()
    text = (
        text.replace("\\times", "*")
        .replace("\\cdot", "*")
        .replace("\\div", "/")
        .replace("×", "*")
        .replace("÷", "/")
    )
    return re.sub(r"(?<=\d),(?:\s|\\[!,;:])*(?=\d{3}\b)", "", text)


def arithmetic_claim_refuted(reply: str) -> bool:
    text = _normalized_math(reply)
    if re.search(r"\b(?:is|was|division is)\s+not exact\b|\bdoes not divide evenly\b", text):
        return True
    if re.search(r"\b(?:approximately|rounded)\b", text):
        return True
    for left, right, claimed in re.findall(
        r"\\?gcd\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)\s*=\s*(\d+)\b", text
    ):
        if math.gcd(int(left), int(right)) != int(claimed):
            return True

    compact = re.sub(r"\s*([*/=])\s*", r"\1", text)
    number = r"\d+(?:\.\d+)?"
    for left, right, divisor, claimed in re.findall(
        rf"\(?\b(\d+)\*(\d+)\)?/(\d+)=({number})\b", compact
    ):
        numerator = int(left) * int(right)
        if int(divisor) == 0 or Fraction(numerator, int(divisor)) != Fraction(claimed):
            return True
    division = re.compile(rf"(?<![\d*])(\d+)/(\d+)=({number})\b")
    remainder_tail = re.compile(r"^\s*\$?\s*(?:with\s+)?remainder\s*[:=]?\s*\$?\s*(\d+)\b")
    for claim in division.finditer(compact):
        dividend, divisor, claimed = claim.groups()
        numerator, denominator = int(dividend), int(divisor)
        if denominator == 0:
            return True
        remainder = remainder_tail.match(compact[claim.end() :])
        if remainder is not None:
            if "." in claimed or divmod(numerator, denominator) != (
                int(claimed),
                int(remainder.group(1)),
            ):
                return True
            continue
        if Fraction(numerator, denominator) != Fraction(claimed):
            return True
    for left, right, claimed in re.findall(r"(?<![\d/])(\d+)\*(\d+)=(\d+)\b", compact):
        if int(left) * int(right) != int(claimed):
            return True
    return False


def lesson_reply_lands(prompt: str, reply: str) -> bool | None:
    problem = problem_from_prompt(prompt)
    if problem is None:
        return None
    if arithmetic_claim_refuted(reply):
        return False
    return assignment_truth_with_tables(reply, problem.assignments)


def candidates() -> list[tuple[int, int, int]]:
    values: list[tuple[int, int, int]] = []
    for left in range(120, 30_001, 37):
        for right in range(12, 41):
            for divisor in range(4, 20):
                if left * right % divisor:
                    continue
                g_left = math.gcd(left, divisor)
                den_after_left = divisor // g_left
                g_right = math.gcd(right, den_after_left)
                if g_left > 1 and den_after_left > 1 and g_right > 1:
                    values.append((left, right, divisor))
    values.sort(key=lambda triple: hashlib.sha256(f"{KIND}:{triple}".encode()).digest())
    return values


def lesson_problem(cycle: int) -> tuple[Problem, int]:
    if cycle < START_CYCLE:
        raise ValueError(f"exact-cancellation lessons begin at cycle {START_CYCLE}")
    occurrence = cycle - START_CYCLE
    pool = candidates()
    return Problem(pool[occurrence % len(pool)]), occurrence
