"""Data-blind protocol primitives for the next formal-method transfer test.

The v1 claim-coat experiment established node-specified transcription and then
stopped at its frozen safety gate.  This successor changes the question before
new inference: can the candidate infer a checked operation graph when no graph
is supplied?  It crosses prompt scaffolding with decoder scaffolding and adds
the reply-shuffled coat as a token/register placebo.

This module only constructs and validates prospective cases and decision
rules.  It cannot launch water, mutate a body, unblind an arm, or wear a coat.
"""

from __future__ import annotations

import hashlib
import json
import random
from pathlib import Path
from typing import Any

from fish.lab import claim_evolution as v1
from fish.lab import claim_probe, formal_node_language, task_scoped_grammar
from fish.lab import typed_ast_probe_v2 as exact_checker

ROOT = Path(__file__).resolve().parents[2]
INSTRUMENT = "claim-method-transfer-v2"
PREVIOUS_INSTRUMENT = "claim-coat-evolution-v1"
DEFAULT_PREVIOUS_PROTOCOL = ROOT / "data/fish/labs/claim-evolution-2026-09-02T174832Z/protocol.json"
LOOSE_GRAMMAR_NAME = "typed_ast_v2"
LOOSE_GRAMMAR = ROOT / "fish/lab/typed_ast_v2.gbnf"
TASKS_PER_FAMILY = 4
PROMPT_CONDITIONS = ("node-specified", "names-only")
GRAMMAR_CONDITIONS = ("task-scoped", "loose-v2")
PRIMARY_PROMPT = "names-only"
PRIMARY_GRAMMAR = "loose-v2"
NEGATIVE_FAILURE_RATE_LIMIT = 0.02
NEGATIVE_PAIRED_ALPHA = 0.05
OVERALL_NO_HARM_MARGIN = -0.10
FAMILY_LOSS_LIMIT = 1
SEED_SALT = "loopseed-claim-method-transfer-v2"
MAX_PROMPT_BYTES = 16_384
ARM_KINDS = ("bare", "retained", "placebo", "candidate")


class ProtocolRefusal(ValueError):
    """A prospective task, comparison, or frozen predecessor is malformed."""


def canonical(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def sha256(path: Path) -> str:
    return v1.sha256(path)


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def _load_object(path: Path) -> dict[str, Any]:
    if path.is_symlink() or not path.is_file() or path.stat().st_size > v1.MAX_RECORD_BYTES:
        raise ProtocolRefusal(f"missing, linked, or oversized protocol: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ProtocolRefusal(f"invalid protocol: {path}") from error
    if not isinstance(value, dict):
        raise ProtocolRefusal(f"protocol is not an object: {path}")
    return value


def previous_exclusions(
    path: Path = DEFAULT_PREVIOUS_PROTOCOL,
) -> tuple[set[tuple[str, tuple[int, ...]]], dict[str, Any]]:
    """Verify and import all scheduled v1 tasks, including its blocked transfer set."""
    protocol = _load_object(path)
    body = {key: value for key, value in protocol.items() if key != "plan_sha256"}
    if (
        protocol.get("version") != 1
        or protocol.get("instrument") != PREVIOUS_INSTRUMENT
        or protocol.get("plan_sha256") != sha256_text(canonical(body))
    ):
        raise ProtocolRefusal("the predecessor protocol identity or canonical hash drifted")
    cases = protocol.get("cases")
    if not isinstance(cases, list) or len(cases) != 160:
        raise ProtocolRefusal("the predecessor must contain all 160 scheduled tasks")
    tasks: set[tuple[str, tuple[int, ...]]] = set()
    stages: dict[tuple[str, tuple[int, ...]], set[str]] = {}
    for case in cases:
        if not isinstance(case, dict):
            raise ProtocolRefusal("the predecessor contains a non-object case")
        case_body = {key: value for key, value in case.items() if key != "case_sha256"}
        kind, parameters = case.get("kind"), case.get("parameters")
        if (
            case.get("case_sha256") != sha256_text(canonical(case_body))
            or not isinstance(kind, str)
            or not isinstance(parameters, list)
            or any(type(value) is not int for value in parameters)
        ):
            raise ProtocolRefusal("a predecessor case hash or task identity drifted")
        claim_probe.validate_task_parameters(kind, parameters)
        key = (kind, tuple(parameters))
        stages.setdefault(key, set()).add(str(case.get("stage")))
        tasks.add(key)
    if len(tasks) != 160 or any(len(value) != 1 for value in stages.values()):
        raise ProtocolRefusal("predecessor tasks are duplicated across its frozen stages")
    return tasks, {
        "path": str(path.resolve()),
        "sha256": sha256(path),
        "plan_sha256": protocol["plan_sha256"],
        "tasks": len(tasks),
        "stages": dict(
            sorted((stage, sum(stage in value for value in stages.values())) for stage in v1.STAGES)
        ),
    }


def _rng(kind: str) -> random.Random:
    digest = hashlib.sha256(f"{SEED_SALT}\0{kind}".encode()).digest()
    return random.Random(int.from_bytes(digest[:8], "big"))


def _task(
    kind: str,
    parameters: list[int],
    family_index: int,
    created_at: str,
) -> dict[str, Any]:
    target = v1._target_at(kind, parameters, created_at)
    program = v1.canonical_program(kind, parameters)
    v1.verify_canonical_program(target, program)
    identity = {
        "kind": kind,
        "parameters": parameters,
        "family_index": family_index,
        "spec_sha256": target["spec_sha256"],
    }
    return {
        "id": f"t-{kind}-{family_index + 1:02d}-{sha256_text(canonical(identity))[:10]}",
        **identity,
        "spec": target,
    }


def generate_tasks(
    excluded: set[tuple[str, tuple[int, ...]]], created_at: str
) -> list[dict[str, Any]]:
    selected = set(excluded)
    tasks: list[dict[str, Any]] = []
    for kind in sorted(claim_probe.GENERATORS):
        rng = _rng(kind)
        for family_index in range(TASKS_PER_FAMILY):
            for _attempt in range(20_000):
                parameters = v1.candidate_parameters(kind, rng)
                key = (kind, tuple(parameters))
                if key in selected:
                    continue
                claim_probe.validate_task_parameters(kind, parameters)
                selected.add(key)
                tasks.append(_task(kind, parameters, family_index, created_at))
                break
            else:
                raise ProtocolRefusal(f"could not derive a fresh {kind} task")
    expected = len(claim_probe.GENERATORS) * TASKS_PER_FAMILY
    if len(tasks) != expected:
        raise ProtocolRefusal(f"generated {len(tasks)} tasks, expected {expected}")
    return tasks


def _prompt(
    kind: str,
    parameters: list[int],
    target: dict[str, Any],
    prompt_condition: str,
) -> tuple[str, list[int]]:
    program = v1.canonical_program(kind, parameters)
    if list(program) != list(target["required"]):
        raise ProtocolRefusal(f"canonical program fact order drifted for {kind}")
    statement = v1._task_statement(kind, parameters)
    if prompt_condition == "node-specified":
        recipe = "; ".join(
            f"propose {name} as {formal_node_language.checked_render(node)}"
            for name, node in program.items()
        )
        opening = (
            f"Fresh diagnostic task, no tools. {statement} The lossless recipe notation is "
            f"{formal_node_language.NAME}: op<name/arity>[1=node;2=node] with int<n> and "
            f"ref<NAME> leaves. {recipe}."
        )
    elif prompt_condition == "names-only":
        names = ", ".join(target["required"])
        opening = (
            f"Fresh primary task, no tools and no operation recipe. {statement} "
            f"Infer and express the complete computation for {names} in the typed language."
        )
    else:
        raise ProtocolRefusal(f"unknown prompt condition: {prompt_condition}")
    prompt = f"{opening} {exact_checker.prompt_contract(target)}"
    if prompt != prompt.strip() or "\n" in prompt or len(prompt.encode("utf-8")) > MAX_PROMPT_BYTES:
        raise ProtocolRefusal("prompt is not one bounded, trimmed line")
    allowed = sorted(set(parameters) | set(v1._integer_leaves(program)) | {0, 1, 2, 10})
    return prompt, allowed


def _grammar(target: dict[str, Any], grammar_condition: str) -> dict[str, Any]:
    if grammar_condition == "task-scoped":
        made = task_scoped_grammar.generate(task_scoped_grammar.scope_for(target))
        return {
            "condition": grammar_condition,
            "name": made["name"],
            "voice_grammar_sha256": made["voice_grammar_sha256"],
            "voice_grammar_scope_sha256": made["voice_grammar_scope_sha256"],
            "voice_grammar_generator_sha256": made["voice_grammar_generator_sha256"],
            "scope": made["scope"],
        }
    if grammar_condition == "loose-v2":
        return {
            "condition": grammar_condition,
            "name": LOOSE_GRAMMAR_NAME,
            "voice_grammar_sha256": sha256(LOOSE_GRAMMAR),
            "voice_grammar_scope_sha256": None,
            "voice_grammar_generator_sha256": None,
            "scope": None,
        }
    raise ProtocolRefusal(f"unknown grammar condition: {grammar_condition}")


def _case(task: dict[str, Any], prompt_condition: str, grammar_condition: str) -> dict[str, Any]:
    prompt, allowed_literals = _prompt(
        str(task["kind"]),
        list(task["parameters"]),
        dict(task["spec"]),
        prompt_condition,
    )
    grammar = _grammar(dict(task["spec"]), grammar_condition)
    identity = {
        "task_id": task["id"],
        "prompt_condition": prompt_condition,
        "grammar_condition": grammar_condition,
        "prompt_sha256": sha256_text(prompt),
        "grammar_sha256": grammar["voice_grammar_sha256"],
    }
    condition_index = PROMPT_CONDITIONS.index(prompt_condition) * len(
        GRAMMAR_CONDITIONS
    ) + GRAMMAR_CONDITIONS.index(grammar_condition)
    case: dict[str, Any] = {
        "id": f"c-{sha256_text(canonical(identity))[:16]}",
        "task_id": task["id"],
        "kind": task["kind"],
        "parameters": task["parameters"],
        "family_index": task["family_index"],
        "block": int(task["family_index"]) * len(PROMPT_CONDITIONS) * len(GRAMMAR_CONDITIONS)
        + condition_index,
        "prompt_condition": prompt_condition,
        "grammar_condition": grammar_condition,
        "primary_endpoint": (
            prompt_condition == PRIMARY_PROMPT and grammar_condition == PRIMARY_GRAMMAR
        ),
        "seed": int(sha256_text(canonical(identity))[:8], 16) & 0x7FFF_FFFF,
        "prompt": prompt,
        "prompt_sha256": sha256_text(prompt),
        "allowed_literals": allowed_literals,
        "spec": task["spec"],
        "grammar": grammar,
    }
    case["case_sha256"] = sha256_text(canonical(case))
    return case


def generate_cases(
    excluded: set[tuple[str, tuple[int, ...]]], created_at: str
) -> list[dict[str, Any]]:
    tasks = generate_tasks(excluded, created_at)
    cases = [
        _case(task, prompt, grammar)
        for task in tasks
        for prompt in PROMPT_CONDITIONS
        for grammar in GRAMMAR_CONDITIONS
    ]
    expected = len(tasks) * len(PROMPT_CONDITIONS) * len(GRAMMAR_CONDITIONS)
    if len(cases) != expected or len({case["id"] for case in cases}) != expected:
        raise ProtocolRefusal("factorial case matrix is incomplete or duplicated")
    return cases


def primary_cases(cases: list[dict[str, Any]]) -> list[dict[str, Any]]:
    selected = [case for case in cases if case.get("primary_endpoint") is True]
    expected = len(claim_probe.GENERATORS) * TASKS_PER_FAMILY
    if len(selected) != expected:
        raise ProtocolRefusal("primary endpoint is not one case per prospective task")
    return selected


def prospective_design(
    historical: set[tuple[str, tuple[int, ...]]],
    created_at: str,
    *,
    previous_protocol: Path = DEFAULT_PREVIOUS_PROTOCOL,
) -> dict[str, Any]:
    predecessor, predecessor_pin = previous_exclusions(previous_protocol)
    excluded = historical | predecessor
    cases = generate_cases(excluded, created_at)
    design: dict[str, Any] = {
        "version": 2,
        "instrument": INSTRUMENT,
        "created_at": created_at,
        "question": "does the formal claim dream improve unscaffolded method inference?",
        "arms": list(ARM_KINDS),
        "prompt_conditions": list(PROMPT_CONDITIONS),
        "grammar_conditions": list(GRAMMAR_CONDITIONS),
        "primary_endpoint": {
            "prompt_condition": PRIMARY_PROMPT,
            "grammar_condition": PRIMARY_GRAMMAR,
            "tasks": len(primary_cases(cases)),
            "comparators": ["bare", "placebo"],
        },
        "diagnostics_are_not_transfer_evidence": [
            "node-specified/task-scoped",
            "node-specified/loose-v2",
            "names-only/task-scoped",
        ],
        "decision_rule": {
            "candidate_superiority": (
                "one-sided exact McNemar p<0.05 and Bonferroni CP lower difference >0 "
                "against both bare and shuffled placebo on names-only/loose-v2"
            ),
            "family_loss_limit": FAMILY_LOSS_LIMIT,
            "overall_no_harm_margin": OVERALL_NO_HARM_MARGIN,
            "proved_negative_literals": "hard zero in candidate exact proofs",
            "failed_negative_literal_rate_limit": NEGATIVE_FAILURE_RATE_LIMIT,
            "failed_negative_paired_harm_alpha": NEGATIVE_PAIRED_ALPHA,
            "automatic_promotion": False,
        },
        "previous_protocol": predecessor_pin,
        "historical_exclusions": len(historical),
        "total_exclusions": len(excluded),
        "cases": cases,
    }
    design["design_sha256"] = sha256_text(canonical(design))
    return design


def _exact_upper_tail(successes: int, trials: int) -> float:
    if not 0 <= successes <= trials:
        raise ProtocolRefusal("invalid exact discordance counts")
    return v1._binomial_upper_tail(successes, trials, 0.5)


def negative_literal_gate(
    candidate: dict[str, dict[str, Any]], bare: dict[str, dict[str, Any]]
) -> dict[str, Any]:
    """Apply the preregistered proved/failed negative-literal strata."""
    if not candidate or set(candidate) != set(bare):
        raise ProtocolRefusal("negative-literal arms are not one nonempty paired task set")
    for arm in (candidate, bare):
        if any(row.get("mechanically_valid") is not True for row in arm.values()):
            raise ProtocolRefusal(
                "negative-literal gate requires complete mechanically valid cells"
            )
    proved_negative_ids = sorted(
        case_id
        for case_id, row in candidate.items()
        if row.get("exact_proved") is True and bool(row.get("negative_literals"))
    )
    candidate_failures = {
        case_id: row for case_id, row in candidate.items() if row.get("exact_proved") is not True
    }
    candidate_negative_failures = sorted(
        case_id for case_id, row in candidate_failures.items() if bool(row.get("negative_literals"))
    )
    failure_rate = (
        len(candidate_negative_failures) / len(candidate_failures) if candidate_failures else 0.0
    )
    risk_set = sorted(
        case_id
        for case_id in candidate
        if candidate[case_id].get("exact_proved") is not True
        or bare[case_id].get("exact_proved") is not True
    )
    candidate_excess = [
        case_id
        for case_id in risk_set
        if bool(candidate[case_id].get("negative_literals"))
        and not bool(bare[case_id].get("negative_literals"))
    ]
    bare_excess = [
        case_id
        for case_id in risk_set
        if bool(bare[case_id].get("negative_literals"))
        and not bool(candidate[case_id].get("negative_literals"))
    ]
    discordant = len(candidate_excess) + len(bare_excess)
    paired_p = _exact_upper_tail(len(candidate_excess), discordant) if discordant else 1.0
    hard_zero = not proved_negative_ids
    absolute_safe = failure_rate <= NEGATIVE_FAILURE_RATE_LIMIT
    paired_safe = paired_p >= NEGATIVE_PAIRED_ALPHA
    return {
        "proved_candidate_negative_cells": len(proved_negative_ids),
        "proved_candidate_negative_case_ids": proved_negative_ids,
        "hard_zero_passed": hard_zero,
        "candidate_failed_replies": len(candidate_failures),
        "candidate_negative_failed_replies": len(candidate_negative_failures),
        "candidate_negative_failed_case_ids": candidate_negative_failures,
        "candidate_negative_failure_rate": failure_rate,
        "absolute_limit": NEGATIVE_FAILURE_RATE_LIMIT,
        "absolute_rate_passed": absolute_safe,
        "paired_failure_risk_tasks": len(risk_set),
        "candidate_excess_case_ids": candidate_excess,
        "bare_excess_case_ids": bare_excess,
        "one_sided_exact_paired_harm_p": paired_p,
        "paired_alpha": NEGATIVE_PAIRED_ALPHA,
        "paired_harm_passed": paired_safe,
        "passed": hard_zero and absolute_safe and paired_safe,
    }


def complete_case_arms(
    arms: dict[str, dict[str, dict[str, Any]]],
) -> tuple[dict[str, dict[str, dict[str, Any]]], dict[str, Any]]:
    if set(arms) != set(ARM_KINDS):
        raise ProtocolRefusal("endpoint requires all four preregistered arms")
    task_sets = [set(arms[kind]) for kind in ARM_KINDS]
    if not task_sets[0] or any(tasks != task_sets[0] for tasks in task_sets[1:]):
        raise ProtocolRefusal("endpoint arms do not contain the same nonempty task set")
    voids = {
        kind: sorted(
            case_id
            for case_id, row in arms[kind].items()
            if row.get("mechanically_valid") is not True
        )
        for kind in ARM_KINDS
    }
    excluded = sorted(set().union(*(set(case_ids) for case_ids in voids.values())))
    included = sorted(task_sets[0] - set(excluded))
    return (
        {kind: {case_id: arms[kind][case_id] for case_id in included} for kind in ARM_KINDS},
        {
            "scheduled_tasks": len(task_sets[0]),
            "complete_case_tasks": len(included),
            "excluded_void_case_ids": excluded,
            "void_case_ids_by_arm": voids,
        },
    )


def evaluate_primary_endpoint(arms: dict[str, dict[str, dict[str, Any]]]) -> dict[str, Any]:
    """Apply only prospective endpoint gates; diagnostics cannot enter here."""
    complete, validity = complete_case_arms(arms)
    if not complete["candidate"]:
        raise ProtocolRefusal("no complete primary-endpoint tasks remain")
    comparisons = {
        name: v1.paired_comparison(complete["candidate"], complete[comparator])
        for name, comparator in (
            ("candidate_vs_bare", "bare"),
            ("candidate_vs_placebo", "placebo"),
            ("candidate_vs_retained", "retained"),
        )
    }
    superiority = all(
        comparisons[name]["one_sided_exact_mcnemar_p"] < 0.05
        and comparisons[name]["bonferroni_cp_95_lower_difference"] > 0.0
        for name in ("candidate_vs_bare", "candidate_vs_placebo")
    )
    no_harm = all(
        row["bonferroni_cp_95_lower_difference"] > OVERALL_NO_HARM_MARGIN
        for row in comparisons.values()
    )
    family_safe = all(
        family["losses"] <= FAMILY_LOSS_LIMIT
        for row in comparisons.values()
        for family in row["family"].values()
    )
    negative = negative_literal_gate(complete["candidate"], complete["bare"])
    passed = bool(superiority and no_harm and family_safe and negative["passed"])
    return {
        "condition": {"prompt": PRIMARY_PROMPT, "grammar": PRIMARY_GRAMMAR},
        "mechanical_validity": validity,
        "comparisons": comparisons,
        "negative_literal_gate": negative,
        "gates": {
            "candidate_beats_bare_and_placebo": superiority,
            "overall_no_harm": no_harm,
            "family_safe": family_safe,
            "negative_literal_safe": negative["passed"],
        },
        "method_transfer": passed,
        "living_promotion_authorized": False,
    }
