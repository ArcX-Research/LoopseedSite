"""The plain register: what a reply may bear and still count as evidence.

A pictograph in the fish's own voice is a register failure — the fish slipping
out of the plain speech its company keeps — so a reply bearing one is refused
whole, as a training target and as a behavioural success alike. Refusing whole
is the only safe move: stripping the pictograph would launder a register
failure into clean-looking evidence, which is exactly the corruption the
refusal exists to prevent. One rule, so that training selection and behavioural
scoring cannot drift apart; they differ only in what they read, and on purpose.
The night refuses an exchange whose reply or prompt is decorated, both being
lived speech in the room, while a probe's prompt is written by the protocol
rather than by the fish, so scoring reads the reply alone.

The line is Unicode's own, with nothing added by taste. A text bears a
pictograph if it carries a code point with the Extended_Pictographic property,
a regional indicator, an emoji skin-tone modifier, a variation selector, a
combining enclosing keycap, or a tag character. Everything else stays
admissible: the operators, superscripts, subscripts, Greek letters, floors,
primes and box drawing the nine classrooms genuinely use are none of those
things, and neither is a bare digit.

Arrows split, so the promise is stated exactly rather than loosely. The
classrooms write → ← ↑ ↓ ↦ ⇒ ⟹ and every one of those is admitted; the
arrow-shaped emoji Unicode counts as pictographs are refused: ↔ ↕ ↖ ↗ ↘ ↙ ↩ ↪
⤴ ⤵ ⬅ ⬆ ⬇ ➡ ◀ ▶ ⏩ ⏪ and their kin above the BMP. ↔ is the one that can bite,
being ordinary writing for a correspondence, but no classroom reply in the body
uses it — bijections here are written ↦ and → — and carving it out is not free:
only seven pictographs carry Unicode's own math category, and four of them are
the decorative squares ◻ ◼ ◽ ◾ the fish already reaches for. So the refusal
stands: it is visible in the refusal record and one line to revisit, whereas a
hand-picked exception would make "nothing added by taste" false. The tests
execute both lists, so this paragraph cannot drift from the rule.

Marks are whole grapheme clusters under the emoji rules of UAX #29, so a keycap
names its digit, a flag its pair of indicators, and a joined family counts once
rather than four times.
"""

from __future__ import annotations

import unicodedata
from bisect import bisect_right
from collections.abc import Iterator
from typing import NamedTuple

# Extended_Pictographic (UTS #51 emoji-data.txt) at Unicode 15.1 — 156 ranges,
# 2848 code points, derived from the installed Unicode tables, never typed by
# hand. The property covers unassigned code points inside the emoji blocks, so a
# release goes stale here only when it adds a RANGE; nothing in this file would
# say so, which is why tests/test_plain_register.py re-derives it and names the drift.
_EXTENDED_PICTOGRAPHIC = (
    "00A9 00AE 203C 2049 2122 2139 2194-2199 21A9-21AA 231A-231B 2328 23CF 23E9-23F3 "
    "23F8-23FA 24C2 25AA-25AB 25B6 25C0 25FB-25FE 2600-2604 260E 2611 2614-2615 2618 "
    "261D 2620 2622-2623 2626 262A 262E-262F 2638-263A 2640 2642 2648-2653 265F-2660 "
    "2663 2665-2666 2668 267B 267E-267F 2692-2697 2699 269B-269C 26A0-26A1 26A7 "
    "26AA-26AB 26B0-26B1 26BD-26BE 26C4-26C5 26C8 26CE-26CF 26D1 26D3-26D4 26E9-26EA "
    "26F0-26F5 26F7-26FA 26FD 2702 2705 2708-270D 270F 2712 2714 2716 271D 2721 2728 "
    "2733-2734 2744 2747 274C 274E 2753-2755 2757 2763-2764 2795-2797 27A1 27B0 27BF "
    "2934-2935 2B05-2B07 2B1B-2B1C 2B50 2B55 3030 303D 3297 3299 1F004 1F02C-1F02F "
    "1F094-1F09F 1F0AF-1F0B0 1F0C0 1F0CF-1F0D0 1F0F6-1F0FF 1F170-1F171 1F17E-1F17F 1F18E "
    "1F191-1F19A 1F1AE-1F1E5 1F201-1F20F 1F21A 1F22F 1F232-1F23A 1F23C-1F23F 1F249-1F25F "
    "1F266-1F321 1F324-1F393 1F396-1F397 1F399-1F39B 1F39E-1F3F0 1F3F3-1F3F5 1F3F7-1F3FA "
    "1F400-1F4FD 1F4FF-1F53D 1F549-1F54E 1F550-1F567 1F56F-1F570 1F573-1F57A 1F587 "
    "1F58A-1F58D 1F590 1F595-1F596 1F5A4-1F5A5 1F5A8 1F5B1-1F5B2 1F5BC 1F5C2-1F5C4 "
    "1F5D1-1F5D3 1F5DC-1F5DE 1F5E1 1F5E3 1F5E8 1F5EF 1F5F3 1F5FA-1F64F 1F680-1F6C5 "
    "1F6CB-1F6D2 1F6D5-1F6E5 1F6E9 1F6EB-1F6F0 1F6F3-1F6FF 1F7DA-1F7FF 1F80C-1F80F "
    "1F848-1F84F 1F85A-1F85F 1F888-1F88F 1F8AE-1F8AF 1F8BC-1F8BF 1F8C2-1F8CF 1F8D9-1F8FF "
    "1F90C-1F93A 1F93C-1F945 1F947-1F9FF 1FA58-1FA5F 1FA6E-1FAFF 1FC00-1FFFD"
)

ZERO_WIDTH_JOINER = 0x200D
KEYCAP = 0x20E3
TEXT_PRESENTATION = 0xFE0E
EMOJI_PRESENTATION = 0xFE0F
REGIONAL_INDICATORS = range(0x1F1E6, 0x1F200)
SKIN_TONES = range(0x1F3FB, 0x1F400)
TAGS = range(0xE0000, 0xE0080)
_COMBINING = {"Mn", "Me", "Mc"}


def _spans(table: str) -> tuple[tuple[int, int], ...]:
    spans = []
    for token in table.split():
        low, _, high = token.partition("-")
        spans.append((int(low, 16), int(high or low, 16)))
    return tuple(spans)


PICTOGRAPHIC_RANGES = _spans(_EXTENDED_PICTOGRAPHIC)
_STARTS = tuple(low for low, _ in PICTOGRAPHIC_RANGES)
_ENDS = tuple(high for _, high in PICTOGRAPHIC_RANGES)


class Pictograph(NamedTuple):
    """One refused mark: where it starts, its whole cluster, and its class."""

    offset: int
    text: str
    kind: str


def pictographic(code_point: int) -> bool:
    """Extended_Pictographic, by binary search over the derived table."""
    span = bisect_right(_STARTS, code_point) - 1
    return span >= 0 and code_point <= _ENDS[span]


def _refuses(code_point: int) -> bool:
    return (
        pictographic(code_point)
        or code_point in REGIONAL_INDICATORS
        or code_point in SKIN_TONES
        or code_point in TAGS
        or code_point in (TEXT_PRESENTATION, EMOJI_PRESENTATION, KEYCAP)
    )


def _continues(code_point: int) -> bool:
    """A code point that rides on the cluster before it rather than opening one."""
    return (
        unicodedata.category(chr(code_point)) in _COMBINING
        or code_point in SKIN_TONES
        or code_point in TAGS
    )


def _cluster_end(text: str, start: int) -> int:
    """Consume one grapheme cluster under the emoji rules of UAX #29."""
    index = start + 1
    pair = text[start : start + 2]
    if len(pair) == 2 and all(ord(character) in REGIONAL_INDICATORS for character in pair):
        index += 1
    while index < len(text):
        code_point = ord(text[index])
        if _continues(code_point):
            index += 1
        elif (
            code_point == ZERO_WIDTH_JOINER
            and index + 1 < len(text)
            and pictographic(ord(text[index + 1]))
        ):
            index += 2
        else:
            break
    return index


def _kind(cluster: str) -> str:
    points = [ord(character) for character in cluster]
    if KEYCAP in points:
        return "keycap"
    if any(point in REGIONAL_INDICATORS for point in points):
        return "flag"
    if any(point in TAGS for point in points):
        return "tag-sequence"
    if ZERO_WIDTH_JOINER in points:
        return "joined-sequence"
    if any(point in SKIN_TONES for point in points):
        return "skin-tone"
    if any(pictographic(point) for point in points):
        return "pictograph"
    return "presentation-selector"


def _marks(text: str) -> Iterator[Pictograph]:
    index = 0
    while index < len(text):
        end = _cluster_end(text, index)
        cluster = text[index:end]
        if any(_refuses(ord(character)) for character in cluster):
            yield Pictograph(index, cluster, _kind(cluster))
        index = end


def pictographs(text: str) -> list[Pictograph]:
    """Every pictographic cluster in the text, in order, whole."""
    return list(_marks(text))


def first_pictograph(text: str) -> Pictograph | None:
    """The first refused mark, or None when the text keeps the plain register."""
    return next(_marks(text), None)
