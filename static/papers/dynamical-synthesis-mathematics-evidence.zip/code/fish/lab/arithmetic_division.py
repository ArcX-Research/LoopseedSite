"""Ground truth for Euclidean division and fraction reduction."""

from __future__ import annotations

import hashlib
import math
import re
from dataclasses import dataclass

from fish.lab.counted_structure import assignment_truth_with_tables

START_CYCLE = 4070
FRACTION_REPAIR_CYCLE = 4087
KINDS = ("quotient-remainder", "fraction-reduction")

METHODS = {
    "quotient-remainder": (
        "Use integer division. Write dividend = divisor · quotient + remainder and check "
        "0 ≤ remainder < divisor"
    ),
    "fraction-reduction": (
        "Use Euclid's algorithm. For a proper fraction the numerator is smaller than the "
        "denominator, so do not begin by dividing the numerator by the denominator. Start "
        "directly with denominator = quotient · numerator + remainder, where quotient ≥ 1 "
        "and 0 ≤ remainder < numerator. Then repeatedly use the preceding divisor and "
        "remainder until the remainder is zero. The last nonzero remainder is the greatest "
        "common divisor. Divide both original terms by it, reconstruct each original term "
        "in a separate multiplication identity, and check that the reduced terms have "
        "greatest common divisor one"
    ),
}


@dataclass(frozen=True)
class Problem:
    kind: str
    parameters: tuple[int, ...]

    @property
    def assignments(self) -> dict[str, int]:
        return states(self.kind, self.parameters)

    @property
    def method(self) -> str:
        return METHODS[self.kind]

    def prompt(self) -> str:
        return f"{statement(self.kind, self.parameters)} {requested_work(self.kind)}"

    def nudge(self) -> str:
        return f"{statement(self.kind, self.parameters)} {self.method}. {requested_work(self.kind)}"

    def repair(self) -> str:
        return (
            f"{statement(self.kind, self.parameters)} Your preceding calculation did not "
            f"satisfy every identity. The checked calculation is {self.record()}. Rewrite "
            "that calculation in ordinary mathematical notation."
        )

    def record(self) -> str:
        trace = self.assignments
        if self.kind == "quotient-remainder":
            dividend, divisor = self.parameters
            return (
                f"quotient = {trace['QUOTIENT']}; remainder = {trace['REMAINDER']}; "
                f"{dividend} = {divisor} · {trace['QUOTIENT']} + {trace['REMAINDER']}; "
                f"0 ≤ {trace['REMAINDER']} < {divisor}"
            )
        numerator, denominator = self.parameters
        chain = "; ".join(
            f"{left} = {quotient} · {right} + {remainder}"
            for left, right, quotient, remainder in euclidean_steps(numerator, denominator)
        )
        return (
            f"{chain}; gcd({numerator}, {denominator}) = {trace['GCD']}; "
            f"{numerator}/{denominator} = {trace['REDUCED_NUMERATOR']}/"
            f"{trace['REDUCED_DENOMINATOR']}; "
            f"{numerator} = {trace['GCD']} · {trace['REDUCED_NUMERATOR']}; "
            f"{denominator} = {trace['GCD']} · {trace['REDUCED_DENOMINATOR']}; "
            f"gcd({trace['REDUCED_NUMERATOR']}, {trace['REDUCED_DENOMINATOR']}) = 1"
        )


def euclidean_steps(numerator: int, denominator: int) -> tuple[tuple[int, int, int, int], ...]:
    if not 0 < numerator < denominator:
        raise ValueError("Euclidean fraction inputs must be positive and ordered")
    steps: list[tuple[int, int, int, int]] = []
    left, right = denominator, numerator
    while right:
        quotient, remainder = divmod(left, right)
        steps.append((left, right, quotient, remainder))
        left, right = right, remainder
    return tuple(steps)


def states(kind: str, parameters: tuple[int, ...]) -> dict[str, int]:
    if len(parameters) != 2:
        raise ValueError("division lessons require two parameters")
    first, second = parameters
    if kind == "quotient-remainder":
        dividend, divisor = first, second
        if not 2 <= divisor < dividend <= 999:
            raise ValueError("invalid quotient-remainder problem")
        quotient, remainder = divmod(dividend, divisor)
        if quotient < 2 or remainder == 0:
            raise ValueError("quotient-remainder problems require a nonzero remainder")
        product = divisor * quotient
        return {
            "QUOTIENT": quotient,
            "REMAINDER": remainder,
            "PRODUCT": product,
            "RECONSTRUCTED": product + remainder,
        }
    if kind == "fraction-reduction":
        numerator, denominator = first, second
        if not 2 <= numerator < denominator <= 250:
            raise ValueError("invalid fraction-reduction problem")
        divisor = euclidean_steps(numerator, denominator)[-1][1]
        if divisor == 1:
            raise ValueError("fraction-reduction problems must be reducible")
        reduced_numerator = numerator // divisor
        reduced_denominator = denominator // divisor
        if reduced_numerator == 1:
            raise ValueError("fraction-reduction problems require two non-unit reduced terms")
        return {
            "GCD": divisor,
            "REDUCED_NUMERATOR": reduced_numerator,
            "REDUCED_DENOMINATOR": reduced_denominator,
            "REDUCED_GCD": math.gcd(reduced_numerator, reduced_denominator),
            "CHECK_NUMERATOR": divisor * reduced_numerator,
            "CHECK_DENOMINATOR": divisor * reduced_denominator,
        }
    raise ValueError(f"unknown arithmetic division task: {kind}")


def statement(kind: str, parameters: tuple[int, ...]) -> str:
    if kind == "quotient-remainder":
        dividend, divisor = parameters
        return f"Quotient remainder: divide {dividend} by {divisor}."
    if kind == "fraction-reduction":
        numerator, denominator = parameters
        return f"Fraction reduction: reduce {numerator}/{denominator}."
    raise ValueError(f"unknown arithmetic division task: {kind}")


def requested_work(kind: str) -> str:
    if kind == "quotient-remainder":
        return (
            "State the quotient and remainder, then show the reconstruction identity and "
            "the remainder bound. Write only the calculation in ordinary mathematical "
            "notation, without field names."
        )
    if kind == "fraction-reduction":
        return (
            "Show every Euclidean division in order through remainder zero. Then state the "
            "greatest common divisor, the fraction in lowest terms, two separate "
            "multiplication identities reconstructing the original numerator and "
            "denominator, and the greatest common divisor of the reduced terms. Write only "
            "the calculation in ordinary mathematical notation, without field names."
        )
    raise ValueError(f"unknown arithmetic division task: {kind}")


def problem_from_prompt(prompt: str) -> Problem | None:
    quotient = re.search(
        r"Quotient-remainder state question:.*DIVIDEND=(\d+) and DIVISOR=(\d+)",
        prompt,
        re.IGNORECASE,
    )
    if quotient is not None:
        return Problem("quotient-remainder", tuple(int(value) for value in quotient.groups()))
    fraction = re.search(
        r"Fraction-reduction state question:.*NUMERATOR=(\d+) and DENOMINATOR=(\d+)",
        prompt,
        re.IGNORECASE,
    )
    if fraction is not None:
        return Problem("fraction-reduction", tuple(int(value) for value in fraction.groups()))
    quotient = re.search(r"\bdivide\s+(\d+)\s+by\s+(\d+)\b", prompt, re.IGNORECASE)
    if quotient is not None:
        return Problem("quotient-remainder", tuple(int(value) for value in quotient.groups()))
    fraction = re.search(
        r"\breduce(?:\s+the\s+fraction)?\s+(\d+)\s*/\s*(\d+)\b",
        prompt,
        re.IGNORECASE,
    )
    if fraction is not None:
        return Problem("fraction-reduction", tuple(int(value) for value in fraction.groups()))
    return None


def lesson_reply_lands(prompt: str, reply: str) -> bool | None:
    problem = problem_from_prompt(prompt)
    if problem is None:
        return None
    legacy_fields = re.search(
        r"\b(?:DIVIDEND|DIVISOR|NUMERATOR|DENOMINATOR)\s*=\s*\d+",
        prompt,
        re.IGNORECASE,
    )
    if legacy_fields is not None:
        return assignment_truth_with_tables(reply, problem.assignments)
    return natural_truth(problem, reply)


def natural_truth(problem: Problem, reply: str) -> bool:
    text = _normalized_notation(reply)
    if problem.kind == "quotient-remainder":
        return _quotient_truth(problem, text)
    return _fraction_truth(problem, text)


def _normalized_notation(reply: str) -> str:
    text = re.sub(
        r"\\(?:d|t)?frac\s*\{([^{}]+)\}\s*\{([^{}]+)\}",
        r"(\1)/(\2)",
        reply,
    )
    text = re.sub(r"\(\s*(\d+)\s*\)", r"\1", text)
    text = re.sub(r"\\text\s*\{([^{}]*)\}", r"\1", text)
    text = text.replace("\\gcd", "gcd").replace("\\div", "÷")
    text = text.replace("\\quad", " ").replace("\\Rightarrow", " ")
    text = text.replace("\\cdot", "·").replace("\\times", "·")
    text = re.sub(r"&(?=\s*=)", "", text)
    text = re.sub(r"\*\*([^*\n]+)\*\*", r"\1", text)
    text = text.replace("×", "·").replace("`", "").replace("$", "")
    text = text.replace("\\(", "").replace("\\)", "")
    return re.sub(r"(?<=\d)\s*(?:·|\*|[xX])\s*(?=\d)", " * ", text)


def _quotient_truth(problem: Problem, text: str) -> bool:
    dividend, divisor = problem.parameters
    trace = problem.assignments
    quotient, remainder = trace["QUOTIENT"], trace["REMAINDER"]
    quotient_claims = [
        int(value) for value in re.findall(r"\bquotient\s*(?:is|=|:)?\s*(\d+)\b", text, re.I)
    ]
    remainder_claims = [
        int(value) for value in re.findall(r"\bremainder\s*(?:is|=|:)?\s*(\d+)\b", text, re.I)
    ]
    if quotient not in quotient_claims or remainder not in remainder_claims:
        return False
    if any(value != quotient for value in quotient_claims):
        return False
    if any(value != remainder for value in remainder_claims):
        return False
    identities = [
        tuple(map(int, claim))
        for claim in re.findall(r"(\d+)\s*=\s*(\d+)\s*\*\s*(\d+)\s*\+\s*(\d+)", text)
    ]
    if not any(
        left == dividend
        and sorted((factor, multiple)) == sorted((divisor, quotient))
        and rest == remainder
        for left, factor, multiple, rest in identities
    ):
        return False
    if any(left != factor * multiple + rest for left, factor, multiple, rest in identities):
        return False
    bounds = [
        tuple(map(int, claim))
        for claim in re.findall(r"(\d+)\s*(?:≤|<=)\s*(\d+)\s*<\s*(\d+)", text)
    ]
    return (0, remainder, divisor) in bounds and all(
        left <= middle < right for left, middle, right in bounds
    )


def _fraction_truth(problem: Problem, text: str) -> bool:
    numerator, denominator = problem.parameters
    trace = problem.assignments
    divisor = trace["GCD"]
    reduced_numerator = trace["REDUCED_NUMERATOR"]
    reduced_denominator = trace["REDUCED_DENOMINATOR"]

    identity_chain = [
        tuple(map(int, claim))
        for claim in re.findall(r"(\d+)\s*=\s*(\d+)\s*\*\s*(\d+)\s*\+\s*(\d+)", text)
    ]
    division_chain = [
        tuple(map(int, claim))
        for claim in re.findall(
            r"(\d+)\s*(?:÷|/)\s*(\d+)\s*=\s*(\d+)\s*"
            r"r(?:em(?:ainder)?)?\s*:?\s*(\d+)\b",
            text,
            re.I,
        )
    ]
    expected_chain = list(euclidean_steps(numerator, denominator))
    if not identity_chain and not division_chain:
        return False
    if identity_chain and not _repeated_identity_chain_matches(identity_chain, expected_chain):
        return False
    if division_chain and not _repeated_exact_chain(division_chain, expected_chain):
        return False

    gcd_claims = _gcd_claims(text)
    original_pair = {numerator, denominator}
    reduced_pair = {reduced_numerator, reduced_denominator}
    original_values = [value for left, right, value in gcd_claims if {left, right} == original_pair]
    reduced_values = [value for left, right, value in gcd_claims if {left, right} == reduced_pair]
    original_values.extend(
        int(value)
        for value in re.findall(
            r"\b(?:greatest\s+common\s+divisor(?:\s*\(\s*gcd\s*\))?|gcd)"
            r"\s*(?:is|=|:)\s*(\d+)\b(?!\s*/)",
            text,
            re.I,
        )
    )
    reduced_values.extend(
        int(value)
        for value in re.findall(
            r"\b(?:gcd|greatest\s+common\s+divisor)\s+of\s+"
            r"(?:the\s+)?reduced\s+terms"
            r"(?:\s*\([^)]*\))?\s*(?:is|=|:)\s*(\d+)\b",
            text,
            re.I,
        )
    )
    if divisor not in original_values or 1 not in reduced_values:
        return False
    if any(value != divisor for value in original_values) or any(
        value != 1 for value in reduced_values
    ):
        return False

    ratio = re.search(
        rf"\b{numerator}\s*/\s*{denominator}\s*=\s*"
        rf"{reduced_numerator}\s*/\s*{reduced_denominator}\b",
        text,
    )
    ratio_via_division = re.search(
        rf"\b{numerator}\s*/\s*{denominator}\s*=\s*"
        rf"\(?\s*{numerator}\s*(?:÷|/)\s*{divisor}\s*\)?\s*/\s*"
        rf"\(?\s*{denominator}\s*(?:÷|/)\s*{divisor}\s*\)?\s*=\s*"
        rf"{reduced_numerator}\s*/\s*{reduced_denominator}\b",
        text,
    )
    reduced_via_division = re.search(
        rf"\b(?:fraction\s+in\s+lowest\s+terms|reduced\s+fraction)\s*"
        rf"(?:is)?\s*:?\s*\(?\s*{numerator}\s*(?:÷|/)\s*{divisor}\s*\)?\s*/\s*"
        rf"\(?\s*{denominator}\s*(?:÷|/)\s*{divisor}\s*\)?\s*=\s*"
        rf"{reduced_numerator}\s*/\s*{reduced_denominator}\b",
        text,
        re.I,
    )
    named_ratio = re.search(
        rf"\b(?:reduced\s+fraction|fraction\s+in\s+lowest\s+terms)\s*"
        rf"(?:is)?\s*:?\s*"
        rf"{reduced_numerator}\s*/\s*{reduced_denominator}\b",
        text,
        re.I,
    )
    if (
        ratio is None
        and ratio_via_division is None
        and reduced_via_division is None
        and named_ratio is None
    ):
        return False

    products = _multiplication_identities(text)
    if any(left != first * second for left, first, second in products):
        return False
    required = {
        (numerator, frozenset((divisor, reduced_numerator))),
        (denominator, frozenset((divisor, reduced_denominator))),
    }
    present = {(left, frozenset((first, second))) for left, first, second in products}
    return required <= present


def _gcd_claims(text: str) -> list[tuple[int, int, int]]:
    claims = [
        (int(left), int(right), int(value))
        for left, right, value in re.findall(
            r"\bgcd\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)\s*=\s*(\d+)", text, re.I
        )
    ]
    claims.extend(
        (int(left), int(right), int(value))
        for left, right, value in re.findall(
            r"\b(?:gcd|greatest\s+common\s+divisor)\s+of\s+"
            r"(\d+)\s+and\s+(\d+)\s+(?:is|=)\s*(\d+)\b",
            text,
            re.I,
        )
    )
    return claims


def _repeated_identity_chain_matches(
    written: list[tuple[int, ...]], expected: list[tuple[int, int, int, int]]
) -> bool:
    if not expected or len(written) % len(expected):
        return False
    for offset in range(0, len(written), len(expected)):
        chunk = written[offset : offset + len(expected)]
        if not all(
            left == expected_left
            and sorted((first, second)) == sorted((right, quotient))
            and remainder == expected_remainder
            for (left, first, second, remainder), (
                expected_left,
                right,
                quotient,
                expected_remainder,
            ) in zip(chunk, expected, strict=True)
        ):
            return False
    return True


def _repeated_exact_chain(
    written: list[tuple[int, ...]], expected: list[tuple[int, int, int, int]]
) -> bool:
    if not expected or len(written) % len(expected):
        return False
    return all(
        written[offset : offset + len(expected)] == expected
        for offset in range(0, len(written), len(expected))
    )


def _multiplication_identities(text: str) -> list[tuple[int, int, int]]:
    leftward = [
        (int(result), int(first), int(second))
        for result, first, second in re.findall(r"(\d+)\s*=\s*(\d+)\s*\*\s*(\d+)\b(?!\s*\+)", text)
    ]
    rightward = [
        (int(result), int(first), int(second))
        for first, second, result in re.findall(r"(\d+)\s*\*\s*(\d+)\s*=\s*(\d+)\b", text)
    ]
    return leftward + rightward


def lesson_format_lands(prompt: str, reply: str) -> bool | None:
    return lesson_reply_lands(prompt, reply)


def rehearse_method(cycle: int, problem: Problem) -> bool:
    return cycle >= FRACTION_REPAIR_CYCLE and problem.kind == "fraction-reduction"


def candidates(kind: str) -> list[tuple[int, ...]]:
    values: list[tuple[int, ...]]
    if kind == "quotient-remainder":
        values = [
            (dividend, divisor)
            for dividend in range(20, 1000)
            for divisor in range(2, min(dividend, 32))
            if dividend // divisor >= 2 and dividend % divisor
        ]
    elif kind == "fraction-reduction":
        values = [
            (numerator, denominator)
            for numerator in range(2, 201)
            for denominator in range(numerator + 1, 251)
            if math.gcd(numerator, denominator) > 1
            and numerator // math.gcd(numerator, denominator) > 1
        ]
    else:
        raise ValueError(f"unknown arithmetic division task: {kind}")
    values.sort(key=lambda item: hashlib.sha256(f"{kind}:{item}".encode()).digest())
    return values


def lesson_problem(cycle: int) -> tuple[Problem, int]:
    if cycle < START_CYCLE:
        raise ValueError(f"arithmetic division lessons begin at cycle {START_CYCLE}")
    if cycle >= FRACTION_REPAIR_CYCLE:
        occurrence = 8 + cycle - FRACTION_REPAIR_CYCLE
        pool = candidates("fraction-reduction")
        return Problem("fraction-reduction", pool[occurrence % len(pool)]), occurrence
    offset = cycle - START_CYCLE
    block, position = divmod(offset, 4)
    kind = KINDS[position // 2]
    occurrence = block * 2 + position % 2
    pool = candidates(kind)
    return Problem(kind, pool[occurrence % len(pool)]), occurrence
