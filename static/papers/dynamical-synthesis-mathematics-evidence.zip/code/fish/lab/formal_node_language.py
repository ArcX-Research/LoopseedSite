"""Lossless, bounded notation for describing a typed arithmetic AST.

The first claim-coat experiment described nested nodes with natural-language
``then`` separators.  Those separators did not say where a variadic child
ended, so a reader could attach a following argument to the wrong operation.
This notation is deliberately small and redundant: every operation declares
its arity, every child has a one-based ordinal, and brackets close every node.

It is a prompt language, not an evaluator.  ``parse`` exists so an experiment
can prove before inference that a rendered recipe reconstructs the exact
repository-owned AST.  No text from this language is executed.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from fish.lab import typed_ast_probe

NAME = "fish-formal-node-description-v1"
IDENTIFIER = re.compile(r"[A-Za-z][A-Za-z0-9_]{0,79}")
INTEGER = re.compile(r"-?(?:0|[1-9][0-9]{0,12})")


class NodeLanguageError(ValueError):
    """A node or its textual description crossed the bounded language."""


def _validate_operation(name: object, arguments: object) -> tuple[str, list[object]]:
    if not isinstance(name, str) or name not in typed_ast_probe.OPERATIONS:
        raise NodeLanguageError(f"unknown operation: {name!r}")
    if not isinstance(arguments, list):
        raise NodeLanguageError(f"{name}: arguments must be a list")
    minimum, maximum, _trusted_name = typed_ast_probe.OPERATIONS[name]
    if not minimum <= len(arguments) <= maximum:
        expected = str(minimum) if minimum == maximum else f"{minimum}..{maximum}"
        raise NodeLanguageError(f"{name}: expected {expected} arguments")
    return name, arguments


def _render(node: object, *, depth: int, budget: list[int]) -> str:
    if depth > typed_ast_probe.MAX_DEPTH:
        raise NodeLanguageError("node depth cap")
    budget[0] += 1
    if budget[0] > typed_ast_probe.MAX_NODES:
        raise NodeLanguageError("node count cap")
    if type(node) is int:
        if abs(node) > typed_ast_probe.MAX_INTEGER:
            raise NodeLanguageError("integer magnitude cap")
        return f"int<{node}>"
    if not isinstance(node, dict):
        raise NodeLanguageError("every node must be an integer or object")
    if set(node) == {"ref"}:
        reference = node["ref"]
        if not isinstance(reference, str) or IDENTIFIER.fullmatch(reference) is None:
            raise NodeLanguageError("reference is not a bounded identifier")
        return f"ref<{reference}>"
    if set(node) != {"op", "args"}:
        raise NodeLanguageError("node keys must be exactly op/args or ref")
    operation, arguments = _validate_operation(node["op"], node["args"])
    rendered = [
        f"{position}={_render(argument, depth=depth + 1, budget=budget)}"
        for position, argument in enumerate(arguments, start=1)
    ]
    return f"op<{operation}/{len(arguments)}>[{';'.join(rendered)}]"


def render(node: object) -> str:
    """Render one node with explicit arity, ordinals, and nested boundaries."""
    return _render(node, depth=0, budget=[0])


@dataclass
class _Cursor:
    text: str
    index: int = 0
    nodes: int = 0

    def expect(self, token: str) -> None:
        if not self.text.startswith(token, self.index):
            raise NodeLanguageError(f"expected {token!r} at byte {self.index}")
        self.index += len(token)

    def match(self, pattern: re.Pattern[str], label: str) -> str:
        found = pattern.match(self.text, self.index)
        if found is None:
            raise NodeLanguageError(f"expected {label} at byte {self.index}")
        self.index = found.end()
        return found.group(0)


def _parse(cursor: _Cursor, *, depth: int) -> object:
    if depth > typed_ast_probe.MAX_DEPTH:
        raise NodeLanguageError("node depth cap")
    cursor.nodes += 1
    if cursor.nodes > typed_ast_probe.MAX_NODES:
        raise NodeLanguageError("node count cap")
    if cursor.text.startswith("int<", cursor.index):
        cursor.expect("int<")
        value = int(cursor.match(INTEGER, "canonical integer"))
        cursor.expect(">")
        if abs(value) > typed_ast_probe.MAX_INTEGER:
            raise NodeLanguageError("integer magnitude cap")
        return value
    if cursor.text.startswith("ref<", cursor.index):
        cursor.expect("ref<")
        reference = cursor.match(IDENTIFIER, "reference identifier")
        cursor.expect(">")
        return {"ref": reference}
    cursor.expect("op<")
    operation = cursor.match(IDENTIFIER, "operation identifier")
    cursor.expect("/")
    arity_text = cursor.match(re.compile(r"(?:0|[1-9][0-9]?)"), "canonical arity")
    arity = int(arity_text)
    cursor.expect(">[")
    arguments: list[object] = []
    for position in range(1, arity + 1):
        if position > 1:
            cursor.expect(";")
        cursor.expect(f"{position}=")
        arguments.append(_parse(cursor, depth=depth + 1))
    cursor.expect("]")
    operation, arguments = _validate_operation(operation, arguments)
    return {"op": operation, "args": arguments}


def parse(description: str) -> object:
    """Parse only the canonical bounded notation emitted by :func:`render`."""
    if not isinstance(description, str) or not description:
        raise NodeLanguageError("description must be a nonempty string")
    if len(description.encode("utf-8")) > typed_ast_probe.JSON_CAP:
        raise NodeLanguageError("description size cap")
    cursor = _Cursor(description)
    node = _parse(cursor, depth=0)
    if cursor.index != len(description):
        raise NodeLanguageError(f"trailing text at byte {cursor.index}")
    if render(node) != description:
        raise NodeLanguageError("description is not canonical")
    return node


def checked_render(node: object) -> str:
    """Render and independently round-trip one recipe before it reaches Fish."""
    description = render(node)
    if parse(description) != node:
        raise NodeLanguageError("rendered node did not round-trip")
    return description
