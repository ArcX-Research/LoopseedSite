"""Seal and train a private direct-response dream from audited claim replies.

This is the bridge between the manual Claude/Fish formal classroom and a
disposable prediction coat.  It admits a reply only when the task-scoped ruler
proved it and Claude's latest whole-JSON audit accepted it.  The living body is
opened only to verify its pinned hash; datasets, adapters, and wearing remain
inside the private classroom clone.

The v2 corpus never feeds a conversational correction turn to the trainer.
The original teacher message remains immutable provenance, while the trainable
message is deterministically reconstructed from the already sealed task spec.
This prevents a rejected reply, an earlier task, or a teacher's explanation
from becoming an accidental completion cue.  The accepted Fish reply itself is
not rewritten.

The corpus split is deterministic.  Every admitted task family remains in the
training split, while distinct well-represented families contribute validation
and test witnesses.  A coat survives only when validation loss contracts and
the untouched test perplexity is finite.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import shutil
import sqlite3
import subprocess
from collections import Counter, defaultdict
from contextlib import closing
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from fish.lab import claim_conversation as conversation
from fish.lab import claim_evolution, claim_probe

ROOT = Path(__file__).resolve().parents[2]
LABS = ROOT / "data/fish/labs"
NIGHT_PYTHON = ROOT / "fish/night/.venv/bin/python"
MLX_MODEL = os.environ.get("FISH_MLX_MODEL", "mlx-community/Qwen3-8B-4bit")
ITERS = int(os.environ.get("FISH_CLAIM_DREAM_ITERS", "200"))
NUM_LAYERS = int(os.environ.get("FISH_CLAIM_DREAM_LAYERS", "16"))
MAX_SEQ = int(os.environ.get("FISH_CLAIM_DREAM_MAX_SEQ", "1024"))
MASK_PROMPT = "--mask-prompt"
WHOLE_WITNESS = ["--val-batches", "-1"]
NUMBER = r"(nan|-?inf|-?\d+(?:\.\d+)?)"
HEX64 = re.compile(r"[0-9a-f]{64}")
INTEGER_TOKEN = re.compile(r"(?<![A-Za-z0-9_])-?\d+(?![A-Za-z0-9_])")
SPLIT_SALT = "loopseed-claim-dream-v1"
MAX_TEXT_CHARS = 16_384
MAX_DATASET_BYTES = 32 * 1024 * 1024
INSTRUMENT_V1 = "private-claim-dream-v1"
INSTRUMENT_V2 = "private-claim-dream-v2"
CLEAN_PROMPT_POLICY = "sealed-spec-names-only-v1"


class DreamRefusal(ValueError):
    """The classroom evidence cannot safely become training data."""


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def _strict_json(text: str) -> Any:
    def unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        value = dict(pairs)
        if len(value) != len(pairs):
            raise DreamRefusal("accepted Fish JSON repeats a field")
        return value

    def refuse_constant(value: str) -> Any:
        raise DreamRefusal(f"accepted Fish JSON contains non-standard {value}")

    try:
        return json.loads(text, object_pairs_hook=unique, parse_constant=refuse_constant)
    except json.JSONDecodeError as error:
        raise DreamRefusal("accepted Fish reply is no longer strict JSON") from error


def _contains_negative_integer(value: Any) -> bool:
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return value < 0
    if isinstance(value, list):
        return any(_contains_negative_integer(item) for item in value)
    if isinstance(value, dict):
        return any(_contains_negative_integer(item) for item in value.values())
    return False


def _integer_literals(text: str) -> list[int]:
    """Return standalone decimal integers, excluding digits inside identifiers."""
    return [int(match.group()) for match in INTEGER_TOKEN.finditer(text)]


def _integer_leaves(value: Any) -> list[int]:
    if isinstance(value, bool):
        return []
    if isinstance(value, int):
        return [value]
    if isinstance(value, list):
        return [number for item in value for number in _integer_leaves(item)]
    if isinstance(value, dict):
        return [number for item in value.values() for number in _integer_leaves(item)]
    return []


def _clean_prompt(
    target: dict[str, Any], proposal: dict[str, Any]
) -> tuple[str, list[int], dict[str, Any]]:
    """Render SFT input from sealed task data, never from conversational text."""
    kind, parameters = claim_probe.validate_task_parameters(
        target.get("kind"), target.get("parameters")
    )
    prompt, allowed = claim_evolution.render_prompt(
        kind, parameters, target, claim_evolution.TRANSFER
    )
    prompt_literals = _integer_literals(prompt)
    negative_prompt = sorted({value for value in prompt_literals if value < 0})
    unlicensed_prompt = sorted(set(prompt_literals) - set(allowed))
    if negative_prompt:
        raise DreamRefusal("sealed-spec training prompt contains a negative integer literal")
    if unlicensed_prompt:
        raise DreamRefusal(
            f"sealed-spec training prompt contains unlicensed integer literals: {unlicensed_prompt}"
        )
    reply_literals = _integer_leaves(proposal)
    diagnostics = {
        "prompt_integer_literals": prompt_literals,
        "prompt_negative_literals": negative_prompt,
        "prompt_unlicensed_literals": unlicensed_prompt,
        "reply_integer_literals": reply_literals,
        "reply_unlicensed_literals": sorted(set(reply_literals) - set(allowed)),
    }
    return prompt, allowed, diagnostics


def _confined(path: Path, root: Path, label: str, *, must_exist: bool = True) -> Path:
    resolved = path.resolve(strict=must_exist)
    if not resolved.is_relative_to(root.resolve()):
        raise DreamRefusal(f"{label} must remain beneath {root}")
    return resolved


def _load_object(path: Path) -> dict[str, Any]:
    try:
        value = _strict_json(path.read_text())
    except OSError as error:
        raise DreamRefusal(f"missing dream evidence: {path}") from error
    if not isinstance(value, dict):
        raise DreamRefusal(f"dream evidence is not an object: {path}")
    return value


def _snapshot(source: Path, destination: Path) -> None:
    with closing(sqlite3.connect(f"file:{source.resolve()}?mode=ro", uri=True)) as src:
        with closing(sqlite3.connect(destination)) as dst:
            src.backup(dst)
    destination.chmod(0o444)


def _latest_accepted(database: sqlite3.Connection) -> list[tuple[Any, ...]]:
    return database.execute(
        "WITH latest AS ("
        " SELECT exchange_id, MAX(id) AS audit_id FROM claim_audits GROUP BY exchange_id"
        ") "
        "SELECT e.id, e.ts, e.you, e.i, e.speaker, e.kept, e.quarantined, "
        "e.soul_leak, e.voice_leak, r.verdict, r.disposition, r.spec_sha256, "
        "r.reply_sha256, r.record_json, r.finalized_after_grade, r.final_state, "
        "a.audited_at, a.reviewer, a.decision, "
        "a.reason, a.reply_sha256, a.review_sha256 "
        "FROM latest l JOIN claim_audits a ON a.id=l.audit_id "
        "JOIN claim_reviews r ON r.exchange_id=l.exchange_id "
        "JOIN exchanges e ON e.id=l.exchange_id "
        "WHERE a.decision='accepted' ORDER BY e.id"
    ).fetchall()


def _validate_instrument(record: dict[str, Any], metadata: dict[str, Any]) -> None:
    instrument = record.get("instrument")
    activation = metadata.get("task_scoped_ast")
    if not isinstance(instrument, dict) or not isinstance(activation, dict):
        raise DreamRefusal("accepted reply lacks its task-scoped instrument")
    fixed = {
        "voice_grammar": "typed_ast_v3a",
        "voice_grammar_generator_sha256": activation.get("voice_grammar_generator_sha256"),
        "daemon_binary_sha256": activation.get("daemon_binary_sha256"),
        "voice_decoder": activation.get("voice_decoder"),
    }
    if any(instrument.get(key) != value for key, value in fixed.items()):
        raise DreamRefusal("accepted reply differs from the activated task-scoped instrument")
    for key in (
        "voice_grammar_sha256",
        "voice_grammar_scope_sha256",
        "voice_grammar_generator_sha256",
        "daemon_binary_sha256",
    ):
        if not isinstance(instrument.get(key), str) or HEX64.fullmatch(instrument[key]) is None:
            raise DreamRefusal(f"accepted reply has an invalid instrument digest: {key}")


def _accepted_examples(
    room: Path,
    metadata: dict[str, Any],
    snapshot: Path,
    expect: int,
    terminal_exchange_id: int,
) -> list[dict[str, Any]]:
    with closing(sqlite3.connect(f"file:{snapshot.resolve()}?mode=ro", uri=True)) as database:
        rows = _latest_accepted(database)
    if len(rows) != expect:
        raise DreamRefusal(f"expected exactly {expect} latest accepted replies, found {len(rows)}")

    examples: list[dict[str, Any]] = []
    for row in rows:
        (
            exchange_id,
            timestamp,
            prompt,
            reply,
            speaker,
            kept,
            quarantined,
            soul_leak,
            voice_leak,
            verdict,
            disposition,
            spec_sha,
            review_reply_sha,
            review_json,
            finalized_after_grade,
            final_state,
            audited_at,
            reviewer,
            decision,
            reason,
            audit_reply_sha,
            audit_review_sha,
        ) = row
        exchange_id = int(exchange_id)
        prompt, reply, review_json = str(prompt), str(reply), str(review_json)
        if (
            verdict != "proved"
            or disposition != "eligible"
            or decision != "accepted"
            or reviewer != "claude"
        ):
            raise DreamRefusal(f"exchange #{exchange_id} lacks both required approvals")
        if speaker != metadata.get("speaker"):
            raise DreamRefusal(f"exchange #{exchange_id} belongs to another teacher voice")
        terminal_sigma_pending = (
            bool(quarantined)
            and exchange_id == terminal_exchange_id
            and not bool(finalized_after_grade)
            and final_state is None
        )
        if (
            (bool(quarantined) and not terminal_sigma_pending)
            or bool(soul_leak)
            or bool(voice_leak)
        ):
            raise DreamRefusal(f"exchange #{exchange_id} is sealed from training")
        if not prompt or not reply or len(prompt) > MAX_TEXT_CHARS or len(reply) > MAX_TEXT_CHARS:
            raise DreamRefusal(f"exchange #{exchange_id} has missing or oversized text")
        if reply != reply.strip() or "\n" in reply or "\r" in reply:
            raise DreamRefusal(f"exchange #{exchange_id} is not one raw JSON line")
        reply_sha = sha256_text(reply)
        if review_reply_sha != reply_sha or audit_reply_sha != reply_sha:
            raise DreamRefusal(f"exchange #{exchange_id} reply hash drifted")
        if audit_review_sha != sha256_text(review_json):
            raise DreamRefusal(f"exchange #{exchange_id} Claude audit names another review")

        proposal = _strict_json(reply)
        if not isinstance(proposal, dict) or set(proposal) != {"v", "facts"}:
            raise DreamRefusal(f"exchange #{exchange_id} is not a typed proposal object")
        if _contains_negative_integer(proposal):
            raise DreamRefusal(f"exchange #{exchange_id} contains a negative integer literal")

        record = _strict_json(review_json)
        if not isinstance(record, dict):
            raise DreamRefusal(f"exchange #{exchange_id} ruler record is not an object")
        if record.get("verdict") != "proved" or record.get("reply_sha256") != reply_sha:
            raise DreamRefusal(f"exchange #{exchange_id} ruler record no longer proves this reply")
        if record.get("language") != "fish-formal-ast-v1":
            raise DreamRefusal(f"exchange #{exchange_id} uses another formal language")
        _validate_instrument(record, metadata)

        if not isinstance(spec_sha, str) or HEX64.fullmatch(spec_sha) is None:
            raise DreamRefusal(f"exchange #{exchange_id} has an invalid spec digest")
        spec_path = room / "specs" / f"{spec_sha}.json"
        target = _load_object(spec_path)
        conversation.verify_spec(target, str(metadata["checker_sha256"]))
        claim_probe.verify_spec(target)
        if record.get("spec_sha256") != spec_sha:
            raise DreamRefusal(f"exchange #{exchange_id} ruler record names another task")

        reply_path = room / "replies" / f"{exchange_id}.txt"
        review_path = room / "reviews" / f"{exchange_id}.json"
        if reply_path.read_text() != reply or _load_object(review_path) != record:
            raise DreamRefusal(f"exchange #{exchange_id} artifacts differ from the clone ledger")
        kind = record.get("kind")
        if not isinstance(kind, str) or not kind or kind != target.get("kind"):
            raise DreamRefusal(f"exchange #{exchange_id} has no task family")
        training_prompt, allowed_literals, literal_diagnostics = _clean_prompt(target, proposal)
        source_literals = _integer_literals(prompt)
        source_negative = sorted({value for value in source_literals if value < 0})
        source_unlicensed = sorted(set(source_literals) - set(allowed_literals))
        examples.append(
            {
                "exchange_id": exchange_id,
                "timestamp": str(timestamp),
                "audited_at": str(audited_at),
                "reviewer": "claude",
                "audit_reason": str(reason),
                "kind": kind,
                "spec_sha256": spec_sha,
                "task_spec": target,
                "reply_sha256": reply_sha,
                "source_prompt": prompt,
                "source_prompt_sha256": sha256_text(prompt),
                "source_prompt_integer_literals": source_literals,
                "source_prompt_negative_literals": source_negative,
                "source_prompt_unlicensed_literals": source_unlicensed,
                "source_prompt_contaminated": bool(source_negative or source_unlicensed),
                "training_prompt_policy": CLEAN_PROMPT_POLICY,
                "training_prompt_sha256": sha256_text(training_prompt),
                "training_allowed_literals": allowed_literals,
                **literal_diagnostics,
                "kept_by_sigma": bool(kept),
                "terminal_sigma_pending": terminal_sigma_pending,
                "instrument": record["instrument"],
                "messages": [
                    {"role": "user", "content": training_prompt},
                    {"role": "assistant", "content": reply},
                ],
            }
        )
    return examples


def _order(value: str) -> str:
    return sha256_text(f"{SPLIT_SALT}\0{value}")


def split_examples(examples: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    """Hold out 10% twice, without removing any family from training."""
    if len(examples) < 10:
        raise DreamRefusal("a private claim dream needs at least ten accepted replies")
    witness_count = max(1, len(examples) // 10)
    by_kind: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for example in examples:
        by_kind[str(example["kind"])].append(example)
    eligible = sorted((kind for kind, rows in by_kind.items() if len(rows) >= 2), key=_order)
    if len(eligible) < 2 * witness_count:
        raise DreamRefusal("too few represented task families for separate validation and test")
    valid_kinds = set(eligible[:witness_count])
    test_kinds = set(eligible[witness_count : 2 * witness_count])
    held: dict[str, int] = {}
    for kind in valid_kinds | test_kinds:
        held[kind] = max(
            (int(row["exchange_id"]) for row in by_kind[kind]),
            key=lambda exchange_id: _order(f"{kind}\0{exchange_id}"),
        )
    splits: dict[str, list[dict[str, Any]]] = {"train": [], "valid": [], "test": []}
    for row in examples:
        kind, exchange_id = str(row["kind"]), int(row["exchange_id"])
        label = (
            "valid"
            if kind in valid_kinds and held[kind] == exchange_id
            else "test"
            if kind in test_kinds and held[kind] == exchange_id
            else "train"
        )
        row["dataset_split"] = label
        splits[label].append(row)
    if any(not rows for rows in splits.values()):
        raise DreamRefusal("claim dream produced an empty dataset split")
    trained_kinds = {str(row["kind"]) for row in splits["train"]}
    if trained_kinds != set(by_kind):
        raise DreamRefusal("claim dream removed a task family from training")
    return splits


def _write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True, ensure_ascii=False) + "\n")


def _bare(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [{"messages": row["messages"]} for row in rows]


def build_dataset(room: Path, out: Path, expect: int) -> dict[str, Any]:
    room = _confined(room, LABS, "claim classroom")
    out = _confined(out, room / "dreams", "claim dream output", must_exist=False)
    if out.exists():
        raise DreamRefusal(f"claim dream output already exists: {out}")
    metadata = _load_object(room / "conversation.json")
    state = _load_object(room / "state.json")
    if (
        state.get("phase") != "ready"
        or state.get("pending_exchange_id") is not None
        or state.get("pending_audit_exchange_id") is not None
    ):
        raise DreamRefusal("claim classroom must be settled before dreaming")
    if int(state.get("metrics", {}).get("audit_accepted", -1)) != expect:
        raise DreamRefusal("room counter does not match the requested accepted checkpoint")
    if conversation._pane_alive(str(metadata.get("tmux_target", ""))):
        raise DreamRefusal("stop the private Fish chair before freezing its dream")
    checker = Path(str(metadata.get("checker", "")))
    living = Path(str(metadata.get("living_body", "")))
    clone = Path(str(metadata.get("clone_body", "")))
    if sha256(checker) != metadata.get("checker_sha256"):
        raise DreamRefusal("the classroom checker changed before the dream was sealed")
    if sha256(living) != metadata.get("living_sha256"):
        raise DreamRefusal("the living body changed during the private classroom")
    _confined(clone, room / "body", "private clone")

    out.mkdir(parents=True)
    try:
        snapshot = out / "source.db"
        clone_sha = sha256(clone)
        _snapshot(clone, snapshot)
        terminal_exchange_id = state.get("last_exchange_id")
        if not isinstance(terminal_exchange_id, int):
            raise DreamRefusal("settled classroom has no terminal exchange id")
        examples = _accepted_examples(room, metadata, snapshot, expect, terminal_exchange_id)
        splits = split_examples(examples)
        for label in ("train", "valid", "test"):
            _write_jsonl(out / f"{label}.jsonl", _bare(splits[label]))
        _write_jsonl(out / "provenance.jsonl", examples)
        counts = {label: len(rows) for label, rows in splits.items()}
        kinds = dict(sorted(Counter(str(row["kind"]) for row in examples).items()))
        source_negative = [
            int(row["exchange_id"]) for row in examples if row["source_prompt_negative_literals"]
        ]
        source_contaminated = [
            int(row["exchange_id"]) for row in examples if row["source_prompt_contaminated"]
        ]
        reply_unlicensed = [
            int(row["exchange_id"]) for row in examples if row["reply_unlicensed_literals"]
        ]
        manifest = {
            "version": 2,
            "instrument": INSTRUMENT_V2,
            "objective": "audited typed-AST direct response from sealed-spec-only prompts",
            "created_at": datetime.now(UTC).isoformat(timespec="seconds"),
            "room": str(room),
            "room_state_sha256": sha256(room / "state.json"),
            "conversation_sha256": sha256(room / "conversation.json"),
            "source_clone": str(clone),
            "source_clone_sha256": clone_sha,
            "source_snapshot": str(snapshot),
            "source_snapshot_sha256": sha256(snapshot),
            "living_body": str(living),
            "living_sha256": str(metadata["living_sha256"]),
            "checker_sha256": str(metadata["checker_sha256"]),
            "voice_grammar": "typed_ast_v3a",
            "voice_grammar_generator_sha256": metadata["task_scoped_ast"][
                "voice_grammar_generator_sha256"
            ],
            "daemon_binary_sha256": metadata["task_scoped_ast"]["daemon_binary_sha256"],
            "admission_rule": (
                "latest Claude audit accepted AND task-scoped exact ruler proved; "
                "only the terminal accepted row may await its one-turn-late sigma grade; "
                "other sealed/negative/foreign rows refused"
            ),
            "training_prompt_rule": (
                "render names-only input deterministically from the sealed task spec; "
                "keep the original conversational turn only in provenance"
            ),
            "training_prompt_policy": CLEAN_PROMPT_POLICY,
            "prompt_generator": {
                "module": str(Path(str(claim_evolution.__file__)).resolve()),
                "sha256": sha256(Path(str(claim_evolution.__file__))),
                "stage": claim_evolution.TRANSFER,
            },
            "accepted": len(examples),
            "accepted_exchange_ids": [int(row["exchange_id"]) for row in examples],
            "counts": counts,
            "kinds": kinds,
            "coverage": {
                "families": len(kinds),
                "minimum_examples_per_family": min(kinds.values()),
                "maximum_examples_per_family": max(kinds.values()),
                "sparse_families_below_four": sorted(
                    kind for kind, count in kinds.items() if count < 4
                ),
            },
            "contamination_audit": {
                "source_prompts_with_negative_literals": len(source_negative),
                "source_prompt_negative_exchange_ids": source_negative,
                "source_prompts_with_foreign_literals": len(source_contaminated),
                "source_prompt_foreign_exchange_ids": source_contaminated,
                "training_prompts_with_negative_literals": 0,
                "training_prompts_with_unlicensed_literals": 0,
                "assistant_replies_with_negative_literals": 0,
                "assistant_replies_with_unlicensed_literals": len(reply_unlicensed),
                "assistant_reply_unlicensed_exchange_ids": reply_unlicensed,
            },
            "split_rule": (
                "deterministic 10% validation and 10% test from distinct represented "
                "families; every family retained in train"
            ),
            "hashes": {
                name: sha256(out / name)
                for name in (
                    "train.jsonl",
                    "valid.jsonl",
                    "test.jsonl",
                    "provenance.jsonl",
                    "source.db",
                )
            },
        }
        (out / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
        return manifest
    except BaseException:
        shutil.rmtree(out, ignore_errors=True)
        raise


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    if path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_DATASET_BYTES:
        raise DreamRefusal(f"missing, linked, or oversized dream data: {path}")
    rows: list[dict[str, Any]] = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line or len(line) > MAX_TEXT_CHARS * 4:
            raise DreamRefusal(f"invalid dream row {path.name}:{number}")
        value = _strict_json(line)
        if not isinstance(value, dict):
            raise DreamRefusal(f"dream row is not an object: {path.name}:{number}")
        rows.append(value)
    return rows


def _verify_clean_dataset(data: Path, manifest: dict[str, Any]) -> None:
    if manifest.get("training_prompt_policy") != CLEAN_PROMPT_POLICY:
        raise DreamRefusal("unknown clean training-prompt policy")
    generator = manifest.get("prompt_generator")
    if not isinstance(generator, dict):
        raise DreamRefusal("clean training-prompt generator is missing")
    generator_path = Path(str(generator.get("module", "")))
    if (
        generator_path.resolve() != Path(str(claim_evolution.__file__)).resolve()
        or not generator_path.is_file()
        or sha256(generator_path) != generator.get("sha256")
        or generator.get("stage") != claim_evolution.TRANSFER
    ):
        raise DreamRefusal("clean training-prompt generator changed")

    provenance = _read_jsonl(data / "provenance.jsonl")
    accepted = manifest.get("accepted")
    if (
        not isinstance(accepted, int)
        or accepted != len(provenance)
        or manifest.get("accepted_exchange_ids") != [row.get("exchange_id") for row in provenance]
    ):
        raise DreamRefusal("clean dream provenance count or order drifted")

    expected_splits: dict[str, list[dict[str, Any]]] = {
        "train": [],
        "valid": [],
        "test": [],
    }
    for row in provenance:
        exchange_id = row.get("exchange_id")
        spec_sha = row.get("spec_sha256")
        target = row.get("task_spec")
        messages = row.get("messages")
        source_prompt = row.get("source_prompt")
        if (
            not isinstance(exchange_id, int)
            or not isinstance(spec_sha, str)
            or HEX64.fullmatch(spec_sha) is None
            or not isinstance(target, dict)
            or target.get("spec_sha256") != spec_sha
            or not isinstance(source_prompt, str)
            or row.get("source_prompt_sha256") != sha256_text(source_prompt)
            or not isinstance(messages, list)
            or len(messages) != 2
        ):
            raise DreamRefusal("clean dream provenance row is malformed")
        user, assistant = messages
        if (
            not isinstance(user, dict)
            or user.get("role") != "user"
            or not isinstance(user.get("content"), str)
            or not isinstance(assistant, dict)
            or assistant.get("role") != "assistant"
            or not isinstance(assistant.get("content"), str)
        ):
            raise DreamRefusal(f"clean dream messages are malformed for #{exchange_id}")
        reply = str(assistant["content"])
        if row.get("reply_sha256") != sha256_text(reply):
            raise DreamRefusal(f"clean dream reply hash drifted for #{exchange_id}")
        proposal = _strict_json(reply)
        if not isinstance(proposal, dict) or _contains_negative_integer(proposal):
            raise DreamRefusal(f"clean dream reply is unsafe for #{exchange_id}")
        claim_probe.verify_spec(target)
        training_prompt, allowed, diagnostics = _clean_prompt(target, proposal)
        if (
            user["content"] != training_prompt
            or row.get("training_prompt_sha256") != sha256_text(training_prompt)
            or row.get("training_prompt_policy") != CLEAN_PROMPT_POLICY
            or row.get("training_allowed_literals") != allowed
            or any(row.get(key) != value for key, value in diagnostics.items())
        ):
            raise DreamRefusal(f"clean dream prompt drifted for #{exchange_id}")
        source_literals = _integer_literals(source_prompt)
        source_negative = sorted({value for value in source_literals if value < 0})
        source_unlicensed = sorted(set(source_literals) - set(allowed))
        if (
            row.get("source_prompt_integer_literals") != source_literals
            or row.get("source_prompt_negative_literals") != source_negative
            or row.get("source_prompt_unlicensed_literals") != source_unlicensed
            or row.get("source_prompt_contaminated")
            is not bool(source_negative or source_unlicensed)
        ):
            raise DreamRefusal(f"source-prompt provenance drifted for #{exchange_id}")
        split = row.get("dataset_split")
        if split not in expected_splits:
            raise DreamRefusal(f"clean dream has an unknown split for #{exchange_id}")
        expected_splits[str(split)].append({"messages": messages})

    counts = {label: len(rows) for label, rows in expected_splits.items()}
    if manifest.get("counts") != counts:
        raise DreamRefusal("clean dream split counts drifted")
    for label, expected in expected_splits.items():
        if _read_jsonl(data / f"{label}.jsonl") != expected:
            raise DreamRefusal(f"clean dream {label} rows differ from provenance")


def _verify_dataset(data: Path) -> dict[str, Any]:
    data = data.resolve(strict=True)
    manifest = _load_object(data / "manifest.json")
    instrument = manifest.get("instrument")
    if instrument not in {INSTRUMENT_V1, INSTRUMENT_V2}:
        raise DreamRefusal("unknown claim dream manifest")
    hashes = manifest.get("hashes")
    if not isinstance(hashes, dict):
        raise DreamRefusal("claim dream manifest has no hashes")
    for name, digest in hashes.items():
        if (
            not isinstance(name, str)
            or not isinstance(digest, str)
            or sha256(data / name) != digest
        ):
            raise DreamRefusal(f"claim dream dataset hash drift: {name}")
    living = Path(str(manifest.get("living_body", "")))
    if sha256(living) != manifest.get("living_sha256"):
        raise DreamRefusal("living body changed after the private dream was sealed")
    if instrument == INSTRUMENT_V2:
        if manifest.get("version") != 2:
            raise DreamRefusal("clean claim dream has the wrong version")
        _verify_clean_dataset(data, manifest)
    return manifest


def mlx_argv(data: Path, adapter: Path) -> list[str]:
    if ITERS < 1 or NUM_LAYERS < 1 or MAX_SEQ < 1:
        raise DreamRefusal("claim dream training controls must be positive")
    return [
        str(NIGHT_PYTHON),
        "-m",
        "mlx_lm.lora",
        "--model",
        MLX_MODEL,
        "--train",
        "--data",
        str(data),
        "--adapter-path",
        str(adapter),
        "--iters",
        str(ITERS),
        "--batch-size",
        "1",
        "--num-layers",
        str(NUM_LAYERS),
        "--max-seq-length",
        str(MAX_SEQ),
        *WHOLE_WITNESS,
        MASK_PROMPT,
    ]


def _validation_losses(text: str) -> list[float]:
    return [float(value) for value in re.findall(rf"Val loss {NUMBER}", text)]


def _test_perplexity(data: Path, adapter: Path) -> float:
    process = subprocess.run(
        [
            str(NIGHT_PYTHON),
            "-m",
            "mlx_lm.lora",
            "--model",
            MLX_MODEL,
            "--data",
            str(data),
            "--test",
            "--adapter-path",
            str(adapter),
            "--batch-size",
            "1",
            "--max-seq-length",
            str(MAX_SEQ),
            MASK_PROMPT,
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    output = process.stdout + process.stderr
    match = re.search(rf"Test ppl {NUMBER}", output)
    if process.returncode != 0 or match is None:
        raise RuntimeError(f"claim dream test witness could not be read:\n{output[-1000:]}")
    value = float(match.group(1))
    if not math.isfinite(value):
        raise RuntimeError("claim dream test witness is not finite")
    return value


def train(data: Path, adapter: Path) -> dict[str, Any]:
    data = data.resolve(strict=True)
    manifest = _verify_dataset(data)
    clone_home = Path(
        str(_load_object(Path(str(manifest["room"])) / "conversation.json")["clone_home"])
    )
    adapter = _confined(
        adapter, clone_home / "water/adapters", "private claim adapter", must_exist=False
    )
    if adapter.exists():
        raise DreamRefusal(f"private claim adapter already exists: {adapter}")
    adapter.mkdir(parents=True)
    process = subprocess.run(mlx_argv(data, adapter), capture_output=True, text=True, check=False)
    output = process.stdout + process.stderr
    (adapter / "train.log").write_text(output)
    losses = _validation_losses(output)
    contracted = (
        process.returncode == 0
        and len(losses) >= 2
        and math.isfinite(losses[0])
        and math.isfinite(losses[-1])
        and losses[-1] < losses[0]
    )
    test_perplexity: float | None = None
    if contracted:
        try:
            test_perplexity = _test_perplexity(data, adapter)
        except RuntimeError:
            contracted = False
    record = {
        "version": 1,
        "instrument": str(manifest["instrument"]),
        "status": "survived-private-witness" if contracted else "rejected-training",
        "objective": str(manifest["objective"]),
        "dreamed_at": datetime.now(UTC).isoformat(timespec="microseconds"),
        "dataset": str(data),
        "dataset_manifest_sha256": sha256(data / "manifest.json"),
        "accepted_pairs": int(manifest["accepted"]),
        "trained_pairs": int(manifest["counts"]["train"]),
        "validation_pairs": int(manifest["counts"]["valid"]),
        "test_pairs": int(manifest["counts"]["test"]),
        "validation_losses": losses,
        "validation_contracted": contracted,
        "test_perplexity": test_perplexity,
        "returncode": process.returncode,
        "model": MLX_MODEL,
        "iters": ITERS,
        "num_layers": NUM_LAYERS,
        "max_seq_length": MAX_SEQ,
        "scope": "private classroom clone only; no living-body promotion",
    }
    (adapter / "dream.json").write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    if not contracted:
        raise RuntimeError("claim dream did not pass its independent witnesses")
    return record


def _fresh(root: Path, prefix: str) -> Path:
    stamp = datetime.now(UTC).strftime("%Y-%m-%dT%H%M%S.%fZ")
    return root / f"{prefix}-{stamp}"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    build = sub.add_parser("build")
    build.add_argument("--room", type=Path, required=True)
    build.add_argument("--out", type=Path)
    build.add_argument("--expect", type=int, required=True)
    training = sub.add_parser("train")
    training.add_argument("dataset", type=Path)
    training.add_argument("--adapter", type=Path)
    args = parser.parse_args()

    if args.command == "build":
        out = args.out or _fresh(args.room / "dreams", "accepted")
        print(json.dumps(build_dataset(args.room, out, args.expect), indent=2))
        print(f"private claim dataset: {out}")
    else:
        manifest = _verify_dataset(args.dataset)
        metadata = _load_object(Path(str(manifest["room"])) / "conversation.json")
        adapter = args.adapter or _fresh(
            Path(str(metadata["clone_home"])) / "water/adapters", "claim-dream"
        )
        print(json.dumps(train(args.dataset, adapter), indent=2))
        print(f"private claim adapter: {adapter}")


if __name__ == "__main__":
    main()
