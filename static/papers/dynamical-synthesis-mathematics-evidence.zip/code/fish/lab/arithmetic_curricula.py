"""One registry for arithmetic-component curricula and their cycle epochs."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from fish.lab import (
    arithmetic_components,
    arithmetic_compositions,
    arithmetic_division,
    arithmetic_hierarchy,
    arithmetic_place_value,
    arithmetic_recomposition,
    arithmetic_substeps,
)

CURRICULA: tuple[Any, ...] = (
    arithmetic_components,
    arithmetic_substeps,
    arithmetic_compositions,
    arithmetic_place_value,
    arithmetic_hierarchy,
    arithmetic_recomposition,
    arithmetic_division,
)
ALL_KINDS = tuple(kind for curriculum in CURRICULA for kind in curriculum.KINDS)

# A measured field may revisit a family without changing kind ownership.
CYCLE_OVERRIDES = (
    (3926, arithmetic_place_value),
    (4070, arithmetic_division),
)


def for_cycle(cycle: int):
    for start, curriculum in sorted(CYCLE_OVERRIDES, key=lambda item: item[0], reverse=True):
        if cycle >= start:
            return curriculum
    for curriculum in reversed(CURRICULA):
        if cycle >= curriculum.START_CYCLE:
            return curriculum
    return CURRICULA[0]


def for_kind(kind: str):
    for curriculum in CURRICULA:
        if kind in curriculum.KINDS:
            return curriculum
    raise ValueError(f"unknown arithmetic component: {kind}")


def source_path(kind: str) -> Path:
    curriculum = for_kind(kind)
    return Path(str(curriculum.__file__)).resolve()
