"""Teacher-blind, coat-to-coat measurement of adaptive evolution.

The retained coat and body are frozen before more teaching. Once the next coat
exists, its content hash deterministically generates the exact transfer probes
and matched request seeds. Both coats then run on both the pre- and
post-teaching bodies, separating memory, weight, interaction, and total change.
Every probe gets a fresh synthesis chair and every body is disposable.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import copy
import hashlib
import json
import math
import os
import platform
import random
import re
import shutil
import signal
import socket
import sqlite3
import stat
import subprocess
import tempfile
import threading
import time
import urllib.error
import urllib.request
from contextlib import AbstractContextManager
from datetime import UTC, datetime
from pathlib import Path
from types import TracebackType
from typing import Any, Callable, TypeVar

from fish.lab.adaptive_scoring import (
    SCORERS,
    is_prime,
    one_sided_sign_p,
    protocol_leaks,
    score_reply,
)

REPO = Path(__file__).resolve().parents[2]
DEFAULT_BINARY = REPO / "fish" / "daemon" / "target" / "debug" / "fish-daemon"
DEFAULT_BASE = REPO / "fish" / "water" / "base.gguf"
DEFAULT_SERVER = Path(shutil.which("llama-server") or "llama-server")
T = TypeVar("T")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def process_start_sha256(pid: int) -> str | None:
    """Return a stable OS start identity, or None when the process is absent/unreadable."""
    checked = subprocess.run(
        ["ps", "-o", "lstart=", "-p", str(pid)],
        capture_output=True,
        text=True,
        check=False,
    )
    identity = checked.stdout.strip()
    if checked.returncode != 0 or not identity:
        return None
    return hashlib.sha256(identity.encode()).hexdigest()


def process_is_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError as error:
        raise RuntimeError(f"cannot establish whether water pid {pid} is alive") from error
    checked = subprocess.run(
        ["ps", "-o", "stat=", "-p", str(pid)],
        capture_output=True,
        text=True,
        check=False,
    )
    return checked.returncode == 0 and not checked.stdout.strip().startswith("Z")


def manifest_sha256(paths: list[Path]) -> str:
    digest = hashlib.sha256()
    for path in sorted((path.resolve() for path in paths), key=lambda item: str(item)):
        relative = path.relative_to(REPO.resolve())
        digest.update(str(relative).encode())
        digest.update(b"\0")
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
        digest.update(b"\0")
    return digest.hexdigest()


def daemon_source_sha256() -> str:
    paths = list((REPO / "fish" / "daemon" / "src").rglob("*.rs"))
    paths += [REPO / "fish" / "daemon" / "Cargo.toml", REPO / "fish" / "daemon" / "Cargo.lock"]
    return manifest_sha256(paths)


def embedder_sha256() -> str:
    paths = [
        path
        for path in (REPO / "fish" / "water" / "embedders").rglob("*")
        if path.is_file() and path.suffix != ".lock"
    ]
    return manifest_sha256(paths)


def load_plan(path: Path) -> dict[str, Any]:
    plan = json.loads(path.read_text())
    if plan.get("version") != 1:
        raise ValueError("adaptive plan version must be 1")
    if int(plan["derivation"]["request_seed_count"]) < 3:
        raise ValueError("at least three matched request seeds are required")
    probe_ids = [probe["id"] for probe in plan["fixed_probes"]]
    if len(probe_ids) != len(set(probe_ids)):
        raise ValueError("fixed probe ids must be unique")
    domains = set(plan["domains"])
    for pattern in plan["global_reject"]:
        re.compile(pattern, re.IGNORECASE)
    for probe in plan["fixed_probes"]:
        if probe["domain"] not in domains:
            raise ValueError(f"unknown domain for {probe['id']}: {probe['domain']}")
        if probe["scorer"]["type"] not in SCORERS:
            raise ValueError(f"unknown scorer for {probe['id']}")
    return plan


def server_version(server: Path) -> str:
    return subprocess.check_output(
        [str(server), "--version"], text=True, stderr=subprocess.STDOUT
    ).strip()


def validate_pins(plan: dict[str, Any], args: argparse.Namespace) -> None:
    pins = plan["pins"]
    actual = {
        "adaptive_evolution_sha256": sha256(Path(__file__)),
        "adaptive_scoring_sha256": sha256(REPO / "fish" / "lab" / "adaptive_scoring.py"),
        "soul_sha256": sha256(REPO / "SOUL.md"),
        "base_sha256": sha256(args.base),
        "daemon_binary_sha256": sha256(args.binary),
        "daemon_source_sha256": daemon_source_sha256(),
        "embedder_sha256": embedder_sha256(),
        "python": platform.python_version(),
        "llama_server": server_version(args.server),
    }
    drift = {
        name: {"expected": pins.get(name), "actual": value}
        for name, value in actual.items()
        if pins.get(name) != value
    }
    if drift:
        raise ValueError(f"measurement runtime drift: {json.dumps(drift, indent=2)}")


def max_exchange_id(body: Path) -> int:
    with sqlite3.connect(f"file:{body.resolve()}?mode=ro", uri=True) as db:
        return int(db.execute("SELECT COALESCE(MAX(id), 0) FROM exchanges").fetchone()[0])


def numbers_in(body: Path) -> set[str]:
    numbers: set[str] = set()
    with sqlite3.connect(f"file:{body.resolve()}?mode=ro", uri=True) as db:
        for you, reply in db.execute("SELECT you, i FROM exchanges"):
            numbers.update(re.findall(r"\d+", f"{you}\n{reply}"))
        tables = {
            str(row[0]) for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")
        }
        if "verified_lessons" in tables:
            for parameters, query, content in db.execute(
                "SELECT parameters_json, query_text, content FROM verified_lessons WHERE active=1"
            ):
                numbers.update(re.findall(r"\d+", f"{parameters}\n{query}\n{content}"))
    return numbers


def derived_rng(plan_sha: str, candidate_sha: str, label: str) -> random.Random:
    material = f"adaptive-evolution-v1\0{plan_sha}\0{candidate_sha}\0{label}".encode()
    return random.Random(int.from_bytes(hashlib.sha256(material).digest()))


def choose_unique(
    candidates: list[Any], count: int, rng: random.Random, key: Any, seen: set[str]
) -> list[Any]:
    rng.shuffle(candidates)
    selected = []
    used: set[str] = set()
    for candidate in candidates:
        token = str(key(candidate))
        if token in seen or token in used:
            continue
        selected.append(candidate)
        used.add(token)
        if len(selected) == count:
            return selected
    raise ValueError(f"only {len(selected)} unseen candidates available; need {count}")


def factor_probes(
    family: dict[str, Any], rng: random.Random, seen: set[str]
) -> list[dict[str, Any]]:
    primes = [
        value
        for value in range(int(family["prime_min"]), int(family["prime_max"]) + 1)
        if is_prime(value)
    ]
    balanced = [(left, right) for i, left in enumerate(primes) for right in primes[i + 1 :]]
    balanced = [pair for pair in balanced if pair[1] / pair[0] <= 1.35]
    small = [prime for prime in primes if prime <= int(family["small_factor_max"])]
    large = [prime for prime in primes if prime >= int(family["large_factor_min"])]
    unbalanced = [(left, right) for left in small for right in large]
    selected = choose_unique(
        balanced,
        int(family["balanced_count"]),
        rng,
        lambda pair: pair[0] * pair[1],
        seen,
    )
    used = seen | {str(left * right) for left, right in selected}
    selected += choose_unique(
        unbalanced,
        int(family["unbalanced_count"]),
        rng,
        lambda pair: pair[0] * pair[1],
        used,
    )
    probes = []
    for index, (left, right) in enumerate(selected, start=1):
        target = left * right
        probes.append(
            {
                "id": f"transfer-factor-{index:02d}",
                "domain": "transfer",
                "prompt": (
                    f"Factor {target} completely. Return one equality containing only integers, "
                    "an equals sign, multiplication signs, and optional exponents."
                ),
                "scorer": {"type": "factorization", "target": target},
                "novel_tokens": [str(target)],
            }
        )
    return probes


def classification_probes(
    family: dict[str, Any], rng: random.Random, seen: set[str]
) -> list[dict[str, Any]]:
    values = range(int(family["minimum"]), int(family["maximum"]) + 1)
    primes = [value for value in values if is_prime(value)]
    composites = [
        value
        for value in values
        if value % 2 == 1 and not is_prime(value) and all(value % divisor for divisor in (3, 5))
    ]
    selected = [
        (value, "PRIME")
        for value in choose_unique(
            primes, int(family["prime_count"]), rng, lambda value: value, seen
        )
    ]
    used = seen | {str(value) for value, _ in selected}
    selected += [
        (value, "COMPOSITE")
        for value in choose_unique(
            composites,
            int(family["composite_count"]),
            rng,
            lambda value: value,
            used,
        )
    ]
    rng.shuffle(selected)
    return [
        {
            "id": f"transfer-classify-{index:02d}",
            "domain": "transfer",
            "prompt": f"Classify {value}. Reply with PRIME or COMPOSITE only.",
            "scorer": {"type": "exact", "accepted": [answer]},
            "novel_tokens": [str(value)],
        }
        for index, (value, answer) in enumerate(selected, start=1)
    ]


def linear_probes(family: dict[str, Any], rng: random.Random) -> list[dict[str, Any]]:
    variables = list("xyzwuv")
    probes: list[dict[str, Any]] = []
    used: set[tuple[int, int, int]] = set()
    while len(probes) < int(family["count"]):
        coefficient = rng.randint(3, 17)
        solution = rng.choice([value for value in range(-12, 13) if value])
        offset = rng.randint(-29, 29)
        key = (coefficient, solution, offset)
        if key in used:
            continue
        used.add(key)
        result = coefficient * solution + offset
        variable = variables[len(probes)]
        sign = "+" if offset >= 0 else "-"
        prompt = (
            f"Solve {coefficient}{variable} {sign} {abs(offset)} = {result}. "
            f"Reply only in the form {variable} = integer."
        )
        probes.append(
            {
                "id": f"transfer-linear-{len(probes) + 1:02d}",
                "domain": "transfer",
                "prompt": prompt,
                "scorer": {"type": "linear", "variable": variable, "value": solution},
            }
        )
    return probes


def modular_probes(family: dict[str, Any], rng: random.Random) -> list[dict[str, Any]]:
    moduli = [value for value in range(29, 98) if is_prime(value)]
    probes = []
    for index in range(int(family["power_count"])):
        modulus = rng.choice(moduli)
        base = rng.randint(2, modulus - 2)
        exponent = rng.randint(11, 43)
        probes.append(
            {
                "id": f"transfer-mod-power-{index + 1:02d}",
                "domain": "transfer",
                "prompt": (
                    f"Compute {base} to the power {exponent} modulo {modulus}. "
                    "Reply with the integer residue only."
                ),
                "scorer": {"type": "integer", "value": pow(base, exponent, modulus)},
            }
        )
    for index in range(int(family["inverse_count"])):
        modulus = rng.choice(moduli)
        value = rng.randint(2, modulus - 2)
        probes.append(
            {
                "id": f"transfer-mod-inverse-{index + 1:02d}",
                "domain": "transfer",
                "prompt": (
                    f"Find the least positive inverse of {value} modulo {modulus}. "
                    "Reply with the integer only."
                ),
                "scorer": {"type": "integer", "value": pow(value, -1, modulus)},
            }
        )
    for index in range(int(family["gcd_count"])):
        common = rng.choice([value for value in range(7, 44) if is_prime(value)])
        left_scale = rng.choice([value for value in range(11, 40) if value % common])
        right_scale = rng.choice(
            [value for value in range(41, 80) if math.gcd(left_scale, value) == 1]
        )
        left, right = common * left_scale, common * right_scale
        probes.append(
            {
                "id": f"transfer-gcd-{index + 1:02d}",
                "domain": "transfer",
                "prompt": (
                    f"Compute the greatest common divisor of {left} and {right}. "
                    "Reply with the integer only."
                ),
                "scorer": {"type": "integer", "value": common},
            }
        )
    return probes


def instantiate_protocol(
    plan: dict[str, Any], plan_sha: str, candidate_sha: str, pre_body: Path, post_body: Path
) -> dict[str, Any]:
    seen = numbers_in(pre_body) | numbers_in(post_body)
    families = plan["probe_families"]
    probes = copy.deepcopy(plan["fixed_probes"])
    probes += factor_probes(
        families["factorization"], derived_rng(plan_sha, candidate_sha, "factor"), seen
    )
    probes += classification_probes(
        families["classification"], derived_rng(plan_sha, candidate_sha, "classification"), seen
    )
    probes += linear_probes(families["linear"], derived_rng(plan_sha, candidate_sha, "linear"))
    probes += modular_probes(families["modular"], derived_rng(plan_sha, candidate_sha, "modular"))
    seed_rng = derived_rng(plan_sha, candidate_sha, "request-seeds")
    seeds = [
        seed_rng.randrange(1, 2**31) for _ in range(int(plan["derivation"]["request_seed_count"]))
    ]
    protocol = {
        "version": 1,
        "name": plan["name"],
        "derived_from_plan_sha256": plan_sha,
        "candidate_coat_sha256": candidate_sha,
        "seeds": seeds,
        "domains": plan["domains"],
        "adaptive_domains": plan["adaptive_domains"],
        "controls": plan["controls"],
        "global_reject": plan["global_reject"],
        "probes": probes,
        "decision_rule": plan["decision_rule"],
    }
    probe_ids = [probe["id"] for probe in probes]
    if len(probe_ids) != len(set(probe_ids)):
        raise ValueError("derived probe ids are not unique")
    return protocol


def ensure_port_free(port: int) -> None:
    with socket.socket() as probe:
        if probe.connect_ex(("127.0.0.1", port)) == 0:
            raise RuntimeError(f"measurement port {port} is already in use")


class WaterServer(AbstractContextManager["WaterServer"]):
    def __init__(
        self,
        executable: Path,
        base: Path,
        coat: Path,
        port: int,
        context: int,
        parallel: int,
        log_path: Path,
        warm_scale: float = 1.0,
    ) -> None:
        self.executable = executable
        self.base = base
        self.coat = coat
        self.port = port
        self.context = context
        self.parallel = parallel
        self.log_path = log_path
        self.warm_scale = warm_scale
        self.process: subprocess.Popen[str] | None = None
        self._log: Any = None

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    @property
    def command(self) -> list[str]:
        return [
            str(self.executable),
            "-m",
            str(self.base),
            "--port",
            str(self.port),
            "-c",
            str(self.context),
            "-np",
            str(self.parallel),
            "--reasoning-budget",
            "0",
            "--repeat-penalty",
            "1.1",
            "--lora",
            str(self.coat),
        ]

    def __enter__(self) -> WaterServer:
        ensure_port_free(self.port)
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self._log = self.log_path.open("x")
        try:
            self.process = subprocess.Popen(
                self.command,
                cwd=REPO,
                stdout=self._log,
                stderr=subprocess.STDOUT,
                text=True,
                start_new_session=True,
            )
            self._wait_ready()
            self._warm()
        except BaseException:
            self.close()
            raise
        return self

    @property
    def returncode(self) -> int | None:
        return self.process.poll() if self.process is not None else None

    @property
    def alive(self) -> bool:
        return self.process is not None and self.process.poll() is None

    def _wait_ready(self) -> None:
        deadline = time.monotonic() + 180
        while time.monotonic() < deadline:
            if self.process is None or self.process.poll() is not None:
                raise RuntimeError(f"water exited during load; see {self.log_path}")
            try:
                with urllib.request.urlopen(f"{self.url}/health", timeout=2) as reply:
                    if reply.status == 200:
                        return
            except (OSError, urllib.error.URLError):
                pass
            time.sleep(0.5)
        raise TimeoutError(f"water did not become ready; see {self.log_path}")

    def _warm(self) -> None:
        body = {
            "messages": [{"role": "user", "content": "Reply with READY only. /no_think"}],
            "max_tokens": 8,
            "seed": 104729,
            "lora": [{"id": 0, "scale": self.warm_scale}],
        }
        request = urllib.request.Request(
            f"{self.url}/v1/chat/completions",
            json.dumps(body).encode(),
            {"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(request, timeout=60):
            pass

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        self.close()

    def close(self) -> None:
        if self.process is not None and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=5)
        if self._log is not None:
            self._log.close()
            self._log = None


def _atomic_json(path: Path, value: Any) -> None:
    """Durably replace one mutable runtime journal without exposing partial JSON."""
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    temporary = path.parent / f".{path.name}.{os.getpid()}.{time.time_ns()}.tmp"
    descriptor: int | None = None
    try:
        descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        remaining = memoryview(encoded)
        while remaining:
            written = os.write(descriptor, remaining)
            if written <= 0:
                raise OSError("water-epochs: journal write made no progress")
            remaining = remaining[written:]
        os.fsync(descriptor)
        os.close(descriptor)
        descriptor = None
        os.replace(temporary, path)
        directory = os.open(path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if descriptor is not None:
            os.close(descriptor)
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass


class RecoveringWaterServer(AbstractContextManager["RecoveringWaterServer"]):
    """One outcome-blind, restartable measurement server with an immutable epoch trail.

    A probe is accepted only if the exact server epoch that began it is still alive when it
    finishes.  If that process exited, the probe result is discarded, a new epoch starts under
    the same command, and the caller reruns only that uncheckpointed probe.  The shared lock also
    makes two concurrent probe workers converge on one replacement epoch.

    The epoch journal survives a runner crash.  A later, explicitly authorised transaction
    recovery marks the unfinished epoch interrupted and continues with the next ordinal; it never
    overwrites a log or resets the configured epoch ceiling.
    """

    INSTRUMENT = "water-server-epochs-v1"

    def __init__(
        self,
        executable: Path,
        base: Path,
        coat: Path,
        port: int,
        context: int,
        parallel: int,
        root: Path,
        *,
        max_epochs: int,
        warm_scale: float = 1.0,
    ) -> None:
        if max_epochs <= 0:
            raise ValueError("water-epochs: max_epochs must be positive")
        self.executable = executable
        self.base = base
        self.coat = coat
        self.port = port
        self.context = context
        self.parallel = parallel
        self.root = root
        self.max_epochs = max_epochs
        self.warm_scale = warm_scale
        self.manifest_path = root / "water-epochs.json"
        self._lock = threading.RLock()
        self._server: WaterServer | None = None
        self._generation = 0
        self._journal: dict[str, Any] = {}

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    @property
    def command(self) -> list[str]:
        return WaterServer(
            self.executable,
            self.base,
            self.coat,
            self.port,
            self.context,
            self.parallel,
            Path("unused"),
            self.warm_scale,
        ).command

    def _configuration(self) -> dict[str, Any]:
        return {
            "command": self.command,
            "port": self.port,
            "context": self.context,
            "parallel": self.parallel,
            "warm_scale": self.warm_scale,
            "max_epochs": self.max_epochs,
        }

    @staticmethod
    def _canonical_sha256(value: Any) -> str:
        return hashlib.sha256(
            json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()

    def _load_journal(self) -> None:
        configuration = self._configuration()
        configuration_sha = self._canonical_sha256(configuration)
        if self.manifest_path.exists():
            if self.manifest_path.is_symlink() or not self.manifest_path.is_file():
                raise RuntimeError("water-epochs: journal is not a regular file")
            value = json.loads(self.manifest_path.read_text())
            if (
                not isinstance(value, dict)
                or value.get("instrument") != self.INSTRUMENT
                or value.get("configuration") != configuration
                or value.get("configuration_sha256") != configuration_sha
                or not isinstance(value.get("epochs"), list)
            ):
                raise RuntimeError("water-epochs: existing journal configuration drifted")
            self._journal = value
            changed = False
            for index, epoch in enumerate(self._journal["epochs"], start=1):
                expected = self.root / "water" / f"epoch-{index:03d}.log"
                if (
                    not isinstance(epoch, dict)
                    or epoch.get("ordinal") != index
                    or Path(str(epoch.get("log") or "")) != expected
                ):
                    raise RuntimeError("water-epochs: existing epoch trail is malformed")
                if epoch.get("status") == "starting" and not expected.exists():
                    expected.parent.mkdir(parents=True, exist_ok=True)
                    expected.open("x").close()
                    epoch.update(
                        {
                            "status": "interrupted-before-start",
                            "ended_unix": int(time.time()),
                            "exit_code": None,
                            "log_sha256": sha256(expected),
                            "bytes": 0,
                        }
                    )
                    changed = True
                if not expected.is_file() or expected.is_symlink():
                    raise RuntimeError("water-epochs: existing epoch log is not a regular file")
                if epoch.get("status") == "starting":
                    raise RuntimeError(
                        "water-epochs: a starting epoch has a log but no bound process identity"
                    )
                if epoch.get("status") == "running":
                    self._retire_orphan_locked(epoch)
                    epoch["status"] = "interrupted"
                    epoch["ended_unix"] = int(time.time())
                    epoch["exit_code"] = None
                    epoch["log_sha256"] = sha256(expected)
                    epoch["bytes"] = expected.stat().st_size
                    changed = True
                status = epoch.get("status")
                if status not in {
                    "closed",
                    "server-exited",
                    "interrupted",
                    "interrupted-before-start",
                    "runner-error",
                    "startup-failed",
                }:
                    raise RuntimeError(f"water-epochs: unknown epoch status {status!r}")
                if (
                    epoch.get("log_sha256") != sha256(expected)
                    or epoch.get("bytes") != expected.stat().st_size
                ):
                    raise RuntimeError("water-epochs: a closed epoch log changed")
            if changed:
                _atomic_json(self.manifest_path, self._journal)
        else:
            self._journal = {
                "version": 1,
                "instrument": self.INSTRUMENT,
                "configuration": configuration,
                "configuration_sha256": configuration_sha,
                "epochs": [],
            }
            _atomic_json(self.manifest_path, self._journal)

    def _retire_orphan_locked(self, epoch: dict[str, Any]) -> None:
        """Stop only the exact prior epoch process after its parent runner is known dead."""
        pid = epoch.get("pid")
        identity = epoch.get("pid_start_sha256")
        if type(pid) is not int or not isinstance(identity, str) or not identity:
            raise RuntimeError("water-epochs: running epoch lacks a bound process identity")
        if not process_is_alive(pid):
            return
        if process_start_sha256(pid) != identity:
            raise RuntimeError("water-epochs: running epoch pid was reused; refusing to signal it")
        try:
            if os.getpgid(pid) != pid:
                raise RuntimeError("water-epochs: epoch process no longer owns its process group")
        except ProcessLookupError:
            return
        os.killpg(pid, signal.SIGTERM)
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline and process_is_alive(pid):
            time.sleep(0.1)
        if process_is_alive(pid):
            os.killpg(pid, signal.SIGKILL)
            deadline = time.monotonic() + 5
            while time.monotonic() < deadline and process_is_alive(pid):
                time.sleep(0.1)
        if process_is_alive(pid):
            raise RuntimeError(f"water-epochs: prior epoch pid {pid} did not exit")
        epoch["orphan_process_retired"] = True

    def __enter__(self) -> RecoveringWaterServer:
        with self._lock:
            self.root.mkdir(parents=True, exist_ok=True)
            self._load_journal()
            self._start_locked("initial" if not self._journal["epochs"] else "runner-recovery")
        return self

    def _finish_epoch_locked(self, status: str) -> None:
        if self._server is None:
            return
        server = self._server
        returncode = server.returncode
        server.close()
        if returncode is None:
            returncode = server.returncode
        epoch = self._journal["epochs"][self._generation - 1]
        log = Path(epoch["log"])
        epoch.update(
            {
                "status": status,
                "ended_unix": int(time.time()),
                "exit_code": returncode,
                "log_sha256": sha256(log),
                "bytes": log.stat().st_size,
            }
        )
        self._server = None
        _atomic_json(self.manifest_path, self._journal)

    def _start_locked(self, reason: str) -> None:
        if len(self._journal["epochs"]) >= self.max_epochs:
            raise RuntimeError(
                f"water-epochs-exhausted: used {len(self._journal['epochs'])} of "
                f"{self.max_epochs} exact server epochs"
            )
        ordinal = len(self._journal["epochs"]) + 1
        log = self.root / "water" / f"epoch-{ordinal:03d}.log"
        if log.exists() or log.is_symlink():
            raise FileExistsError(f"water-epochs: refusing to replace {log}")
        epoch = {
            "ordinal": ordinal,
            "reason": reason,
            "status": "starting",
            "started_unix": int(time.time()),
            "log": str(log),
            "command": self.command,
        }
        self._journal["epochs"].append(epoch)
        _atomic_json(self.manifest_path, self._journal)
        server = WaterServer(
            self.executable,
            self.base,
            self.coat,
            self.port,
            self.context,
            self.parallel,
            log,
            self.warm_scale,
        )
        self._generation = ordinal
        self._server = server
        try:
            server.__enter__()
        except BaseException:
            if log.is_file() and not log.is_symlink():
                self._finish_epoch_locked("startup-failed")
            else:
                epoch.update(
                    {
                        "status": "startup-failed",
                        "ended_unix": int(time.time()),
                        "exit_code": server.returncode,
                        "log_sha256": None,
                        "bytes": 0,
                    }
                )
                self._server = None
                _atomic_json(self.manifest_path, self._journal)
            raise
        epoch["status"] = "running"
        epoch["pid"] = server.process.pid if server.process is not None else None
        epoch["pid_start_sha256"] = (
            process_start_sha256(server.process.pid) if server.process is not None else None
        )
        if not epoch["pid_start_sha256"]:
            self._finish_epoch_locked("startup-failed")
            raise RuntimeError("water-epochs: could not bind the server process start identity")
        _atomic_json(self.manifest_path, self._journal)

    def _replace_dead_locked(self, generation: int) -> None:
        if generation != self._generation:
            return
        if self._server is not None and self._server.alive:
            return
        self._finish_epoch_locked("server-exited")
        self._start_locked("server-process-exit")

    def run(self, operation: Callable[[str, int], T]) -> tuple[T, int]:
        """Run one probe, retrying only when its exact server process objectively exited."""
        while True:
            with self._lock:
                if self._server is None or not self._server.alive:
                    self._replace_dead_locked(self._generation)
                assert self._server is not None
                generation = self._generation
                url = self._server.url
            try:
                result = operation(url, generation)
            except Exception:
                with self._lock:
                    infrastructure = (
                        generation != self._generation
                        or self._server is None
                        or not self._server.alive
                    )
                    if infrastructure:
                        self._replace_dead_locked(generation)
                if infrastructure:
                    continue
                raise
            with self._lock:
                infrastructure = (
                    generation != self._generation or self._server is None or not self._server.alive
                )
                if infrastructure:
                    self._replace_dead_locked(generation)
            if infrastructure:
                continue
            return result, generation

    def record(self) -> dict[str, Any]:
        with self._lock:
            return json.loads(json.dumps(self._journal))

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        with self._lock:
            status = "closed" if exc_type is None else "runner-error"
            if self._server is not None and not self._server.alive:
                status = "server-exited"
            self._finish_epoch_locked(status)


def prepare_home(root: Path, body: Path, coat: Path) -> tuple[Path, Path]:
    home = root / "fish"
    bridge = root / "bridge"
    adapters = home / "water" / "adapters"
    adapters.mkdir(parents=True)
    bridge.mkdir(parents=True)
    copied_body = home / "sediment.db"
    shutil.copy2(body, copied_body)
    copied_body.chmod(copied_body.stat().st_mode | stat.S_IWUSR)
    shutil.copy2(REPO / "SOUL.md", home / "SOUL.md")
    (home / "water" / "embedders").symlink_to(REPO / "fish" / "water" / "embedders")
    (adapters / "worn.gguf").symlink_to(coat.resolve())
    return home, bridge


def bench_home(home: Path) -> dict[str, str]:
    """The home, declared a bench — one string under both names, never two.

    water/request.rs::is_lab reads a scale override only on a body whose
    FISH_WATER_LAB names its own home and holds no keeper.secret, which is what
    prepare_home builds. A declaration that differs by a resolved-versus-relative
    step is no declaration, and the arm would measure the undeclared body in
    silence.
    """
    return {"FISH_HOME": str(home), "FISH_WATER_LAB": str(home)}


def retrieval_addresses(stderr: str) -> list[str]:
    addresses: list[str] = []
    for line in stderr.splitlines():
        if "· ledger:" in line and "precious retrieved" in line:
            addresses.extend(re.findall(r"#(\d+)", line))
        if "· lessons:" in line and "retrieved" in line:  # loose: this wording has changed once
            addresses.extend(f"lesson:{value}" for value in re.findall(r"lesson:(\d+)", line))
    return addresses


def parse_narration(stderr: str) -> dict[str, Any]:
    """Read one request's stderr narration into fields; an absent line leaves None/False/[].

    Flags and lesson addresses accumulate over every line; the ledger and bridge
    scalars keep the last line's values (a lab request is one turn). Never raises.
    The lines, quoted from fish/daemon/src (narrated under FISH_DEBUG, main.rs:153-154):
      main.rs:326  "· bridge: control applied — temperature={} k={k} theta·mul={:.3}
                    → theta={theta:.3}"
      main.rs:330  "· bridge: no control.json — SOUL defaults"
      main.rs:478  "· ledger: {} of k={k} precious retrieved{}{}"
                    (then " — #id@relevance:…/synthesis:…" per row)
      main.rs:485  "· lessons: {} recorded retrieved — {}"
                    (lesson:id@relevance:…/synthesis:… per row)
      main.rs:491  "· lessons: known family has no transfer-qualified method — recall abstains"
      main.rs:875  "· sediment: withheld voice held outside memory and dream"
      water/mod.rs:173  "· water: cut at the cap ({token_cap} tokens)
                    — the fish had not finished speaking"
    """
    narration: dict[str, Any] = {
        "abstained": False,
        "withheld": False,
        "cut_at_cap": False,
        "ledger_count": None,
        "ledger_k": None,
        "lessons": [],
        "theta": None,
        "k": None,
        "control_policy": None,
    }
    for raw in stderr.splitlines():
        line = re.sub(r"\x1b\[[0-9;]*m", "", raw)  # port/ink/mod.rs:270 styles only on a terminal
        if line.startswith("· lessons:"):
            if "recall abstains" in line:
                narration["abstained"] = True
            elif "retrieved" in line:
                narration["lessons"].extend(
                    f"lesson:{value}" for value in re.findall(r"lesson:(\d+)", line)
                )
        elif line.startswith("· sediment: withheld voice"):
            narration["withheld"] = True
        elif line.startswith("· water: cut at the cap"):
            narration["cut_at_cap"] = True
        elif (
            ledger := re.match(r"· ledger: (\d+) of k=(\d+) precious retrieved", line)
        ) is not None:
            narration["ledger_count"], narration["ledger_k"] = int(ledger[1]), int(ledger[2])
        elif line.startswith("· bridge: control applied"):
            narration["control_policy"] = "control.json"
            k = re.search(r"\bk=(\d+)\b", line)
            theta = re.search(r"→ theta=(\S+)", line)
            narration["k"] = int(k[1]) if k else None
            try:
                narration["theta"] = float(theta[1]) if theta else None
            except ValueError:
                narration["theta"] = None
        elif line.startswith("· bridge: no control.json"):
            narration["control_policy"] = "none(SOUL)"
    return narration


def run_probe(
    probe: dict[str, Any],
    seed: int,
    home: Path,
    bridge: Path,
    binary: Path,
    water_url: str,
    protocol: dict[str, Any],
) -> dict[str, Any]:
    speaker = f"adaptive-{seed}-{probe['id']}"
    env = os.environ.copy()
    env.update(
        {
            **bench_home(home),
            "FISH_BRIDGE": str(bridge),
            "FISH_SPEAKER": speaker,
            "FISH_WATER_URL": water_url,
            "FISH_WATER_SEED": str(seed),
            "FISH_WATER_LORA_SCALE": "1",
            "FISH_MAX_REPLY_TOKENS": str(protocol["controls"]["max_reply_tokens"]),
            "FISH_WATER_PATIENCE_SECS": "120",
            "FISH_MIRROR": "off",
            "FISH_FIN": "off",
            "FISH_DEBUG": "1",
        }
    )
    started = time.monotonic()
    process = subprocess.run(
        [str(binary)],
        input=f"{probe['prompt']}\n",
        capture_output=True,
        text=True,
        cwd=REPO,
        env=env,
        timeout=240,
    )
    duration = time.monotonic() - started
    with sqlite3.connect(home / "sediment.db") as db:
        row = db.execute(
            "SELECT id, i FROM exchanges WHERE speaker = ? ORDER BY id DESC LIMIT 1", (speaker,)
        ).fetchone()
    reply = str(row[1]) if row else ""
    return {
        "probe": probe["id"],
        "domain": probe["domain"],
        "seed": seed,
        "prompt": probe["prompt"],
        "reply": reply,
        "exchange_id": int(row[0]) if row else None,
        "retrieved": retrieval_addresses(process.stderr),
        "returncode": process.returncode,
        "duration_seconds": round(duration, 3),
        "score": score_reply(protocol, probe, reply),
        "stderr_tail": process.stderr.splitlines()[-12:],
    }


def run_seed(
    seed: int,
    run_root: Path,
    label: str,
    body: Path,
    coat: Path,
    binary: Path,
    water_url: str,
    protocol: dict[str, Any],
) -> dict[str, Any]:
    home, bridge = prepare_home(run_root / label / f"seed-{seed}", body, coat)
    results = [
        run_probe(probe, seed, home, bridge, binary, water_url, protocol)
        for probe in protocol["probes"]
    ]
    return {"seed": seed, "results": results, "body_after_sha256": sha256(home / "sediment.db")}


def summarize(results: list[dict[str, Any]], protocol: dict[str, Any]) -> dict[str, Any]:
    by_seed = []
    for seed in protocol["seeds"]:
        rows = [row for row in results if row["seed"] == seed]
        scores = {}
        for domain in protocol["domains"]:
            domain_rows = [row for row in rows if row["domain"] == domain]
            scores[domain] = {
                "task": sum(row["score"]["task"] for row in domain_rows),
                "correct": sum(row["score"]["correct"] for row in domain_rows),
                "semantic": sum(row["score"]["semantic"] for row in domain_rows),
                "format": sum(row["score"]["format"] for row in domain_rows),
                "n": len(domain_rows),
            }
        by_seed.append(
            {
                "seed": seed,
                "task": sum(row["score"]["task"] for row in rows),
                "semantic": sum(row["score"]["semantic"] for row in rows),
                "clean": sum(row["score"]["clean"] for row in rows),
                "n": len(rows),
                "domains": scores,
            }
        )
    valid = all(row["returncode"] == 0 and row["exchange_id"] is not None for row in results)
    return {"valid": valid, "by_seed": by_seed}


def evaluate_cell(
    label: str,
    body: Path,
    coat: Path,
    protocol: dict[str, Any],
    binary: Path,
    water_url: str,
    jobs: int,
    run_root: Path,
) -> dict[str, Any]:
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, jobs)) as pool:
        futures = [
            pool.submit(
                run_seed,
                seed,
                run_root,
                label,
                body,
                coat,
                binary,
                water_url,
                protocol,
            )
            for seed in protocol["seeds"]
        ]
        seeded = [future.result() for future in futures]
    results = [row for seed_result in seeded for row in seed_result["results"]]
    order = {probe["id"]: index for index, probe in enumerate(protocol["probes"])}
    results.sort(key=lambda row: (protocol["seeds"].index(row["seed"]), order[row["probe"]]))
    return {
        "label": label,
        "body_path": str(body.resolve()),
        "body_sha256": sha256(body),
        "body_max_exchange_id": max_exchange_id(body),
        "coat_path": str(coat.resolve()),
        "coat_sha256": sha256(coat),
        "experimental_body_sha256_after": {
            str(result["seed"]): result["body_after_sha256"] for result in seeded
        },
        "summary": summarize(results, protocol),
        "results": results,
    }


def evaluate_two_bodies(
    coat_label: str,
    coat: Path,
    pre_body: Path,
    post_body: Path,
    protocol: dict[str, Any],
    args: argparse.Namespace,
    run_root: Path,
) -> tuple[dict[str, Any], dict[str, Any]]:
    log_path = run_root / f"{coat_label}-water.log"
    controls = protocol["controls"]
    with WaterServer(
        args.server,
        args.base,
        coat,
        args.port,
        int(controls["context"]),
        int(controls["parallel_requests"]),
        log_path,
    ) as water:
        pre = evaluate_cell(
            f"{coat_label}_pre_body",
            pre_body,
            coat,
            protocol,
            args.binary,
            water.url,
            args.jobs,
            run_root,
        )
        post = evaluate_cell(
            f"{coat_label}_post_body",
            post_body,
            coat,
            protocol,
            args.binary,
            water.url,
            args.jobs,
            run_root,
        )
    return pre, post


def paired_effect(
    earlier: dict[str, Any],
    later: dict[str, Any],
    protocol: dict[str, Any],
    score_key: str = "task",
) -> dict[str, Any]:
    left = {(row["seed"], row["probe"]): row for row in earlier["results"]}
    right = {(row["seed"], row["probe"]): row for row in later["results"]}
    domains = {}
    for domain in protocol["domains"]:
        gains = losses = ties = 0
        success_delta = 0
        by_probe = []
        for probe in protocol["probes"]:
            if probe["domain"] != domain:
                continue
            before = sum(
                bool(left[(seed, probe["id"])]["score"][score_key]) for seed in protocol["seeds"]
            )
            after = sum(
                bool(right[(seed, probe["id"])]["score"][score_key]) for seed in protocol["seeds"]
            )
            delta = after - before
            success_delta += delta
            if delta > 0:
                gains += 1
            elif delta < 0:
                losses += 1
            else:
                ties += 1
            by_probe.append(
                {
                    "probe": probe["id"],
                    "before_successes": before,
                    "after_successes": after,
                    "success_delta": delta,
                }
            )
        deltas = []
        for seed in protocol["seeds"]:
            seed_gain = seed_loss = 0
            for probe in protocol["probes"]:
                if probe["domain"] != domain:
                    continue
                before = bool(left[(seed, probe["id"])]["score"][score_key])
                after = bool(right[(seed, probe["id"])]["score"][score_key])
                if after and not before:
                    seed_gain += 1
                elif before and not after:
                    seed_loss += 1
            deltas.append({"seed": seed, f"{score_key}_delta": seed_gain - seed_loss})
        domains[domain] = {
            "gains": gains,
            "losses": losses,
            "ties": ties,
            "success_delta": success_delta,
            "one_sided_sign_p": round(one_sided_sign_p(gains, losses), 8),
            "by_probe": by_probe,
            "by_seed": deltas,
        }
    return {"from": earlier["label"], "to": later["label"], "domains": domains}


def domain_totals(
    cell: dict[str, Any], protocol: dict[str, Any], score_key: str = "task"
) -> dict[str, int]:
    return {
        domain: sum(row["score"][score_key] for row in cell["results"] if row["domain"] == domain)
        for domain in protocol["domains"]
    }


def interaction_effect(
    retained_pre: dict[str, Any],
    retained_post: dict[str, Any],
    candidate_pre: dict[str, Any],
    candidate_post: dict[str, Any],
    protocol: dict[str, Any],
) -> dict[str, int]:
    a = domain_totals(retained_pre, protocol)
    b = domain_totals(retained_post, protocol)
    d = domain_totals(candidate_pre, protocol)
    c = domain_totals(candidate_post, protocol)
    return {domain: (c[domain] - d[domain]) - (b[domain] - a[domain]) for domain in a}


def adaptive_decision(
    retained_pre: dict[str, Any],
    retained_post: dict[str, Any],
    candidate_pre: dict[str, Any],
    candidate_post: dict[str, Any],
    protocol: dict[str, Any],
) -> dict[str, Any]:
    effects = {
        "memory_under_retained": paired_effect(retained_pre, retained_post, protocol),
        "weight_on_pre_body": paired_effect(retained_pre, candidate_pre, protocol),
        "weight_on_post_body": paired_effect(retained_post, candidate_post, protocol),
        "memory_under_candidate": paired_effect(candidate_pre, candidate_post, protocol),
        "total_organism": paired_effect(retained_pre, candidate_post, protocol),
    }
    rule = protocol["decision_rule"]
    adaptive_domains = protocol["adaptive_domains"]

    def combined(effect: dict[str, Any]) -> tuple[int, int, int]:
        gains = sum(effect["domains"][domain]["gains"] for domain in adaptive_domains)
        losses = sum(effect["domains"][domain]["losses"] for domain in adaptive_domains)
        success_delta = sum(
            effect["domains"][domain]["success_delta"] for domain in adaptive_domains
        )
        return gains, losses, success_delta

    weight = effects["weight_on_post_body"]
    total = effects["total_organism"]
    weight_gains, weight_losses, weight_success_delta = combined(weight)
    total_gains, total_losses, total_success_delta = combined(total)
    retention = weight["domains"]["retention"]
    boundary = weight["domains"]["boundary"]
    candidate_clean = all(row["score"]["clean"] for row in candidate_post["results"])
    valid = all(
        cell["summary"]["valid"]
        for cell in (retained_pre, retained_post, candidate_pre, candidate_post)
    )
    passed = (
        valid
        and candidate_clean
        and weight_gains - weight_losses >= int(rule["minimum_paired_gain"])
        and weight_success_delta >= int(rule["minimum_success_delta"])
        and one_sided_sign_p(weight_gains, weight_losses) <= float(rule["maximum_sign_p"])
        and total_gains > total_losses
        and total_success_delta > 0
        and retention["losses"] <= retention["gains"]
        and boundary["losses"] == 0
    )
    return {
        "valid": valid,
        "adaptive_evolution": passed,
        "candidate_clean": candidate_clean,
        "weight_paired": {
            "gains": weight_gains,
            "losses": weight_losses,
            "success_delta": weight_success_delta,
        },
        "total_paired": {
            "gains": total_gains,
            "losses": total_losses,
            "success_delta": total_success_delta,
        },
        "interaction": interaction_effect(
            retained_pre, retained_post, candidate_pre, candidate_post, protocol
        ),
        "effects": effects,
    }


def environment_record(server: Path) -> dict[str, Any]:
    return {
        "platform": platform.platform(),
        "machine": platform.machine(),
        "llama_server": server_version(server),
    }


def render_markdown(record: dict[str, Any]) -> str:
    lines = [
        "# Teacher-blind adaptive-evolution measurement",
        "",
        f"Run `{record['run_id']}` · plan `{record['plan_sha256']}` · generated protocol "
        f"`{record['protocol_sha256']}`.",
        "",
        "The candidate coat hash generated the exact transfer instances and request seeds only "
        "after teaching ended. Each probe used a fresh synthesis chair on a disposable body.",
    ]
    for cell in record["cells"]:
        lines += [
            "",
            f"## {cell['label']}",
            "",
            "| seed | total | clean | domains |",
            "|---:|---:|---:|---|",
        ]
        for seed in cell["summary"]["by_seed"]:
            domains = ", ".join(
                f"{name} {score['task']}/{score['n']}" for name, score in seed["domains"].items()
            )
            total = f"{seed['task']}/{seed['n']}"
            clean = f"{seed['clean']}/{seed['n']}"
            lines.append(f"| {seed['seed']} | {total} | {clean} | {domains} |")
    decision = record["decision"]
    lines += [
        "",
        "## Ruling",
        "",
        f"- Valid: **{'PASS' if decision['valid'] else 'FAIL'}**.",
        f"- Adaptive evolution: **{'PASS' if decision['adaptive_evolution'] else 'FAIL'}**.",
        f"- Weight-paired gains/losses: `{decision['weight_paired']['gains']}/"
        f"{decision['weight_paired']['losses']}`.",
        f"- Total gains/losses: `{decision['total_paired']['gains']}/"
        f"{decision['total_paired']['losses']}`.",
        f"- Interaction by domain: `{json.dumps(decision['interaction'], sort_keys=True)}`.",
        "",
        "## Exact exchanges",
    ]
    for cell in record["cells"]:
        lines += ["", f"### {cell['label']}"]
        for row in cell["results"]:
            verdict = "task✓" if row["score"]["task"] else "task✗"
            clean = "clean✓" if row["score"]["clean"] else "clean✗"
            lines += [
                "",
                f"**{row['probe']} · seed {row['seed']}** · {verdict} · {clean}",
                "",
                f"> You: {row['prompt']}",
                "",
                "> Fish: " + row["reply"].replace("\n", "\n> "),
            ]
    return "\n".join(lines) + "\n"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--pre-body", type=Path, required=True)
    parser.add_argument("--post-body", type=Path, required=True)
    parser.add_argument("--retained-coat", type=Path, required=True)
    parser.add_argument("--candidate-coat", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--binary", type=Path, default=DEFAULT_BINARY)
    parser.add_argument("--base", type=Path, default=DEFAULT_BASE)
    parser.add_argument("--server", type=Path, default=DEFAULT_SERVER)
    parser.add_argument("--port", type=int, default=18080)
    parser.add_argument("--jobs", type=int, default=2)
    return parser.parse_args()


def validate_paths(args: argparse.Namespace) -> None:
    for path in (
        args.plan,
        args.pre_body,
        args.post_body,
        args.retained_coat,
        args.candidate_coat,
        args.binary,
        args.base,
        args.server,
    ):
        if not path.is_file():
            raise FileNotFoundError(path)


def main() -> None:
    args = parse_args()
    validate_paths(args)
    plan = load_plan(args.plan)
    validate_pins(plan, args)
    baseline = plan["baseline"]
    if sha256(args.pre_body) != baseline["body_sha256"]:
        raise ValueError("pre-teaching body hash drift")
    if max_exchange_id(args.pre_body) != int(baseline["max_exchange_id"]):
        raise ValueError("pre-teaching chronology drift")
    if sha256(args.retained_coat) != baseline["coat_sha256"]:
        raise ValueError("retained coat hash drift")
    if max_exchange_id(args.post_body) < int(baseline["max_exchange_id"]):
        raise ValueError("post-teaching body predates the baseline")

    plan_sha = sha256(args.plan)
    candidate_sha = sha256(args.candidate_coat)
    protocol = instantiate_protocol(plan, plan_sha, candidate_sha, args.pre_body, args.post_body)
    leaks = {
        "pre_body": protocol_leaks(protocol, args.pre_body),
        "post_body": protocol_leaks(protocol, args.post_body),
    }
    if leaks["pre_body"] or leaks["post_body"]:
        raise ValueError(f"derived protocol leakage: {json.dumps(leaks)}")

    living = REPO / "fish" / "sediment.db"
    living_before = sha256(living)
    with tempfile.TemporaryDirectory(prefix="fish-adaptive-") as temporary:
        root = Path(temporary)
        retained_pre, retained_post = evaluate_two_bodies(
            "retained_coat",
            args.retained_coat,
            args.pre_body,
            args.post_body,
            protocol,
            args,
            root,
        )
        candidate_pre, candidate_post = evaluate_two_bodies(
            "candidate_coat",
            args.candidate_coat,
            args.pre_body,
            args.post_body,
            protocol,
            args,
            root,
        )
    cells = [retained_pre, retained_post, candidate_pre, candidate_post]
    record = {
        "version": 1,
        "run_id": datetime.now(UTC).isoformat(timespec="seconds"),
        "git_commit": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=REPO, text=True
        ).strip(),
        "environment": environment_record(args.server),
        "plan_path": str(args.plan),
        "plan_sha256": plan_sha,
        "plan": plan,
        "protocol_sha256": hashlib.sha256(
            json.dumps(protocol, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest(),
        "protocol": protocol,
        "leakage": {"valid": True, "violations": leaks},
        "living_sha256_before": living_before,
        "cells": cells,
        "decision": adaptive_decision(
            retained_pre, retained_post, candidate_pre, candidate_post, protocol
        ),
        "living_sha256_after": sha256(living),
    }
    if record["living_sha256_before"] != record["living_sha256_after"]:
        raise RuntimeError("living sediment changed during isolated measurement")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(record, indent=2, ensure_ascii=False) + "\n")
    args.output.with_suffix(".md").write_text(render_markdown(record))
    print(json.dumps(record["decision"], indent=2))


if __name__ == "__main__":
    main()
