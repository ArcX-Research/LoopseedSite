"""Ground truth for decimal place weighting and positional recomposition."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass

from fish.lab import arithmetic_hierarchy
from fish.lab.counted_structure import assignment_truth_with_tables

START_CYCLE = 3830
KINDS = ("place-value-terms", "place-value-sum")

METHODS = {
    "place-value-terms": (
        "Set HUNDREDS_TERM=100*HUNDREDS_RAW, TENS_TERM=10*OUT_TENS, and ONES_TERM=OUT_ONES"
    ),
    "place-value-sum": (
        "Set PREFIX_SUM=HUNDREDS_TERM+TENS_TERM, then set RESULT=PREFIX_SUM+ONES_TERM"
    ),
}


@dataclass(frozen=True)
class Problem:
    kind: str
    parameters: tuple[int, ...]

    @property
    def assignments(self) -> dict[str, int]:
        return states(self.kind, self.parameters)

    @property
    def method(self) -> str:
        return METHODS[self.kind]

    def _contract(self) -> str:
        return "; ".join(f"{label} = integer" for label in self.assignments)

    def prompt(self) -> str:
        return (
            f"{statement(self.kind, self.parameters)} Evaluate every assignment to a decimal "
            f"integer. Return one line with no prose: {self._contract()}."
        )

    def nudge(self) -> str:
        return (
            f"{statement(self.kind, self.parameters)} Use this relation: {self.method}. "
            f"Do not leave arithmetic operators unevaluated. Return exactly {self._contract()} "
            "and no prose."
        )

    def repair(self) -> str:
        trace = self.assignments
        if self.kind == "place-value-terms":
            check = (
                f"The checked hundreds term is HUNDREDS_TERM={trace['HUNDREDS_TERM']}; "
                "weight the supplied tens digit by ten and leave the ones digit unshifted"
            )
        else:
            check = (
                f"The checked first addition is PREFIX_SUM={trace['PREFIX_SUM']}; "
                "add the supplied ones term once"
            )
        return (
            f"{statement(self.kind, self.parameters)} Your preceding values did not all "
            f"satisfy the place-value relations. {check}. Return exactly {self._contract()} "
            "with decimal integers and no prose."
        )

    def record(self) -> str:
        return "; ".join(f"{label} = {value}" for label, value in self.assignments.items())


def states(kind: str, parameters: tuple[int, ...]) -> dict[str, int]:
    if len(parameters) != 3:
        raise ValueError("place-value recomposition requires three parameters")
    first, second, third = parameters
    if kind == "place-value-terms":
        hundreds_raw, out_tens, out_ones = first, second, third
        if not 1 <= hundreds_raw <= 99 or not 0 <= out_tens <= 9 or not 0 <= out_ones <= 9:
            raise ValueError("invalid place-value terms")
        return {
            "HUNDREDS_TERM": 100 * hundreds_raw,
            "TENS_TERM": 10 * out_tens,
            "ONES_TERM": out_ones,
        }
    if kind == "place-value-sum":
        hundreds_term, tens_term, ones_term = first, second, third
        if (
            not 100 <= hundreds_term <= 9900
            or hundreds_term % 100
            or not 0 <= tens_term <= 90
            or tens_term % 10
            or not 0 <= ones_term <= 9
        ):
            raise ValueError("invalid place-value sum")
        prefix = hundreds_term + tens_term
        return {"PREFIX_SUM": prefix, "RESULT": prefix + ones_term}
    raise ValueError(f"unknown arithmetic recomposition task: {kind}")


def statement(kind: str, parameters: tuple[int, ...]) -> str:
    if kind == "place-value-terms":
        hundreds_raw, out_tens, out_ones = parameters
        return (
            "Place-value-terms state question: "
            f"HUNDREDS_RAW={hundreds_raw}, OUT_TENS={out_tens}, and OUT_ONES={out_ones}."
        )
    if kind == "place-value-sum":
        hundreds_term, tens_term, ones_term = parameters
        return (
            "Place-value-sum state question: "
            f"HUNDREDS_TERM={hundreds_term}, TENS_TERM={tens_term}, "
            f"and ONES_TERM={ones_term}."
        )
    raise ValueError(f"unknown arithmetic recomposition task: {kind}")


def problem_from_prompt(prompt: str) -> Problem | None:
    terms = re.search(
        r"Place-value-terms state question:.*HUNDREDS_RAW=(\d+), OUT_TENS=(\d+), "
        r"and OUT_ONES=(\d+)",
        prompt,
    )
    if terms is not None:
        return Problem("place-value-terms", tuple(int(value) for value in terms.groups()))
    total = re.search(
        r"Place-value-sum state question:.*HUNDREDS_TERM=(\d+), TENS_TERM=(\d+), "
        r"and ONES_TERM=(\d+)",
        prompt,
    )
    if total is not None:
        return Problem("place-value-sum", tuple(int(value) for value in total.groups()))
    return None


def lesson_reply_lands(prompt: str, reply: str) -> bool | None:
    problem = problem_from_prompt(prompt)
    if problem is None:
        return None
    return assignment_truth_with_tables(reply, problem.assignments)


def _term_candidates() -> set[tuple[int, int, int]]:
    values: set[tuple[int, int, int]] = set()
    for parameters in arithmetic_hierarchy.candidates("three-column-upper-block"):
        hundreds, multiplier, carry, out_tens, out_ones = parameters
        upper = arithmetic_hierarchy.states(
            "three-column-upper-block", (hundreds, multiplier, carry, out_tens, out_ones)
        )
        values.add((upper["HUNDREDS_RAW"], out_tens, out_ones))
    return values


def candidates(kind: str) -> list[tuple[int, ...]]:
    values: list[tuple[int, ...]]
    if kind == "place-value-terms":
        values = list(_term_candidates())
    elif kind == "place-value-sum":
        values = [
            (100 * hundreds_raw, 10 * out_tens, out_ones)
            for hundreds_raw, out_tens, out_ones in _term_candidates()
        ]
    else:
        raise ValueError(f"unknown arithmetic recomposition task: {kind}")
    values.sort(key=lambda item: hashlib.sha256(f"{kind}:{item}".encode()).digest())
    return values


def lesson_problem(cycle: int) -> tuple[Problem, int]:
    if cycle < START_CYCLE:
        raise ValueError(f"arithmetic recomposition lessons begin at cycle {START_CYCLE}")
    offset = cycle - START_CYCLE
    block, position = divmod(offset, 4)
    kind = KINDS[position // 2]
    occurrence = block * 2 + position % 2
    pool = candidates(kind)
    return Problem(kind, pool[occurrence % len(pool)]), occurrence
