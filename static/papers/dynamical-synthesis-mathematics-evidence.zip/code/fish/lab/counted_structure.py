"""Truth and review rules for bag 6 counted-structure lessons."""

from __future__ import annotations

import hashlib
import math
import re
from dataclasses import dataclass
from typing import Any, Iterable

KINDS = ("shared-seams", "non-square-rectangles", "blocked-paths", "separated-choices")

TEACHING_CONFIG: dict[str, dict[str, int]] = {
    "shared-seams": {
        "rows_min": 4,
        "rows_max": 14,
        "columns_min": 4,
        "columns_max": 14,
    },
    "non-square-rectangles": {
        "rows_min": 3,
        "rows_max": 9,
        "columns_min": 3,
        "columns_max": 9,
    },
    "blocked-paths": {"east_min": 4, "east_max": 8, "north_min": 4, "north_max": 8},
    "separated-choices": {
        "objects_min": 9,
        "objects_max": 20,
        "chosen_min": 3,
        "chosen_max": 7,
    },
}


@dataclass(frozen=True)
class Problem:
    kind: str
    parameters: tuple[int, ...]

    @property
    def assignments(self) -> dict[str, int]:
        return answers(self.kind, self.parameters)

    def prompt(self, case_id: int | None = None) -> str:
        lead = f"Case {case_id}. " if case_id is not None else ""
        labels = "; ".join(f"{label} = integer" for label in self.assignments)
        return f"{lead}{problem_statement(self.kind, self.parameters)} Return exactly {labels}."

    def nudge(self) -> str:
        return f"{problem_statement(self.kind, self.parameters)} {nudge(self.kind)}"

    def record(self) -> str:
        return "; ".join(f"{label} = {value}" for label, value in self.assignments.items())


def answers(kind: str, parameters: tuple[int, ...]) -> dict[str, int]:
    if kind == "shared-seams":
        rows, columns = parameters
        horizontal = (rows - 1) * columns
        vertical = rows * (columns - 1)
        return {"H_SHARED": horizontal, "V_SHARED": vertical, "TOTAL": horizontal + vertical}
    if kind == "non-square-rectangles":
        rows, columns = parameters
        all_rectangles = math.comb(rows + 1, 2) * math.comb(columns + 1, 2)
        squares = sum(
            (rows - side + 1) * (columns - side + 1) for side in range(1, min(rows, columns) + 1)
        )
        return {
            "ALL_RECTANGLES": all_rectangles,
            "SQUARES": squares,
            "NON_SQUARE": all_rectangles - squares,
        }
    if kind == "blocked-paths":
        east, north, blocked_east, blocked_north = parameters
        all_paths = math.comb(east + north, east)
        through = math.comb(blocked_east + blocked_north, blocked_east) * math.comb(
            east - blocked_east + north - blocked_north,
            east - blocked_east,
        )
        return {"ALL": all_paths, "THROUGH": through, "AVOID": all_paths - through}
    if kind == "separated-choices":
        objects, chosen = parameters
        all_choices = math.comb(objects, chosen)
        together = math.comb(objects - 2, chosen - 2)
        return {"ALL": all_choices, "TOGETHER": together, "ALLOWED": all_choices - together}
    raise ValueError(f"unknown counted-structure kind: {kind}")


def problem_statement(kind: str, parameters: tuple[int, ...]) -> str:
    if kind == "shared-seams":
        rows, columns = parameters
        return (
            f"Shared-seam problem: a rectangular cell grid has {rows} rows and {columns} "
            "columns. Count only unit seams shared by two neighboring cells, separated into "
            "horizontal and vertical seams."
        )
    if kind == "non-square-rectangles":
        rows, columns = parameters
        return (
            f"Non-square rectangle problem: a rectangular cell grid has {rows} rows and "
            f"{columns} columns. Count all axis-aligned rectangles, all axis-aligned squares, "
            "and then the rectangles that are not squares."
        )
    if kind == "blocked-paths":
        east, north, blocked_east, blocked_north = parameters
        return (
            f"Blocked-path problem: shortest lattice paths go from (0, 0) to ({east}, {north}) "
            f"using only east and north steps, while avoiding ({blocked_east}, {blocked_north}). "
            "Count all shortest paths, those through the blocked point, and those avoiding it."
        )
    if kind == "separated-choices":
        objects, chosen = parameters
        return (
            f"Separated-choice problem: choose {chosen} objects from {objects} distinct objects, "
            "but two distinguished objects may not both be chosen. Count all choices, choices "
            "containing both distinguished objects, and allowed choices."
        )
    raise ValueError(f"unknown counted-structure kind: {kind}")


def nudge(kind: str) -> str:
    directions = {
        "shared-seams": (
            "Count the gaps between adjacent rows across every column, then the gaps between "
            "adjacent columns across every row; add the two counts."
        ),
        "non-square-rectangles": (
            "Choose two horizontal grid lines and two vertical grid lines for all rectangles. "
            "Let s=min(rows,columns) and l=max(rows,columns), then use the exact closed form "
            "s(s+1)(3l-s+1)/6 for the square count and subtract."
        ),
        "blocked-paths": (
            "Evaluate each choose(n,k) by setting q=min(k,n-k), B_0=1, and "
            "B_j=B_{j-1}(n-j+1)/j through j=q, with exact division at each step. Multiply the "
            "two path counts through the blocked point, subtract, and check ALL=THROUGH+AVOID."
        ),
        "separated-choices": (
            "Evaluate each choose(n,k) by setting q=min(k,n-k), B_0=1, and "
            "B_j=B_{j-1}(n-j+1)/j through j=q, with exact division at each step. Fix the two "
            "distinguished objects for TOGETHER, subtract, and check ALL=TOGETHER+ALLOWED."
        ),
    }
    return directions[kind] + " Finish with only the three requested assignments."


METHOD_PROMPTS = {
    "shared-seams": (
        "The examples are settled. State a reusable symbolic rule for shared unit seams in an "
        "r-by-c cell grid. Use H_SHARED, V_SHARED, and TOTAL; give both TOTAL=H_SHARED+V_SHARED "
        "and the independent check TOTAL=2rc-r-c; explain why no seam is counted twice. Do not "
        "calculate a case."
    ),
    "non-square-rectangles": (
        "The examples are settled. State a reusable symbolic rule for non-square axis-aligned "
        "rectangles in an r-by-c cell grid. Let s=min(r,c) and l=max(r,c). Use choose(u,v), "
        "ALL_RECTANGLES, the closed form SQUARES=s(s+1)(3l-s+1)/6, and NON_SQUARE. Do not "
        "calculate a case."
    ),
    "blocked-paths": (
        "The examples are settled. State a reusable symbolic rule for shortest east-north paths "
        "from (0,0) to (a,b) that avoid (x,y). Use choose(u,v), ALL, THROUGH, and AVOID. Also "
        "state the exact integer recurrence B_0=1, B_j=B_{j-1}(n-j+1)/j through "
        "q=min(k,n-k) for evaluating choose(n,k), and check ALL=THROUGH+AVOID. Do not calculate "
        "a case."
    ),
    "separated-choices": (
        "The examples are settled. State a reusable symbolic rule for choosing k of n objects "
        "when two distinguished objects may not both appear. Use choose(u,v), ALL, TOGETHER, "
        "and ALLOWED. Also state the exact integer recurrence B_0=1, "
        "B_j=B_{j-1}(n-j+1)/j through q=min(k,n-k) for evaluating choose(n,k), and check "
        "ALL=TOGETHER+ALLOWED. Do not calculate a case."
    ),
}

METHOD_NUDGES = {
    "shared-seams": (
        "Check the orientation labels: horizontal seams lie between adjacent rows, across every "
        "column; vertical seams lie between adjacent columns, across every row. State all three "
        "symbolic rules, the independent check TOTAL=2rc-r-c, and why the two seam sets are "
        "disjoint."
    ),
    "non-square-rectangles": (
        "Choose two horizontal and two vertical boundary lines for every rectangle. Let "
        "s=min(r,c), l=max(r,c), use SQUARES=s(s+1)(3l-s+1)/6, then subtract. State all three "
        "symbolic rules."
    ),
    "blocked-paths": (
        "Choose positions for every shortest path. For paths through the blocked point, multiply "
        "the independent counts on its two sides, then subtract. Include the exact B_j binomial "
        "recurrence and the check ALL=THROUGH+AVOID."
    ),
    "separated-choices": (
        "Count every k-of-n choice. For choices containing both distinguished objects, fix those "
        "two and choose the remaining k-2 from n-2, then subtract. Include the exact B_j "
        "binomial recurrence and the check ALL=TOGETHER+ALLOWED."
    ),
}

METHOD_RECORDS = {
    "shared-seams": ("H_SHARED = (r-1)c; V_SHARED = r(c-1); TOTAL = H_SHARED+V_SHARED = 2rc-r-c"),
    "non-square-rectangles": (
        "s = min(r,c); l = max(r,c); "
        "ALL_RECTANGLES = choose(r+1,2)choose(c+1,2); "
        "SQUARES = s(s+1)(3l-s+1)/6; "
        "NON_SQUARE = ALL_RECTANGLES-SQUARES"
    ),
    "blocked-paths": (
        "For choose(n,k): q=min(k,n-k), B_0=1, "
        "B_j=B_{j-1}(n-j+1)/j for j=1..q, each division exact; "
        "ALL = choose(a+b,a); THROUGH = choose(x+y,x)choose((a-x)+(b-y),a-x); "
        "AVOID = ALL-THROUGH; check ALL=THROUGH+AVOID"
    ),
    "separated-choices": (
        "For choose(n,k): q=min(k,n-k), B_0=1, "
        "B_j=B_{j-1}(n-j+1)/j for j=1..q, each division exact; "
        "ALL = choose(n,k); TOGETHER = choose(n-2,k-2); ALLOWED = ALL-TOGETHER; "
        "check ALL=TOGETHER+ALLOWED"
    ),
}


def method_prompt(kind: str) -> str:
    return METHOD_PROMPTS[kind]


def method_nudge(kind: str) -> str:
    return METHOD_NUDGES[kind]


def method_record(kind: str) -> str:
    return METHOD_RECORDS[kind]


def method_kind(prompt: str) -> str | None:
    return next((kind for kind, marker in METHOD_PROMPTS.items() if prompt == marker), None)


def _label_pattern(label: str) -> str:
    pieces = [re.escape(piece) for piece in re.findall(r"[A-Za-z]+|\d+", label)]
    return r"[\s_-]*".join(pieces)


def assignment_score(
    reply: str, expected: dict[str, int] | Iterable[tuple[str, int]]
) -> tuple[bool, bool]:
    assignments = dict(expected)
    search_text = reply.replace("**", "").replace("`", "")
    found: dict[str, list[int]] = {}
    for label in assignments:
        values = re.findall(
            rf"(?<!\w){_label_pattern(label)}(?!\w)\s*=\s*([+-]?\d+)",
            search_text,
            re.IGNORECASE,
        )
        found[label] = [int(value) for value in values]
    correct = all(found[label] == [value] for label, value in assignments.items())

    clean = search_text.strip()
    segments = [
        segment.strip(" \t-*•") for segment in re.split(r"[;\n]+", clean) if segment.strip()
    ]
    format_ok = len(segments) == len(assignments)
    if format_ok:
        for segment, label in zip(segments, assignments, strict=True):
            if (
                re.fullmatch(
                    rf"{_label_pattern(label)}\s*=\s*[+-]?\d+\.?",
                    segment,
                    re.IGNORECASE,
                )
                is None
            ):
                format_ok = False
                break
    return correct, format_ok


def assignment_truth(
    reply: str, expected: dict[str, int] | Iterable[tuple[str, int]]
) -> bool | None:
    """Judge explicit values while leaving incomplete symbolic work unsettled."""
    assignments = dict(expected)
    text = (
        reply.translate(str.maketrans("₀₁₂₃₄₅₆₇₈₉", "0123456789"))
        .replace("**", "")
        .replace("`", "")
        .replace("$", "")
        .replace("\\_", "_")
        .replace("\\ ", " ")
    )
    text = re.sub(r"\\[,;:!]", "", text)
    text = re.sub(r"\\(?:text|mathrm|operatorname)\s*\{([^{}]+)\}", r"\1", text)
    text = re.sub(r"\\(?:boxed|mathbf)\s*\{([^{}\n]+)\}", r"\1", text)
    text = re.sub(r"\\(?:quad|qquad)\b", ";", text)
    text = re.sub(r"(?<=\d),\s+(?=\d{3}\b)", ",", text)
    text = re.sub(r"[ \t]*\n[ \t]*(?==)", " ", text)
    next_label = "|".join(_label_pattern(label) for label in assignments)
    text = re.sub(rf",\s*(?=(?:{next_label})(?!\w)\s*=)", ";", text, flags=re.IGNORECASE)
    complete = True
    for label, expected_value in assignments.items():
        label_at_start = re.compile(
            rf"{_label_pattern(label)}(?!\w)[ \t]*=[ \t]*(.*)", re.IGNORECASE
        )
        expressions: list[str] = []
        for clause in re.split(r"[;\n]", text):
            clause = clause.lstrip()
            numbered = re.match(r"\d+[.)][ \t]*", clause)
            if numbered is not None:
                clause = clause[numbered.end() :]
            clause = clause.lstrip()
            while clause and not (clause[0].isalnum() or clause[0] == "_"):
                clause = clause[1:].lstrip()
            match = label_at_start.fullmatch(clause)
            if match is not None:
                expressions.append(match.group(1))
        table_values = re.findall(
            rf"(?im)^\s*\|\s*{_label_pattern(label)}\s*\|\s*"
            r"([+-]?(?:\d{1,3}(?:,\d{3})+|\d+))\s*\|",
            text,
        )
        values = table_values
        for expression in expressions:
            tail = expression.rsplit("=", 1)[-1]
            scalar = re.fullmatch(
                r"[ \t]*([+-]?(?:\d{1,3}(?:,\d{3})+|\d+))[ \t]*[.,]?[ \t]*(?:\\\\)?[ \t]*",
                tail,
            )
            if scalar is not None:
                values.append(scalar.group(1))
        if any(not _integer_equals(value, expected_value) for value in values):
            return False
        if not values:
            complete = False
    return True if complete else None


def _integer_equals(raw: str, expected: int) -> bool:
    """Compare decimal spellings without constructing an unbounded integer."""
    compact = raw.replace(",", "")
    negative = compact.startswith("-")
    digits = compact.lstrip("+-").lstrip("0") or "0"
    canonical = f"-{digits}" if negative and digits != "0" else digits
    return canonical == str(expected)


def assignment_truth_with_tables(
    reply: str, expected: dict[str, int] | Iterable[tuple[str, int]]
) -> bool | None:
    """Read a labeled table cell by its final scalar identity."""
    assignments = dict(expected)
    text = (
        reply.translate(str.maketrans("₀₁₂₃₄₅₆₇₈₉", "0123456789"))
        .replace("**", "")
        .replace("`", "")
        .replace("\\_", "_")
    )
    additions: list[str] = []

    def scalar_value(cell: str) -> str | None:
        cell = re.sub(r"\\[,;:!]", "", cell.replace("$", ""))
        tail = cell.rsplit("=", 1)[-1]
        scalar = re.fullmatch(
            r"\s*([+-]?(?:\d{1,3}(?:,\s*\d{3})+|\d+))\s*[.,]?\s*",
            tail,
        )
        if scalar is None:
            return None
        return scalar.group(1).replace(",", "").replace(" ", "")

    for label in assignments:
        cells = re.findall(
            rf"(?im)^\s*\|\s*{_label_pattern(label)}\s*\|\s*(.*?)\|\s*$",
            text,
        )
        for cell in cells:
            value = scalar_value(cell)
            if value is not None:
                additions.append(f"{label} = {value}")

    rows = [line.strip().strip("|").split("|") for line in text.splitlines() if "|" in line]
    for headers, separator, values in zip(rows, rows[1:], rows[2:]):
        if len(headers) != len(separator) or len(headers) != len(values):
            continue
        if not all(re.fullmatch(r"\s*:?-{3,}:?\s*", cell) for cell in separator):
            continue
        for label in assignments:
            index = next(
                (
                    i
                    for i, header in enumerate(headers)
                    if re.fullmatch(_label_pattern(label), header.strip(), re.IGNORECASE)
                ),
                None,
            )
            if index is not None:
                value = scalar_value(values[index])
                if value is not None:
                    additions.append(f"{label} = {value}")
    measured = reply + ("\n" + "; ".join(additions) if additions else "")
    return assignment_truth(measured, assignments)


def problem_from_prompt(prompt: str) -> Problem | None:
    patterns: tuple[tuple[str, str], ...] = (
        ("shared-seams", r"Shared-seam problem:.*?has (\d+) rows and (\d+) columns"),
        (
            "non-square-rectangles",
            r"Non-square rectangle problem:.*?has (\d+) rows and (\d+) columns",
        ),
        (
            "blocked-paths",
            r"Blocked-path problem:.*?from \(0, 0\) to \((\d+), (\d+)\).*?avoiding "
            r"\((\d+), (\d+)\)",
        ),
        (
            "separated-choices",
            r"Separated-choice problem: choose (\d+) objects from (\d+) distinct objects",
        ),
    )
    for kind, pattern in patterns:
        match = re.search(pattern, prompt, re.DOTALL)
        if match is None:
            continue
        values = tuple(int(value) for value in match.groups())
        if kind == "separated-choices":
            chosen, objects = values
            values = (objects, chosen)
        return Problem(kind, values)
    return None


def _symbolic(text: str) -> str:
    out = text.casefold().replace("−", "-").replace("×", "*").replace("·", "*")
    out = re.sub(r"\\(?:text|mathrm|operatorname)\s*\{([^{}]+)\}", r"\1", out)
    out = out.replace("\\times", "*").replace("\\cdot", "*")
    out = re.sub(
        r"\\binom\s*\{([^{}]+)\}\s*\{([^{}]+)\}",
        r"choose(\1,\2)",
        out,
    )
    out = out.replace("\\left", "").replace("\\right", "").replace("\\_", "_")
    out = out.replace("$", "").replace("{", "(").replace("}", ")")
    out = re.sub(r"\s+", "", out)
    out = out.replace("*", "")
    return out


def method_claim_lands(kind: str, reply: str) -> bool:
    text = _symbolic(reply)
    if kind == "shared-seams":
        horizontal = any(term in text for term in ("h_shared=(r-1)c", "h_shared=c(r-1)"))
        vertical = any(term in text for term in ("v_shared=r(c-1)", "v_shared=(c-1)r"))
        total = any(term in text for term in ("total=h_shared+v_shared", "total=v_shared+h_shared"))
        independent = (
            any(term in text for term in ("total=2rc-r-c", "2rc-r-c=total"))
            or re.search(r"total=[^;]*=2rc-r-c", text) is not None
        )
        return horizontal and vertical and total and independent
    if kind == "non-square-rectangles":
        all_rectangles = any(
            term in text
            for term in (
                "all_rectangles=choose(r+1,2)choose(c+1,2)",
                "all_rectangles=choose(c+1,2)choose(r+1,2)",
            )
        )
        bounds = "s=min(r,c)" in text and "l=max(r,c)" in text
        square_sum = "squares=s(s+1)(3l-s+1)/6" in text
        subtract = "non_square=all_rectangles-squares" in text
        return all_rectangles and bounds and square_sum and subtract
    if kind == "blocked-paths":
        all_paths = any(term in text for term in ("all=choose(a+b,a)", "all=choose(a+b,b)"))
        first = any(term in text for term in ("choose(x+y,x)", "choose(x+y,y)"))
        second = any(
            term in text
            for term in (
                "choose(a-x+b-y,a-x)",
                "choose(a-x+b-y,b-y)",
                "choose((a-x)+(b-y),a-x)",
                "choose((a-x)+(b-y),b-y)",
            )
        )
        check = "all=through+avoid" in text or "through+avoid=all" in text
        return (
            all_paths
            and first
            and second
            and "through=" in text
            and "avoid=all-through" in text
            and binomial_recurrence_lands(text)
            and check
        )
    if kind == "separated-choices":
        all_choices = "all=choose(n,k)" in text
        together = "together=choose(n-2,k-2)" in text
        check = "all=together+allowed" in text or "together+allowed=all" in text
        return (
            all_choices
            and together
            and "allowed=all-together" in text
            and binomial_recurrence_lands(text)
            and check
        )
    return False


def binomial_recurrence_lands(text: str) -> bool:
    start = re.search(r"([a-z])_?0=1", text)
    if start is None or "min(k,n-k)" not in text:
        return False
    letter = re.escape(start.group(1))
    return re.search(rf"{letter}_?j={letter}_?\(j-1\)\(n-j\+1\)/j", text) is not None


def method_claim_refuted(kind: str, reply: str) -> bool:
    text = _symbolic(reply)
    wrong = {
        "shared-seams": (
            ("h_shared", "r(c-1)"),
            ("h_shared", "(c-1)r"),
            ("v_shared", "c(r-1)"),
            ("v_shared", "(r-1)c"),
            ("total", "h_sharedv_shared"),
        ),
        "non-square-rectangles": (("non_square", "all_rectangles+squares"),),
        "blocked-paths": (("avoid", "all+through"),),
        "separated-choices": (
            ("allowed", "all+together"),
            ("together", "choose(n,k-2)"),
        ),
    }
    return any(
        re.search(rf"(?<![+*/=]){label}={re.escape(value)}", text) is not None
        for label, value in wrong[kind]
    )


def lesson_reply_lands(prompt: str, reply: str) -> bool | None:
    problem = problem_from_prompt(prompt)
    if problem is not None:
        truth = assignment_truth(reply, problem.assignments)
        if truth is not True:
            return truth
        _, format_ok = assignment_score(reply, problem.assignments)
        return True if format_ok else None
    kind = method_kind(prompt)
    if kind is None:
        return None
    if method_claim_refuted(kind, reply):
        return False
    return True if method_claim_lands(kind, reply) else None


def lesson_problem(cycle: int) -> tuple[Problem, int]:
    if cycle < 3001:
        raise ValueError("counted-structure lessons begin at cycle 3001")
    offset = cycle - 3001
    kind = KINDS[offset % len(KINDS)]
    occurrence = offset // len(KINDS)
    candidates = probe_candidates(kind, TEACHING_CONFIG[kind])
    candidates.sort(key=lambda values: hashlib.sha256(f"{kind}:{values}".encode()).digest())
    return Problem(kind, candidates[occurrence % len(candidates)]), occurrence


def reflection_due(occurrence: int) -> bool:
    return occurrence >= 3 and occurrence % 4 == 3


def probe_candidates(kind: str, config: dict[str, Any]) -> list[tuple[int, ...]]:
    if kind in {"shared-seams", "non-square-rectangles"}:
        return [
            (rows, columns)
            for rows in range(int(config["rows_min"]), int(config["rows_max"]) + 1)
            for columns in range(int(config["columns_min"]), int(config["columns_max"]) + 1)
            if rows != columns
        ]
    if kind == "blocked-paths":
        return [
            (east, north, blocked_east, blocked_north)
            for east in range(int(config["east_min"]), int(config["east_max"]) + 1)
            for north in range(int(config["north_min"]), int(config["north_max"]) + 1)
            for blocked_east in range(1, east)
            for blocked_north in range(1, north)
        ]
    if kind == "separated-choices":
        return [
            (objects, chosen)
            for objects in range(int(config["objects_min"]), int(config["objects_max"]) + 1)
            for chosen in range(int(config["chosen_min"]), int(config["chosen_max"]) + 1)
            if 2 <= chosen <= objects - 2
        ]
    raise ValueError(f"unknown counted-structure kind: {kind}")
