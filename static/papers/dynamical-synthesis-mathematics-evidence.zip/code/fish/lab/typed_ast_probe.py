"""Compile a bounded, typed arithmetic AST proposed by Fish and check exact task truth.

This is the stricter sibling of ``expression_probe``.  Fish never writes Wolfram source or
chooses a Wolfram head.  It selects operations from a tiny JSON algebra; trusted code
expands references to earlier facts, emits the corresponding allow-listed Wolfram
expression, evaluates it, and compares the result with the predeclared task generator.

The root transport is ``{"v": 1, "facts": {...}}``.  A fact is an operation node
``{"op": NAME, "args": [...]}``; integer leaves are permitted only inside operations,
and ``{"ref": FACT}`` refers to an earlier required fact.  Unknown fields, operations,
forward references, excessive depth, and excessive size are refused before evaluation.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
from typing import Any

from fish.lab import claim_probe

JSON_CAP = claim_probe.INPUT_CAP
MAX_DEPTH = 16
MAX_NODES = 128
MAX_ARGS = 16
MAX_INTEGER = 10**12
INTEGER = re.compile(r"-?\d+")

# Public DSL name -> (minimum arity, maximum arity, trusted Wolfram rendering kind).
OPERATIONS: dict[str, tuple[int, int, str]] = {
    "add": (2, MAX_ARGS, "+"),
    "sub": (2, 2, "-"),
    "mul": (2, MAX_ARGS, "*"),
    "div": (2, 2, "/"),
    "pow": (2, 2, "^"),
    "mod": (2, 2, "Mod"),
    "quotient": (2, 2, "Quotient"),
    "gcd": (2, MAX_ARGS, "GCD"),
    "binomial": (2, 2, "Binomial"),
    "min": (2, MAX_ARGS, "Min"),
    "max": (2, MAX_ARGS, "Max"),
}

OPERATION_HELP = (
    "add(a,b,...)=sum; sub(a,b)=a minus b; mul(a,b,...)=product; "
    "div(a,b)=exact division; pow(a,b)=a to power b; mod(a,b)=remainder; "
    "quotient(a,b)=whole-number quotient; gcd(a,b,...)=greatest common divisor; "
    "binomial(n,k)=n choose k; min(a,b,...)=minimum; max(a,b,...)=maximum"
)


class ProposalError(ValueError):
    """A bounded refusal at the typed-program boundary."""


def checker_sha256() -> str:
    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise ProposalError(f"duplicate JSON key: {key}")
        value[key] = item
    return value


def _parse_json(reply: str, target: dict[str, Any]) -> dict[str, Any]:
    target = claim_probe.verify_spec(target)
    raw = reply.strip()
    if not raw:
        raise ProposalError("empty reply")
    if len(raw.encode("utf-8")) > JSON_CAP:
        raise ProposalError("JSON input cap")
    if not (raw.startswith("{") and raw.endswith("}")):
        raise ProposalError("whole reply must be one JSON object with no prose or fence")
    try:
        value = json.loads(raw, object_pairs_hook=_unique_object)
    except ProposalError:
        raise
    except json.JSONDecodeError as error:
        raise ProposalError(f"invalid JSON: {error.msg}") from error
    if not isinstance(value, dict) or set(value) != {"v", "facts"}:
        raise ProposalError("top-level keys must be exactly v and facts")
    if type(value["v"]) is not int or value["v"] != 1:
        raise ProposalError("v must be the integer 1")
    facts = value["facts"]
    if not isinstance(facts, dict):
        raise ProposalError("facts must be an object")
    required = list(target["required"])
    missing = [name for name in required if name not in facts]
    extra = [name for name in facts if name not in required]
    if missing or extra:
        details = []
        if missing:
            details.append(f"missing facts: {', '.join(missing)}")
        if extra:
            details.append(f"extra facts: {', '.join(extra)}")
        raise ProposalError("; ".join(details))
    return {name: facts[name] for name in required}


def _render_operation(kind: str, arguments: list[str]) -> str:
    if kind in {"+", "-", "*", "/", "^"}:
        return f"({'{}'.format(kind).join(arguments)})"
    return f"{kind}[{','.join(arguments)}]"


def _compile_node(
    node: Any,
    expanded: dict[str, str],
    *,
    fact: str,
    depth: int,
    budget: list[int],
) -> str:
    if depth > MAX_DEPTH:
        raise ProposalError(f"{fact}: AST depth cap")
    budget[0] += 1
    if budget[0] > MAX_NODES:
        raise ProposalError(f"{fact}: AST node cap")
    if type(node) is int:
        if abs(node) > MAX_INTEGER:
            raise ProposalError(f"{fact}: integer magnitude cap")
        return str(node)
    if not isinstance(node, dict):
        raise ProposalError(f"{fact}: every node must be an integer or object")
    if set(node) == {"ref"}:
        reference = node["ref"]
        if not isinstance(reference, str) or reference not in expanded:
            shown = reference if isinstance(reference, str) else repr(reference)
            raise ProposalError(f"{fact}: unknown or forward fact reference: {shown}")
        return f"({expanded[reference]})"
    if set(node) != {"op", "args"}:
        raise ProposalError(f"{fact}: node keys must be exactly op/args or ref")
    operation = node["op"]
    arguments = node["args"]
    if not isinstance(operation, str) or operation not in OPERATIONS:
        raise ProposalError(f"{fact}: unknown operation: {operation!r}")
    if not isinstance(arguments, list):
        raise ProposalError(f"{fact}: args must be an array")
    minimum, maximum, kind = OPERATIONS[operation]
    if not minimum <= len(arguments) <= maximum:
        expected = str(minimum) if minimum == maximum else f"{minimum}..{maximum}"
        raise ProposalError(f"{fact}: {operation} expects {expected} args")
    compiled = [
        _compile_node(item, expanded, fact=fact, depth=depth + 1, budget=budget)
        for item in arguments
    ]
    return _render_operation(kind, compiled)


def compile_proposal(reply: str, target: dict[str, Any]) -> tuple[dict[str, Any], dict[str, str]]:
    """Return Fish's typed nodes and their closed trusted Wolfram expansion."""
    programs = _parse_json(reply, target)
    expanded: dict[str, str] = {}
    functions, constants = claim_probe.allowlists()
    budget = [0]
    for name in target["required"]:
        root = programs[name]
        if not isinstance(root, dict):
            raise ProposalError(f"{name}: a fact root must be an operation or reference")
        expression = _compile_node(root, expanded, fact=name, depth=0, budget=budget)
        if len(expression.encode("utf-8")) > JSON_CAP:
            raise ProposalError(f"{name}: expanded expression cap")
        refusal = claim_probe.gate_refusal(expression, functions, constants)
        if refusal is not None:
            raise ProposalError(f"{name}: compiler emitted refused expression: {refusal}")
        expanded[name] = expression
    return programs, expanded


def parse_proposal(reply: str, target: dict[str, Any]) -> dict[str, Any]:
    programs, _expanded = compile_proposal(reply, target)
    return programs


def _base_record(target: dict[str, Any], exchange_id: int | None) -> dict[str, Any]:
    return {
        "exchange_id": exchange_id,
        "spec_sha256": target["spec_sha256"],
        "kind": target["kind"],
        "parameters": target["parameters"],
        "required": list(target["required"]),
        # These shared field names let the existing whole-JSON audit verify either
        # expression strings or typed programs without weakening either parser.
        "expressions": {},
        "expanded_expressions": {},
        "results": {},
        "checker": "bounded typed JSON AST + trusted compiler + wolfram kernel + exact generator",
        "task_checker_sha256": target["checker_sha256"],
        "proposal_checker_sha256": checker_sha256(),
        "language": "fish-formal-ast-v1",
    }


def _finish(
    record: dict[str, Any],
    verdict: str,
    text: str,
    *,
    counterexample: dict[str, Any] | None = None,
    gate_refusal: str | None = None,
) -> dict[str, Any]:
    return {
        **record,
        "verdict": verdict,
        "disposition": claim_probe.disposition(verdict),
        "gate_refusal": gate_refusal,
        "counterexample": counterexample,
        "text": text,
    }


def judge(reply: str, target: dict[str, Any], exchange_id: int | None = None) -> dict[str, Any]:
    target = claim_probe.verify_spec(target)
    record = _base_record(target, exchange_id)
    try:
        programs, expanded = compile_proposal(reply, target)
    except ProposalError as error:
        reason = str(error)
        return _finish(
            record,
            "refused",
            f"refused before compilation: {reason}.",
            gate_refusal=reason,
        )
    record["expressions"] = programs
    record["expanded_expressions"] = expanded
    names = list(target["required"])
    values = claim_probe.evaluate([expanded[name] for name in names])
    record["results"] = dict(zip(names, values, strict=True))
    expected = {fact["name"]: int(fact["expected"]) for fact in target["facts"]}
    for name, value in record["results"].items():
        if not INTEGER.fullmatch(value):
            witness = {"kind": "not_an_integer", "fact": name, "value": value}
            return _finish(
                record,
                "underdetermined",
                f"underdetermined: {name} compiled to `{value}`, not an integer.",
                counterexample=witness,
            )
        actual = int(value)
        if actual != expected[name]:
            witness = {
                "kind": "wrong_value",
                "fact": name,
                "program": programs[name],
                "expanded_expression": expanded[name],
                "expected": expected[name],
                "actual": actual,
            }
            return _finish(
                record,
                "refuted",
                f"refuted: {name} compiles to {actual}, expected {expected[name]}.",
                counterexample=witness,
            )
    return _finish(
        record,
        "proved",
        f"proved: the typed program compiled {', '.join(names)} to exact task values.",
    )


def prompt_contract(target: dict[str, Any]) -> str:
    target = claim_probe.verify_spec(target)
    facts = ",".join(f'"{name}":{{"op":"<op>","args":[]}}' for name in target["required"])
    operations = ", ".join(OPERATIONS)
    return (
        "Reply with raw JSON only, no prose or Markdown: "
        f'{{"v":1,"facts":{{{facts}}}}}. '
        "The complete node grammar is: NODE := INTEGER | "
        '{"ref":"EARLIER_FACT"} | {"op":"OP_NAME","args":[NODE,...]}. '
        "A fact root is an operation node or an earlier-fact reference. Integers are bare "
        "JSON integers. The integers stated in the task are input literals: put those "
        "integers directly in args. Do not replace a requested output fact with its final "
        "computed integer. Put a reference object directly inside args; never put a bare "
        "fact-name string there. Operation nodes have exactly op and args; reference nodes "
        "have exactly ref. Do not add comment, label, refs, or lit keys. Operation meanings "
        f"are: {OPERATION_HELP}. Allowed op names are: {operations}."
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", type=Path, required=True)
    parser.add_argument("--reply", type=Path)
    parser.add_argument("--exchange", type=int)
    parser.add_argument("--prompt", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    target = json.loads(args.spec.read_text(encoding="utf-8"))
    if args.prompt:
        if args.reply is not None:
            raise SystemExit("--prompt and --reply are mutually exclusive")
        print(prompt_contract(target))
        return
    if args.reply is None:
        raise SystemExit("--reply is required unless --prompt is used")
    result = judge(args.reply.read_text(encoding="utf-8"), target, args.exchange)
    if args.json:
        print(json.dumps(result, ensure_ascii=False))
    else:
        print(f"{result['verdict']:15} {result['disposition']:9} {result['text']}")


if __name__ == "__main__":
    main()
