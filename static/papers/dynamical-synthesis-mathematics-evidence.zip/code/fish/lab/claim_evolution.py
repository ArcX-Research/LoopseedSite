"""Blinded causal test of the private formal-claim dream coat.

The experiment compares three speech generators on matched, previously unseen
tasks: bare base water, the retained August coat, and the new audited-claim
dream.  Every cell gets a fresh daemon process and a disposable clone of the
same frozen body.  Retrieval, verified recall, sigma, fins, and ocean are off.
Fish still speaks through the ordinary daemon and the repository-generated
v3a grammar; the v2 exact checker and a blinded whole-reply audit decide the
reply afterward.

No verb in this file can wear or promote a coat.  ``prepare`` freezes the task
matrix and a sealed arm key before inference.  ``run`` records resumable cells.
``audit-bundle`` emits an arm-blind package.  ``import-audit`` accepts only
veto-or-accept decisions for machine-proved replies.  ``decide`` hashes all
evidence before opening the arm key.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import math
import os
import platform
import random
import re
import secrets
import shutil
import sqlite3
import subprocess
import tempfile
import time
from collections import Counter
from contextlib import closing
from datetime import UTC, datetime
from fractions import Fraction
from pathlib import Path
from typing import Any, Callable

from fish.lab import adaptive_evolution as adaptive
from fish.lab import claim_probe
from fish.lab import task_scoped_grammar as scoped_grammar
from fish.lab import typed_ast_probe_v2 as exact_checker

ROOT = Path(__file__).resolve().parents[2]
LABS = ROOT / "data/fish/labs"
CURRENT_ROOM = LABS / "claims-current.json"
LIVING_BODY = ROOT / "fish/sediment.db"
DEFAULT_BINARY = ROOT / "fish/daemon/target/debug/fish-daemon"
DEFAULT_BASE = ROOT / "fish/water/base.gguf"
DEFAULT_SERVER = Path(shutil.which("llama-server") or "llama-server")
DEFAULT_WOLFRAM = Path(shutil.which("wolframscript") or "wolframscript")
OLD_COAT = ROOT / "fish/water/adapters/2026-08-16T163701.626802Z/lora.gguf"
INSTRUMENT = "claim-coat-evolution-v1"
PRIMARY_PER_FAMILY = 8
TRANSFER_PER_FAMILY = 2
PRIMARY = "node-specified"
TRANSFER = "unscaffolded-transfer"
STAGES = (PRIMARY, TRANSFER)
ARM_KINDS = ("bare", "retained", "candidate")
MAX_REPLY_TOKENS = 1024
MAX_RECORD_BYTES = 4 * 1024 * 1024
MAX_AUDIT_BYTES = 16 * 1024 * 1024
MAX_AUDIT_REASON = 2_000
PORT = 18093
CONTEXT = 8192
PARALLEL = 1
CELL_TIMEOUT = 180
SWAP_LIMIT_MIB = 8192.0
MAX_VOID_CELLS_PER_ARM = 4
SEED_SALT = "loopseed-claim-evolution-v1"
HEX64 = re.compile(r"[0-9a-f]{64}")
INTEGER_TOKEN = re.compile(r"(?<![A-Za-z0-9_])-?\d+(?![A-Za-z0-9_])")
PINNED_ENV = (
    "FISH_HOME",
    "FISH_WATER_LAB",
    "FISH_BRIDGE",
    "FISH_WATER",
    "FISH_SPEAKER",
    "FISH_SESSION",
    "FISH_KEEPER_WORD",
    "FISH_KRYPTOS_VOICE",
    "FISH_EMBEDDER",
    "FISH_VISION_BIN",
    "FISH_WATER_URL",
    "FISH_WATER_SEED",
    "FISH_LEDGER",
    "FISH_MIRROR",
    "FISH_FIN",
    "FISH_OCEAN",
    "FISH_DEBUG",
    "FISH_WATER_VOICE_LORA_SCALE",
    "FISH_WATER_PREDICTION_LORA_SCALE",
    "FISH_WATER_LORA_SCALE",
    "FISH_MAX_REPLY_TOKENS",
    "FISH_WATER_PATIENCE_SECS",
    "FISH_WIRE_PREVIEW_CHARS",
    "FISH_PORT_JSONL",
    "FISH_VERIFIED",
    "FISH_VERIFIED_KIND",
    "FISH_RETRIEVAL",
)


class ExperimentRefusal(RuntimeError):
    """A frozen or safety boundary did not hold."""


def utc_now() -> str:
    return datetime.now(UTC).isoformat(timespec="milliseconds")


def canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def sha256(path: Path) -> str:
    return adaptive.sha256(path)


def _load_object(path: Path, *, cap: int = MAX_RECORD_BYTES) -> dict[str, Any]:
    if path.is_symlink() or not path.is_file() or path.stat().st_size > cap:
        raise ExperimentRefusal(f"missing, linked, or oversized JSON artifact: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ExperimentRefusal(f"invalid JSON artifact: {path}") from error
    if not isinstance(value, dict):
        raise ExperimentRefusal(f"JSON artifact is not an object: {path}")
    return value


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + "\n"
    with tempfile.NamedTemporaryFile(
        "w", encoding="utf-8", dir=path.parent, prefix=f".{path.name}.", delete=False
    ) as stream:
        temporary = Path(stream.name)
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def _write_once(path: Path, value: dict[str, Any]) -> dict[str, Any]:
    """Create immutable evidence, or verify that an identical artifact exists."""
    if path.exists():
        existing = _load_object(path, cap=MAX_AUDIT_BYTES)
        if canonical(existing) != canonical(value):
            raise ExperimentRefusal(f"refusing to overwrite frozen evidence: {path}")
        return existing
    _atomic_json(path, value)
    path.chmod(0o444)
    return value


def _confined(path: Path, root: Path, label: str, *, exists: bool = True) -> Path:
    resolved = path.resolve(strict=exists)
    if not resolved.is_relative_to(root.resolve()):
        raise ExperimentRefusal(f"{label} escapes {root}")
    return resolved


def _target_at(kind: str, parameters: list[int], created_at: str) -> dict[str, Any]:
    target = claim_probe.spec(kind, parameters)
    target["created_at"] = created_at
    body = {key: value for key, value in target.items() if key != "spec_sha256"}
    target["spec_sha256"] = hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()
    return claim_probe.verify_spec(target)


def _ref(name: str) -> dict[str, str]:
    return {"ref": name}


def _op(name: str, *arguments: object) -> dict[str, object]:
    return {"op": name, "args": list(arguments)}


def canonical_program(kind: str, p: list[int]) -> dict[str, Any]:
    """A checked operation graph used only to describe the node-specified arm."""
    if kind == "euclidean-recurrence":
        a, b = p
        previous_name: str | None = None
        before_previous_name: str | None = None
        previous, current, index = a, b, 2
        facts: dict[str, Any] = {}
        while current:
            name = f"R{index}"
            if index == 2:
                facts[name] = _op("mod", a, b)
            elif index == 3:
                facts[name] = _op("mod", b, _ref(str(previous_name)))
            else:
                facts[name] = _op("mod", _ref(str(before_previous_name)), _ref(str(previous_name)))
            previous, current = current, previous % current
            before_previous_name, previous_name = previous_name, name
            index += 1
        facts["GCD"] = _op("gcd", a, b)
        return facts
    if kind in {"gcd-reduction", "fraction-reduction"}:
        a, b = p
        gcd_name = "G" if kind == "gcd-reduction" else "GCD"
        numerator = "VALUE_REDUCED" if kind == "gcd-reduction" else "REDUCED_NUMERATOR"
        denominator = "DIVISOR_REDUCED" if kind == "gcd-reduction" else "REDUCED_DENOMINATOR"
        return {
            gcd_name: _op("gcd", a, b),
            numerator: _op("div", a, _ref(gcd_name)),
            denominator: _op("div", b, _ref(gcd_name)),
        }
    if kind == "quotient-remainder":
        a, b = p
        return {
            "QUOTIENT": _op("quotient", a, b),
            "REMAINDER": _op("mod", a, b),
            "RECONSTRUCTED": _op("add", _op("mul", b, _ref("QUOTIENT")), _ref("REMAINDER")),
        }
    if kind == "binomial-recurrence":
        return {"CHOOSE": _op("binomial", p[0], p[1])}
    if kind == "shared-seams":
        r, c = p
        return {
            "H_SHARED": _op("mul", _op("sub", r, 1), c),
            "V_SHARED": _op("mul", r, _op("sub", c, 1)),
            "TOTAL": _op("add", _ref("H_SHARED"), _ref("V_SHARED")),
        }
    if kind == "blocked-paths":
        a, b, x, y = p
        return {
            "ALL": _op("binomial", _op("add", a, b), a),
            "THROUGH": _op(
                "mul",
                _op("binomial", _op("add", x, y), x),
                _op(
                    "binomial",
                    _op("add", _op("sub", a, x), _op("sub", b, y)),
                    _op("sub", a, x),
                ),
            ),
            "AVOID": _op("sub", _ref("ALL"), _ref("THROUGH")),
        }
    if kind == "separated-choices":
        n, k = p
        return {
            "ALL": _op("binomial", n, k),
            "TOGETHER": _op("binomial", _op("sub", n, 2), _op("sub", k, 2)),
            "ALLOWED": _op("sub", _ref("ALL"), _ref("TOGETHER")),
        }
    if kind == "non-square-rectangles":
        r, c = p
        squares = []
        for side in range(1, min(r, c) + 1):
            height: object = r if side == 1 else _op("sub", r, side - 1)
            width: object = c if side == 1 else _op("sub", c, side - 1)
            squares.append(_op("mul", height, width))
        return {
            "ALL_RECTANGLES": _op(
                "mul",
                _op("binomial", _op("add", r, 1), 2),
                _op("binomial", _op("add", c, 1), 2),
            ),
            "SQUARES": _op("add", *squares),
            "NON_SQUARE": _op("sub", _ref("ALL_RECTANGLES"), _ref("SQUARES")),
        }
    if kind == "carry-addition":
        product, carry = p
        return {
            "RAW": _op("add", product, carry),
            "OUT_DIGIT": _op("mod", _ref("RAW"), 10),
            "NEXT_CARRY": _op("quotient", _ref("RAW"), 10),
        }
    if kind == "digit-product":
        digit, multiplier = p
        return {
            "PRODUCT": _op("mul", digit, multiplier),
            "TENS_PART": _op("quotient", _ref("PRODUCT"), 10),
            "ONES_PART": _op("mod", _ref("PRODUCT"), 10),
        }
    if kind == "place-value-sum":
        hundreds, tens, ones = p
        return {
            "PREFIX_SUM": _op("add", hundreds, tens),
            "RESULT": _op("add", _ref("PREFIX_SUM"), ones),
        }
    if kind in {"tens-carry-join", "hundreds-carry-join"}:
        value, multiplier, carry = p
        prefix = "TENS" if kind == "tens-carry-join" else "HUNDREDS"
        return {
            f"{prefix}_PRODUCT": _op("mul", value, multiplier),
            f"{prefix}_RAW": _op("add", _ref(f"{prefix}_PRODUCT"), carry),
        }
    if kind == "two-column-product":
        tens, ones, multiplier = p
        return {
            "ONES_PRODUCT": _op("mul", ones, multiplier),
            "ONES_DIGIT": _op("mod", _ref("ONES_PRODUCT"), 10),
            "CARRY_TO_TENS": _op("quotient", _ref("ONES_PRODUCT"), 10),
            "TENS_RAW": _op("add", _op("mul", tens, multiplier), _ref("CARRY_TO_TENS")),
            "RESULT": _op("add", _op("mul", _ref("TENS_RAW"), 10), _ref("ONES_DIGIT")),
        }
    if kind == "chinese-remainders":
        r1, m1, r2, m2 = p
        # Candidate moduli are prime. Fermat's inverse constructs the solution
        # entirely from the public task inputs; putting the already-solved CRT
        # value in this node-specified prompt would leak the answer.
        inverse = _op("mod", _op("pow", m1, _op("sub", m2, 2)), m2)
        solution = _op(
            "add",
            r1,
            _op("mul", m1, _op("mod", _op("mul", _op("sub", r2, r1), inverse), m2)),
        )
        return {
            "RESIDUE_MOD_FIRST": _op("mod", solution, m1),
            "RESIDUE_MOD_SECOND": _op("mod", solution, m2),
            "MODULUS": _op("mul", m1, m2),
        }
    raise ExperimentRefusal(f"no node program for {kind}")


def _describe_node(node: object) -> str:
    if type(node) is int:
        return f"the bare integer {node}"
    if not isinstance(node, dict):
        raise ExperimentRefusal("canonical node is not typed")
    if set(node) == {"ref"}:
        return f"the exact reference {node['ref']}"
    operation = str(node["op"])
    arguments = ", then ".join(_describe_node(value) for value in node["args"])
    return f"a {operation} node whose arguments are {arguments}"


def _integer_leaves(value: object) -> list[int]:
    if type(value) is int:
        return [value]
    if isinstance(value, list):
        return [number for item in value for number in _integer_leaves(item)]
    if isinstance(value, dict):
        return [number for item in value.values() for number in _integer_leaves(item)]
    return []


def _task_statement(kind: str, p: list[int]) -> str:
    if kind == "euclidean-recurrence":
        return f"Run Euclid's remainder chain on {p[0]} and {p[1]} through the zero remainder."
    if kind == "gcd-reduction":
        return f"Reduce the integer ratio {p[0]} to {p[1]} by their greatest common divisor."
    if kind == "fraction-reduction":
        return f"Reduce the fraction {p[0]}/{p[1]} to lowest terms."
    if kind == "quotient-remainder":
        return f"Divide {p[0]} by {p[1]} and reconstruct the dividend."
    if kind == "binomial-recurrence":
        return f"Choose {p[1]} unordered objects from {p[0]} distinct objects."
    if kind == "shared-seams":
        return (
            f"Count horizontal, vertical, and total shared seams in a {p[0]} by {p[1]} cell grid."
        )
    if kind == "blocked-paths":
        return (
            f"Count monotone paths {p[0]} steps right and {p[1]} up that avoid "
            f"the point ({p[2]},{p[3]}), including the all and through counts."
        )
    if kind == "separated-choices":
        return (
            f"Choose {p[1]} items from {p[0]} when two distinguished items may not both "
            "be chosen; compute all, together, and allowed."
        )
    if kind == "non-square-rectangles":
        return (
            f"In a {p[0]} by {p[1]} cell grid count all rectangles, all squares, "
            "and the non-square rectangles."
        )
    if kind == "carry-addition":
        return f"Add carry {p[1]} to column product {p[0]}, then split the raw value at base 10."
    if kind == "digit-product":
        return f"Multiply digit {p[0]} by {p[1]}, then split the product into tens and ones parts."
    if kind == "place-value-sum":
        return f"Join place-value parts {p[0]}, {p[1]}, and {p[2]} by exact addition."
    if kind == "tens-carry-join":
        return f"Multiply tens digit {p[0]} by {p[1]}, then add incoming carry {p[2]}."
    if kind == "hundreds-carry-join":
        return f"Multiply hundreds digit {p[0]} by {p[1]}, then add incoming carry {p[2]}."
    if kind == "two-column-product":
        return (
            f"Multiply the two-digit number with tens digit {p[0]} and ones digit {p[1]} "
            f"by {p[2]}, preserving the column trace."
        )
    if kind == "chinese-remainders":
        return (
            f"Find the least nonnegative integer congruent to {p[0]} modulo {p[1]} and "
            f"to {p[2]} modulo {p[3]}, then verify both residues and the combined modulus."
        )
    raise ExperimentRefusal(f"no task wording for {kind}")


def render_prompt(
    kind: str, parameters: list[int], target: dict[str, Any], stage: str
) -> tuple[str, list[int]]:
    program = canonical_program(kind, parameters)
    if list(program) != list(target["required"]):
        raise ExperimentRefusal(f"canonical program differs from the exact facts for {kind}")
    statement = _task_statement(kind, parameters)
    if stage == PRIMARY:
        recipe = "; ".join(
            f"propose {name} as {_describe_node(node)}" for name, node in program.items()
        )
        opening = f"One fresh task, no tools. {statement} {recipe}."
    elif stage == TRANSFER:
        names = ", ".join(target["required"])
        opening = (
            f"Unseen transfer task, no tools and no operation recipe. {statement} "
            f"Express the complete computation for {names} in the typed language."
        )
    else:
        raise ExperimentRefusal(f"unknown prompt stage: {stage}")
    prompt = f"{opening} {exact_checker.prompt_contract(target)}"
    if "\n" in prompt or prompt != prompt.strip():
        raise ExperimentRefusal("a Fish port prompt must be one trimmed line")
    allowed = sorted(set(parameters) | set(_integer_leaves(program)) | {0, 1, 2, 10})
    return prompt, allowed


FAMILIES = tuple(sorted(claim_probe.GENERATORS))


def _coprime_pair(rng: random.Random, low: int, high: int) -> tuple[int, int]:
    while True:
        left, right = rng.randint(low, high), rng.randint(low, high)
        if left != right and math.gcd(left, right) == 1:
            return left, right


def candidate_parameters(kind: str, rng: random.Random) -> list[int]:
    if kind == "euclidean-recurrence":
        while True:
            a, b = rng.randint(300, 9999), rng.randint(80, 2999)
            if a > b and len(claim_probe.euclid([a, b])) >= 4:
                return [a, b]
    if kind in {"gcd-reduction", "fraction-reduction"}:
        left, right = _coprime_pair(rng, 3, 97)
        common = rng.randint(3, 47)
        return [common * left, common * right]
    if kind == "quotient-remainder":
        divisor = rng.randint(17, 97)
        quotient = rng.randint(11, 179)
        remainder = rng.randint(1, divisor - 1)
        return [divisor * quotient + remainder, divisor]
    if kind == "binomial-recurrence":
        n = rng.randint(10, 36)
        return [n, rng.randint(2, min(9, n - 2))]
    if kind == "shared-seams":
        return [rng.randint(20, 99), rng.randint(20, 99)]
    if kind == "blocked-paths":
        a, b = rng.randint(6, 16), rng.randint(6, 16)
        return [a, b, rng.randint(1, a - 1), rng.randint(1, b - 1)]
    if kind == "separated-choices":
        n = rng.randint(12, 38)
        return [n, rng.randint(3, min(10, n - 1))]
    if kind == "non-square-rectangles":
        return [rng.randint(3, 10), rng.randint(3, 12)]
    if kind == "carry-addition":
        return [rng.randint(21, 999), rng.randint(1, 19)]
    if kind == "digit-product":
        return [rng.randint(2, 9), rng.randint(2, 12)]
    if kind == "place-value-sum":
        return [100 * rng.randint(1, 9), 10 * rng.randint(1, 9), rng.randint(1, 9)]
    if kind in {"tens-carry-join", "hundreds-carry-join"}:
        return [rng.randint(2, 9), rng.randint(2, 12), rng.randint(1, 9)]
    if kind == "two-column-product":
        return [rng.randint(2, 9), rng.randint(2, 9), rng.randint(2, 9)]
    if kind == "chinese-remainders":
        moduli = [11, 13, 17, 19, 23, 29, 31, 37, 41, 43]
        m1, m2 = rng.sample(moduli, 2)
        return [rng.randrange(m1), m1, rng.randrange(m2), m2]
    raise ExperimentRefusal(f"no candidate domain for {kind}")


def _evaluate_node(node: object, values: dict[str, int]) -> int | Fraction:
    if type(node) is int:
        return int(node)
    if not isinstance(node, dict):
        raise ExperimentRefusal("canonical program contains an untyped node")
    if set(node) == {"ref"}:
        name = str(node["ref"])
        if name not in values:
            raise ExperimentRefusal(f"canonical program has a forward reference: {name}")
        return values[name]
    if set(node) != {"op", "args"}:
        raise ExperimentRefusal("canonical program contains an invalid object")
    operation = str(node["op"])
    arguments = [_evaluate_node(value, values) for value in node["args"]]
    if operation == "add":
        return sum(arguments, start=Fraction(0))
    if operation == "sub":
        return arguments[0] - arguments[1]
    if operation == "mul":
        result: int | Fraction = 1
        for argument in arguments:
            result *= argument
        return result
    if operation == "div":
        return Fraction(arguments[0], arguments[1])
    if operation == "pow":
        return arguments[0] ** int(arguments[1])
    integer_arguments = [int(value) for value in arguments]
    if operation == "mod":
        return integer_arguments[0] % integer_arguments[1]
    if operation == "quotient":
        return integer_arguments[0] // integer_arguments[1]
    if operation == "gcd":
        return math.gcd(*integer_arguments)
    if operation == "binomial":
        return math.comb(integer_arguments[0], integer_arguments[1])
    if operation == "min":
        return min(integer_arguments)
    if operation == "max":
        return max(integer_arguments)
    raise ExperimentRefusal(f"canonical program uses an unknown operation: {operation}")


def verify_canonical_program(target: dict[str, Any], program: dict[str, Any]) -> None:
    expected = {str(fact["name"]): int(fact["expected"]) for fact in target["facts"]}
    values: dict[str, int] = {}
    for name in target["required"]:
        actual = _evaluate_node(program[name], values)
        if isinstance(actual, Fraction) and actual.denominator != 1:
            raise ExperimentRefusal(f"canonical {target['kind']} fact {name} is fractional")
        value = int(actual)
        if value != expected[name]:
            raise ExperimentRefusal(
                f"canonical {target['kind']} fact {name} is {value}, expected {expected[name]}"
            )
        values[name] = value


def historical_tasks(
    room: Path, source: Path
) -> tuple[set[tuple[str, tuple[int, ...]]], dict[str, Any]]:
    """Read every structured task the room or frozen body can name."""
    seen: set[tuple[str, tuple[int, ...]]] = set()
    sources: list[dict[str, Any]] = []
    specs = room / "specs"
    for path in sorted(specs.glob("*.json")):
        value = _load_object(path)
        kind, parameters = value.get("kind"), value.get("parameters")
        if (
            type(kind) is str
            and isinstance(parameters, list)
            and all(type(number) is int for number in parameters)
        ):
            seen.add((kind, tuple(parameters)))
        sources.append({"path": str(path), "sha256": sha256(path)})

    with closing(sqlite3.connect(f"file:{source.resolve()}?mode=ro", uri=True)) as database:
        tables = {
            str(row[0])
            for row in database.execute("SELECT name FROM sqlite_master WHERE type='table'")
        }
        if "verified_lessons" in tables:
            for kind, raw in database.execute("SELECT kind, parameters_json FROM verified_lessons"):
                try:
                    parameters = json.loads(str(raw))
                except json.JSONDecodeError:
                    continue
                if isinstance(parameters, list) and all(
                    type(number) is int for number in parameters
                ):
                    seen.add((str(kind), tuple(parameters)))
        if "claim_reviews" in tables:
            for (raw,) in database.execute("SELECT record_json FROM claim_reviews"):
                try:
                    record = json.loads(str(raw))
                except json.JSONDecodeError:
                    continue
                kind, parameters = record.get("kind"), record.get("parameters")
                if (
                    type(kind) is str
                    and isinstance(parameters, list)
                    and all(type(number) is int for number in parameters)
                ):
                    seen.add((kind, tuple(parameters)))
    canonical_seen = [
        {"kind": kind, "parameters": list(parameters)} for kind, parameters in sorted(seen)
    ]
    return seen, {
        "tasks": canonical_seen,
        "tasks_sha256": sha256_text(canonical(canonical_seen)),
        "task_count": len(canonical_seen),
        "room_spec_files": sources,
    }


def _derive_rng(kind: str, stage: str) -> random.Random:
    digest = hashlib.sha256(f"{SEED_SALT}\0{kind}\0{stage}".encode()).digest()
    return random.Random(int.from_bytes(digest[:8], "big"))


def _case(
    kind: str,
    parameters: list[int],
    stage: str,
    index: int,
    created_at: str,
) -> dict[str, Any]:
    target = _target_at(kind, parameters, created_at)
    program = canonical_program(kind, parameters)
    verify_canonical_program(target, program)
    prompt, allowed_literals = render_prompt(kind, parameters, target, stage)
    scope = scoped_grammar.scope_for(target)
    generated = scoped_grammar.generate(scope)
    identity = sha256_text(
        canonical(
            {
                "kind": kind,
                "parameters": parameters,
                "stage": stage,
                "index": index,
                "spec_sha256": target["spec_sha256"],
                "prompt_sha256": sha256_text(prompt),
            }
        )
    )
    case = {
        "id": f"{stage[:1]}-{kind}-{index + 1:02d}-{identity[:10]}",
        "kind": kind,
        "parameters": parameters,
        "stage": stage,
        "family_index": index,
        "block": index,
        "seed": int(identity[:8], 16) & 0x7FFF_FFFF,
        "prompt": prompt,
        "prompt_sha256": sha256_text(prompt),
        "allowed_literals": allowed_literals,
        "spec": target,
        "scope": scope,
        "grammar": {
            key: generated[key]
            for key in (
                "name",
                "voice_grammar_sha256",
                "voice_grammar_scope_sha256",
                "voice_grammar_generator_sha256",
            )
        },
    }
    case["case_sha256"] = sha256_text(canonical(case))
    return case


def generate_cases(seen: set[tuple[str, tuple[int, ...]]], created_at: str) -> list[dict[str, Any]]:
    cases: list[dict[str, Any]] = []
    selected = set(seen)
    for stage, count in ((PRIMARY, PRIMARY_PER_FAMILY), (TRANSFER, TRANSFER_PER_FAMILY)):
        for kind in FAMILIES:
            rng = _derive_rng(kind, stage)
            for index in range(count):
                for _attempt in range(20_000):
                    parameters = candidate_parameters(kind, rng)
                    key = (kind, tuple(parameters))
                    if key in selected:
                        continue
                    claim_probe.validate_task_parameters(kind, parameters)
                    selected.add(key)
                    cases.append(_case(kind, parameters, stage, index, created_at))
                    break
                else:
                    raise ExperimentRefusal(f"could not derive an unseen {kind} task")
    expected = len(FAMILIES) * (PRIMARY_PER_FAMILY + TRANSFER_PER_FAMILY)
    if len(cases) != expected:
        raise ExperimentRefusal(f"case matrix has {len(cases)} tasks, expected {expected}")
    return cases


def _current_lineage(room_pointer: Path = CURRENT_ROOM) -> dict[str, Any]:
    pointer = _load_object(room_pointer)
    room = _confined(Path(str(pointer.get("run", ""))), LABS, "claim room")
    conversation = _load_object(room / "conversation.json")
    dataset_path = Path((room / "dreams/current-dataset.path").read_text().strip())
    dataset = _confined(dataset_path, room / "dreams", "dream dataset")
    manifest = _load_object(dataset / "manifest.json")
    source = _confined(Path(str(manifest.get("source_snapshot", ""))), dataset, "source snapshot")
    adapter_path = Path((room / "dreams/current-adapter.path").read_text().strip())
    adapter = _confined(adapter_path, room / "body/fish/water/adapters", "dream adapter")
    candidate = _confined(adapter / "lora.gguf", adapter, "candidate coat")
    return {
        "room": room,
        "conversation": conversation,
        "dataset": dataset,
        "manifest": manifest,
        "source": source,
        "candidate": candidate,
    }


def _validate_lineage(lineage: dict[str, Any]) -> None:
    room = Path(str(lineage["room"]))
    source = Path(str(lineage["source"]))
    candidate = Path(str(lineage["candidate"]))
    manifest = lineage["manifest"]
    conversation = lineage["conversation"]
    if not isinstance(manifest, dict) or not isinstance(conversation, dict):
        raise ExperimentRefusal("claim lineage metadata is malformed")
    expected_source = manifest.get("source_snapshot_sha256")
    if (
        expected_source != sha256(source)
        or manifest.get("hashes", {}).get("source.db") != expected_source
    ):
        raise ExperimentRefusal("the frozen dream source differs from its manifest")
    if source.resolve() in {
        LIVING_BODY.resolve(),
        Path(str(conversation.get("clone_body", ""))).resolve(),
    }:
        raise ExperimentRefusal("the experiment source may not be living or the mutable room clone")
    living_expected = str(manifest.get("living_sha256", ""))
    if (
        sha256(LIVING_BODY) != living_expected
        or conversation.get("living_sha256") != living_expected
    ):
        raise ExperimentRefusal("the living body changed after the claim room was cloned")
    if sha256(candidate) != "40a7d899597fc09b66ebbac39c5835bbd254bbde8e001e9582415ba91fe40b57":
        raise ExperimentRefusal("the private claim-dream coat is not the trained candidate")
    if room != Path(str(manifest.get("room", ""))).resolve():
        raise ExperimentRefusal("the dream manifest belongs to another claim room")


def _server_identity(path: Path) -> dict[str, str]:
    resolved = path.resolve(strict=True)
    version = subprocess.check_output(
        [str(resolved), "--version"], text=True, stderr=subprocess.STDOUT, timeout=30
    ).strip()
    return {"path": str(resolved), "sha256": sha256(resolved), "version": version}


def _wolfram_identity(path: Path = DEFAULT_WOLFRAM) -> dict[str, str]:
    resolved = path.resolve(strict=True)
    version = subprocess.check_output(
        [str(resolved), "-version"], text=True, stderr=subprocess.STDOUT, timeout=30
    ).strip()
    return {"path": str(resolved), "sha256": sha256(resolved), "version": version}


def _git_commit() -> str:
    return subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, timeout=30
    ).strip()


def _require_tracked_tree_clean() -> None:
    result = subprocess.run(["git", "diff", "--quiet", "--"], cwd=ROOT, check=False, timeout=30)
    if result.returncode != 0:
        raise ExperimentRefusal("commit the tracked experiment instruments before prepare")


def _arm_key(old_coat: Path, candidate: Path, created_at: str) -> dict[str, Any]:
    labels = ["A", "B", "C"]
    kinds = list(ARM_KINDS)
    secrets.SystemRandom().shuffle(kinds)
    descriptions = {
        "bare": {"coat": str(old_coat.resolve()), "coat_sha256": sha256(old_coat), "scale": 0.0},
        "retained": {
            "coat": str(old_coat.resolve()),
            "coat_sha256": sha256(old_coat),
            "scale": 1.0,
        },
        "candidate": {
            "coat": str(candidate.resolve()),
            "coat_sha256": sha256(candidate),
            "scale": 1.0,
        },
    }
    return {
        "version": 1,
        "instrument": INSTRUMENT,
        "created_at": created_at,
        "nonce": secrets.token_hex(32),
        "mapping": {
            label: {"kind": kind, **descriptions[kind]} for label, kind in zip(labels, kinds)
        },
    }


def _block_orders(labels: list[str], blocks: int) -> dict[str, list[str]]:
    patterns = [
        labels,
        list(reversed(labels)),
        labels[1:] + labels[:1],
        [labels[0], labels[2], labels[1]],
        [labels[2], labels[0], labels[1]],
        [labels[1], labels[0], labels[2]],
    ]
    return {str(index): list(patterns[index % len(patterns)]) for index in range(blocks)}


def prepare(
    out: Path,
    *,
    room_pointer: Path = CURRENT_ROOM,
    binary: Path = DEFAULT_BINARY,
    base: Path = DEFAULT_BASE,
    server: Path = DEFAULT_SERVER,
    created_at: str | None = None,
) -> dict[str, Any]:
    if out.exists():
        raise ExperimentRefusal(f"experiment directory already exists: {out}")
    _require_tracked_tree_clean()
    lineage = _current_lineage(room_pointer)
    _validate_lineage(lineage)
    room = Path(str(lineage["room"]))
    source = Path(str(lineage["source"]))
    candidate = Path(str(lineage["candidate"]))
    made_at = created_at or utc_now()
    seen, exclusion = historical_tasks(room, source)
    cases = generate_cases(seen, made_at)
    out.mkdir(parents=True)
    key = _arm_key(OLD_COAT, candidate, made_at)
    key_path = out / "arm-key.json"
    _atomic_json(key_path, key)
    key_path.chmod(0o600)
    server_pin = _server_identity(server)
    wolfram_pin = _wolfram_identity()
    manifest = lineage["manifest"]
    if not isinstance(manifest, dict):
        raise ExperimentRefusal("dream manifest is not an object")
    pins = {
        "claim_evolution_sha256": sha256(Path(__file__)),
        "adaptive_evolution_sha256": sha256(Path(adaptive.__file__)),
        "claim_probe_sha256": sha256(Path(claim_probe.__file__)),
        "typed_ast_probe_v2_sha256": sha256(Path(exact_checker.__file__)),
        "task_scoped_grammar_sha256": sha256(Path(scoped_grammar.__file__)),
        "task_grammar_manifest_sha256": sha256(scoped_grammar.MANIFEST),
        "soul_sha256": sha256(ROOT / "SOUL.md"),
        "daemon_binary_path": str(binary.resolve(strict=True)),
        "daemon_binary_sha256": sha256(binary),
        "base_path": str(base.resolve(strict=True)),
        "base_sha256": sha256(base),
        "server": server_pin,
        "wolfram": wolfram_pin,
        "python": platform.python_version(),
        "git_commit": _git_commit(),
        "source_body_path": str(source),
        "source_body_sha256": sha256(source),
        "living_body_path": str(LIVING_BODY.resolve()),
        "living_body_sha256": sha256(LIVING_BODY),
        "retained_coat_path": str(OLD_COAT.resolve(strict=True)),
        "retained_coat_sha256": sha256(OLD_COAT),
        "candidate_coat_path": str(candidate),
        "candidate_coat_sha256": sha256(candidate),
        "dream_manifest_path": str(Path(str(lineage["dataset"])) / "manifest.json"),
        "dream_manifest_sha256": sha256(Path(str(lineage["dataset"])) / "manifest.json"),
        "arm_key_sha256": sha256(key_path),
    }
    plan = {
        "version": 1,
        "instrument": INSTRUMENT,
        "created_at": made_at,
        "status": "prepared",
        "objective": (
            "causal behavioral effect of the audited formal-claim dream on tasks absent "
            "from the frozen accepted dream data"
        ),
        "design": {
            "arms": 3,
            "arm_labels": ["A", "B", "C"],
            "temperature": 0.0,
            "water_port": PORT,
            "context_tokens": CONTEXT,
            "parallel_requests": PARALLEL,
            "max_reply_tokens": MAX_REPLY_TOKENS,
            "cell_timeout_seconds": CELL_TIMEOUT,
            "primary": {
                "stage": PRIMARY,
                "tasks_per_family": PRIMARY_PER_FAMILY,
                "families": len(FAMILIES),
                "tasks": len(FAMILIES) * PRIMARY_PER_FAMILY,
            },
            "conditional_transfer": {
                "stage": TRANSFER,
                "run_only_after_primary_gate": True,
                "tasks_per_family": TRANSFER_PER_FAMILY,
                "families": len(FAMILIES),
                "tasks": len(FAMILIES) * TRANSFER_PER_FAMILY,
            },
            "fresh_body_and_daemon_per_cell": True,
            "retrieval": "off",
            "verified_recall": "off",
            "ledger": "off",
            "mirror": "off",
            "fins": "off",
            "ocean": "off",
            "voice_grammar": scoped_grammar.NAME,
            "exact_ruler": "typed_ast_probe_v2",
            "whole_reply_audit": "Claude may veto a proof and may never upgrade a failure",
        },
        "decision_rule": {
            "unit": "distinct matched task",
            "analysis_set": (
                "three-arm complete cases only: if any arm is mechanically void for a task, "
                "that task is excluded from both paired comparisons"
            ),
            "mechanical_validity": (
                "at most 4 mechanically void cells in each arm per stage; above the ceiling "
                "the stage has no causal verdict and no void may become a gain, loss, or tie"
            ),
            "max_void_cells_per_arm_per_stage": MAX_VOID_CELLS_PER_ARM,
            "reply_cap_cuts": (
                "a 1024-token cap cut is a counted model failure, never a mechanical void, "
                "and is reported separately per arm"
            ),
            "success": (
                "within the three-arm complete-case set: exact proved AND blinded audit accepted"
            ),
            "primary_superiority": (
                "candidate must beat retained and bare with one-sided exact McNemar p<0.05 "
                "and Bonferroni-Clopper-Pearson paired 95% lower difference >0"
            ),
            "paired_lower_difference": (
                "CP lower 97.5% bound for gain probability minus CP upper 97.5% "
                "bound for loss probability"
            ),
            "overall_no_harm_margin": -0.10,
            "family_loss_limit_of_eight": 2,
            "negative_literal_rate_may_not_increase": True,
            "conditional_transfer": "at least 5 gains, 0 losses, spanning at least 3 families",
            "power_expectation": (
                "with all 128 primary tasks complete and zero losses, each comparison needs "
                "at least 9 candidate-only successes; losses increase that requirement"
            ),
            "audit_rubric": (
                "whole JSON only; exact requested facts; operation graph addresses the task; "
                "no answer injection, unrelated claim, prose, or leakage"
            ),
            "automatic_promotion": False,
            "placebo_required_before_living_promotion": True,
        },
        "block_orders": {
            PRIMARY: _block_orders(["A", "B", "C"], PRIMARY_PER_FAMILY),
            TRANSFER: _block_orders(["A", "B", "C"], TRANSFER_PER_FAMILY),
        },
        "pins": pins,
        "exclusion": exclusion,
        "cases": cases,
    }
    plan["plan_sha256"] = sha256_text(canonical(plan))
    _atomic_json(out / "protocol.json", plan)
    _atomic_json(
        out / "state.json",
        {
            "version": 1,
            "instrument": INSTRUMENT,
            "status": "prepared",
            "created_at": made_at,
            "updated_at": made_at,
            "protocol_sha256": sha256(out / "protocol.json"),
            "stages": {PRIMARY: "not-run", TRANSFER: "blocked-on-primary"},
            "audits": {PRIMARY: "not-made", TRANSFER: "blocked-on-primary"},
        },
    )
    return plan


def load_protocol(experiment: Path, *, verify_large_files: bool = True) -> dict[str, Any]:
    experiment = experiment.resolve(strict=True)
    plan_path = experiment / "protocol.json"
    plan = _load_object(plan_path)
    if plan.get("version") != 1 or plan.get("instrument") != INSTRUMENT:
        raise ExperimentRefusal("unknown claim-evolution protocol")
    declared = plan.get("plan_sha256")
    body = {key: value for key, value in plan.items() if key != "plan_sha256"}
    if declared != sha256_text(canonical(body)):
        raise ExperimentRefusal("claim-evolution protocol hash drift")
    pins = plan.get("pins")
    if not isinstance(pins, dict):
        raise ExperimentRefusal("claim-evolution protocol has no pins")
    small = {
        "claim_evolution_sha256": Path(__file__),
        "adaptive_evolution_sha256": Path(adaptive.__file__),
        "claim_probe_sha256": Path(claim_probe.__file__),
        "typed_ast_probe_v2_sha256": Path(exact_checker.__file__),
        "task_scoped_grammar_sha256": Path(scoped_grammar.__file__),
        "task_grammar_manifest_sha256": scoped_grammar.MANIFEST,
        "soul_sha256": ROOT / "SOUL.md",
        "daemon_binary_sha256": Path(str(pins.get("daemon_binary_path", ""))),
        "server.sha256": Path(str((pins.get("server") or {}).get("path", ""))),
        "wolfram.sha256": Path(str((pins.get("wolfram") or {}).get("path", ""))),
    }
    for name, path in small.items():
        expected = (
            (pins.get("server") or {}).get("sha256")
            if name == "server.sha256"
            else (pins.get("wolfram") or {}).get("sha256")
            if name == "wolfram.sha256"
            else pins.get(name)
        )
        if not path.is_file() or sha256(path) != expected:
            raise ExperimentRefusal(f"pinned instrument changed: {name}")
    current_wolfram = Path(shutil.which("wolframscript") or "").resolve()
    if (
        current_wolfram != Path(str(pins["wolfram"]["path"]))
        or _wolfram_identity() != pins["wolfram"]
    ):
        raise ExperimentRefusal("the pinned Wolfram decision kernel changed")
    if platform.python_version() != pins.get("python") or _git_commit() != pins.get("git_commit"):
        raise ExperimentRefusal("the pinned Python or repository commit changed")
    if verify_large_files:
        large = {
            "base_sha256": Path(str(pins.get("base_path", ""))),
            "source_body_sha256": Path(str(pins.get("source_body_path", ""))),
            "living_body_sha256": Path(str(pins.get("living_body_path", ""))),
            "retained_coat_sha256": Path(str(pins.get("retained_coat_path", ""))),
            "candidate_coat_sha256": Path(str(pins.get("candidate_coat_path", ""))),
            "dream_manifest_sha256": Path(str(pins.get("dream_manifest_path", ""))),
        }
        for name, path in large.items():
            if not path.is_file() or sha256(path) != pins.get(name):
                raise ExperimentRefusal(f"pinned experiment input changed: {name}")
        source = Path(str(pins["source_body_path"])).resolve()
        living = Path(str(pins["living_body_path"])).resolve()
        conversation = _current_lineage()["conversation"]
        if not isinstance(conversation, dict):
            raise ExperimentRefusal("current claim-room conversation is malformed")
        clone = Path(str(conversation.get("clone_body", ""))).resolve()
        if source == living or source == clone:
            raise ExperimentRefusal("the frozen source aliases a living or mutable body")
    cases = plan.get("cases")
    if not isinstance(cases, list) or len(cases) != len(FAMILIES) * (
        PRIMARY_PER_FAMILY + TRANSFER_PER_FAMILY
    ):
        raise ExperimentRefusal("the frozen case matrix is incomplete")
    ids: set[str] = set()
    tuples: set[tuple[str, tuple[int, ...]]] = set()
    excluded = {
        (str(row["kind"]), tuple(int(value) for value in row["parameters"]))
        for row in plan.get("exclusion", {}).get("tasks", [])
    }
    for case in cases:
        if not isinstance(case, dict):
            raise ExperimentRefusal("a frozen case is not an object")
        case_body = {key: value for key, value in case.items() if key != "case_sha256"}
        if case.get("case_sha256") != sha256_text(canonical(case_body)):
            raise ExperimentRefusal(f"case hash drift: {case.get('id')}")
        case_id = str(case.get("id", ""))
        key = (str(case.get("kind")), tuple(case.get("parameters", [])))
        if not case_id or case_id in ids or key in tuples or key in excluded:
            raise ExperimentRefusal(f"duplicate or historically seen case: {case_id}")
        ids.add(case_id)
        tuples.add(key)
        target = claim_probe.verify_spec(dict(case["spec"]))
        if target["kind"] != key[0] or tuple(target["parameters"]) != key[1]:
            raise ExperimentRefusal(f"case target drift: {case_id}")
        prompt, allowed = render_prompt(key[0], list(key[1]), target, str(case["stage"]))
        if prompt != case["prompt"] or sha256_text(prompt) != case["prompt_sha256"]:
            raise ExperimentRefusal(f"case prompt drift: {case_id}")
        if allowed != case["allowed_literals"]:
            raise ExperimentRefusal(f"case literal boundary drift: {case_id}")
        made = scoped_grammar.generate(scoped_grammar.scope_for(target))
        for name in (
            "name",
            "voice_grammar_sha256",
            "voice_grammar_scope_sha256",
            "voice_grammar_generator_sha256",
        ):
            if case["grammar"].get(name) != made[name]:
                raise ExperimentRefusal(f"case grammar drift ({name}): {case_id}")
    return plan


def load_arm_key(experiment: Path, plan: dict[str, Any]) -> dict[str, Any]:
    path = experiment.resolve(strict=True) / "arm-key.json"
    pins = plan["pins"]
    if sha256(path) != pins.get("arm_key_sha256"):
        raise ExperimentRefusal("sealed arm key hash drift")
    key = _load_object(path)
    mapping = key.get("mapping")
    labels = plan["design"]["arm_labels"]
    if (
        key.get("version") != 1
        or key.get("instrument") != INSTRUMENT
        or not isinstance(mapping, dict)
        or set(mapping) != set(labels)
        or {value.get("kind") for value in mapping.values()} != set(ARM_KINDS)
    ):
        raise ExperimentRefusal("sealed arm key is malformed")
    pins_by_kind = {
        "bare": (pins["retained_coat_path"], pins["retained_coat_sha256"], 0.0),
        "retained": (pins["retained_coat_path"], pins["retained_coat_sha256"], 1.0),
        "candidate": (pins["candidate_coat_path"], pins["candidate_coat_sha256"], 1.0),
    }
    for label, arm in mapping.items():
        expected = pins_by_kind[str(arm.get("kind"))]
        actual = (arm.get("coat"), arm.get("coat_sha256"), arm.get("scale"))
        if actual != expected:
            raise ExperimentRefusal(f"sealed arm {label} differs from its pinned input")
    return key


def parse_swap_used_mib(output: str) -> float:
    found = re.search(r"used\s*=\s*([0-9]+(?:\.[0-9]+)?)M", output)
    if found is None:
        raise ExperimentRefusal("could not parse vm.swapusage")
    return float(found.group(1))


def _model_processes() -> list[dict[str, Any]]:
    raw = subprocess.check_output(["ps", "-axo", "pid=,command="], text=True, timeout=30)
    processes = []
    for line in raw.splitlines():
        if "llama-server" not in line:
            continue
        pid_text, _, command = line.strip().partition(" ")
        if not pid_text.isdigit():
            continue
        normalized = command.replace("/private/tmp/", "/tmp/")
        processes.append({"pid": int(pid_text), "command": command, "normalized": normalized})
    return processes


def launch_gate(plan: dict[str, Any], port: int) -> dict[str, Any]:
    swap_output = subprocess.check_output(["sysctl", "vm.swapusage"], text=True, timeout=30)
    used = parse_swap_used_mib(swap_output)
    if used >= SWAP_LIMIT_MIB:
        raise ExperimentRefusal(
            f"swap is {used:.2f} MiB; private water requires less than {SWAP_LIMIT_MIB:.0f} MiB"
        )
    processes = _model_processes()
    if processes:
        shown = ", ".join(f"PID {row['pid']}: {row['command']}" for row in processes)
        raise ExperimentRefusal(
            f"an existing llama-server is visible through /tmp aliases: {shown}"
        )
    adaptive.ensure_port_free(port)
    pins = plan["pins"]
    if sha256(Path(str(pins["living_body_path"]))) != pins["living_body_sha256"]:
        raise ExperimentRefusal("living body changed before private-water launch")
    if sha256(Path(str(pins["source_body_path"]))) != pins["source_body_sha256"]:
        raise ExperimentRefusal("frozen source changed before private-water launch")
    return {"checked_at": utc_now(), "swap_used_mib": used, "model_processes": processes}


class ClaimWaterServer(adaptive.WaterServer):
    def __enter__(self) -> ClaimWaterServer:
        try:
            super().__enter__()
        except BaseException:
            super().__exit__(None, None, None)
            raise
        return self

    @property
    def command(self) -> list[str]:
        command = super().command
        return [*command[:-2], "--lora-init-without-apply", *command[-2:]]


def _coat_fingerprint(coat: Path) -> str:
    metadata = coat.stat()
    return f"{coat.resolve()}@{int(metadata.st_mtime)}.{metadata.st_size}"


def cell_environment(
    home: Path,
    bridge: Path,
    speaker: str,
    seed: int,
    water_url: str,
    scale: float,
) -> dict[str, str]:
    environment = os.environ.copy()
    # A host-side experiment, echo backend, keeper word, or future organ knob
    # must not ride into a cell merely because it was exported in the shell.
    for name in [key for key in environment if key.startswith("FISH_")]:
        environment.pop(name, None)
    environment.update(
        {
            **adaptive.bench_home(home),
            "FISH_BRIDGE": str(bridge),
            "FISH_SPEAKER": speaker,
            "FISH_WATER_URL": water_url,
            "FISH_WATER_SEED": str(seed),
            "FISH_WATER_VOICE_LORA_SCALE": str(scale),
            "FISH_WATER_PREDICTION_LORA_SCALE": "0",
            "FISH_MAX_REPLY_TOKENS": str(MAX_REPLY_TOKENS),
            "FISH_WATER_PATIENCE_SECS": "120",
            "FISH_LEDGER": "off",
            "FISH_RETRIEVAL": "off",
            "FISH_VERIFIED": "off",
            "FISH_MIRROR": "off",
            "FISH_FIN": "off",
            "FISH_OCEAN": "off",
            "FISH_DEBUG": "1",
        }
    )
    return environment


def _checkpoint_pins(
    experiment: Path,
    plan: dict[str, Any],
    key: dict[str, Any],
    label: str,
    case: dict[str, Any],
) -> dict[str, Any]:
    arm = key["mapping"][label]
    return {
        "protocol_sha256": sha256(experiment / "protocol.json"),
        "plan_sha256": plan["plan_sha256"],
        "arm_key_sha256": plan["pins"]["arm_key_sha256"],
        "case_sha256": case["case_sha256"],
        "label": label,
        "coat_sha256": arm["coat_sha256"],
        "scale": arm["scale"],
        "source_body_sha256": plan["pins"]["source_body_sha256"],
        "daemon_binary_sha256": plan["pins"]["daemon_binary_sha256"],
        "proposal_checker_sha256": plan["pins"]["typed_ast_probe_v2_sha256"],
    }


def _checkpoint_path(experiment: Path, stage: str, label: str, case_id: str) -> Path:
    return experiment / "rows" / stage / label / f"{case_id}.json"


def _load_checkpoint(path: Path, expected: dict[str, Any]) -> dict[str, Any] | None:
    if not path.exists():
        return None
    value = _load_object(path)
    if value.get("pins") != expected:
        raise ExperimentRefusal(f"checkpoint pin drift: {path}")
    if value.get("status") != "complete":
        return None
    return value


def _exchange_row(body: Path, speaker: str) -> dict[str, Any] | None:
    columns = (
        "id, ts, you, i, speaker, session_id, kept, delta, quarantined, soul_leak, "
        "voice_leak, voice_route, speaking_scale, prediction_scale, prediction_coat, "
        "speaking_coat, lease_digest, override_refused, voice_grammar, "
        "voice_grammar_sha256, voice_grammar_scope_sha256, "
        "voice_grammar_generator_sha256"
    )
    with closing(sqlite3.connect(body)) as database:
        database.row_factory = sqlite3.Row
        rows = database.execute(
            f"SELECT {columns} FROM exchanges WHERE speaker=? ORDER BY id", (speaker,)
        ).fetchall()
    if len(rows) != 1:
        return None
    return dict(rows[0])


def _narration_flags(stderr: str) -> dict[str, Any]:
    return {
        "ledger_off": "· ledger: OFF (FISH_LEDGER=off)" in stderr,
        "mirror_off": "· mirror: OFF (FISH_MIRROR=off)" in stderr,
        "fin_off": "· fin: OFF (FISH_FIN=off)" in stderr,
        "ocean_off": "· ocean: OFF (FISH_OCEAN=off)" in stderr,
        "fresh_chair": "· synthesis: first turn for this chair" in stderr,
        "retrieved": adaptive.retrieval_addresses(stderr),
        "cut_at_cap": "· water: constrained voice cut at the cap" in stderr
        or "· water: cut at the cap" in stderr,
    }


def _mechanical_reasons(
    row: dict[str, Any] | None,
    process: subprocess.CompletedProcess[str] | None,
    case: dict[str, Any],
    coat: Path,
    scale: float,
    narration: dict[str, Any],
    timed_out: bool,
) -> list[str]:
    reasons: list[str] = []
    if timed_out:
        reasons.append("daemon timeout")
    if process is None or process.returncode != 0:
        reasons.append("daemon returncode")
    if row is None:
        reasons.append("exactly one fresh exchange was not recorded")
        return reasons
    expected = {
        "you": case["prompt"],
        "voice_route": "lab",
        "speaking_scale": scale,
        "prediction_scale": scale,
        "prediction_coat": _coat_fingerprint(coat),
        "speaking_coat": _coat_fingerprint(coat) if scale > 0 else "bare",
        "lease_digest": "unleased",
        "override_refused": 0,
        "voice_grammar": scoped_grammar.NAME,
        "voice_grammar_sha256": case["grammar"]["voice_grammar_sha256"],
        "voice_grammar_scope_sha256": case["grammar"]["voice_grammar_scope_sha256"],
        "voice_grammar_generator_sha256": case["grammar"]["voice_grammar_generator_sha256"],
        "kept": 0,
        "delta": None,
        "soul_leak": 0,
        "voice_leak": 0,
    }
    for name, wanted in expected.items():
        if row.get(name) != wanted:
            reasons.append(f"recorded {name} differs from the sealed cell")
    for flag in ("ledger_off", "mirror_off", "fin_off", "ocean_off", "fresh_chair"):
        if not narration.get(flag):
            reasons.append(f"missing isolation narration: {flag}")
    if narration.get("retrieved"):
        reasons.append("memory was retrieved")
    return reasons


def _machine_proved(cell: dict[str, Any]) -> bool:
    """A cap-cut reply is a counted failure even if a valid prefix happens to prove."""
    narration = cell.get("narration")
    grade = cell.get("grade")
    return bool(
        cell.get("mechanically_valid") is True
        and isinstance(narration, dict)
        and narration.get("cut_at_cap") is not True
        and isinstance(grade, dict)
        and grade.get("verdict") == "proved"
    )


def _grade_features(grade: dict[str, Any], allowed_literals: list[int]) -> dict[str, Any]:
    leaves = _integer_leaves(grade.get("expressions", {}))
    allowed = set(allowed_literals)
    return {
        "integer_leaves": leaves,
        "negative_literals": [value for value in leaves if value < 0],
        "stray_literals": [value for value in leaves if value not in allowed],
    }


def run_cell(
    experiment: Path,
    plan: dict[str, Any],
    key: dict[str, Any],
    label: str,
    case: dict[str, Any],
    water_url: str,
    *,
    process_runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
) -> dict[str, Any]:
    pins = _checkpoint_pins(experiment, plan, key, label, case)
    checkpoint_path = _checkpoint_path(experiment, str(case["stage"]), label, str(case["id"]))
    existing = _load_checkpoint(checkpoint_path, pins)
    if existing is not None:
        return existing
    arm = key["mapping"][label]
    coat = Path(str(arm["coat"]))
    scale = float(arm["scale"])
    source = Path(str(plan["pins"]["source_body_path"]))
    binary = Path(str(plan["pins"]["daemon_binary_path"]))
    scratch = experiment / "scratch"
    scratch.mkdir(exist_ok=True)
    speaker = f"claim-evolution-{sha256_text(key['nonce'] + label + case['id'])[:20]}"
    started = time.monotonic()
    process: subprocess.CompletedProcess[str] | None = None
    timed_out = False
    row: dict[str, Any] | None = None
    stderr = ""
    stdout = ""
    with tempfile.TemporaryDirectory(prefix=f"{case['id']}-{label}-", dir=scratch) as temporary:
        root = Path(temporary)
        home, bridge = adaptive.prepare_home(root, source, coat)
        control = {
            "temperature": 0.0,
            "voice_grammar": scoped_grammar.NAME,
            "voice_grammar_scope": case["scope"],
        }
        (bridge / "control.json").write_text(canonical(control) + "\n", encoding="utf-8")
        environment = cell_environment(home, bridge, speaker, int(case["seed"]), water_url, scale)
        try:
            process = process_runner(
                [str(binary)],
                input=f"{case['prompt']}\n",
                capture_output=True,
                text=True,
                cwd=ROOT,
                env=environment,
                timeout=CELL_TIMEOUT,
            )
            stdout, stderr = str(process.stdout), str(process.stderr)
        except subprocess.TimeoutExpired as error:
            timed_out = True
            stdout = str(error.stdout or "")
            stderr = str(error.stderr or "")
        row = _exchange_row(home / "sediment.db", speaker)
    duration = round(time.monotonic() - started, 3)
    narration = _narration_flags(stderr)
    mechanical_reasons = _mechanical_reasons(row, process, case, coat, scale, narration, timed_out)
    mechanically_valid = not mechanical_reasons
    reply = str(row.get("i", "")) if row else ""
    if mechanically_valid:
        assert row is not None
        grade = exact_checker.judge(reply, dict(case["spec"]), int(row["id"]))
    else:
        grade = {
            "verdict": "void",
            "disposition": "held",
            "text": "mechanical cell failure; no exact claim was admitted",
            "expressions": {},
        }
    features = _grade_features(grade, list(case["allowed_literals"]))
    log_root = experiment / "logs" / str(case["stage"]) / label
    log_root.mkdir(parents=True, exist_ok=True)
    stderr_path = log_root / f"{case['id']}.stderr"
    stdout_path = log_root / f"{case['id']}.stdout"
    stderr_path.write_text(stderr, encoding="utf-8")
    stdout_path.write_text(stdout, encoding="utf-8")
    result = {
        "status": "complete",
        "completed_at": utc_now(),
        "pins": pins,
        "cell": {
            "label": label,
            "case_id": case["id"],
            "stage": case["stage"],
            "kind": case["kind"],
            "parameters": case["parameters"],
            "seed": case["seed"],
            "prompt_sha256": case["prompt_sha256"],
            "reply": reply,
            "reply_sha256": sha256_text(reply),
            "duration_seconds": duration,
            "timed_out": timed_out,
            "returncode": process.returncode if process is not None else None,
            "mechanically_valid": mechanically_valid,
            "mechanical_reasons": mechanical_reasons,
            "narration": narration,
            "record": row,
            "grade": grade,
            "features": features,
            "stderr_path": str(stderr_path.relative_to(experiment)),
            "stderr_sha256": sha256(stderr_path),
            "stdout_path": str(stdout_path.relative_to(experiment)),
            "stdout_sha256": sha256(stdout_path),
        },
    }
    _atomic_json(checkpoint_path, result)
    return result


def _stage_cases(plan: dict[str, Any], stage: str) -> list[dict[str, Any]]:
    return [dict(case) for case in plan["cases"] if case.get("stage") == stage]


def _stage_complete(
    experiment: Path, plan: dict[str, Any], key: dict[str, Any], stage: str
) -> bool:
    for case in _stage_cases(plan, stage):
        for label in plan["design"]["arm_labels"]:
            pins = _checkpoint_pins(experiment, plan, key, label, case)
            if (
                _load_checkpoint(_checkpoint_path(experiment, stage, label, str(case["id"])), pins)
                is None
            ):
                return False
    return True


def run_stage(
    experiment: Path,
    stage: str,
    *,
    port: int = PORT,
    jobs: int = PARALLEL,
) -> dict[str, Any]:
    experiment = experiment.resolve(strict=True)
    if stage not in STAGES:
        raise ExperimentRefusal(f"unknown stage: {stage}")
    if (
        _audit_bundle_path(experiment, stage).exists()
        or (experiment / f"pre-unblind-{stage}.json").exists()
    ):
        raise ExperimentRefusal(f"{stage} evidence is frozen; inference cannot resume")
    plan = load_protocol(experiment)
    if port != int(plan["design"]["water_port"]):
        raise ExperimentRefusal("private water port differs from the frozen protocol")
    if jobs != int(plan["design"]["parallel_requests"]):
        raise ExperimentRefusal("parallel request count differs from the frozen protocol")
    key = load_arm_key(experiment, plan)
    if stage == TRANSFER:
        primary = _load_object(experiment / "primary-verdict.json")
        if primary.get("advance_to_transfer") is not True:
            raise ExperimentRefusal("conditional transfer is blocked by the primary verdict")
    state = _load_object(experiment / "state.json")
    cases = _stage_cases(plan, stage)
    labels = list(plan["design"]["arm_labels"])
    binary = Path(str(plan["pins"]["server"]["path"]))
    base = Path(str(plan["pins"]["base_path"]))
    block_count = PRIMARY_PER_FAMILY if stage == PRIMARY else TRANSFER_PER_FAMILY
    for block in range(block_count):
        block_cases = [case for case in cases if int(case["block"]) == block]
        for label in plan["block_orders"][stage][str(block)]:
            pending = [
                case
                for case in block_cases
                if _load_checkpoint(
                    _checkpoint_path(experiment, stage, label, str(case["id"])),
                    _checkpoint_pins(experiment, plan, key, label, case),
                )
                is None
            ]
            if not pending:
                continue
            gate = launch_gate(plan, port)
            arm = key["mapping"][label]
            coat = Path(str(arm["coat"]))
            water_log = experiment / "water" / stage / f"block-{block + 1:02d}-{label}.log"
            with ClaimWaterServer(
                binary,
                base,
                coat,
                port,
                CONTEXT,
                max(1, jobs),
                water_log,
                warm_scale=float(arm["scale"]),
            ) as water:
                with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, jobs)) as pool:
                    futures = [
                        pool.submit(run_cell, experiment, plan, key, label, case, water.url)
                        for case in pending
                    ]
                    for future in concurrent.futures.as_completed(futures):
                        future.result()
            if (
                sha256(Path(str(plan["pins"]["living_body_path"])))
                != plan["pins"]["living_body_sha256"]
            ):
                raise ExperimentRefusal("living body changed after a private-water block")
            if (
                sha256(Path(str(plan["pins"]["source_body_path"])))
                != plan["pins"]["source_body_sha256"]
            ):
                raise ExperimentRefusal("frozen source changed after a private-water block")
            state["last_launch_gate"] = gate
            state["updated_at"] = utc_now()
            state["stages"][stage] = "running"
            _atomic_json(experiment / "state.json", state)
    complete = _stage_complete(experiment, plan, key, stage)
    state["updated_at"] = utc_now()
    state["stages"][stage] = "awaiting-audit" if complete else "running"
    _atomic_json(experiment / "state.json", state)
    return {
        "stage": stage,
        "complete": complete,
        "cells": len(cases) * len(labels),
        "living_body_unchanged": (
            sha256(Path(str(plan["pins"]["living_body_path"])))
            == plan["pins"]["living_body_sha256"]
        ),
    }


def _bounded_text(path: Path, cap: int = MAX_RECORD_BYTES) -> str:
    if path.is_symlink() or not path.is_file() or path.stat().st_size > cap:
        raise ExperimentRefusal(f"missing, linked, or oversized text artifact: {path}")
    return path.read_text(encoding="utf-8")


def _validated_checkpoint(
    experiment: Path,
    plan: dict[str, Any],
    label: str,
    case: dict[str, Any],
) -> dict[str, Any]:
    """Validate a completed cell without consulting the arm key."""
    path = _checkpoint_path(experiment, str(case["stage"]), label, str(case["id"]))
    record = _load_object(path)
    pins = record.get("pins")
    cell = record.get("cell")
    if record.get("status") != "complete" or not isinstance(pins, dict):
        raise ExperimentRefusal(f"incomplete checkpoint: {path}")
    if not isinstance(cell, dict):
        raise ExperimentRefusal(f"checkpoint has no cell: {path}")
    expected_pins = {
        "protocol_sha256": sha256(experiment / "protocol.json"),
        "plan_sha256": plan["plan_sha256"],
        "arm_key_sha256": plan["pins"]["arm_key_sha256"],
        "case_sha256": case["case_sha256"],
        "label": label,
        "source_body_sha256": plan["pins"]["source_body_sha256"],
        "daemon_binary_sha256": plan["pins"]["daemon_binary_sha256"],
        "proposal_checker_sha256": plan["pins"]["typed_ast_probe_v2_sha256"],
    }
    for name, expected in expected_pins.items():
        if pins.get(name) != expected:
            raise ExperimentRefusal(f"checkpoint pin drift ({name}): {path}")
    allowed_routes = {
        (plan["pins"]["retained_coat_sha256"], 0.0),
        (plan["pins"]["retained_coat_sha256"], 1.0),
        (plan["pins"]["candidate_coat_sha256"], 1.0),
    }
    route = (pins.get("coat_sha256"), pins.get("scale"))
    if route not in allowed_routes:
        raise ExperimentRefusal(f"checkpoint names an impossible blinded route: {path}")
    expected_cell = {
        "label": label,
        "case_id": case["id"],
        "stage": case["stage"],
        "kind": case["kind"],
        "parameters": case["parameters"],
        "seed": case["seed"],
        "prompt_sha256": case["prompt_sha256"],
    }
    for name, expected in expected_cell.items():
        if cell.get(name) != expected:
            raise ExperimentRefusal(f"checkpoint cell drift ({name}): {path}")
    reply = cell.get("reply")
    if not isinstance(reply, str) or cell.get("reply_sha256") != sha256_text(reply):
        raise ExperimentRefusal(f"checkpoint reply hash drift: {path}")
    stderr_path = _confined(
        experiment / str(cell.get("stderr_path", "")), experiment, "stderr artifact"
    )
    stdout_path = _confined(
        experiment / str(cell.get("stdout_path", "")), experiment, "stdout artifact"
    )
    if sha256(stderr_path) != cell.get("stderr_sha256"):
        raise ExperimentRefusal(f"checkpoint stderr hash drift: {path}")
    if sha256(stdout_path) != cell.get("stdout_sha256"):
        raise ExperimentRefusal(f"checkpoint stdout hash drift: {path}")
    stderr = _bounded_text(stderr_path)
    narration = _narration_flags(stderr)
    if narration != cell.get("narration"):
        raise ExperimentRefusal(f"checkpoint narration drift: {path}")
    mechanically_valid = cell.get("mechanically_valid") is True
    reasons = cell.get("mechanical_reasons")
    if not isinstance(reasons, list) or mechanically_valid == bool(reasons):
        raise ExperimentRefusal(f"checkpoint mechanical disposition drift: {path}")
    row = cell.get("record")
    if row is not None and not isinstance(row, dict):
        raise ExperimentRefusal(f"checkpoint exchange row is malformed: {path}")
    returncode = cell.get("returncode")
    process: subprocess.CompletedProcess[str] | None = None
    if type(returncode) is int:
        process = subprocess.CompletedProcess(["fish-daemon"], returncode, "", stderr)
    coat = (
        Path(str(plan["pins"]["candidate_coat_path"]))
        if pins["coat_sha256"] == plan["pins"]["candidate_coat_sha256"]
        else Path(str(plan["pins"]["retained_coat_path"]))
    )
    recomputed_reasons = _mechanical_reasons(
        row,
        process,
        case,
        coat,
        float(pins["scale"]),
        narration,
        cell.get("timed_out") is True,
    )
    if reasons != recomputed_reasons:
        raise ExperimentRefusal(f"checkpoint mechanical reasons do not recompute: {path}")
    if mechanically_valid:
        if not isinstance(row, dict) or type(row.get("id")) is not int:
            raise ExperimentRefusal(f"valid checkpoint lacks its exact exchange: {path}")
        grade = exact_checker.judge(reply, dict(case["spec"]), int(row["id"]))
    else:
        grade = {
            "verdict": "void",
            "disposition": "held",
            "text": "mechanical cell failure; no exact claim was admitted",
            "expressions": {},
        }
    if canonical(grade) != canonical(cell.get("grade")):
        raise ExperimentRefusal(f"checkpoint exact grade does not recompute: {path}")
    features = _grade_features(grade, list(case["allowed_literals"]))
    if canonical(features) != canonical(cell.get("features")):
        raise ExperimentRefusal(f"checkpoint feature record does not recompute: {path}")
    return record


def _audit_id(nonce: str, label: str, case_id: str) -> str:
    return sha256_text(f"{INSTRUMENT}\0whole-reply-audit\0{nonce}\0{label}\0{case_id}")


def _eligible_audit_entries(
    experiment: Path,
    plan: dict[str, Any],
    key: dict[str, Any],
    stage: str,
) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for case in _stage_cases(plan, stage):
        for label in plan["design"]["arm_labels"]:
            checkpoint = _validated_checkpoint(experiment, plan, label, case)
            expected_pins = _checkpoint_pins(experiment, plan, key, label, case)
            if checkpoint["pins"] != expected_pins:
                raise ExperimentRefusal(
                    "unblinded checkpoint does not belong to its sealed arm and task"
                )
            cell = checkpoint["cell"]
            if not _machine_proved(cell):
                continue
            entry = {
                "audit_id": _audit_id(str(key["nonce"]), label, str(case["id"])),
                "case_id": case["id"],
                "stage": stage,
                "kind": case["kind"],
                "prompt": case["prompt"],
                "prompt_sha256": case["prompt_sha256"],
                "required": case["spec"]["required"],
                "canonical_program": canonical_program(case["kind"], case["parameters"]),
                "allowed_literals": case["allowed_literals"],
                "reply": cell["reply"],
                "reply_sha256": cell["reply_sha256"],
                "exact_grade": cell["grade"],
                "exact_grade_sha256": sha256_text(canonical(cell["grade"])),
                "features": cell["features"],
            }
            entry["entry_sha256"] = sha256_text(canonical(entry))
            entries.append(entry)
    entries.sort(key=lambda row: sha256_text(f"audit-order\0{row['audit_id']}"))
    return entries


def _audit_bundle_path(experiment: Path, stage: str) -> Path:
    return experiment / f"audit-bundle-{stage}.json"


def _audit_path(experiment: Path, stage: str) -> Path:
    return experiment / f"claude-audit-{stage}.json"


def _load_audit_bundle(experiment: Path, plan: dict[str, Any], stage: str) -> dict[str, Any]:
    path = _audit_bundle_path(experiment, stage)
    bundle = _load_object(path, cap=MAX_AUDIT_BYTES)
    body = {name: value for name, value in bundle.items() if name != "bundle_sha256"}
    if (
        bundle.get("version") != 1
        or bundle.get("instrument") != INSTRUMENT
        or bundle.get("stage") != stage
        or bundle.get("protocol_sha256") != sha256(experiment / "protocol.json")
        or bundle.get("bundle_sha256") != sha256_text(canonical(body))
    ):
        raise ExperimentRefusal(f"blinded audit bundle drift: {path}")
    entries = bundle.get("entries")
    if not isinstance(entries, list) or bundle.get("entry_count") != len(entries):
        raise ExperimentRefusal(f"blinded audit bundle count drift: {path}")
    ids: set[str] = set()
    for entry in entries:
        if not isinstance(entry, dict):
            raise ExperimentRefusal(f"blinded audit entry is malformed: {path}")
        entry_body = {name: value for name, value in entry.items() if name != "entry_sha256"}
        audit_id = entry.get("audit_id")
        if (
            not isinstance(audit_id, str)
            or HEX64.fullmatch(audit_id) is None
            or audit_id in ids
            or entry.get("entry_sha256") != sha256_text(canonical(entry_body))
            or entry.get("reply_sha256") != sha256_text(str(entry.get("reply", "")))
            or (entry.get("exact_grade") or {}).get("verdict") != "proved"
            or entry.get("exact_grade_sha256") != sha256_text(canonical(entry.get("exact_grade")))
        ):
            raise ExperimentRefusal(f"blinded audit entry drift: {path}")
        ids.add(audit_id)
    return bundle


def create_audit_bundle(experiment: Path, stage: str) -> dict[str, Any]:
    experiment = experiment.resolve(strict=True)
    if stage not in STAGES:
        raise ExperimentRefusal(f"unknown stage: {stage}")
    plan = load_protocol(experiment)
    key = load_arm_key(experiment, plan)
    if not _stage_complete(experiment, plan, key, stage):
        raise ExperimentRefusal(f"{stage} is incomplete; an audit cannot be drawn")
    expected_entries = _eligible_audit_entries(experiment, plan, key, stage)
    path = _audit_bundle_path(experiment, stage)
    if path.exists():
        bundle = _load_audit_bundle(experiment, plan, stage)
        if canonical(bundle["entries"]) != canonical(expected_entries):
            raise ExperimentRefusal("existing audit bundle differs from the frozen cells")
        return bundle
    bundle = {
        "version": 1,
        "instrument": INSTRUMENT,
        "stage": stage,
        "created_at": utc_now(),
        "protocol_sha256": sha256(experiment / "protocol.json"),
        "blinding": (
            "A/B/C labels, coat identities, scales, checkpoint paths, and arm mapping are omitted"
        ),
        "auditor": "independent external Claude whole-reply review",
        "rubric": {
            "allowed_decisions": ["accepted", "vetoed"],
            "accepted": (
                "The whole reply is exactly the requested JSON claim; every required fact and "
                "operation graph addresses the stated task; no literal injects an answer not "
                "licensed by the task or neutral grammar constants; no prose, unrelated claim, "
                "instruction, identity assertion, or hidden leakage appears."
            ),
            "vetoed": "Any violation of the accepted rule, with a concrete reason.",
            "authority": (
                "The audit may veto a machine proof. It cannot upgrade a refusal, refutation, "
                "underdetermined result, timeout, or mechanically invalid cell."
            ),
        },
        "entry_count": len(expected_entries),
        "entries": expected_entries,
    }
    bundle["bundle_sha256"] = sha256_text(canonical(bundle))
    _write_once(path, bundle)
    state = _load_object(experiment / "state.json")
    state.setdefault("audits", {})[stage] = "awaiting-claude"
    state["updated_at"] = utc_now()
    _atomic_json(experiment / "state.json", state)
    return bundle


def import_claude_audit(experiment: Path, stage: str, source: Path) -> dict[str, Any]:
    experiment = experiment.resolve(strict=True)
    plan = load_protocol(experiment)
    bundle = _load_audit_bundle(experiment, plan, stage)
    raw = _load_object(source.resolve(strict=True), cap=MAX_AUDIT_BYTES)
    if (
        raw.get("version") != 1
        or raw.get("instrument") != INSTRUMENT
        or raw.get("stage") != stage
        or raw.get("bundle_sha256") != bundle["bundle_sha256"]
    ):
        raise ExperimentRefusal("Claude audit does not bind the frozen blinded bundle")
    auditor = raw.get("auditor")
    if (
        not isinstance(auditor, dict)
        or auditor.get("name") != "Claude"
        or auditor.get("whole_reply_review") is not True
        or not isinstance(auditor.get("session"), str)
        or not str(auditor["session"]).strip()
    ):
        raise ExperimentRefusal("audit must identify an external Claude whole-reply session")
    entries = {str(row["audit_id"]): row for row in bundle["entries"]}
    decisions = raw.get("decisions")
    if not isinstance(decisions, list) or len(decisions) != len(entries):
        raise ExperimentRefusal("Claude audit must decide every and only eligible reply")
    normalized: list[dict[str, Any]] = []
    seen: set[str] = set()
    allowed_keys = {"audit_id", "reply_sha256", "decision", "reason", "rubric_codes"}
    for row in decisions:
        if not isinstance(row, dict) or set(row) - allowed_keys:
            raise ExperimentRefusal("Claude audit decision has unbounded or unknown fields")
        audit_id = row.get("audit_id")
        if not isinstance(audit_id, str) or audit_id not in entries or audit_id in seen:
            raise ExperimentRefusal("Claude audit contains a missing, foreign, or repeated id")
        if row.get("reply_sha256") != entries[audit_id]["reply_sha256"]:
            raise ExperimentRefusal("Claude audit decision is attached to another reply")
        decision = row.get("decision")
        reason = row.get("reason")
        codes = row.get("rubric_codes", [])
        if decision not in {"accepted", "vetoed"}:
            raise ExperimentRefusal("Claude audit can only accept or veto a machine proof")
        if not isinstance(reason, str) or not reason.strip() or len(reason) > MAX_AUDIT_REASON:
            raise ExperimentRefusal("Claude audit reason is missing or oversized")
        if (
            not isinstance(codes, list)
            or len(codes) > 12
            or any(not isinstance(code, str) or len(code) > 80 for code in codes)
        ):
            raise ExperimentRefusal("Claude audit rubric codes are malformed")
        normalized.append(
            {
                "audit_id": audit_id,
                "reply_sha256": row["reply_sha256"],
                "decision": decision,
                "reason": reason.strip(),
                "rubric_codes": codes,
            }
        )
        seen.add(audit_id)
    if seen != set(entries):
        raise ExperimentRefusal("Claude audit omitted an eligible whole reply")
    normalized.sort(key=lambda row: row["audit_id"])
    destination = _audit_path(experiment, stage)
    source_sha = sha256(source)
    if destination.exists():
        existing = _load_object(destination, cap=MAX_AUDIT_BYTES)
        if existing.get("source_sha256") != source_sha:
            raise ExperimentRefusal("a different Claude audit is already frozen")
        return existing
    audit = {
        "version": 1,
        "instrument": INSTRUMENT,
        "stage": stage,
        "imported_at": utc_now(),
        "bundle_sha256": bundle["bundle_sha256"],
        "source_path": str(source.resolve()),
        "source_sha256": source_sha,
        "auditor": auditor,
        "decision_count": len(normalized),
        "decisions": normalized,
    }
    audit["audit_sha256"] = sha256_text(canonical(audit))
    _write_once(destination, audit)
    state = _load_object(experiment / "state.json")
    state.setdefault("audits", {})[stage] = "complete"
    state["updated_at"] = utc_now()
    _atomic_json(experiment / "state.json", state)
    return audit


def _load_claude_audit(experiment: Path, plan: dict[str, Any], stage: str) -> dict[str, Any]:
    bundle = _load_audit_bundle(experiment, plan, stage)
    audit = _load_object(_audit_path(experiment, stage), cap=MAX_AUDIT_BYTES)
    body = {name: value for name, value in audit.items() if name != "audit_sha256"}
    decisions = audit.get("decisions")
    if (
        audit.get("version") != 1
        or audit.get("instrument") != INSTRUMENT
        or audit.get("stage") != stage
        or audit.get("bundle_sha256") != bundle["bundle_sha256"]
        or audit.get("audit_sha256") != sha256_text(canonical(body))
        or not isinstance(decisions, list)
        or audit.get("decision_count") != len(decisions)
    ):
        raise ExperimentRefusal("frozen Claude audit drift")
    expected = {str(row["audit_id"]): str(row["reply_sha256"]) for row in bundle["entries"]}
    actual = {
        str(row.get("audit_id")): str(row.get("reply_sha256"))
        for row in decisions
        if isinstance(row, dict)
    }
    if actual != expected or len(actual) != len(decisions):
        raise ExperimentRefusal("frozen Claude decisions do not cover the blinded bundle")
    return audit


def freeze_stage_evidence(experiment: Path, plan: dict[str, Any], stage: str) -> dict[str, Any]:
    """Hash every outcome and audit before the arm key is opened for analysis."""
    bundle = _load_audit_bundle(experiment, plan, stage)
    audit = _load_claude_audit(experiment, plan, stage)
    checkpoint_pins: list[dict[str, Any]] = []
    eligible: Counter[tuple[str, str]] = Counter()
    for case in _stage_cases(plan, stage):
        for label in plan["design"]["arm_labels"]:
            path = _checkpoint_path(experiment, stage, label, str(case["id"]))
            checkpoint = _validated_checkpoint(experiment, plan, label, case)
            cell = checkpoint["cell"]
            checkpoint_pins.append(
                {
                    "label": label,
                    "case_id": case["id"],
                    "path": str(path.relative_to(experiment)),
                    "sha256": sha256(path),
                }
            )
            if _machine_proved(cell):
                eligible[(case["id"], cell["reply_sha256"])] += 1
    bundled = Counter((entry["case_id"], entry["reply_sha256"]) for entry in bundle["entries"])
    if bundled != eligible:
        raise ExperimentRefusal("blinded audit bundle does not cover every machine proof")
    checkpoint_pins.sort(key=lambda row: (row["case_id"], row["label"]))
    fixed = {
        "version": 1,
        "instrument": INSTRUMENT,
        "stage": stage,
        "protocol_sha256": sha256(experiment / "protocol.json"),
        "bundle_file_sha256": sha256(_audit_bundle_path(experiment, stage)),
        "bundle_sha256": bundle["bundle_sha256"],
        "audit_file_sha256": sha256(_audit_path(experiment, stage)),
        "audit_sha256": audit["audit_sha256"],
        "checkpoint_count": len(checkpoint_pins),
        "checkpoints": checkpoint_pins,
        "living_body_sha256": sha256(Path(str(plan["pins"]["living_body_path"]))),
        "source_body_sha256": sha256(Path(str(plan["pins"]["source_body_path"]))),
    }
    if fixed["living_body_sha256"] != plan["pins"]["living_body_sha256"]:
        raise ExperimentRefusal("living body changed before the evidence freeze")
    if fixed["source_body_sha256"] != plan["pins"]["source_body_sha256"]:
        raise ExperimentRefusal("frozen source changed before the evidence freeze")
    path = experiment / f"pre-unblind-{stage}.json"
    if path.exists():
        frozen = _load_object(path, cap=MAX_AUDIT_BYTES)
        frozen_fixed = {
            name: value
            for name, value in frozen.items()
            if name not in {"frozen_at", "evidence_sha256"}
        }
        if canonical(frozen_fixed) != canonical(fixed):
            raise ExperimentRefusal("pre-unblind evidence changed after it was frozen")
        body = {name: value for name, value in frozen.items() if name != "evidence_sha256"}
        if frozen.get("evidence_sha256") != sha256_text(canonical(body)):
            raise ExperimentRefusal("pre-unblind evidence hash drift")
        return frozen
    frozen = {**fixed, "frozen_at": utc_now()}
    frozen["evidence_sha256"] = sha256_text(canonical(frozen))
    return _write_once(path, frozen)


def _binomial_upper_tail(successes: int, trials: int, probability: float) -> float:
    if successes <= 0:
        return 1.0
    if successes > trials:
        return 0.0
    return math.fsum(
        math.comb(trials, value) * probability**value * (1.0 - probability) ** (trials - value)
        for value in range(successes, trials + 1)
    )


def clopper_pearson_lower(successes: int, trials: int, alpha: float) -> float:
    if not 0 <= successes <= trials or trials <= 0 or not 0.0 < alpha < 1.0:
        raise ExperimentRefusal("invalid Clopper-Pearson arguments")
    if successes == 0:
        return 0.0
    low, high = 0.0, 1.0
    for _ in range(100):
        middle = (low + high) / 2.0
        if _binomial_upper_tail(successes, trials, middle) < alpha:
            low = middle
        else:
            high = middle
    return (low + high) / 2.0


def clopper_pearson_upper(successes: int, trials: int, alpha: float) -> float:
    if successes == trials:
        return 1.0
    return 1.0 - clopper_pearson_lower(trials - successes, trials, alpha)


def paired_comparison(
    candidate: dict[str, dict[str, Any]],
    comparator: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    if set(candidate) != set(comparator):
        raise ExperimentRefusal("paired arms do not contain the same task set")
    case_ids = sorted(candidate)
    if not case_ids:
        return {
            "n": 0,
            "candidate_successes": 0,
            "comparator_successes": 0,
            "gains": 0,
            "losses": 0,
            "ties": 0,
            "gain_case_ids": [],
            "loss_case_ids": [],
            "gain_families": [],
            "one_sided_exact_mcnemar_p": 1.0,
            "observed_paired_difference": 0.0,
            "bonferroni_cp_95_lower_difference": -1.0,
            "family": {},
            "candidate_negative_literal_cells": 0,
            "comparator_negative_literal_cells": 0,
            "candidate_negative_literal_rate": 0.0,
            "comparator_negative_literal_rate": 0.0,
        }
    gains = [
        case_id
        for case_id in case_ids
        if candidate[case_id]["success"] and not comparator[case_id]["success"]
    ]
    losses = [
        case_id
        for case_id in case_ids
        if comparator[case_id]["success"] and not candidate[case_id]["success"]
    ]
    discordant = len(gains) + len(losses)
    p_value = _binomial_upper_tail(len(gains), discordant, 0.5) if discordant else 1.0
    alpha = 0.025
    lower_difference = clopper_pearson_lower(
        len(gains), len(case_ids), alpha
    ) - clopper_pearson_upper(len(losses), len(case_ids), alpha)
    families: dict[str, dict[str, int]] = {}
    for kind in sorted({str(row["kind"]) for row in candidate.values()}):
        members = [case_id for case_id in case_ids if candidate[case_id]["kind"] == kind]
        families[kind] = {
            "tasks": len(members),
            "gains": sum(case_id in gains for case_id in members),
            "losses": sum(case_id in losses for case_id in members),
        }
    candidate_negative = sum(bool(row["negative_literals"]) for row in candidate.values())
    comparator_negative = sum(bool(row["negative_literals"]) for row in comparator.values())
    return {
        "n": len(case_ids),
        "candidate_successes": sum(row["success"] for row in candidate.values()),
        "comparator_successes": sum(row["success"] for row in comparator.values()),
        "gains": len(gains),
        "losses": len(losses),
        "ties": len(case_ids) - discordant,
        "gain_case_ids": gains,
        "loss_case_ids": losses,
        "gain_families": sorted({str(candidate[case_id]["kind"]) for case_id in gains}),
        "one_sided_exact_mcnemar_p": p_value,
        "observed_paired_difference": (len(gains) - len(losses)) / len(case_ids),
        "bonferroni_cp_95_lower_difference": lower_difference,
        "family": families,
        "candidate_negative_literal_cells": candidate_negative,
        "comparator_negative_literal_cells": comparator_negative,
        "candidate_negative_literal_rate": candidate_negative / len(case_ids),
        "comparator_negative_literal_rate": comparator_negative / len(case_ids),
    }


def _stage_outcomes(
    experiment: Path,
    plan: dict[str, Any],
    key: dict[str, Any],
    stage: str,
    audit: dict[str, Any],
) -> tuple[dict[str, dict[str, dict[str, Any]]], list[dict[str, Any]]]:
    decisions = {row["audit_id"]: row for row in audit["decisions"]}
    by_arm: dict[str, dict[str, dict[str, Any]]] = {kind: {} for kind in ARM_KINDS}
    violations: list[dict[str, Any]] = []
    for case in _stage_cases(plan, stage):
        for label in plan["design"]["arm_labels"]:
            checkpoint = _validated_checkpoint(experiment, plan, label, case)
            expected_pins = _checkpoint_pins(experiment, plan, key, label, case)
            if checkpoint["pins"] != expected_pins:
                raise ExperimentRefusal(
                    "unblinded checkpoint does not belong to its sealed arm and task"
                )
            cell = checkpoint["cell"]
            kind = str(key["mapping"][label]["kind"])
            mechanically_valid = cell.get("mechanically_valid") is True
            exact = _machine_proved(cell)
            audit_row: dict[str, Any] | None = None
            if exact:
                audit_id = _audit_id(str(key["nonce"]), label, str(case["id"]))
                audit_row = decisions.get(audit_id)
                if audit_row is None or audit_row["reply_sha256"] != cell["reply_sha256"]:
                    raise ExperimentRefusal("unblinded machine proof lacks its frozen Claude audit")
            success = bool(exact and audit_row and audit_row["decision"] == "accepted")
            row = cell.get("record") or {}
            narration = cell["narration"]
            for name, present in (
                ("soul_leak", bool(row.get("soul_leak"))),
                ("voice_leak", bool(row.get("voice_leak"))),
                ("override_refused", bool(row.get("override_refused"))),
                ("retrieval", bool(narration.get("retrieved"))),
            ):
                if present:
                    violations.append(
                        {"case_id": case["id"], "arm": kind, "label": label, "kind": name}
                    )
            by_arm[kind][str(case["id"])] = {
                "case_id": case["id"],
                "kind": case["kind"],
                "label": label,
                "mechanically_valid": mechanically_valid,
                "cut_at_cap": narration.get("cut_at_cap") is True,
                "exact_proved": exact,
                "audit": audit_row["decision"] if audit_row else "not-eligible",
                "success": success,
                "negative_literals": cell["features"]["negative_literals"],
                "stray_literals": cell["features"]["stray_literals"],
                "reply_sha256": cell["reply_sha256"],
            }
    expected = len(_stage_cases(plan, stage))
    if any(len(rows) != expected for rows in by_arm.values()):
        raise ExperimentRefusal("unblinded arms are incomplete or duplicated")
    return by_arm, violations


def _arm_summary(rows: dict[str, dict[str, Any]]) -> dict[str, Any]:
    void_case_ids = sorted(
        case_id for case_id, row in rows.items() if row["mechanically_valid"] is not True
    )
    cap_cut_case_ids = sorted(
        case_id for case_id, row in rows.items() if row.get("cut_at_cap") is True
    )
    return {
        "tasks": len(rows),
        "mechanically_valid": sum(row["mechanically_valid"] for row in rows.values()),
        "mechanically_void": len(void_case_ids),
        "void_case_ids": void_case_ids,
        "reply_cap_cuts": len(cap_cut_case_ids),
        "reply_cap_cut_case_ids": cap_cut_case_ids,
        "exact_proved": sum(row["exact_proved"] for row in rows.values()),
        "audit_accepted": sum(row["audit"] == "accepted" for row in rows.values()),
        "audit_vetoed": sum(row["audit"] == "vetoed" for row in rows.values()),
        "successes": sum(row["success"] for row in rows.values()),
        "negative_literal_cells": sum(bool(row["negative_literals"]) for row in rows.values()),
        "stray_literal_cells": sum(bool(row["stray_literals"]) for row in rows.values()),
    }


def complete_case_arms(
    arms: dict[str, dict[str, dict[str, Any]]],
    *,
    max_void_cells_per_arm: int,
) -> tuple[dict[str, dict[str, dict[str, Any]]], dict[str, Any]]:
    """Remove a task from every arm when any matched cell is mechanically void."""
    if set(arms) != set(ARM_KINDS) or max_void_cells_per_arm < 0:
        raise ExperimentRefusal("the mechanical complete-case rule is malformed")
    task_sets = [set(arms[kind]) for kind in ARM_KINDS]
    if not task_sets[0] or any(tasks != task_sets[0] for tasks in task_sets[1:]):
        raise ExperimentRefusal("three-arm outcomes do not contain the same nonempty task set")
    void_case_ids_by_arm = {
        kind: sorted(
            case_id
            for case_id, row in arms[kind].items()
            if row.get("mechanically_valid") is not True
        )
        for kind in ARM_KINDS
    }
    excluded = sorted(set().union(*(set(case_ids) for case_ids in void_case_ids_by_arm.values())))
    included = sorted(task_sets[0] - set(excluded))
    filtered = {kind: {case_id: arms[kind][case_id] for case_id in included} for kind in ARM_KINDS}
    void_counts = {kind: len(case_ids) for kind, case_ids in void_case_ids_by_arm.items()}
    validity = {
        "scheduled_tasks": len(task_sets[0]),
        "complete_case_tasks": len(included),
        "excluded_void_tasks": len(excluded),
        "excluded_void_case_ids": excluded,
        "void_cells_by_arm": void_counts,
        "void_case_ids_by_arm": void_case_ids_by_arm,
        "max_void_cells_per_arm": max_void_cells_per_arm,
        "passed": bool(
            included and all(count <= max_void_cells_per_arm for count in void_counts.values())
        ),
    }
    return filtered, validity


def decide_stage(experiment: Path, stage: str) -> dict[str, Any]:
    experiment = experiment.resolve(strict=True)
    if stage not in STAGES:
        raise ExperimentRefusal(f"unknown stage: {stage}")
    plan = load_protocol(experiment)
    if stage == TRANSFER:
        primary = _load_object(experiment / "primary-verdict.json", cap=MAX_AUDIT_BYTES)
        if primary.get("advance_to_transfer") is not True:
            raise ExperimentRefusal("the frozen primary verdict did not open transfer")
    frozen = freeze_stage_evidence(experiment, plan, stage)
    key = load_arm_key(experiment, plan)
    audit = _load_claude_audit(experiment, plan, stage)
    arms, violations = _stage_outcomes(experiment, plan, key, stage, audit)
    analysis_arms, mechanical_validity = complete_case_arms(
        arms,
        max_void_cells_per_arm=int(plan["decision_rule"]["max_void_cells_per_arm_per_stage"]),
    )
    comparisons = {
        "candidate_vs_retained": paired_comparison(
            analysis_arms["candidate"], analysis_arms["retained"]
        ),
        "candidate_vs_bare": paired_comparison(analysis_arms["candidate"], analysis_arms["bare"]),
    }
    living_unchanged = (
        sha256(Path(str(plan["pins"]["living_body_path"]))) == plan["pins"]["living_body_sha256"]
    )
    common = {
        "version": 1,
        "instrument": INSTRUMENT,
        "stage": stage,
        "decided_at": frozen["frozen_at"],
        "protocol_sha256": sha256(experiment / "protocol.json"),
        "pre_unblind_evidence_sha256": frozen["evidence_sha256"],
        "arm_key_sha256": plan["pins"]["arm_key_sha256"],
        "arm_mapping": {
            label: {"kind": arm["kind"], "coat_sha256": arm["coat_sha256"], "scale": arm["scale"]}
            for label, arm in key["mapping"].items()
        },
        "arms": {kind: _arm_summary(rows) for kind, rows in arms.items()},
        "complete_case_arms": {kind: _arm_summary(rows) for kind, rows in analysis_arms.items()},
        "mechanical_validity": mechanical_validity,
        "comparisons": comparisons,
        "isolation_violations": violations,
        "zero_leaks": not violations,
        "living_body_unchanged": living_unchanged,
        "automatic_promotion": False,
    }
    if stage == PRIMARY:
        mechanically_valid = mechanical_validity["passed"] is True
        superiority = mechanically_valid and all(
            row["one_sided_exact_mcnemar_p"] < 0.05
            and row["bonferroni_cp_95_lower_difference"] > 0.0
            for row in comparisons.values()
        )
        no_harm = mechanically_valid and all(
            row["bonferroni_cp_95_lower_difference"]
            > float(plan["decision_rule"]["overall_no_harm_margin"])
            for row in comparisons.values()
        )
        family_safe = mechanically_valid and all(
            family["losses"] <= int(plan["decision_rule"]["family_loss_limit_of_eight"])
            for row in comparisons.values()
            for family in row["family"].values()
        )
        negative_safe = mechanically_valid and all(
            row["candidate_negative_literal_rate"] <= row["comparator_negative_literal_rate"]
            for row in comparisons.values()
        )
        advance = bool(
            mechanically_valid
            and living_unchanged
            and not violations
            and superiority
            and no_harm
            and family_safe
            and negative_safe
        )
        verdict = {
            **common,
            "gates": {
                "mechanical_validity": mechanically_valid,
                "superiority": superiority,
                "overall_no_harm": no_harm,
                "family_safe": family_safe,
                "negative_literal_safe": negative_safe,
                "zero_leaks": not violations,
                "living_body_unchanged": living_unchanged,
            },
            "advance_to_transfer": advance,
            "causal_conclusion": (
                "no causal verdict: the preregistered mechanical-void ceiling was exceeded"
                if not mechanically_valid
                else (
                    "candidate passed the preregistered scaffolded generalization gate"
                    if advance
                    else "no preregistered causal evidence that the dream improved generalization"
                )
            ),
            "living_promotion_authorized": False,
            "placebo_required_before_living_promotion": True,
        }
        verdict["verdict_sha256"] = sha256_text(canonical(verdict))
        _write_once(experiment / "primary-verdict.json", verdict)
        final = {
            "version": 1,
            "instrument": INSTRUMENT,
            "status": "awaiting-transfer" if advance else "complete",
            "primary_verdict_sha256": verdict["verdict_sha256"],
            "conclusion": verdict["causal_conclusion"],
            "living_promotion_authorized": False,
            "next_required": (
                "run the frozen unscaffolded transfer stage"
                if advance
                else (
                    "start a newly preregistered run; do not reinterpret void cells or "
                    "wear this coat"
                    if not mechanically_valid
                    else "diagnose the failed gates; do not wear this coat"
                )
            ),
        }
        _atomic_json(experiment / "verdict.json", final)
    else:
        mechanically_valid = mechanical_validity["passed"] is True
        transfer_gate = mechanically_valid and all(
            row["gains"] >= 5 and row["losses"] == 0 and len(row["gain_families"]) >= 3
            for row in comparisons.values()
        )
        passed = bool(mechanically_valid and living_unchanged and not violations and transfer_gate)
        verdict = {
            **common,
            "gates": {
                "mechanical_validity": mechanically_valid,
                "five_gains_zero_losses_three_families": transfer_gate,
                "zero_leaks": not violations,
                "living_body_unchanged": living_unchanged,
            },
            "transfer_generalization": passed,
            "causal_conclusion": (
                "no causal verdict: the preregistered mechanical-void ceiling was exceeded"
                if not mechanically_valid
                else (
                    "candidate passed scaffolded and unscaffolded preregistered generalization"
                    if passed
                    else (
                        "candidate did not carry the scaffolded effect into unseen "
                        "unscaffolded tasks"
                    )
                )
            ),
            "living_promotion_authorized": False,
            "placebo_required_before_living_promotion": True,
        }
        verdict["verdict_sha256"] = sha256_text(canonical(verdict))
        _write_once(experiment / "transfer-verdict.json", verdict)
        primary = _load_object(experiment / "primary-verdict.json", cap=MAX_AUDIT_BYTES)
        final = {
            "version": 1,
            "instrument": INSTRUMENT,
            "status": "complete",
            "primary_verdict_sha256": primary["verdict_sha256"],
            "transfer_verdict_sha256": verdict["verdict_sha256"],
            "conclusion": verdict["causal_conclusion"],
            "living_promotion_authorized": False,
            "next_required": (
                "start a newly preregistered run; do not reinterpret void cells or wear this coat"
                if not mechanically_valid
                else (
                    "run a shuffled-reply placebo coat before any living promotion"
                    if passed
                    else "diagnose the failed transfer gate; do not wear this coat"
                )
            ),
        }
        _atomic_json(experiment / "verdict.json", final)
    state = _load_object(experiment / "state.json")
    state["stages"][stage] = "decided"
    if stage == PRIMARY and verdict["advance_to_transfer"]:
        state["stages"][TRANSFER] = "ready"
        state.setdefault("audits", {})[TRANSFER] = "not-made"
    state["status"] = "complete" if final["status"] == "complete" else "running"
    state["updated_at"] = utc_now()
    _atomic_json(experiment / "state.json", state)
    return verdict


def experiment_status(experiment: Path) -> dict[str, Any]:
    experiment = experiment.resolve(strict=True)
    plan = load_protocol(experiment)
    state = _load_object(experiment / "state.json")
    counts: dict[str, dict[str, int]] = {}
    for stage in STAGES:
        expected = len(_stage_cases(plan, stage)) * len(plan["design"]["arm_labels"])
        present = sum(
            1
            for case in _stage_cases(plan, stage)
            for label in plan["design"]["arm_labels"]
            if _checkpoint_path(experiment, stage, label, str(case["id"])).is_file()
        )
        counts[stage] = {"present": present, "expected": expected}
    return {
        "experiment": str(experiment),
        "state": state,
        "cells": counts,
        "living_body_unchanged": (
            sha256(Path(str(plan["pins"]["living_body_path"])))
            == plan["pins"]["living_body_sha256"]
        ),
        "llama_servers": _model_processes(),
        "primary_verdict": (experiment / "primary-verdict.json").is_file(),
        "transfer_verdict": (experiment / "transfer-verdict.json").is_file(),
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    make = commands.add_parser("prepare", help="freeze arms, unseen tasks, instruments, and gates")
    make.add_argument("--out", type=Path, required=True)
    make.add_argument("--room-pointer", type=Path, default=CURRENT_ROOM)
    make.add_argument("--binary", type=Path, default=DEFAULT_BINARY)
    make.add_argument("--base", type=Path, default=DEFAULT_BASE)
    make.add_argument("--server", type=Path, default=DEFAULT_SERVER)
    run = commands.add_parser("run", help="run or resume one frozen stage")
    run.add_argument("--experiment", type=Path, required=True)
    run.add_argument("--stage", choices=STAGES, required=True)
    run.add_argument("--port", type=int, default=PORT)
    run.add_argument("--jobs", type=int, default=PARALLEL)
    bundle = commands.add_parser("audit-bundle", help="emit the arm-blind Claude review set")
    bundle.add_argument("--experiment", type=Path, required=True)
    bundle.add_argument("--stage", choices=STAGES, required=True)
    imported = commands.add_parser("import-audit", help="freeze a complete Claude veto audit")
    imported.add_argument("--experiment", type=Path, required=True)
    imported.add_argument("--stage", choices=STAGES, required=True)
    imported.add_argument("--audit", type=Path, required=True)
    decide = commands.add_parser("decide", help="freeze evidence, unblind, and apply the gates")
    decide.add_argument("--experiment", type=Path, required=True)
    decide.add_argument("--stage", choices=STAGES, required=True)
    status = commands.add_parser("status", help="show blinded progress without opening the key")
    status.add_argument("--experiment", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.command == "prepare":
        result = prepare(
            args.out,
            room_pointer=args.room_pointer,
            binary=args.binary,
            base=args.base,
            server=args.server,
        )
        shown: Any = {
            "experiment": str(args.out.resolve()),
            "plan_sha256": result["plan_sha256"],
            "cases": len(result["cases"]),
        }
    elif args.command == "run":
        shown = run_stage(args.experiment, args.stage, port=args.port, jobs=args.jobs)
    elif args.command == "audit-bundle":
        result = create_audit_bundle(args.experiment, args.stage)
        shown = {
            "path": str(_audit_bundle_path(args.experiment.resolve(), args.stage)),
            "bundle_sha256": result["bundle_sha256"],
            "entries": result["entry_count"],
        }
    elif args.command == "import-audit":
        result = import_claude_audit(args.experiment, args.stage, args.audit)
        shown = {
            "audit_sha256": result["audit_sha256"],
            "decisions": result["decision_count"],
        }
    elif args.command == "decide":
        shown = decide_stage(args.experiment, args.stage)
    else:
        shown = experiment_status(args.experiment)
    print(json.dumps(shown, indent=2, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
