"""Ground truth for composing a three-column product in bounded blocks."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass

from fish.lab.counted_structure import assignment_truth_with_tables

START_CYCLE = 3766
KINDS = ("three-column-lower-block", "three-column-upper-block")

METHODS = {
    "three-column-lower-block": (
        "Set ONES_PRODUCT=ONES_INPUT*MULTIPLIER, OUT_ONES=ONES_PRODUCT mod 10, and "
        "CARRY_TO_TENS=ONES_PRODUCT div 10; set TENS_PRODUCT=TENS_INPUT*MULTIPLIER, "
        "TENS_RAW=TENS_PRODUCT+CARRY_TO_TENS, OUT_TENS=TENS_RAW mod 10, and "
        "CARRY_TO_HUNDREDS=TENS_RAW div 10"
    ),
    "three-column-upper-block": (
        "Set HUNDREDS_PRODUCT=HUNDREDS_INPUT*MULTIPLIER, "
        "HUNDREDS_RAW=HUNDREDS_PRODUCT+CARRY_TO_HUNDREDS, and "
        "RESULT=100*HUNDREDS_RAW+10*OUT_TENS+OUT_ONES"
    ),
}


@dataclass(frozen=True)
class Problem:
    kind: str
    parameters: tuple[int, ...]

    @property
    def assignments(self) -> dict[str, int]:
        return states(self.kind, self.parameters)

    @property
    def method(self) -> str:
        return METHODS[self.kind]

    def _contract(self) -> str:
        return "; ".join(f"{label} = integer" for label in self.assignments)

    def prompt(self) -> str:
        return (
            f"{statement(self.kind, self.parameters)} Evaluate every assignment to a decimal "
            f"integer. Return one line with no prose: {self._contract()}."
        )

    def nudge(self) -> str:
        return (
            f"{statement(self.kind, self.parameters)} Use this relation: {self.method}. "
            f"Do not leave arithmetic operators unevaluated. Return exactly {self._contract()} "
            "and no prose."
        )

    def repair(self) -> str:
        trace = self.assignments
        if self.kind == "three-column-lower-block":
            check = (
                f"The checked ones states are ONES_PRODUCT={trace['ONES_PRODUCT']}, "
                f"OUT_ONES={trace['OUT_ONES']}, and "
                f"CARRY_TO_TENS={trace['CARRY_TO_TENS']}; the checked tens product is "
                f"TENS_PRODUCT={trace['TENS_PRODUCT']}"
            )
        else:
            check = (
                f"The checked hundreds product is HUNDREDS_PRODUCT="
                f"{trace['HUNDREDS_PRODUCT']}; add the supplied carry before recomposing "
                "the three output places"
            )
        return (
            f"{statement(self.kind, self.parameters)} Your preceding values did not all "
            f"satisfy the decimal-block relations. {check}. Continue the block and return "
            f"exactly {self._contract()} with decimal integers and no prose."
        )

    def record(self) -> str:
        return "; ".join(f"{label} = {value}" for label, value in self.assignments.items())


def states(kind: str, parameters: tuple[int, ...]) -> dict[str, int]:
    if kind == "three-column-lower-block":
        if len(parameters) != 3:
            raise ValueError("lower place-value block requires three parameters")
        tens, ones, multiplier = parameters
        if not 0 <= tens <= 9 or not 0 <= ones <= 9 or not 2 <= multiplier <= 9:
            raise ValueError("invalid lower place-value block")
        ones_product = ones * multiplier
        out_ones = ones_product % 10
        carry_to_tens = ones_product // 10
        tens_product = tens * multiplier
        tens_raw = tens_product + carry_to_tens
        return {
            "ONES_PRODUCT": ones_product,
            "OUT_ONES": out_ones,
            "CARRY_TO_TENS": carry_to_tens,
            "TENS_PRODUCT": tens_product,
            "TENS_RAW": tens_raw,
            "OUT_TENS": tens_raw % 10,
            "CARRY_TO_HUNDREDS": tens_raw // 10,
        }
    if kind == "three-column-upper-block":
        if len(parameters) != 5:
            raise ValueError("upper place-value block requires five parameters")
        hundreds, multiplier, carry, out_tens, out_ones = parameters
        if (
            not 1 <= hundreds <= 9
            or not 2 <= multiplier <= 9
            or not 1 <= carry < multiplier
            or not 0 <= out_tens <= 9
            or not 0 <= out_ones <= 9
        ):
            raise ValueError("invalid upper place-value block")
        hundreds_product = hundreds * multiplier
        hundreds_raw = hundreds_product + carry
        return {
            "HUNDREDS_PRODUCT": hundreds_product,
            "HUNDREDS_RAW": hundreds_raw,
            "RESULT": 100 * hundreds_raw + 10 * out_tens + out_ones,
        }
    raise ValueError(f"unknown arithmetic hierarchy task: {kind}")


def statement(kind: str, parameters: tuple[int, ...]) -> str:
    if kind == "three-column-lower-block":
        tens, ones, multiplier = parameters
        return (
            "Three-column-lower-block state question: "
            f"TENS_INPUT={tens}, ONES_INPUT={ones}, and MULTIPLIER={multiplier}."
        )
    if kind == "three-column-upper-block":
        hundreds, multiplier, carry, out_tens, out_ones = parameters
        return (
            "Three-column-upper-block state question: "
            f"HUNDREDS_INPUT={hundreds}, MULTIPLIER={multiplier}, "
            f"CARRY_TO_HUNDREDS={carry}, OUT_TENS={out_tens}, and OUT_ONES={out_ones}."
        )
    raise ValueError(f"unknown arithmetic hierarchy task: {kind}")


def problem_from_prompt(prompt: str) -> Problem | None:
    lower = re.search(
        r"Three-column-lower-block state question:.*TENS_INPUT=(\d+), "
        r"ONES_INPUT=(\d+), and MULTIPLIER=(\d+)",
        prompt,
    )
    if lower is not None:
        return Problem("three-column-lower-block", tuple(int(value) for value in lower.groups()))
    upper = re.search(
        r"Three-column-upper-block state question:.*HUNDREDS_INPUT=(\d+), "
        r"MULTIPLIER=(\d+), CARRY_TO_HUNDREDS=(\d+), OUT_TENS=(\d+), "
        r"and OUT_ONES=(\d+)",
        prompt,
    )
    if upper is not None:
        return Problem("three-column-upper-block", tuple(int(value) for value in upper.groups()))
    return None


def lesson_reply_lands(prompt: str, reply: str) -> bool | None:
    problem = problem_from_prompt(prompt)
    if problem is None:
        return None
    return assignment_truth_with_tables(reply, problem.assignments)


def candidates(kind: str) -> list[tuple[int, ...]]:
    values: list[tuple[int, ...]]
    if kind == "three-column-lower-block":
        values = []
        for tens in range(10):
            for ones in range(10):
                for multiplier in range(2, 10):
                    trace = states(kind, (tens, ones, multiplier))
                    if trace["CARRY_TO_TENS"] and trace["CARRY_TO_HUNDREDS"]:
                        values.append((tens, ones, multiplier))
    elif kind == "three-column-upper-block":
        coherent: set[tuple[int, ...]] = set()
        for hundreds in range(1, 10):
            for tens in range(10):
                for ones in range(10):
                    for multiplier in range(2, 10):
                        lower = states("three-column-lower-block", (tens, ones, multiplier))
                        carry = lower["CARRY_TO_HUNDREDS"]
                        if lower["CARRY_TO_TENS"] and carry:
                            coherent.add(
                                (
                                    hundreds,
                                    multiplier,
                                    carry,
                                    lower["OUT_TENS"],
                                    lower["OUT_ONES"],
                                )
                            )
        values = list(coherent)
    else:
        raise ValueError(f"unknown arithmetic hierarchy task: {kind}")
    values.sort(key=lambda item: hashlib.sha256(f"{kind}:{item}".encode()).digest())
    return values


def lesson_problem(cycle: int) -> tuple[Problem, int]:
    if cycle < START_CYCLE:
        raise ValueError(f"arithmetic hierarchy lessons begin at cycle {START_CYCLE}")
    offset = cycle - START_CYCLE
    block, position = divmod(offset, 4)
    kind = KINDS[position // 2]
    occurrence = block * 2 + position % 2
    pool = candidates(kind)
    return Problem(kind, pool[occurrence % len(pool)]), occurrence
