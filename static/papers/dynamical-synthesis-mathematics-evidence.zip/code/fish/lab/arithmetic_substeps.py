"""Ground truth for product and carry substeps inside a decimal column."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass

from fish.lab.counted_structure import assignment_truth_with_tables

START_CYCLE = 3501
KINDS = ("digit-product", "carry-addition")

METHODS = {
    "digit-product": (
        "Set PRODUCT=DIGIT*MULTIPLIER, TENS_PART=PRODUCT div 10, and ONES_PART=PRODUCT mod 10"
    ),
    "carry-addition": (
        "Set RAW=PRODUCT+INCOMING_CARRY, OUT_DIGIT=RAW mod 10, and NEXT_CARRY=RAW div 10"
    ),
}


@dataclass(frozen=True)
class Problem:
    kind: str
    parameters: tuple[int, ...]

    @property
    def assignments(self) -> dict[str, int]:
        return states(self.kind, self.parameters)

    @property
    def method(self) -> str:
        return METHODS[self.kind]

    def _contract(self) -> str:
        return "; ".join(f"{label} = integer" for label in self.assignments)

    def prompt(self) -> str:
        return (
            f"{statement(self.kind, self.parameters)} Return exactly these three assignments "
            f"on one line, with no prose: {self._contract()}."
        )

    def nudge(self) -> str:
        return (
            f"{statement(self.kind, self.parameters)} Use this relation: {self.method}. "
            f"Return exactly {self._contract()} and no prose."
        )

    def repair(self) -> str:
        if self.kind == "digit-product":
            digit, multiplier = self.parameters
            partial = digit * (multiplier - 1)
            check = (
                f"The checked smaller product is {digit}*{multiplier - 1}={partial}; "
                f"add {digit} once, then split the result into tens and ones"
            )
        else:
            product, carry = self.parameters
            raw = product + carry
            check = f"The checked sum is {product}+{carry}={raw}; split that sum into base ten"
        return (
            f"{statement(self.kind, self.parameters)} Your preceding values did not all "
            f"satisfy the checked relation. {check}. Return exactly {self._contract()} and "
            "no prose."
        )

    def record(self) -> str:
        return "; ".join(f"{label} = {value}" for label, value in self.assignments.items())


def states(kind: str, parameters: tuple[int, ...]) -> dict[str, int]:
    if len(parameters) != 2:
        raise ValueError("arithmetic substeps require two parameters")
    left, right = parameters
    if kind == "digit-product":
        if not 0 <= left <= 9 or not 2 <= right <= 9:
            raise ValueError("invalid decimal digit product")
        product = left * right
        return {"PRODUCT": product, "TENS_PART": product // 10, "ONES_PART": product % 10}
    if kind == "carry-addition":
        if not 0 <= left <= 81 or not 0 <= right <= 8:
            raise ValueError("invalid product and carry")
        raw = left + right
        return {"RAW": raw, "OUT_DIGIT": raw % 10, "NEXT_CARRY": raw // 10}
    raise ValueError(f"unknown arithmetic substep: {kind}")


def statement(kind: str, parameters: tuple[int, ...]) -> str:
    if kind == "digit-product":
        digit, multiplier = parameters
        return (
            "Column-step digit-product question: before adding any carry, "
            f"DIGIT={digit} and MULTIPLIER={multiplier}."
        )
    if kind == "carry-addition":
        product, carry = parameters
        return (
            "Column-step carry-addition question: the checked digit product is "
            f"PRODUCT={product} and INCOMING_CARRY={carry}."
        )
    raise ValueError(f"unknown arithmetic substep: {kind}")


def problem_from_prompt(prompt: str) -> Problem | None:
    product = re.search(
        r"Column-step digit-product question:.*DIGIT=(\d+) and MULTIPLIER=(\d+)", prompt
    )
    if product is not None:
        return Problem("digit-product", tuple(int(value) for value in product.groups()))
    carry = re.search(
        r"Column-step carry-addition question:.*PRODUCT=(\d+) and INCOMING_CARRY=(\d+)",
        prompt,
    )
    if carry is not None:
        return Problem("carry-addition", tuple(int(value) for value in carry.groups()))
    return None


def lesson_reply_lands(prompt: str, reply: str) -> bool | None:
    problem = problem_from_prompt(prompt)
    if problem is None:
        return None
    return assignment_truth_with_tables(reply, problem.assignments)


def candidates(kind: str) -> list[tuple[int, int]]:
    if kind == "digit-product":
        values = [(digit, multiplier) for digit in range(2, 10) for multiplier in range(2, 10)]
    elif kind == "carry-addition":
        products = {digit * multiplier for digit in range(2, 10) for multiplier in range(2, 10)}
        values = [
            (product, carry) for product in products for carry in range(9) if product + carry >= 10
        ]
    else:
        raise ValueError(f"unknown arithmetic substep: {kind}")
    values.sort(key=lambda item: hashlib.sha256(f"{kind}:{item}".encode()).digest())
    return values


def lesson_problem(cycle: int) -> tuple[Problem, int]:
    if cycle < START_CYCLE:
        raise ValueError(f"arithmetic-substep lessons begin at cycle {START_CYCLE}")
    offset = cycle - START_CYCLE
    block, position = divmod(offset, 4)
    kind = KINDS[position // 2]
    occurrence = block * 2 + position % 2
    pool = candidates(kind)
    return Problem(kind, pool[occurrence % len(pool)]), occurrence
