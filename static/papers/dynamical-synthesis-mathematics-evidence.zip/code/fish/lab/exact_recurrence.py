"""Ground truth for exact integer-recurrence lessons."""

from __future__ import annotations

import hashlib
import math
import re
from dataclasses import dataclass

from fish.lab.counted_structure import assignment_truth_with_tables

START_CYCLE = 3317
ADVANCED_START = 3349
CONSOLIDATION_START = 3381
KINDS = ("binomial-recurrence", "euclidean-recurrence")

METHODS = {
    "binomial-recurrence": (
        "For choose(n,k), set q=min(k,n-k), B0=1, and "
        "Bj=B(j-1)(n-j+1)/j for j=1..q; every division is exact and choose(n,k)=Bq"
    ),
    "euclidean-recurrence": (
        "For a>b>0, set R0=a and R1=b, then R(j+1)=R(j-1) mod Rj until the next "
        "remainder is 0; the last nonzero remainder is gcd(a,b)"
    ),
}


def _normalize_grouped_digits(text: str) -> str:
    return re.sub(r"(?<=\d),(?:\s|\\[!,;:])*(?=\d{3}\b)", "", text)


@dataclass(frozen=True)
class Problem:
    kind: str
    parameters: tuple[int, int]

    @property
    def assignments(self) -> dict[str, int]:
        return states(self.kind, self.parameters)

    def prompt(self) -> str:
        labels = "; ".join(f"{label} = integer" for label in self.assignments)
        return (
            f"{statement(self.kind, self.parameters)} What value belongs to each state in this "
            f"order: {labels}? A short labeled table is enough."
        )

    def nudge(self) -> str:
        return (
            f"{statement(self.kind, self.parameters)} Use this relation: {METHODS[self.kind]}. "
            "What labeled values does it give? A short labeled table is enough."
        )

    def record(self) -> str:
        return "; ".join(f"{label} = {value}" for label, value in self.assignments.items())

    @property
    def method(self) -> str:
        return METHODS[self.kind]


def states(kind: str, parameters: tuple[int, int]) -> dict[str, int]:
    if kind == "binomial-recurrence":
        n, k = parameters
        q = min(k, n - k)
        values = [1]
        for j in range(1, q + 1):
            numerator = values[-1] * (n - j + 1)
            value, remainder = divmod(numerator, j)
            if remainder:
                raise ArithmeticError("binomial recurrence lost exact division")
            values.append(value)
        out = {"DEPTH": q}
        out.update({f"B{j}": value for j, value in enumerate(values)})
        out["RESULT"] = values[-1]
        return out
    if kind == "euclidean-recurrence":
        a, b = parameters
        if not a > b > 0:
            raise ValueError("Euclidean recurrence requires a > b > 0")
        values = [a, b]
        while values[-1]:
            values.append(values[-2] % values[-1])
        out = {f"R{j}": value for j, value in enumerate(values)}
        out["GCD"] = values[-2]
        return out
    raise ValueError(f"unknown recurrence kind: {kind}")


def statement(kind: str, parameters: tuple[int, int]) -> str:
    left, right = parameters
    if kind == "binomial-recurrence":
        return f"Binomial state question: what are the exact states for choose({left},{right})?"
    if kind == "euclidean-recurrence":
        return f"Euclidean state question: what are the exact states for gcd({left},{right})?"
    raise ValueError(f"unknown recurrence kind: {kind}")


def problem_from_prompt(prompt: str) -> Problem | None:
    patterns = (
        (
            "binomial-recurrence",
            r"Binomial state question: what are the exact states for choose\((\d+),(\d+)\)",
        ),
        (
            "euclidean-recurrence",
            r"Euclidean state question: what are the exact states for gcd\((\d+),(\d+)\)",
        ),
    )
    for kind, pattern in patterns:
        match = re.search(pattern, prompt)
        if match is not None:
            return Problem(kind, (int(match.group(1)), int(match.group(2))))
    return None


def lesson_reply_lands(prompt: str, reply: str) -> bool | None:
    problem = problem_from_prompt(prompt)
    if problem is None:
        return None
    if arithmetic_claim_refuted(problem, reply):
        return False
    verdict = assignment_truth_with_tables(reply, problem.assignments)
    if verdict is not None:
        return verdict

    if problem.kind == "binomial-recurrence":
        states = {label: value for label, value in problem.assignments.items() if label != "RESULT"}
        if assignment_truth_with_tables(reply, states) is not True:
            return None
        return True if binomial_function_claim_lands(problem, reply) else None

    remainder_states = {
        label: value for label, value in problem.assignments.items() if label != "GCD"
    }
    if assignment_truth_with_tables(reply, remainder_states) is not True:
        return None
    a, b = problem.parameters
    gcd = problem.assignments["GCD"]
    function_claim = rf"\\?gcd\s*\(\s*{a}\s*,\s*{b}\s*\)\s*=\s*{gcd}\b"
    return True if re.search(function_claim, reply, re.IGNORECASE) else None


def binomial_function_claim_lands(problem: Problem, reply: str) -> bool:
    n, k = problem.parameters
    value = problem.assignments["RESULT"]
    text = reply.translate(str.maketrans("₀₁₂₃₄₅₆₇₈₉", "0123456789"))
    text = _normalize_grouped_digits(text)
    for chosen in {k, n - k}:
        tex = (
            rf"\\binom\s*\{{\s*{n}\s*\}}\s*\{{\s*{chosen}\s*\}}"
            rf"\s*(?:=\s*B\s*_?\s*\d+\s*)?=\s*{value}\b"
        )
        plain = (
            rf"choose\s*\(\s*{n}\s*,\s*{chosen}\s*\)"
            rf"\s*(?:=\s*B\s*_?\s*\d+\s*)?=\s*{value}\b"
        )
        if re.search(tex, text, re.IGNORECASE) or re.search(plain, text, re.IGNORECASE):
            return True
    return False


def arithmetic_claim_refuted(problem: Problem, reply: str) -> bool:
    text = reply.translate(str.maketrans("₀₁₂₃₄₅₆₇₈₉", "0123456789")).casefold()
    if problem.kind == "binomial-recurrence" and re.search(
        r"\b(?:is|was|seems?|division is)\s+not exact\b|\bdoes not divide evenly\b",
        text,
    ):
        return True

    normalized = (
        text.replace("\\mod", " mod ")
        .replace("\\times", "*")
        .replace("\\cdot", "*")
        .replace("×", "*")
    )
    normalized = _normalize_grouped_digits(normalized)
    for left, right, claimed in re.findall(
        r"\\?gcd\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)\s*=\s*(\d+)\b", normalized
    ):
        if math.gcd(int(left), int(right)) != int(claimed):
            return True
    binomial_claims = re.findall(
        r"\\binom\s*\{\s*(\d+)\s*\}\s*\{\s*(\d+)\s*\}"
        r"\s*(?:=\s*b\s*_?\s*\d+\s*)?=\s*([\d,]+)\b",
        normalized,
    )
    binomial_claims += re.findall(
        r"choose\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)"
        r"\s*(?:=\s*b\s*_?\s*\d+\s*)?=\s*([\d,]+)\b",
        normalized,
    )
    for n, k, claimed in binomial_claims:
        if int(k) > int(n) or math.comb(int(n), int(k)) != int(claimed.replace(",", "")):
            return True
    for left, right, claimed in re.findall(
        r"\b(\d+)\s*(?:mod|%)\s*(\d+)\s*=\s*(\d+)\b(?!\s*[-+*/])", normalized
    ):
        divisor = int(right)
        if divisor == 0 or int(left) % divisor != int(claimed):
            return True
    for left, right, divisor, claimed in re.findall(
        r"\b(\d+)\s*\*\s*(\d+)\s*/\s*(\d+)\s*=\s*([\d,]+)\b", normalized
    ):
        numerator = int(left) * int(right)
        quotient, remainder = divmod(numerator, int(divisor))
        if remainder or quotient != int(claimed.replace(",", "")):
            return True
    return False


def candidates(kind: str, *, advanced: bool = False) -> list[tuple[int, int]]:
    if kind == "binomial-recurrence":
        values = [(n, k) for n in range(12, 31) for k in range(3, n - 2) if 3 <= min(k, n - k) <= 6]
    elif kind == "euclidean-recurrence":
        values = []
        for a in range(80, 221):
            for b in range(20, a):
                trace = states(kind, (a, b))
                remainder_count = sum(label.startswith("R") for label in trace)
                if 4 <= remainder_count <= 8 and math.gcd(a, b) <= 15:
                    values.append((a, b))
    else:
        raise ValueError(f"unknown recurrence kind: {kind}")
    values.sort(key=lambda pair: hashlib.sha256(f"{kind}:{pair}".encode()).digest())
    if advanced:
        taught = set(values[:16])
        if kind == "binomial-recurrence":
            values = [pair for pair in values if min(pair[1], pair[0] - pair[1]) >= 4]
        else:
            values = [
                pair
                for pair in values
                if sum(label.startswith("R") for label in states(kind, pair)) >= 6
            ]
        values = [pair for pair in values if pair not in taught]
    return values


def lesson_problem(cycle: int) -> tuple[Problem, int]:
    if cycle < START_CYCLE:
        raise ValueError(f"exact-recurrence lessons begin at cycle {START_CYCLE}")
    if cycle >= CONSOLIDATION_START:
        occurrence = cycle - CONSOLIDATION_START
        advanced_pool = candidates("binomial-recurrence", advanced=True)
        pool = [pair for pair in advanced_pool[16:] if min(pair[1], pair[0] - pair[1]) >= 5]
        return Problem("binomial-recurrence", pool[occurrence % len(pool)]), occurrence
    is_advanced = cycle >= ADVANCED_START
    offset = cycle - (ADVANCED_START if is_advanced else START_CYCLE)
    kind = KINDS[offset % len(KINDS)]
    occurrence = offset // len(KINDS)
    pool = candidates(kind, advanced=is_advanced)
    return Problem(kind, pool[occurrence % len(pool)]), occurrence
