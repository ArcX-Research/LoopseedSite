"""Run the sealed four-arm formal-method transfer experiment on private bodies.

The task generator and decision rules live in :mod:`claim_transfer_protocol`.
This harness adds only frozen inputs, randomized arm labels, resumable cells,
and the existing exact typed-AST ruler.  Every cell gets a fresh SQLite clone
and daemon chair.  Retrieval, verified recall, mirror, fins, and ocean remain
off.  No command in this module can wear a coat or write the living body.

Whole-reply audit and unblinding are intentionally separate later steps.  A
completed inference run remains arm-blind and cannot promote anything.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import json
import os
import platform
import re
import secrets
import shutil
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any, Callable

from fish.lab import adaptive_evolution as adaptive
from fish.lab import (
    claim_dream,
    claim_placebo,
    claim_probe,
    formal_node_language,
    task_scoped_grammar,
)
from fish.lab import claim_evolution as v1
from fish.lab import claim_transfer_protocol as protocol
from fish.lab import typed_ast_probe_v2 as exact_checker

ROOT = Path(__file__).resolve().parents[2]
LABS = ROOT / "data/fish/labs"
CURRENT_ROOM = LABS / "claims-current.json"
LIVING_BODY = ROOT / "fish/sediment.db"
DEFAULT_BINARY = ROOT / "fish/daemon/target/debug/fish-daemon"
DEFAULT_BASE = ROOT / "fish/water/base.gguf"
DEFAULT_SERVER = Path(shutil.which("llama-server") or "llama-server")
DEFAULT_WOLFRAM = Path(shutil.which("wolframscript") or "wolframscript")
OLD_COAT = ROOT / "fish/water/adapters/2026-08-16T163701.626802Z/lora.gguf"
INSTRUMENT = protocol.INSTRUMENT
PORT = 18093
CONTEXT = 8192
MAX_REPLY_TOKENS = 2048
PARALLEL = 1
CELL_TIMEOUT = 240
SWAP_LIMIT_MIB = 8192.0
MAX_VOID_CELLS_PER_ARM = 8
MAX_ENDPOINT_VOID_CELLS_PER_ARM = 2
MAX_RECORD_BYTES = 4 * 1024 * 1024
MAX_AUDIT_BYTES = 32 * 1024 * 1024
MAX_AUDIT_REASON = 2_000
UNCONSTRAINED = "unconstrained"
EXCLUSION_INSTRUMENTS = frozenset({"claim-method-transfer-v2", "claim-clean-prompt-safety-v1"})
MAX_EXCLUSION_EXPERIMENTS = 8
MAX_EXCLUSION_TASKS = 4_096
HEX64 = re.compile(r"[0-9a-f]{64}")
INTEGER_TOKEN = re.compile(r"(?<![A-Za-z0-9_])-?\d+(?![A-Za-z0-9_])")
AUDIT_BUNDLE_FIELDS = frozenset(
    {
        "version",
        "instrument",
        "created_at",
        "protocol_sha256",
        "blinding",
        "rubric",
        "entry_count",
        "entries",
        "bundle_sha256",
    }
)
AUDIT_ENTRY_FIELDS = frozenset(
    {
        "audit_id",
        "case_id",
        "task_id",
        "kind",
        "prompt_condition",
        "grammar_condition",
        "primary_endpoint",
        "prompt",
        "prompt_sha256",
        "required",
        "canonical_program",
        "allowed_literals",
        "reply",
        "reply_sha256",
        "exact_grade",
        "exact_grade_sha256",
        "features",
        "entry_sha256",
    }
)
AUDIT_SOURCE_FIELDS = frozenset({"version", "instrument", "bundle_sha256", "reviewer", "decisions"})
AUDIT_RECORD_FIELDS = frozenset(
    {
        "version",
        "instrument",
        "imported_at",
        "bundle_sha256",
        "source_path",
        "source_sha256",
        "reviewer",
        "decision_count",
        "decisions",
        "audit_sha256",
    }
)
AUDIT_REVIEWER_FIELDS = frozenset({"name", "session", "independent", "whole_reply_review"})
AUDIT_DECISION_FIELDS = frozenset(
    {"audit_id", "reply_sha256", "decision", "reason", "rubric_codes"}
)
RUN_SEAL_FIELDS = frozenset(
    {
        "version",
        "instrument",
        "created_at",
        "protocol_sha256",
        "arm_key_sha256",
        "checkpoint_count",
        "eligible_count",
        "checkpoints",
        "seal_sha256",
    }
)
RUN_SEAL_ENTRY_FIELDS = frozenset(
    {"label", "case_id", "path", "sha256", "reply_sha256", "machine_proved"}
)
PINNED_ENV = v1.PINNED_ENV


class ExperimentRefusal(RuntimeError):
    """A frozen identity, isolation rule, or resource boundary did not hold."""


def utc_now() -> str:
    return v1.utc_now()


def canonical(value: object) -> str:
    return protocol.canonical(value)


def sha256(path: Path) -> str:
    return v1.sha256(path)


def sha256_text(value: str) -> str:
    return protocol.sha256_text(value)


def _load_object(path: Path, *, cap: int = MAX_RECORD_BYTES) -> dict[str, Any]:
    try:
        return v1._load_object(path, cap=cap)
    except v1.ExperimentRefusal as error:
        raise ExperimentRefusal(str(error)) from error


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    v1._atomic_json(path, value)


def _write_once(path: Path, value: dict[str, Any]) -> dict[str, Any]:
    """Create bounded read-only evidence, or verify the existing artifact exactly."""
    if path.exists():
        existing = _load_object(path, cap=MAX_AUDIT_BYTES)
        if canonical(existing) != canonical(value):
            raise ExperimentRefusal(f"refusing to overwrite frozen evidence: {path}")
        return existing
    _atomic_json(path, value)
    path.chmod(0o444)
    return value


def _confined(path: Path, root: Path, label: str, *, exists: bool = True) -> Path:
    try:
        return v1._confined(path, root, label, exists=exists)
    except v1.ExperimentRefusal as error:
        raise ExperimentRefusal(str(error)) from error


def _git_commit() -> str:
    return subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, timeout=30
    ).strip()


def _require_tracked_tree_clean() -> None:
    result = subprocess.run(
        ["git", "diff", "--quiet", "HEAD", "--"], cwd=ROOT, check=False, timeout=30
    )
    if result.returncode != 0:
        raise ExperimentRefusal("commit the tracked experiment instruments before prepare")


def _lineage(room_pointer: Path) -> dict[str, Any]:
    try:
        lineage = v1._current_lineage(room_pointer)
        _validate_transfer_lineage(lineage)
    except (claim_dream.DreamRefusal, v1.ExperimentRefusal) as error:
        raise ExperimentRefusal(str(error)) from error
    return lineage


def _validate_transfer_lineage(lineage: dict[str, Any]) -> None:
    """Bind a current private candidate to its sealed dream instead of one old digest."""
    room = Path(str(lineage["room"])).resolve()
    dataset = Path(str(lineage["dataset"])).resolve()
    source = Path(str(lineage["source"])).resolve()
    candidate = Path(str(lineage["candidate"])).resolve()
    conversation = lineage.get("conversation")
    manifest = lineage.get("manifest")
    if not isinstance(conversation, dict) or not isinstance(manifest, dict):
        raise ExperimentRefusal("claim lineage metadata is malformed")
    verified = claim_dream._verify_dataset(dataset)
    if canonical(verified) != canonical(manifest):
        raise ExperimentRefusal("current claim dataset differs from its verified manifest")
    if room != Path(str(manifest.get("room", ""))).resolve():
        raise ExperimentRefusal("the dream manifest belongs to another claim room")
    expected_source = manifest.get("source_snapshot_sha256")
    if (
        source != Path(str(manifest.get("source_snapshot", ""))).resolve()
        or expected_source != sha256(source)
        or manifest.get("hashes", {}).get("source.db") != expected_source
    ):
        raise ExperimentRefusal("the frozen dream source differs from its manifest")
    living = Path(str(manifest.get("living_body", ""))).resolve()
    mutable = Path(str(conversation.get("clone_body", ""))).resolve()
    living_expected = str(manifest.get("living_sha256", ""))
    if (
        living != LIVING_BODY.resolve()
        or source in {living, mutable}
        or sha256(LIVING_BODY) != living_expected
        or conversation.get("living_sha256") != living_expected
    ):
        raise ExperimentRefusal("the private candidate no longer has an isolated living lineage")

    adapter = candidate.parent
    if not adapter.is_relative_to((room / "body/fish/water/adapters").resolve()):
        raise ExperimentRefusal("the candidate coat is outside the private claim room")
    dream_path = adapter / "dream.json"
    promotion_path = adapter / "promotion.json"
    weights = adapter / "adapters.safetensors"
    dream = _load_object(dream_path)
    promotion = _load_object(promotion_path)
    if (
        dream.get("status") != "survived-private-witness"
        or Path(str(dream.get("dataset", ""))).resolve() != dataset
        or dream.get("dataset_manifest_sha256") != sha256(dataset / "manifest.json")
        or dream.get("accepted_pairs") != manifest.get("accepted")
        or dream.get("validation_contracted") is not True
    ):
        raise ExperimentRefusal("the current candidate did not survive its pinned private dream")
    if manifest.get("version") == 2 and dream.get("instrument") != manifest.get("instrument"):
        raise ExperimentRefusal("the clean candidate and its dataset name different instruments")
    if (
        promotion.get("status") not in {"staged-unworn", "worn"}
        or promotion.get("dream") != dream
        or not weights.is_file()
        or promotion.get("source_sha256") != sha256(weights)
        or promotion.get("gguf_sha256") != sha256(candidate)
        or sha256(candidate) == sha256(OLD_COAT)
    ):
        raise ExperimentRefusal("the candidate is not one distinct, pinned private coat")


def _exclusion_cases(plan: dict[str, Any]) -> list[dict[str, Any]]:
    design = plan.get("design")
    cases = design.get("cases") if isinstance(design, dict) else None
    if not isinstance(cases, list) or not cases:
        raise ExperimentRefusal("an exclusion experiment has no sealed cases")
    return cases


def _validated_external_exclusions(
    experiments: list[Path] | tuple[Path, ...],
    *,
    candidate_sha256: str,
) -> tuple[set[tuple[str, tuple[int, ...]]], list[dict[str, Any]]]:
    """Verify complete prior experiments and recover only their public task identities."""
    if len(experiments) > MAX_EXCLUSION_EXPERIMENTS:
        raise ExperimentRefusal("too many external exclusion experiments")
    resolved = [
        _confined(Path(path), LABS, "external exclusion experiment") for path in experiments
    ]
    if len(set(resolved)) != len(resolved):
        raise ExperimentRefusal("external exclusion experiments are duplicated")

    tasks: set[tuple[str, tuple[int, ...]]] = set()
    records: list[dict[str, Any]] = []
    for experiment in sorted(resolved):
        protocol_path = experiment / "protocol.json"
        state_path = experiment / "state.json"
        verdict_path = experiment / "verdict.json"
        frozen = _load_object(protocol_path, cap=MAX_AUDIT_BYTES)
        state = _load_object(state_path, cap=MAX_AUDIT_BYTES)
        verdict = _load_object(verdict_path, cap=MAX_AUDIT_BYTES)
        instrument = frozen.get("instrument")
        version = frozen.get("version")
        frozen_pins = frozen.get("pins")
        plan_body = {key: value for key, value in frozen.items() if key != "plan_sha256"}
        verdict_body = {key: value for key, value in verdict.items() if key != "verdict_sha256"}
        if (
            instrument not in EXCLUSION_INSTRUMENTS
            or verdict.get("instrument") != instrument
            or verdict.get("version") != version
            or frozen.get("plan_sha256") != sha256_text(canonical(plan_body))
            or verdict.get("verdict_sha256") != sha256_text(canonical(verdict_body))
            or verdict.get("protocol_sha256") != sha256(protocol_path)
            or verdict.get("living_body_unchanged") is not True
            or verdict.get("source_body_unchanged") is not True
            or verdict.get("living_promotion_authorized") is not False
        ):
            raise ExperimentRefusal("external exclusion evidence failed its immutable identity")
        cells = state.get("cells")
        if (
            state.get("instrument") != instrument
            or state.get("status") != "complete"
            or state.get("unblinded") is not True
            or not isinstance(cells, dict)
            or type(cells.get("present")) is not int
            or cells.get("present") != cells.get("expected")
            or int(cells["present"]) < 1
        ):
            raise ExperimentRefusal("external exclusion experiment is not complete")
        if instrument == "claim-clean-prompt-safety-v1" and (
            not isinstance(frozen_pins, dict)
            or frozen_pins.get("candidate_coat_sha256") != candidate_sha256
            or verdict.get("full_blinded_rerun_authorized") is not True
            or verdict.get("prompt_cleaning_supported") is not True
        ):
            raise ExperimentRefusal("the clean safety exclusion does not authorize this candidate")

        run_tasks: set[tuple[str, tuple[int, ...]]] = set()
        cases = _exclusion_cases(frozen)
        for case in cases:
            if not isinstance(case, dict):
                raise ExperimentRefusal("external exclusion case is not an object")
            kind, parameters = case.get("kind"), case.get("parameters")
            if (
                not isinstance(kind, str)
                or not isinstance(parameters, list)
                or any(type(value) is not int for value in parameters)
            ):
                raise ExperimentRefusal("external exclusion task identity is malformed")
            claim_probe.validate_task_parameters(kind, parameters)
            spec = case.get("spec")
            if not isinstance(spec, dict) or claim_probe.verify_spec(spec).get("kind") != kind:
                raise ExperimentRefusal("external exclusion task spec is malformed")
            if spec.get("parameters") != parameters:
                raise ExperimentRefusal("external exclusion task and spec disagree")
            run_tasks.add((kind, tuple(parameters)))
        tasks.update(run_tasks)
        records.append(
            {
                "path": str(experiment),
                "instrument": instrument,
                "protocol_sha256": sha256(protocol_path),
                "plan_sha256": frozen["plan_sha256"],
                "state_sha256": sha256(state_path),
                "verdict_sha256": sha256(verdict_path),
                "internal_verdict_sha256": verdict["verdict_sha256"],
                "sealed_cases": len(cases),
                "distinct_tasks": len(run_tasks),
            }
        )
    if len(tasks) > MAX_EXCLUSION_TASKS:
        raise ExperimentRefusal("external exclusion task set is too large")
    return tasks, records


def _placebo_lineage(adapter: Path, lineage: dict[str, Any]) -> dict[str, Any]:
    room = Path(str(lineage["room"])).resolve()
    adapter = _confined(
        adapter,
        room / "body/fish/water/adapters",
        "private placebo adapter",
    )
    dream_path = _confined(adapter / "dream.json", adapter, "placebo dream")
    dream = _load_object(dream_path)
    if (
        dream.get("instrument") != claim_placebo.INSTRUMENT
        or dream.get("status") != "trained-fixed-schedule-unworn"
        or dream.get("living_body_unchanged") is not True
    ):
        raise ExperimentRefusal("placebo did not complete its fixed private schedule")
    dataset = _confined(
        Path(str(dream.get("dataset", ""))),
        room / "dreams",
        "placebo dataset",
    )
    try:
        manifest = claim_placebo.verify_dataset(dataset)
    except claim_placebo.PlaceboRefusal as error:
        raise ExperimentRefusal(str(error)) from error
    if dream.get("dataset_manifest_sha256") != sha256(dataset / "manifest.json"):
        raise ExperimentRefusal("placebo dream names another dataset")
    reference = manifest["reference_candidate"]
    candidate = Path(str(lineage["candidate"])).resolve()
    if Path(str(reference["candidate_lora_path"])).resolve() != candidate or reference[
        "candidate_lora_sha256"
    ] != sha256(candidate):
        raise ExperimentRefusal("placebo was not paired with this candidate coat")
    coat = _confined(adapter / "lora.gguf", adapter, "staged placebo GGUF")
    promotion_path = _confined(adapter / "promotion.json", adapter, "placebo stage record")
    promotion = _load_object(promotion_path)
    if (
        promotion.get("status") != "staged-unworn"
        or promotion.get("gguf_sha256") != sha256(coat)
        or promotion.get("source_sha256") != sha256(adapter / "adapters.safetensors")
    ):
        raise ExperimentRefusal("placebo GGUF is not one pinned, staged-unworn adapter")
    if sha256(coat) in {sha256(candidate), sha256(OLD_COAT)}:
        raise ExperimentRefusal("placebo coat is byte-identical to a substantive arm")
    return {
        "adapter": adapter,
        "coat": coat,
        "dream": dream,
        "dream_path": dream_path,
        "dataset": dataset,
        "manifest": manifest,
        "promotion": promotion,
        "promotion_path": promotion_path,
    }


def _server_identity(path: Path) -> dict[str, str]:
    try:
        return v1._server_identity(path)
    except (OSError, subprocess.SubprocessError, v1.ExperimentRefusal) as error:
        raise ExperimentRefusal(f"cannot pin private water server: {error}") from error


def _wolfram_identity(path: Path = DEFAULT_WOLFRAM) -> dict[str, str]:
    try:
        return v1._wolfram_identity(path)
    except (OSError, subprocess.SubprocessError, v1.ExperimentRefusal) as error:
        raise ExperimentRefusal(f"cannot pin exact decision kernel: {error}") from error


def _arm_key(candidate: Path, placebo: Path, created_at: str) -> dict[str, Any]:
    labels = ["A", "B", "C", "D"]
    kinds = list(protocol.ARM_KINDS)
    secrets.SystemRandom().shuffle(kinds)
    descriptions = {
        "bare": {"coat": str(OLD_COAT.resolve()), "coat_sha256": sha256(OLD_COAT), "scale": 0.0},
        "retained": {
            "coat": str(OLD_COAT.resolve()),
            "coat_sha256": sha256(OLD_COAT),
            "scale": 1.0,
        },
        "candidate": {
            "coat": str(candidate.resolve()),
            "coat_sha256": sha256(candidate),
            "scale": 1.0,
        },
        "placebo": {
            "coat": str(placebo.resolve()),
            "coat_sha256": sha256(placebo),
            "scale": 1.0,
        },
    }
    return {
        "version": 2,
        "instrument": INSTRUMENT,
        "created_at": created_at,
        "nonce": secrets.token_hex(32),
        "mapping": {
            label: {"kind": kind, **descriptions[kind]}
            for label, kind in zip(labels, kinds, strict=True)
        },
    }


def _block_orders(labels: list[str], blocks: int) -> dict[str, list[str]]:
    if len(labels) != 4 or len(set(labels)) != 4 or blocks < 1:
        raise ExperimentRefusal("four-arm block order is malformed")
    patterns: list[list[str]] = []
    for offset in range(4):
        rotated = labels[offset:] + labels[:offset]
        patterns.extend((rotated, list(reversed(rotated))))
    return {str(block): list(patterns[block % len(patterns)]) for block in range(blocks)}


def prepare(
    out: Path,
    placebo_adapter: Path,
    *,
    room_pointer: Path = CURRENT_ROOM,
    previous_protocol: Path = protocol.DEFAULT_PREVIOUS_PROTOCOL,
    exclude_experiments: tuple[Path, ...] = (),
    binary: Path = DEFAULT_BINARY,
    base: Path = DEFAULT_BASE,
    server: Path = DEFAULT_SERVER,
    created_at: str | None = None,
) -> dict[str, Any]:
    """Freeze all arms, cases, instruments, exclusions, and gates before inference."""
    if out.exists():
        raise ExperimentRefusal(f"experiment directory already exists: {out}")
    _require_tracked_tree_clean()
    lineage = _lineage(room_pointer)
    placebo = _placebo_lineage(placebo_adapter, lineage)
    room = Path(str(lineage["room"]))
    source = Path(str(lineage["source"]))
    candidate = Path(str(lineage["candidate"]))
    made_at = created_at or utc_now()
    try:
        historical, historical_record = v1.historical_tasks(room, source)
        external, exclusion_runs = _validated_external_exclusions(
            exclude_experiments,
            candidate_sha256=sha256(candidate),
        )
        prospective_history = historical | external
        design = protocol.prospective_design(
            prospective_history, made_at, previous_protocol=previous_protocol
        )
    except (v1.ExperimentRefusal, protocol.ProtocolRefusal) as error:
        raise ExperimentRefusal(str(error)) from error

    exclusion_rows = [
        {"kind": kind, "parameters": list(parameters)} for kind, parameters in sorted(external)
    ]

    out.mkdir(parents=True)
    try:
        key = _arm_key(candidate, Path(str(placebo["coat"])), made_at)
        key_path = out / "arm-key.json"
        _atomic_json(key_path, key)
        key_path.chmod(0o600)
        pins: dict[str, Any] = {
            "claim_transfer_experiment_sha256": sha256(Path(__file__)),
            "claim_transfer_protocol_sha256": sha256(Path(protocol.__file__)),
            "claim_placebo_sha256": sha256(Path(claim_placebo.__file__)),
            "formal_node_language_sha256": sha256(Path(formal_node_language.__file__)),
            "claim_evolution_v1_sha256": sha256(Path(v1.__file__)),
            "adaptive_evolution_sha256": sha256(Path(adaptive.__file__)),
            "typed_ast_probe_v2_sha256": sha256(Path(exact_checker.__file__)),
            "task_scoped_grammar_sha256": sha256(Path(task_scoped_grammar.__file__)),
            "task_grammar_manifest_sha256": sha256(task_scoped_grammar.MANIFEST),
            "loose_grammar_sha256": sha256(protocol.LOOSE_GRAMMAR),
            "soul_sha256": sha256(ROOT / "SOUL.md"),
            "daemon_binary_path": str(binary.resolve(strict=True)),
            "daemon_binary_sha256": sha256(binary),
            "base_path": str(base.resolve(strict=True)),
            "base_sha256": sha256(base),
            "server": _server_identity(server),
            "wolfram": _wolfram_identity(),
            "python": platform.python_version(),
            "git_commit": _git_commit(),
            "source_body_path": str(source.resolve()),
            "source_body_sha256": sha256(source),
            "mutable_clone_body_path": str(
                Path(str(lineage["conversation"]["clone_body"])).resolve()
            ),
            "living_body_path": str(LIVING_BODY.resolve()),
            "living_body_sha256": sha256(LIVING_BODY),
            "retained_coat_path": str(OLD_COAT.resolve(strict=True)),
            "retained_coat_sha256": sha256(OLD_COAT),
            "candidate_coat_path": str(candidate.resolve()),
            "candidate_coat_sha256": sha256(candidate),
            "candidate_dream_manifest_path": str(Path(str(lineage["dataset"])) / "manifest.json"),
            "candidate_dream_manifest_sha256": sha256(
                Path(str(lineage["dataset"])) / "manifest.json"
            ),
            "placebo_coat_path": str(Path(str(placebo["coat"])).resolve()),
            "placebo_coat_sha256": sha256(Path(str(placebo["coat"]))),
            "placebo_dream_path": str(Path(str(placebo["dream_path"])).resolve()),
            "placebo_dream_sha256": sha256(Path(str(placebo["dream_path"]))),
            "placebo_manifest_path": str(Path(str(placebo["dataset"])) / "manifest.json"),
            "placebo_manifest_sha256": sha256(Path(str(placebo["dataset"])) / "manifest.json"),
            "placebo_promotion_path": str(Path(str(placebo["promotion_path"])).resolve()),
            "placebo_promotion_sha256": sha256(Path(str(placebo["promotion_path"]))),
            "previous_protocol_path": str(previous_protocol.resolve(strict=True)),
            "previous_protocol_sha256": sha256(previous_protocol),
            "arm_key_sha256": sha256(key_path),
        }
        blocks = (
            len(protocol.PROMPT_CONDITIONS)
            * len(protocol.GRAMMAR_CONDITIONS)
            * protocol.TASKS_PER_FAMILY
        )
        plan: dict[str, Any] = {
            "version": 2,
            "instrument": INSTRUMENT,
            "created_at": made_at,
            "status": "prepared",
            "objective": (
                "causal unscaffolded method transfer from an audited formal speaking dream"
            ),
            "runtime": {
                "water_port": PORT,
                "context_tokens": CONTEXT,
                "parallel_requests": PARALLEL,
                "max_reply_tokens": MAX_REPLY_TOKENS,
                "cell_timeout_seconds": CELL_TIMEOUT,
                "fresh_body_and_daemon_per_cell": True,
                "retrieval": "off",
                "verified_recall": "off",
                "ledger": "off",
                "mirror": "off",
                "fins": "off",
                "ocean": "off",
            },
            "mechanical_rule": {
                "max_void_cells_per_arm": MAX_VOID_CELLS_PER_ARM,
                "max_primary_endpoint_void_cells_per_arm": MAX_ENDPOINT_VOID_CELLS_PER_ARM,
                "cap_cuts_are_model_failures": True,
            },
            "audit_rule": {
                "whole_reply_external_review": "required before unblinding",
                "authority": "veto-only; cannot upgrade an exact-checker failure",
            },
            "automatic_promotion": False,
            "historical": historical_record,
            "historical_tasks": [
                {"kind": kind, "parameters": list(parameters)}
                for kind, parameters in sorted(historical)
            ],
            "external_exclusions": {
                "runs": exclusion_runs,
                "task_count": len(exclusion_rows),
                "tasks": exclusion_rows,
                "tasks_sha256": sha256_text(canonical(exclusion_rows)),
            },
            "design": design,
            "block_orders": _block_orders(["A", "B", "C", "D"], blocks),
            "pins": pins,
        }
        plan["plan_sha256"] = sha256_text(canonical(plan))
        _atomic_json(out / "protocol.json", plan)
        _atomic_json(
            out / "state.json",
            {
                "version": 2,
                "instrument": INSTRUMENT,
                "status": "prepared",
                "created_at": made_at,
                "updated_at": made_at,
                "protocol_sha256": sha256(out / "protocol.json"),
                "cells": {"present": 0, "expected": len(design["cases"]) * 4},
                "audit": "not-made",
                "unblinded": False,
            },
        )
        return plan
    except BaseException:
        shutil.rmtree(out, ignore_errors=True)
        raise


def _source_pins() -> dict[str, Path]:
    return {
        "claim_transfer_experiment_sha256": Path(__file__),
        "claim_transfer_protocol_sha256": Path(protocol.__file__),
        "claim_placebo_sha256": Path(claim_placebo.__file__),
        "formal_node_language_sha256": Path(formal_node_language.__file__),
        "claim_evolution_v1_sha256": Path(v1.__file__),
        "adaptive_evolution_sha256": Path(adaptive.__file__),
        "typed_ast_probe_v2_sha256": Path(exact_checker.__file__),
        "task_scoped_grammar_sha256": Path(task_scoped_grammar.__file__),
        "task_grammar_manifest_sha256": task_scoped_grammar.MANIFEST,
        "loose_grammar_sha256": protocol.LOOSE_GRAMMAR,
        "soul_sha256": ROOT / "SOUL.md",
    }


def load_protocol(experiment: Path, *, verify_large_files: bool = True) -> dict[str, Any]:
    experiment = experiment.resolve(strict=True)
    plan = _load_object(experiment / "protocol.json")
    body = {key: value for key, value in plan.items() if key != "plan_sha256"}
    if (
        plan.get("version") != 2
        or plan.get("instrument") != INSTRUMENT
        or plan.get("plan_sha256") != sha256_text(canonical(body))
    ):
        raise ExperimentRefusal("transfer protocol identity or canonical hash drift")
    pins = plan.get("pins")
    if not isinstance(pins, dict):
        raise ExperimentRefusal("transfer protocol has no instrument pins")
    for name, path in _source_pins().items():
        if not path.is_file() or sha256(path) != pins.get(name):
            raise ExperimentRefusal(f"pinned source instrument changed: {name}")
    live_identities = {
        "server": _server_identity(Path(str(pins.get("server", {}).get("path", "")))),
        "wolfram": _wolfram_identity(Path(str(pins.get("wolfram", {}).get("path", "")))),
    }
    for name, identity in live_identities.items():
        if identity != pins.get(name):
            raise ExperimentRefusal(f"pinned {name} identity changed")
    if platform.python_version() != pins.get("python") or _git_commit() != pins.get("git_commit"):
        raise ExperimentRefusal("pinned Python or repository commit changed")
    previous = Path(str(pins.get("previous_protocol_path", "")))
    if not previous.is_file() or sha256(previous) != pins.get("previous_protocol_sha256"):
        raise ExperimentRefusal("pinned predecessor protocol changed")
    historical_rows = plan.get("historical_tasks")
    if not isinstance(historical_rows, list):
        raise ExperimentRefusal("historical exclusion set is missing")
    historical: set[tuple[str, tuple[int, ...]]] = set()
    for row in historical_rows:
        if (
            not isinstance(row, dict)
            or set(row) != {"kind", "parameters"}
            or not isinstance(row["kind"], str)
            or not isinstance(row["parameters"], list)
            or any(type(value) is not int for value in row["parameters"])
        ):
            raise ExperimentRefusal("historical exclusion row is malformed")
        historical.add((row["kind"], tuple(row["parameters"])))
    historical_record = plan.get("historical")
    if (
        not isinstance(historical_record, dict)
        or len(historical) != historical_record.get("task_count")
        or historical_record.get("tasks") != historical_rows
        or historical_record.get("tasks_sha256") != sha256_text(canonical(historical_rows))
    ):
        raise ExperimentRefusal("historical exclusion count drift")
    external_record = plan.get("external_exclusions")
    if (
        not isinstance(external_record, dict)
        or not isinstance(external_record.get("runs"), list)
        or any(not isinstance(row, dict) for row in external_record["runs"])
    ):
        raise ExperimentRefusal("external exclusion record is missing")
    external, external_runs = _validated_external_exclusions(
        [Path(str(row.get("path", ""))) for row in external_record["runs"]],
        candidate_sha256=str(pins.get("candidate_coat_sha256", "")),
    )
    external_rows = [
        {"kind": kind, "parameters": list(parameters)} for kind, parameters in sorted(external)
    ]
    if (
        external_record.get("runs") != external_runs
        or external_record.get("task_count") != len(external_rows)
        or external_record.get("tasks") != external_rows
        or external_record.get("tasks_sha256") != sha256_text(canonical(external_rows))
    ):
        raise ExperimentRefusal("external exclusion record drift")
    room = Path(str(plan["pins"]["mutable_clone_body_path"])).resolve().parents[2]
    for source_record in historical_record.get("room_spec_files", []):
        if not isinstance(source_record, dict):
            raise ExperimentRefusal("historical room-spec pin is malformed")
        source_path = Path(str(source_record.get("path", "")))
        if (
            not source_path.resolve().is_relative_to(room)
            or not source_path.is_file()
            or sha256(source_path) != source_record.get("sha256")
        ):
            raise ExperimentRefusal("historical room-spec source changed")
    try:
        expected_design = protocol.prospective_design(
            historical | external,
            str(plan["created_at"]),
            previous_protocol=previous,
        )
    except protocol.ProtocolRefusal as error:
        raise ExperimentRefusal(str(error)) from error
    if canonical(expected_design) != canonical(plan.get("design")):
        raise ExperimentRefusal("prospective design was changed after prepare")
    cases = expected_design["cases"]
    blocks = (
        len(protocol.PROMPT_CONDITIONS)
        * len(protocol.GRAMMAR_CONDITIONS)
        * protocol.TASKS_PER_FAMILY
    )
    orders = plan.get("block_orders")
    if orders != _block_orders(["A", "B", "C", "D"], blocks):
        raise ExperimentRefusal("sealed block order drift")
    if len(cases) != 256:
        raise ExperimentRefusal("sealed factorial matrix is incomplete")
    if verify_large_files:
        large = {
            "daemon_binary_sha256": Path(str(pins.get("daemon_binary_path", ""))),
            "base_sha256": Path(str(pins.get("base_path", ""))),
            "source_body_sha256": Path(str(pins.get("source_body_path", ""))),
            "living_body_sha256": Path(str(pins.get("living_body_path", ""))),
            "retained_coat_sha256": Path(str(pins.get("retained_coat_path", ""))),
            "candidate_coat_sha256": Path(str(pins.get("candidate_coat_path", ""))),
            "candidate_dream_manifest_sha256": Path(
                str(pins.get("candidate_dream_manifest_path", ""))
            ),
            "placebo_coat_sha256": Path(str(pins.get("placebo_coat_path", ""))),
            "placebo_dream_sha256": Path(str(pins.get("placebo_dream_path", ""))),
            "placebo_manifest_sha256": Path(str(pins.get("placebo_manifest_path", ""))),
            "placebo_promotion_sha256": Path(str(pins.get("placebo_promotion_path", ""))),
        }
        for name, path in large.items():
            if not path.is_file() or sha256(path) != pins.get(name):
                raise ExperimentRefusal(f"pinned experiment input changed: {name}")
        source = Path(str(pins["source_body_path"])).resolve()
        living = Path(str(pins["living_body_path"])).resolve()
        mutable = Path(str(pins["mutable_clone_body_path"])).resolve()
        if source in {living, mutable}:
            raise ExperimentRefusal("frozen source aliases the living or mutable room body")
    return plan


def load_arm_key(experiment: Path, plan: dict[str, Any]) -> dict[str, Any]:
    path = experiment.resolve(strict=True) / "arm-key.json"
    if sha256(path) != plan["pins"].get("arm_key_sha256"):
        raise ExperimentRefusal("sealed four-arm key hash drift")
    key = _load_object(path)
    mapping = key.get("mapping")
    if (
        key.get("version") != 2
        or key.get("instrument") != INSTRUMENT
        or not isinstance(mapping, dict)
        or set(mapping) != {"A", "B", "C", "D"}
        or {arm.get("kind") for arm in mapping.values()} != set(protocol.ARM_KINDS)
    ):
        raise ExperimentRefusal("sealed four-arm key is malformed")
    pins = plan["pins"]
    expected = {
        "bare": (pins["retained_coat_path"], pins["retained_coat_sha256"], 0.0),
        "retained": (pins["retained_coat_path"], pins["retained_coat_sha256"], 1.0),
        "candidate": (pins["candidate_coat_path"], pins["candidate_coat_sha256"], 1.0),
        "placebo": (pins["placebo_coat_path"], pins["placebo_coat_sha256"], 1.0),
    }
    for label, arm in mapping.items():
        actual = (arm.get("coat"), arm.get("coat_sha256"), arm.get("scale"))
        if actual != expected[str(arm.get("kind"))]:
            raise ExperimentRefusal(f"sealed arm {label} differs from its pinned input")
    return key


def parse_swap_used_mib(output: str) -> float:
    try:
        return v1.parse_swap_used_mib(output)
    except v1.ExperimentRefusal as error:
        raise ExperimentRefusal(str(error)) from error


def _model_processes() -> list[dict[str, Any]]:
    return v1._model_processes()


def launch_gate(plan: dict[str, Any], port: int) -> dict[str, Any]:
    swap_output = subprocess.check_output(["sysctl", "vm.swapusage"], text=True, timeout=30)
    used = parse_swap_used_mib(swap_output)
    if used >= SWAP_LIMIT_MIB:
        raise ExperimentRefusal(
            f"swap is {used:.2f} MiB; private water requires less than {SWAP_LIMIT_MIB:.0f} MiB"
        )
    processes = _model_processes()
    if processes:
        shown = ", ".join(f"PID {row['pid']}: {row['command']}" for row in processes)
        raise ExperimentRefusal(
            f"an existing llama-server is visible through /tmp aliases: {shown}"
        )
    try:
        adaptive.ensure_port_free(port)
    except RuntimeError as error:
        raise ExperimentRefusal(str(error)) from error
    pins = plan["pins"]
    for label in ("living_body", "source_body"):
        path = Path(str(pins[f"{label}_path"]))
        if sha256(path) != pins[f"{label}_sha256"]:
            raise ExperimentRefusal(
                f"{label.replace('_', ' ')} changed before private-water launch"
            )
    return {"checked_at": utc_now(), "swap_used_mib": used, "model_processes": processes}


class ClaimTransferWater(v1.ClaimWaterServer):
    """The same one-coat private water process used by the v1 causal test."""


def cell_environment(
    home: Path,
    bridge: Path,
    speaker: str,
    seed: int,
    water_url: str,
    scale: float,
) -> dict[str, str]:
    environment = os.environ.copy()
    for name in [key for key in environment if key.startswith("FISH_")]:
        environment.pop(name, None)
    environment.update(
        {
            **adaptive.bench_home(home),
            "FISH_BRIDGE": str(bridge),
            "FISH_SPEAKER": speaker,
            "FISH_WATER_URL": water_url,
            "FISH_WATER_SEED": str(seed),
            "FISH_WATER_VOICE_LORA_SCALE": str(scale),
            "FISH_WATER_PREDICTION_LORA_SCALE": "0",
            "FISH_MAX_REPLY_TOKENS": str(MAX_REPLY_TOKENS),
            "FISH_WATER_PATIENCE_SECS": "180",
            "FISH_LEDGER": "off",
            "FISH_RETRIEVAL": "off",
            "FISH_VERIFIED": "off",
            "FISH_MIRROR": "off",
            "FISH_FIN": "off",
            "FISH_OCEAN": "off",
            "FISH_DEBUG": "1",
        }
    )
    return environment


def _coat_fingerprint(coat: Path) -> str:
    return v1._coat_fingerprint(coat)


def _checkpoint_path(experiment: Path, label: str, case_id: str) -> Path:
    return experiment / "rows" / label / f"{case_id}.json"


def _checkpoint_pins(
    experiment: Path,
    plan: dict[str, Any],
    key: dict[str, Any],
    label: str,
    case: dict[str, Any],
) -> dict[str, Any]:
    arm = key["mapping"][label]
    return {
        "protocol_sha256": sha256(experiment / "protocol.json"),
        "plan_sha256": plan["plan_sha256"],
        "arm_key_sha256": plan["pins"]["arm_key_sha256"],
        "case_sha256": case["case_sha256"],
        "label": label,
        "coat_sha256": arm["coat_sha256"],
        "scale": arm["scale"],
        "source_body_sha256": plan["pins"]["source_body_sha256"],
        "daemon_binary_sha256": plan["pins"]["daemon_binary_sha256"],
        "proposal_checker_sha256": plan["pins"]["typed_ast_probe_v2_sha256"],
    }


def _load_checkpoint(path: Path, expected: dict[str, Any]) -> dict[str, Any] | None:
    if not path.exists():
        return None
    value = _load_object(path)
    if value.get("pins") != expected:
        raise ExperimentRefusal(f"checkpoint pin drift: {path}")
    return value if value.get("status") == "complete" else None


def _exchange_row(body: Path, speaker: str) -> dict[str, Any] | None:
    return v1._exchange_row(body, speaker)


def _narration_flags(stderr: str) -> dict[str, Any]:
    return v1._narration_flags(stderr)


def _mechanical_reasons(
    row: dict[str, Any] | None,
    process: subprocess.CompletedProcess[str] | None,
    case: dict[str, Any],
    coat: Path,
    scale: float,
    narration: dict[str, Any],
    timed_out: bool,
) -> list[str]:
    reasons: list[str] = []
    if timed_out:
        reasons.append("daemon timeout")
    if process is None or process.returncode != 0:
        reasons.append("daemon returncode")
    if row is None:
        reasons.append("exactly one fresh exchange was not recorded")
        return reasons
    grammar = case["grammar"]
    # The daemon keeps an absent optional grammar provenance field as the
    # literal sentinel ``unconstrained`` in SQLite.  The sealed case retains
    # ``None`` because no task scope or generator was supplied on the wire;
    # compare against the daemon's persisted representation here.
    persisted_scope = grammar["voice_grammar_scope_sha256"] or UNCONSTRAINED
    persisted_generator = grammar["voice_grammar_generator_sha256"] or UNCONSTRAINED
    expected = {
        "you": case["prompt"],
        "voice_route": "lab",
        "speaking_scale": scale,
        "prediction_scale": scale,
        "prediction_coat": _coat_fingerprint(coat),
        "speaking_coat": _coat_fingerprint(coat) if scale > 0 else "bare",
        "lease_digest": "unleased",
        "override_refused": 0,
        "voice_grammar": grammar["name"],
        "voice_grammar_sha256": grammar["voice_grammar_sha256"],
        "voice_grammar_scope_sha256": persisted_scope,
        "voice_grammar_generator_sha256": persisted_generator,
        "kept": 0,
        "delta": None,
        "soul_leak": 0,
        "voice_leak": 0,
    }
    for name, wanted in expected.items():
        if row.get(name) != wanted:
            reasons.append(f"recorded {name} differs from the sealed cell")
    for flag in ("ledger_off", "mirror_off", "fin_off", "ocean_off", "fresh_chair"):
        if not narration.get(flag):
            reasons.append(f"missing isolation narration: {flag}")
    if narration.get("retrieved"):
        reasons.append("memory was retrieved")
    return reasons


def _grade_features(
    reply: str, grade: dict[str, Any], allowed_literals: list[int]
) -> dict[str, Any]:
    """Record canonical compiled leaves and police literals in the raw reply.

    Exact-grade expression objects are written with sorted JSON keys.  Their
    insertion order therefore cannot be part of a reproducible derived
    feature.  Keep the compiled leaves as a sorted multiset while preserving
    raw-reply literal order for the whole-reply checks.
    """
    compiled = v1._grade_features(grade, allowed_literals)
    raw = [int(match.group()) for match in INTEGER_TOKEN.finditer(reply)]
    allowed = set(allowed_literals)
    return {
        "integer_leaves": sorted(compiled["integer_leaves"]),
        "reply_integer_literals": raw,
        "negative_literals": [value for value in raw if value < 0],
        "stray_literals": [value for value in raw if value not in allowed],
    }


def _machine_proved(cell: dict[str, Any]) -> bool:
    """Keep a token-cap cut as a model failure even when its prefix parses."""
    return v1._machine_proved(cell)


def _control(case: dict[str, Any]) -> dict[str, Any]:
    grammar = case["grammar"]
    control: dict[str, Any] = {
        "temperature": 0.0,
        "voice_grammar": grammar["name"],
    }
    if grammar["scope"] is not None:
        control["voice_grammar_scope"] = grammar["scope"]
    return control


def run_cell(
    experiment: Path,
    plan: dict[str, Any],
    key: dict[str, Any],
    label: str,
    case: dict[str, Any],
    water_url: str,
    *,
    process_runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
) -> dict[str, Any]:
    pins = _checkpoint_pins(experiment, plan, key, label, case)
    checkpoint_path = _checkpoint_path(experiment, label, str(case["id"]))
    existing = _load_checkpoint(checkpoint_path, pins)
    if existing is not None:
        return existing
    arm = key["mapping"][label]
    coat = Path(str(arm["coat"]))
    scale = float(arm["scale"])
    source = Path(str(plan["pins"]["source_body_path"]))
    binary = Path(str(plan["pins"]["daemon_binary_path"]))
    scratch = experiment / "scratch"
    scratch.mkdir(exist_ok=True)
    speaker = f"claim-transfer-{sha256_text(key['nonce'] + label + case['id'])[:20]}"
    started = time.monotonic()
    process: subprocess.CompletedProcess[str] | None = None
    timed_out = False
    row: dict[str, Any] | None = None
    stderr = ""
    stdout = ""
    with tempfile.TemporaryDirectory(prefix=f"{case['id']}-{label}-", dir=scratch) as temporary:
        root = Path(temporary)
        home, bridge = adaptive.prepare_home(root, source, coat)
        (bridge / "control.json").write_text(canonical(_control(case)) + "\n", encoding="utf-8")
        environment = cell_environment(home, bridge, speaker, int(case["seed"]), water_url, scale)
        try:
            process = process_runner(
                [str(binary)],
                input=f"{case['prompt']}\n",
                capture_output=True,
                text=True,
                cwd=ROOT,
                env=environment,
                timeout=CELL_TIMEOUT,
            )
            stdout, stderr = str(process.stdout), str(process.stderr)
        except subprocess.TimeoutExpired as error:
            timed_out = True
            stdout = str(error.stdout or "")
            stderr = str(error.stderr or "")
        row = _exchange_row(home / "sediment.db", speaker)
    duration = round(time.monotonic() - started, 3)
    narration = _narration_flags(stderr)
    reasons = _mechanical_reasons(row, process, case, coat, scale, narration, timed_out)
    mechanically_valid = not reasons
    reply = str(row.get("i", "")) if row else ""
    if mechanically_valid:
        assert row is not None
        grade = exact_checker.judge(reply, dict(case["spec"]), int(row["id"]))
    else:
        grade = {
            "verdict": "void",
            "disposition": "held",
            "text": "mechanical cell failure; no exact claim was admitted",
            "expressions": {},
        }
    features = _grade_features(reply, grade, list(case["allowed_literals"]))
    log_root = experiment / "logs" / label
    log_root.mkdir(parents=True, exist_ok=True)
    stderr_path = log_root / f"{case['id']}.stderr"
    stdout_path = log_root / f"{case['id']}.stdout"
    stderr_path.write_text(stderr, encoding="utf-8")
    stdout_path.write_text(stdout, encoding="utf-8")
    result = {
        "status": "complete",
        "completed_at": utc_now(),
        "pins": pins,
        "cell": {
            "label": label,
            "case_id": case["id"],
            "task_id": case["task_id"],
            "kind": case["kind"],
            "parameters": case["parameters"],
            "prompt_condition": case["prompt_condition"],
            "grammar_condition": case["grammar_condition"],
            "primary_endpoint": case["primary_endpoint"],
            "seed": case["seed"],
            "prompt_sha256": case["prompt_sha256"],
            "reply": reply,
            "reply_sha256": sha256_text(reply),
            "duration_seconds": duration,
            "timed_out": timed_out,
            "returncode": process.returncode if process is not None else None,
            "mechanically_valid": mechanically_valid,
            "mechanical_reasons": reasons,
            "narration": narration,
            "record": row,
            "grade": grade,
            "features": features,
            "stderr_path": str(stderr_path.relative_to(experiment)),
            "stderr_sha256": sha256(stderr_path),
            "stdout_path": str(stdout_path.relative_to(experiment)),
            "stdout_sha256": sha256(stdout_path),
        },
    }
    _atomic_json(checkpoint_path, result)
    for artifact in (stderr_path, stdout_path, checkpoint_path):
        artifact.chmod(0o444)
    for name in ("living_body", "source_body"):
        path = Path(str(plan["pins"][f"{name}_path"]))
        if sha256(path) != plan["pins"][f"{name}_sha256"]:
            raise ExperimentRefusal(f"{name.replace('_', ' ')} changed during a private cell")
    return result


def _cases(plan: dict[str, Any]) -> list[dict[str, Any]]:
    return [dict(case) for case in plan["design"]["cases"]]


def _present(experiment: Path, plan: dict[str, Any], key: dict[str, Any]) -> int:
    return sum(
        _load_checkpoint(
            _checkpoint_path(experiment, label, str(case["id"])),
            _checkpoint_pins(experiment, plan, key, label, case),
        )
        is not None
        for case in _cases(plan)
        for label in ("A", "B", "C", "D")
    )


def run(
    experiment: Path,
    *,
    port: int = PORT,
    jobs: int = PARALLEL,
    max_blocks: int | None = None,
) -> dict[str, Any]:
    """Run or resume whole sealed blocks; default continues through all cells."""
    experiment = experiment.resolve(strict=True)
    if (
        _run_seal_path(experiment).exists()
        or (experiment / "audit-bundle.json").exists()
        or (experiment / "pre-unblind.json").exists()
    ):
        raise ExperimentRefusal("inference evidence is frozen; run cannot resume")
    plan = load_protocol(experiment)
    if port != plan["runtime"]["water_port"] or jobs != plan["runtime"]["parallel_requests"]:
        raise ExperimentRefusal("runtime port or parallelism differs from the frozen protocol")
    if max_blocks is not None and max_blocks < 1:
        raise ExperimentRefusal("max-blocks must be positive")
    key = load_arm_key(experiment, plan)
    cases = _cases(plan)
    binary = Path(str(plan["pins"]["server"]["path"]))
    base = Path(str(plan["pins"]["base_path"]))
    finished_blocks = 0
    for block in sorted({int(case["block"]) for case in cases}):
        block_cases = [case for case in cases if int(case["block"]) == block]
        block_pending = False
        for label in plan["block_orders"][str(block)]:
            pending = [
                case
                for case in block_cases
                if _load_checkpoint(
                    _checkpoint_path(experiment, label, str(case["id"])),
                    _checkpoint_pins(experiment, plan, key, label, case),
                )
                is None
            ]
            if not pending:
                continue
            block_pending = True
            gate = launch_gate(plan, port)
            arm = key["mapping"][label]
            coat = Path(str(arm["coat"]))
            water_log = experiment / "water" / f"block-{block + 1:02d}-{label}.log"
            with ClaimTransferWater(
                binary,
                base,
                coat,
                port,
                CONTEXT,
                max(1, jobs),
                water_log,
                warm_scale=float(arm["scale"]),
            ) as water:
                with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, jobs)) as pool:
                    futures = [
                        pool.submit(run_cell, experiment, plan, key, label, case, water.url)
                        for case in pending
                    ]
                    for future in concurrent.futures.as_completed(futures):
                        result = future.result()
                        cell = result["cell"]
                        print(
                            f"block {block + 1:02d} arm {label} case {cell['case_id']} "
                            f"{cell['grade']['verdict']} {cell['duration_seconds']:.1f}s",
                            flush=True,
                        )
            state = _load_object(experiment / "state.json")
            state["status"] = "running"
            state["updated_at"] = utc_now()
            state["last_launch_gate"] = gate
            state["cells"]["present"] = _present(experiment, plan, key)
            _atomic_json(experiment / "state.json", state)
        if block_pending:
            finished_blocks += 1
            if max_blocks is not None and finished_blocks >= max_blocks:
                break
    present = _present(experiment, plan, key)
    expected = len(cases) * 4
    state = _load_object(experiment / "state.json")
    state["cells"] = {"present": present, "expected": expected}
    state["status"] = "awaiting-independent-audit" if present == expected else "running"
    state["updated_at"] = utc_now()
    _atomic_json(experiment / "state.json", state)
    return {
        "experiment": str(experiment),
        "cells": state["cells"],
        "status": state["status"],
        "living_body_unchanged": (
            sha256(Path(str(plan["pins"]["living_body_path"])))
            == plan["pins"]["living_body_sha256"]
        ),
        "arm_blind": True,
        "automatic_promotion": False,
    }


def _bounded_text(path: Path, cap: int = MAX_RECORD_BYTES) -> str:
    if path.is_symlink() or not path.is_file() or path.stat().st_size > cap:
        raise ExperimentRefusal(f"missing, linked, or oversized text artifact: {path}")
    return path.read_text(encoding="utf-8")


def _validated_checkpoint(
    experiment: Path,
    plan: dict[str, Any],
    label: str,
    case: dict[str, Any],
    *,
    rerun_exact: bool = True,
) -> dict[str, Any]:
    """Recompute a completed cell without consulting the secret arm mapping."""
    path = _checkpoint_path(experiment, label, str(case["id"]))
    record = _load_object(path)
    pins = record.get("pins")
    cell = record.get("cell")
    if record.get("status") != "complete" or not isinstance(pins, dict):
        raise ExperimentRefusal(f"incomplete checkpoint: {path}")
    if not isinstance(cell, dict):
        raise ExperimentRefusal(f"checkpoint has no cell: {path}")
    fixed_pins = {
        "protocol_sha256": sha256(experiment / "protocol.json"),
        "plan_sha256": plan["plan_sha256"],
        "arm_key_sha256": plan["pins"]["arm_key_sha256"],
        "case_sha256": case["case_sha256"],
        "label": label,
        "source_body_sha256": plan["pins"]["source_body_sha256"],
        "daemon_binary_sha256": plan["pins"]["daemon_binary_sha256"],
        "proposal_checker_sha256": plan["pins"]["typed_ast_probe_v2_sha256"],
    }
    for name, expected in fixed_pins.items():
        if pins.get(name) != expected:
            raise ExperimentRefusal(f"checkpoint pin drift ({name}): {path}")
    allowed_routes = {
        (plan["pins"]["retained_coat_sha256"], 0.0),
        (plan["pins"]["retained_coat_sha256"], 1.0),
        (plan["pins"]["candidate_coat_sha256"], 1.0),
        (plan["pins"]["placebo_coat_sha256"], 1.0),
    }
    route = (pins.get("coat_sha256"), pins.get("scale"))
    if route not in allowed_routes:
        raise ExperimentRefusal(f"checkpoint names an impossible blinded route: {path}")
    expected_cell = {
        "label": label,
        "case_id": case["id"],
        "task_id": case["task_id"],
        "kind": case["kind"],
        "parameters": case["parameters"],
        "prompt_condition": case["prompt_condition"],
        "grammar_condition": case["grammar_condition"],
        "primary_endpoint": case["primary_endpoint"],
        "seed": case["seed"],
        "prompt_sha256": case["prompt_sha256"],
    }
    for name, expected in expected_cell.items():
        if cell.get(name) != expected:
            raise ExperimentRefusal(f"checkpoint cell drift ({name}): {path}")
    reply = cell.get("reply")
    if not isinstance(reply, str) or cell.get("reply_sha256") != sha256_text(reply):
        raise ExperimentRefusal(f"checkpoint reply hash drift: {path}")
    stderr_path = _confined(
        experiment / str(cell.get("stderr_path", "")), experiment, "stderr artifact"
    )
    stdout_path = _confined(
        experiment / str(cell.get("stdout_path", "")), experiment, "stdout artifact"
    )
    if sha256(stderr_path) != cell.get("stderr_sha256") or sha256(stdout_path) != cell.get(
        "stdout_sha256"
    ):
        raise ExperimentRefusal(f"checkpoint log hash drift: {path}")
    stderr = _bounded_text(stderr_path)
    narration = _narration_flags(stderr)
    if narration != cell.get("narration"):
        raise ExperimentRefusal(f"checkpoint narration drift: {path}")
    mechanically_valid = cell.get("mechanically_valid") is True
    reasons = cell.get("mechanical_reasons")
    if not isinstance(reasons, list) or mechanically_valid == bool(reasons):
        raise ExperimentRefusal(f"checkpoint mechanical disposition drift: {path}")
    row = cell.get("record")
    if row is not None and not isinstance(row, dict):
        raise ExperimentRefusal(f"checkpoint exchange row is malformed: {path}")
    returncode = cell.get("returncode")
    process: subprocess.CompletedProcess[str] | None = None
    if type(returncode) is int:
        process = subprocess.CompletedProcess(["fish-daemon"], returncode, "", stderr)
    coat_by_sha = {
        plan["pins"]["retained_coat_sha256"]: Path(plan["pins"]["retained_coat_path"]),
        plan["pins"]["candidate_coat_sha256"]: Path(plan["pins"]["candidate_coat_path"]),
        plan["pins"]["placebo_coat_sha256"]: Path(plan["pins"]["placebo_coat_path"]),
    }
    coat = coat_by_sha.get(pins.get("coat_sha256"))
    if coat is None:
        raise ExperimentRefusal(f"checkpoint coat cannot be recovered: {path}")
    recomputed_reasons = _mechanical_reasons(
        row,
        process,
        case,
        coat,
        float(pins["scale"]),
        narration,
        cell.get("timed_out") is True,
    )
    if reasons != recomputed_reasons:
        raise ExperimentRefusal(f"checkpoint mechanical reasons do not recompute: {path}")
    if mechanically_valid:
        if not isinstance(row, dict) or type(row.get("id")) is not int:
            raise ExperimentRefusal(f"valid checkpoint lacks its exact exchange: {path}")
        if rerun_exact:
            grade = exact_checker.judge(reply, dict(case["spec"]), int(row["id"]))
        else:
            stored_grade = cell.get("grade")
            if not isinstance(stored_grade, dict):
                raise ExperimentRefusal(f"checkpoint exact grade is malformed: {path}")
            grade = stored_grade
    else:
        grade = {
            "verdict": "void",
            "disposition": "held",
            "text": "mechanical cell failure; no exact claim was admitted",
            "expressions": {},
        }
    if canonical(grade) != canonical(cell.get("grade")):
        raise ExperimentRefusal(f"checkpoint exact grade does not recompute: {path}")
    features = _grade_features(reply, grade, list(case["allowed_literals"]))
    if canonical(features) != canonical(cell.get("features")):
        raise ExperimentRefusal(f"checkpoint feature record does not recompute: {path}")
    return record


def _all_complete(experiment: Path, plan: dict[str, Any], key: dict[str, Any]) -> bool:
    return all(
        _load_checkpoint(
            _checkpoint_path(experiment, label, str(case["id"])),
            _checkpoint_pins(experiment, plan, key, label, case),
        )
        is not None
        for case in _cases(plan)
        for label in ("A", "B", "C", "D")
    )


def _audit_id(nonce: str, label: str, case_id: str) -> str:
    return sha256_text(f"{INSTRUMENT}\0whole-reply-audit\0{nonce}\0{label}\0{case_id}")


def _run_seal_path(experiment: Path) -> Path:
    return experiment / "validated-run.json"


def _seal_validated_run(
    experiment: Path, plan: dict[str, Any], key: dict[str, Any]
) -> tuple[dict[str, Any], dict[tuple[str, str], dict[str, Any]]]:
    """Validate recorded mechanics and exact-checker artifacts, then pin their bytes."""
    path = _run_seal_path(experiment)
    if path.exists():
        return _load_run_seal(experiment, plan)
    records: dict[tuple[str, str], dict[str, Any]] = {}
    pins: list[dict[str, Any]] = []
    for case in _cases(plan):
        for label in ("A", "B", "C", "D"):
            # The pinned exact checker already ran synchronously in run_cell.
            # Recheck all surrounding evidence without paying a second kernel cold start.
            checkpoint = _validated_checkpoint(experiment, plan, label, case, rerun_exact=False)
            if checkpoint["pins"] != _checkpoint_pins(experiment, plan, key, label, case):
                raise ExperimentRefusal(
                    "validated checkpoint does not belong to its sealed arm and task"
                )
            cell = checkpoint["cell"]
            checkpoint_path = _checkpoint_path(experiment, label, str(case["id"]))
            records[(label, str(case["id"]))] = checkpoint
            pins.append(
                {
                    "label": label,
                    "case_id": case["id"],
                    "path": str(checkpoint_path.relative_to(experiment)),
                    "sha256": sha256(checkpoint_path),
                    "reply_sha256": cell["reply_sha256"],
                    "machine_proved": _machine_proved(cell),
                }
            )
    pins.sort(key=lambda row: (row["case_id"], row["label"]))
    seal: dict[str, Any] = {
        "version": 2,
        "instrument": INSTRUMENT,
        "created_at": utc_now(),
        "protocol_sha256": sha256(experiment / "protocol.json"),
        "arm_key_sha256": plan["pins"]["arm_key_sha256"],
        "checkpoint_count": len(pins),
        "eligible_count": sum(row["machine_proved"] for row in pins),
        "checkpoints": pins,
    }
    seal["seal_sha256"] = sha256_text(canonical(seal))
    _write_once(path, seal)
    return seal, records


def _load_run_seal(
    experiment: Path, plan: dict[str, Any]
) -> tuple[dict[str, Any], dict[tuple[str, str], dict[str, Any]]]:
    """Load only byte-identical cells previously validated before review."""
    path = _run_seal_path(experiment)
    seal = _load_object(path, cap=MAX_AUDIT_BYTES)
    body = {name: value for name, value in seal.items() if name != "seal_sha256"}
    rows = seal.get("checkpoints")
    if (
        set(seal) != RUN_SEAL_FIELDS
        or seal.get("version") != 2
        or seal.get("instrument") != INSTRUMENT
        or seal.get("protocol_sha256") != sha256(experiment / "protocol.json")
        or seal.get("arm_key_sha256") != plan["pins"]["arm_key_sha256"]
        or not isinstance(seal.get("created_at"), str)
        or not str(seal["created_at"]).strip()
        or seal.get("seal_sha256") != sha256_text(canonical(body))
        or not isinstance(rows, list)
        or seal.get("checkpoint_count") != len(rows)
    ):
        raise ExperimentRefusal("validated run seal drift")
    cases = {str(case["id"]): case for case in _cases(plan)}
    expected = {(label, case_id) for case_id in cases for label in ("A", "B", "C", "D")}
    records: dict[tuple[str, str], dict[str, Any]] = {}
    for row in rows:
        if not isinstance(row, dict) or set(row) != RUN_SEAL_ENTRY_FIELDS:
            raise ExperimentRefusal("validated run seal entry is malformed")
        label, case_id = row.get("label"), row.get("case_id")
        identity = (str(label), str(case_id))
        case = cases.get(str(case_id))
        if label not in {"A", "B", "C", "D"} or case is None or identity in records:
            raise ExperimentRefusal("validated run seal contains a foreign or repeated cell")
        checkpoint_path = _checkpoint_path(experiment, str(label), str(case_id))
        expected_path = str(checkpoint_path.relative_to(experiment))
        if (
            row.get("path") != expected_path
            or not isinstance(row.get("sha256"), str)
            or HEX64.fullmatch(str(row["sha256"])) is None
            or sha256(checkpoint_path) != row["sha256"]
        ):
            raise ExperimentRefusal("checkpoint bytes changed after exact validation")
        checkpoint = _validated_checkpoint(experiment, plan, str(label), case, rerun_exact=False)
        cell = checkpoint.get("cell")
        checkpoint_pins = checkpoint.get("pins")
        if (
            checkpoint.get("status") != "complete"
            or not isinstance(cell, dict)
            or not isinstance(checkpoint_pins, dict)
            or checkpoint_pins.get("label") != label
            or cell.get("case_id") != case_id
            or cell.get("reply_sha256") != row.get("reply_sha256")
            or _machine_proved(cell) is not row.get("machine_proved")
        ):
            raise ExperimentRefusal("checkpoint meaning changed after exact validation")
        records[identity] = checkpoint
    if set(records) != expected or seal.get("eligible_count") != sum(
        row["machine_proved"] for row in rows
    ):
        raise ExperimentRefusal("validated run seal is incomplete")
    return seal, records


def _eligible_audit_entries(
    experiment: Path,
    plan: dict[str, Any],
    key: dict[str, Any],
    records: dict[tuple[str, str], dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for case in _cases(plan):
        for label in ("A", "B", "C", "D"):
            checkpoint = (
                records[(label, str(case["id"]))]
                if records is not None
                else _validated_checkpoint(experiment, plan, label, case)
            )
            expected_pins = _checkpoint_pins(experiment, plan, key, label, case)
            if checkpoint["pins"] != expected_pins:
                raise ExperimentRefusal(
                    "blinded checkpoint does not belong to its sealed arm and task"
                )
            cell = checkpoint["cell"]
            if not _machine_proved(cell):
                continue
            entry: dict[str, Any] = {
                "audit_id": _audit_id(str(key["nonce"]), label, str(case["id"])),
                "case_id": case["id"],
                "task_id": case["task_id"],
                "kind": case["kind"],
                "prompt_condition": case["prompt_condition"],
                "grammar_condition": case["grammar_condition"],
                "primary_endpoint": case["primary_endpoint"],
                "prompt": case["prompt"],
                "prompt_sha256": case["prompt_sha256"],
                "required": case["spec"]["required"],
                "canonical_program": v1.canonical_program(case["kind"], case["parameters"]),
                "allowed_literals": case["allowed_literals"],
                "reply": cell["reply"],
                "reply_sha256": cell["reply_sha256"],
                "exact_grade": cell["grade"],
                "exact_grade_sha256": sha256_text(canonical(cell["grade"])),
                "features": cell["features"],
            }
            entry["entry_sha256"] = sha256_text(canonical(entry))
            entries.append(entry)
    entries.sort(key=lambda row: sha256_text(f"audit-order\0{row['audit_id']}"))
    return entries


def _audit_bundle_path(experiment: Path) -> Path:
    return experiment / "audit-bundle.json"


def _audit_path(experiment: Path) -> Path:
    return experiment / "external-audit.json"


def _audit_blinding() -> str:
    return "A/B/C/D labels, coat identities, scales, checkpoint paths, and arm mapping omitted"


def _audit_rubric() -> dict[str, Any]:
    return {
        "allowed_decisions": ["accepted", "vetoed"],
        "accepted": (
            "The whole reply is exactly the requested JSON claim; all required facts and "
            "the operation graph address the task; no answer injection, unrelated claim, "
            "prose, instruction, identity assertion, or hidden leakage appears."
        ),
        "vetoed": "Any violation of the accepted rule, with a concrete reason.",
        "authority": (
            "The reviewer may veto a machine proof and may never upgrade a refusal, "
            "refutation, underdetermined result, timeout, cap cut, or invalid cell."
        ),
    }


def _validate_audit_entry(
    entry: dict[str, Any], case: dict[str, Any], plan: dict[str, Any], path: Path
) -> None:
    entry_body = {name: value for name, value in entry.items() if name != "entry_sha256"}
    audit_id = entry.get("audit_id")
    exact_grade = entry.get("exact_grade")
    reply = entry.get("reply")
    fixed = {
        "case_id": case["id"],
        "task_id": case["task_id"],
        "kind": case["kind"],
        "prompt_condition": case["prompt_condition"],
        "grammar_condition": case["grammar_condition"],
        "primary_endpoint": case["primary_endpoint"],
        "prompt": case["prompt"],
        "prompt_sha256": case["prompt_sha256"],
        "required": case["spec"]["required"],
        "canonical_program": v1.canonical_program(case["kind"], case["parameters"]),
        "allowed_literals": case["allowed_literals"],
    }
    if set(entry) != AUDIT_ENTRY_FIELDS or any(
        entry.get(name) != expected for name, expected in fixed.items()
    ):
        raise ExperimentRefusal(f"blinded audit entry schema or task drift: {path}")
    if (
        not isinstance(audit_id, str)
        or HEX64.fullmatch(audit_id) is None
        or not isinstance(reply, str)
        or len(reply.encode("utf-8")) > MAX_RECORD_BYTES
        or entry.get("entry_sha256") != sha256_text(canonical(entry_body))
        or entry.get("reply_sha256") != sha256_text(reply)
        or not isinstance(exact_grade, dict)
        or exact_grade.get("verdict") != "proved"
        or entry.get("exact_grade_sha256") != sha256_text(canonical(exact_grade))
    ):
        raise ExperimentRefusal(f"blinded audit entry identity drift: {path}")
    try:
        programs, expanded = exact_checker.compile_proposal(reply, dict(case["spec"]))
    except exact_checker.ProposalError as error:
        raise ExperimentRefusal(f"blinded audit proof no longer parses: {path}") from error
    expected_results = {str(fact["name"]): str(fact["expected"]) for fact in case["spec"]["facts"]}
    if (
        canonical(exact_grade.get("expressions")) != canonical(programs)
        or exact_grade.get("expanded_expressions") != expanded
        or exact_grade.get("results") != expected_results
        or exact_grade.get("spec_sha256") != case["spec"]["spec_sha256"]
        or exact_grade.get("kind") != case["kind"]
        or exact_grade.get("parameters") != case["parameters"]
        or exact_grade.get("required") != case["spec"]["required"]
        or exact_grade.get("proposal_checker_sha256") != plan["pins"]["typed_ast_probe_v2_sha256"]
        or entry.get("features")
        != _grade_features(reply, exact_grade, list(case["allowed_literals"]))
    ):
        raise ExperimentRefusal(f"blinded audit proof or feature drift: {path}")


def _load_audit_bundle(experiment: Path, plan: dict[str, Any]) -> dict[str, Any]:
    path = _audit_bundle_path(experiment)
    bundle = _load_object(path, cap=MAX_AUDIT_BYTES)
    body = {name: value for name, value in bundle.items() if name != "bundle_sha256"}
    if (
        set(bundle) != AUDIT_BUNDLE_FIELDS
        or bundle.get("version") != 2
        or bundle.get("instrument") != INSTRUMENT
        or bundle.get("protocol_sha256") != sha256(experiment / "protocol.json")
        or not isinstance(bundle.get("created_at"), str)
        or not str(bundle["created_at"]).strip()
        or bundle.get("blinding") != _audit_blinding()
        or bundle.get("rubric") != _audit_rubric()
        or bundle.get("bundle_sha256") != sha256_text(canonical(body))
    ):
        raise ExperimentRefusal(f"blinded audit bundle drift: {path}")
    entries = bundle.get("entries")
    if not isinstance(entries, list) or bundle.get("entry_count") != len(entries):
        raise ExperimentRefusal(f"blinded audit bundle count drift: {path}")
    cases = {str(case["id"]): case for case in _cases(plan)}
    ids: set[str] = set()
    for entry in entries:
        if not isinstance(entry, dict):
            raise ExperimentRefusal(f"blinded audit entry is malformed: {path}")
        case = cases.get(str(entry.get("case_id")))
        if case is None:
            raise ExperimentRefusal(f"blinded audit entry names a foreign task: {path}")
        _validate_audit_entry(entry, case, plan, path)
        audit_id = str(entry["audit_id"])
        if audit_id in ids:
            raise ExperimentRefusal(f"blinded audit entry id repeats: {path}")
        ids.add(audit_id)
    return bundle


def _verify_bundle_coverage(bundle: dict[str, Any], seal: dict[str, Any]) -> None:
    eligible: dict[tuple[str, str], int] = {}
    for row in seal["checkpoints"]:
        if row["machine_proved"]:
            identity = (str(row["case_id"]), str(row["reply_sha256"]))
            eligible[identity] = eligible.get(identity, 0) + 1
    bundled: dict[tuple[str, str], int] = {}
    for entry in bundle["entries"]:
        identity = (str(entry["case_id"]), str(entry["reply_sha256"]))
        bundled[identity] = bundled.get(identity, 0) + 1
    if bundled != eligible or bundle["entry_count"] != seal["eligible_count"]:
        raise ExperimentRefusal("blinded audit bundle does not cover every machine proof")


def create_audit_bundle(experiment: Path) -> dict[str, Any]:
    """Freeze every machine proof without exposing label, coat, scale, or arm."""
    experiment = experiment.resolve(strict=True)
    plan = load_protocol(experiment)
    key = load_arm_key(experiment, plan)
    if not _all_complete(experiment, plan, key):
        raise ExperimentRefusal("inference is incomplete; an audit cannot be drawn")
    _seal, records = _seal_validated_run(experiment, plan, key)
    expected_entries = _eligible_audit_entries(experiment, plan, key, records)
    path = _audit_bundle_path(experiment)
    if path.exists():
        existing_bundle = _load_audit_bundle(experiment, plan)
        if canonical(existing_bundle["entries"]) != canonical(expected_entries):
            raise ExperimentRefusal("existing audit bundle differs from the frozen cells")
        _verify_bundle_coverage(existing_bundle, _seal)
        return existing_bundle
    bundle: dict[str, Any] = {
        "version": 2,
        "instrument": INSTRUMENT,
        "created_at": utc_now(),
        "protocol_sha256": sha256(experiment / "protocol.json"),
        "blinding": _audit_blinding(),
        "rubric": _audit_rubric(),
        "entry_count": len(expected_entries),
        "entries": expected_entries,
    }
    bundle["bundle_sha256"] = sha256_text(canonical(bundle))
    _write_once(path, bundle)
    _verify_bundle_coverage(bundle, _seal)
    state = _load_object(experiment / "state.json")
    state["audit"] = "awaiting-independent-review"
    state["updated_at"] = utc_now()
    _atomic_json(experiment / "state.json", state)
    return bundle


def _normalize_reviewer(raw: object) -> dict[str, Any]:
    if not isinstance(raw, dict) or set(raw) != AUDIT_REVIEWER_FIELDS:
        raise ExperimentRefusal("audit must identify one independent whole-reply reviewer")
    name, session = raw.get("name"), raw.get("session")
    if (
        not isinstance(name, str)
        or not name.strip()
        or len(name) > 200
        or not isinstance(session, str)
        or not session.strip()
        or len(session) > 200
        or raw.get("independent") is not True
        or raw.get("whole_reply_review") is not True
    ):
        raise ExperimentRefusal("audit must identify one independent whole-reply reviewer")
    return {
        "name": name.strip(),
        "session": session.strip(),
        "independent": True,
        "whole_reply_review": True,
    }


def _normalize_audit_decisions(
    bundle: dict[str, Any], raw: object, *, frozen: bool = False
) -> list[dict[str, Any]]:
    entries = {str(row["audit_id"]): row for row in bundle["entries"]}
    if not isinstance(raw, list) or len(raw) != len(entries):
        raise ExperimentRefusal("external audit must decide every and only eligible reply")
    normalized: list[dict[str, Any]] = []
    seen: set[str] = set()
    for row in raw:
        keys = set(row) if isinstance(row, dict) else set()
        required = AUDIT_DECISION_FIELDS - {"rubric_codes"}
        if (
            not isinstance(row, dict)
            or not required <= keys
            or keys - AUDIT_DECISION_FIELDS
            or (frozen and keys != AUDIT_DECISION_FIELDS)
        ):
            raise ExperimentRefusal("external audit decision has unbounded or unknown fields")
        audit_id = row.get("audit_id")
        if not isinstance(audit_id, str) or audit_id not in entries or audit_id in seen:
            raise ExperimentRefusal("external audit contains a missing, foreign, or repeated id")
        if row.get("reply_sha256") != entries[audit_id]["reply_sha256"]:
            raise ExperimentRefusal("external audit decision is attached to another reply")
        decision = row.get("decision")
        reason = row.get("reason")
        codes = row.get("rubric_codes", [])
        if decision not in {"accepted", "vetoed"}:
            raise ExperimentRefusal("external review can only accept or veto a machine proof")
        if not isinstance(reason, str) or not reason.strip() or len(reason) > MAX_AUDIT_REASON:
            raise ExperimentRefusal("external audit reason is missing or oversized")
        if (
            not isinstance(codes, list)
            or len(codes) > 12
            or any(
                not isinstance(code, str) or not code.strip() or len(code) > 80 for code in codes
            )
        ):
            raise ExperimentRefusal("external audit rubric codes are malformed")
        normalized.append(
            {
                "audit_id": audit_id,
                "reply_sha256": row["reply_sha256"],
                "decision": decision,
                "reason": reason.strip(),
                "rubric_codes": [code.strip() for code in codes],
            }
        )
        seen.add(audit_id)
    if seen != set(entries):
        raise ExperimentRefusal("external audit omitted an eligible whole reply")
    normalized.sort(key=lambda row: row["audit_id"])
    return normalized


def import_audit(experiment: Path, source: Path) -> dict[str, Any]:
    """Import one complete independent veto audit; never infer reviewer decisions."""
    experiment = experiment.resolve(strict=True)
    plan = load_protocol(experiment)
    seal, _records = _load_run_seal(experiment, plan)
    bundle = _load_audit_bundle(experiment, plan)
    _verify_bundle_coverage(bundle, seal)
    source = source.resolve(strict=True)
    raw = _load_object(source, cap=MAX_AUDIT_BYTES)
    if (
        set(raw) != AUDIT_SOURCE_FIELDS
        or raw.get("version") != 2
        or raw.get("instrument") != INSTRUMENT
        or raw.get("bundle_sha256") != bundle["bundle_sha256"]
    ):
        raise ExperimentRefusal("external audit does not bind the frozen blinded bundle")
    reviewer = _normalize_reviewer(raw.get("reviewer"))
    normalized = _normalize_audit_decisions(bundle, raw.get("decisions"))
    destination = _audit_path(experiment)
    source_sha = sha256(source)
    if destination.exists():
        existing = _load_audit(experiment, plan)
        if existing.get("source_sha256") != source_sha:
            raise ExperimentRefusal("a different external audit is already frozen")
        return existing
    audit: dict[str, Any] = {
        "version": 2,
        "instrument": INSTRUMENT,
        "imported_at": utc_now(),
        "bundle_sha256": bundle["bundle_sha256"],
        "source_path": str(source),
        "source_sha256": source_sha,
        "reviewer": reviewer,
        "decision_count": len(normalized),
        "decisions": normalized,
    }
    audit["audit_sha256"] = sha256_text(canonical(audit))
    _write_once(destination, audit)
    state = _load_object(experiment / "state.json")
    state["audit"] = "complete"
    state["updated_at"] = utc_now()
    _atomic_json(experiment / "state.json", state)
    return audit


def _load_audit(experiment: Path, plan: dict[str, Any]) -> dict[str, Any]:
    bundle = _load_audit_bundle(experiment, plan)
    audit = _load_object(_audit_path(experiment), cap=MAX_AUDIT_BYTES)
    body = {name: value for name, value in audit.items() if name != "audit_sha256"}
    decisions = audit.get("decisions")
    if (
        set(audit) != AUDIT_RECORD_FIELDS
        or audit.get("version") != 2
        or audit.get("instrument") != INSTRUMENT
        or audit.get("bundle_sha256") != bundle["bundle_sha256"]
        or audit.get("audit_sha256") != sha256_text(canonical(body))
        or not isinstance(decisions, list)
        or audit.get("decision_count") != len(decisions)
        or not isinstance(audit.get("imported_at"), str)
        or not str(audit["imported_at"]).strip()
        or not isinstance(audit.get("source_path"), str)
        or not str(audit["source_path"]).strip()
        or not isinstance(audit.get("source_sha256"), str)
        or HEX64.fullmatch(str(audit["source_sha256"])) is None
    ):
        raise ExperimentRefusal("frozen external audit drift")
    reviewer = _normalize_reviewer(audit.get("reviewer"))
    normalized = _normalize_audit_decisions(bundle, decisions, frozen=True)
    if reviewer != audit["reviewer"] or normalized != decisions:
        raise ExperimentRefusal("frozen external audit is not canonical")
    return audit


def freeze_evidence(experiment: Path, plan: dict[str, Any]) -> dict[str, Any]:
    """Hash every cell and review before the secret arm key can enter analysis."""
    seal, _records = _load_run_seal(experiment, plan)
    bundle = _load_audit_bundle(experiment, plan)
    audit = _load_audit(experiment, plan)
    checkpoint_pins = [
        {
            "label": row["label"],
            "case_id": row["case_id"],
            "path": row["path"],
            "sha256": row["sha256"],
        }
        for row in seal["checkpoints"]
    ]
    _verify_bundle_coverage(bundle, seal)
    checkpoint_pins.sort(key=lambda row: (row["case_id"], row["label"]))
    fixed: dict[str, Any] = {
        "version": 2,
        "instrument": INSTRUMENT,
        "protocol_sha256": sha256(experiment / "protocol.json"),
        "validated_run_file_sha256": sha256(_run_seal_path(experiment)),
        "validated_run_sha256": seal["seal_sha256"],
        "bundle_file_sha256": sha256(_audit_bundle_path(experiment)),
        "bundle_sha256": bundle["bundle_sha256"],
        "audit_file_sha256": sha256(_audit_path(experiment)),
        "audit_sha256": audit["audit_sha256"],
        "checkpoint_count": len(checkpoint_pins),
        "checkpoints": checkpoint_pins,
        "living_body_sha256": sha256(Path(str(plan["pins"]["living_body_path"]))),
        "source_body_sha256": sha256(Path(str(plan["pins"]["source_body_path"]))),
    }
    if fixed["living_body_sha256"] != plan["pins"]["living_body_sha256"]:
        raise ExperimentRefusal("living body changed before the evidence freeze")
    if fixed["source_body_sha256"] != plan["pins"]["source_body_sha256"]:
        raise ExperimentRefusal("frozen source changed before the evidence freeze")
    path = experiment / "pre-unblind.json"
    if path.exists():
        existing_frozen = _load_object(path, cap=MAX_AUDIT_BYTES)
        frozen_fixed = {
            name: value
            for name, value in existing_frozen.items()
            if name not in {"frozen_at", "evidence_sha256"}
        }
        if canonical(frozen_fixed) != canonical(fixed):
            raise ExperimentRefusal("pre-unblind evidence changed after it was frozen")
        body = {name: value for name, value in existing_frozen.items() if name != "evidence_sha256"}
        if existing_frozen.get("evidence_sha256") != sha256_text(canonical(body)):
            raise ExperimentRefusal("pre-unblind evidence hash drift")
        return existing_frozen
    frozen: dict[str, Any] = {**fixed, "frozen_at": utc_now()}
    frozen["evidence_sha256"] = sha256_text(canonical(frozen))
    return _write_once(path, frozen)


def _outcomes(
    experiment: Path,
    plan: dict[str, Any],
    key: dict[str, Any],
    audit: dict[str, Any],
    records: dict[tuple[str, str], dict[str, Any]] | None = None,
) -> tuple[dict[str, dict[str, dict[str, Any]]], list[dict[str, Any]]]:
    decisions = {row["audit_id"]: row for row in audit["decisions"]}
    arms: dict[str, dict[str, dict[str, Any]]] = {kind: {} for kind in protocol.ARM_KINDS}
    violations: list[dict[str, Any]] = []
    for case in _cases(plan):
        for label in ("A", "B", "C", "D"):
            checkpoint = (
                records[(label, str(case["id"]))]
                if records is not None
                else _validated_checkpoint(experiment, plan, label, case)
            )
            expected_pins = _checkpoint_pins(experiment, plan, key, label, case)
            if checkpoint["pins"] != expected_pins:
                raise ExperimentRefusal(
                    "unblinded checkpoint does not belong to its sealed arm and task"
                )
            cell = checkpoint["cell"]
            arm = str(key["mapping"][label]["kind"])
            exact = _machine_proved(cell)
            audit_row: dict[str, Any] | None = None
            if exact:
                audit_id = _audit_id(str(key["nonce"]), label, str(case["id"]))
                audit_row = decisions.get(audit_id)
                if audit_row is None or audit_row["reply_sha256"] != cell["reply_sha256"]:
                    raise ExperimentRefusal("machine proof lacks its frozen external review")
            success = bool(exact and audit_row and audit_row["decision"] == "accepted")
            exchange = cell.get("record") or {}
            narration = cell["narration"]
            for name, present in (
                ("soul_leak", bool(exchange.get("soul_leak"))),
                ("voice_leak", bool(exchange.get("voice_leak"))),
                ("override_refused", bool(exchange.get("override_refused"))),
                ("retrieval", bool(narration.get("retrieved"))),
            ):
                if present:
                    violations.append(
                        {"case_id": case["id"], "arm": arm, "label": label, "kind": name}
                    )
            arms[arm][str(case["id"])] = {
                "case_id": case["id"],
                "task_id": case["task_id"],
                "kind": case["kind"],
                "label": label,
                "prompt_condition": case["prompt_condition"],
                "grammar_condition": case["grammar_condition"],
                "primary_endpoint": case["primary_endpoint"],
                "mechanically_valid": cell.get("mechanically_valid") is True,
                "cut_at_cap": narration.get("cut_at_cap") is True,
                "exact_proved": exact,
                "audit": audit_row["decision"] if audit_row else "not-eligible",
                "success": success,
                "negative_literals": cell["features"]["negative_literals"],
                "stray_literals": cell["features"]["stray_literals"],
                "reply_sha256": cell["reply_sha256"],
            }
    expected = len(_cases(plan))
    if any(len(rows) != expected for rows in arms.values()):
        raise ExperimentRefusal("unblinded arms are incomplete or duplicated")
    return arms, violations


def _arm_summary(rows: dict[str, dict[str, Any]]) -> dict[str, Any]:
    void_ids = sorted(
        case_id for case_id, row in rows.items() if row["mechanically_valid"] is not True
    )
    cap_ids = sorted(case_id for case_id, row in rows.items() if row["cut_at_cap"] is True)
    return {
        "tasks": len(rows),
        "mechanically_valid": sum(row["mechanically_valid"] for row in rows.values()),
        "mechanically_void": len(void_ids),
        "void_case_ids": void_ids,
        "reply_cap_cuts": len(cap_ids),
        "reply_cap_cut_case_ids": cap_ids,
        "exact_proved": sum(row["exact_proved"] for row in rows.values()),
        "audit_accepted": sum(row["audit"] == "accepted" for row in rows.values()),
        "audit_vetoed": sum(row["audit"] == "vetoed" for row in rows.values()),
        "successes": sum(row["success"] for row in rows.values()),
        "negative_literal_cells": sum(bool(row["negative_literals"]) for row in rows.values()),
        "stray_literal_cells": sum(bool(row["stray_literals"]) for row in rows.values()),
    }


def _condition_rows(
    arms: dict[str, dict[str, dict[str, Any]]],
    prompt_condition: str,
    grammar_condition: str,
) -> dict[str, dict[str, dict[str, Any]]]:
    selected = {
        arm: {
            case_id: row
            for case_id, row in rows.items()
            if row["prompt_condition"] == prompt_condition
            and row["grammar_condition"] == grammar_condition
        }
        for arm, rows in arms.items()
    }
    expected = len(claim_probe.GENERATORS) * protocol.TASKS_PER_FAMILY
    if any(len(rows) != expected for rows in selected.values()):
        raise ExperimentRefusal("factorial condition does not contain every prospective task")
    return selected


def _condition_diagnostic(
    arms: dict[str, dict[str, dict[str, Any]]],
    prompt_condition: str,
    grammar_condition: str,
) -> dict[str, Any]:
    selected = _condition_rows(arms, prompt_condition, grammar_condition)
    complete, validity = protocol.complete_case_arms(selected)
    comparisons = {
        f"candidate_vs_{comparator}": v1.paired_comparison(
            complete["candidate"], complete[comparator]
        )
        for comparator in ("bare", "placebo", "retained")
    }
    return {
        "prompt_condition": prompt_condition,
        "grammar_condition": grammar_condition,
        "transfer_endpoint": (
            prompt_condition == protocol.PRIMARY_PROMPT
            and grammar_condition == protocol.PRIMARY_GRAMMAR
        ),
        "mechanical_validity": validity,
        "arms": {arm: _arm_summary(rows) for arm, rows in selected.items()},
        "complete_case_arms": {arm: _arm_summary(rows) for arm, rows in complete.items()},
        "comparisons": comparisons,
    }


def decide(experiment: Path) -> dict[str, Any]:
    """Freeze, unblind once, and apply the prospective transfer gates exactly."""
    experiment = experiment.resolve(strict=True)
    plan = load_protocol(experiment)
    frozen = freeze_evidence(experiment, plan)
    _seal, records = _load_run_seal(experiment, plan)
    key = load_arm_key(experiment, plan)
    audit = _load_audit(experiment, plan)
    arms, violations = _outcomes(experiment, plan, key, audit, records)
    primary = _condition_rows(arms, protocol.PRIMARY_PROMPT, protocol.PRIMARY_GRAMMAR)
    endpoint = protocol.evaluate_primary_endpoint(primary)
    full_voids = {
        arm: sum(row["mechanically_valid"] is not True for row in rows.values())
        for arm, rows in arms.items()
    }
    endpoint_voids = {
        arm: sum(row["mechanically_valid"] is not True for row in rows.values())
        for arm, rows in primary.items()
    }
    mechanical_gate = all(
        count <= int(plan["mechanical_rule"]["max_void_cells_per_arm"])
        for count in full_voids.values()
    ) and all(
        count <= int(plan["mechanical_rule"]["max_primary_endpoint_void_cells_per_arm"])
        for count in endpoint_voids.values()
    )
    living_unchanged = (
        sha256(Path(str(plan["pins"]["living_body_path"]))) == plan["pins"]["living_body_sha256"]
    )
    source_unchanged = (
        sha256(Path(str(plan["pins"]["source_body_path"]))) == plan["pins"]["source_body_sha256"]
    )
    transfer = bool(
        endpoint["method_transfer"]
        and mechanical_gate
        and living_unchanged
        and source_unchanged
        and not violations
    )
    diagnostics = [
        _condition_diagnostic(arms, prompt, grammar)
        for prompt in protocol.PROMPT_CONDITIONS
        for grammar in protocol.GRAMMAR_CONDITIONS
    ]
    verdict: dict[str, Any] = {
        "version": 2,
        "instrument": INSTRUMENT,
        "decided_at": frozen["frozen_at"],
        "protocol_sha256": sha256(experiment / "protocol.json"),
        "pre_unblind_evidence_sha256": frozen["evidence_sha256"],
        "arm_key_sha256": plan["pins"]["arm_key_sha256"],
        "arm_mapping": {
            label: {
                "kind": arm["kind"],
                "coat_sha256": arm["coat_sha256"],
                "scale": arm["scale"],
            }
            for label, arm in key["mapping"].items()
        },
        "arms": {arm: _arm_summary(rows) for arm, rows in arms.items()},
        "primary_endpoint": endpoint,
        "factorial_diagnostics": diagnostics,
        "mechanical_gate": {
            "full_voids_by_arm": full_voids,
            "full_limit_per_arm": plan["mechanical_rule"]["max_void_cells_per_arm"],
            "endpoint_voids_by_arm": endpoint_voids,
            "endpoint_limit_per_arm": plan["mechanical_rule"][
                "max_primary_endpoint_void_cells_per_arm"
            ],
            "passed": mechanical_gate,
        },
        "isolation_violations": violations,
        "zero_leaks": not violations,
        "living_body_unchanged": living_unchanged,
        "source_body_unchanged": source_unchanged,
        "method_transfer": transfer,
        "causal_conclusion": (
            "candidate passed the preregistered names-only loose-grammar transfer endpoint"
            if transfer
            else "no preregistered causal evidence of unscaffolded method transfer"
        ),
        "automatic_promotion": False,
        "living_promotion_authorized": False,
        "next_required": (
            "independent consolidation qualification; this experiment still cannot wear a coat"
            if transfer
            else "diagnose factorial results; do not wear or consolidate this coat"
        ),
    }
    verdict["verdict_sha256"] = sha256_text(canonical(verdict))
    _write_once(experiment / "verdict.json", verdict)
    state = _load_object(experiment / "state.json")
    state["status"] = "complete"
    state["unblinded"] = True
    state["updated_at"] = utc_now()
    state["verdict_sha256"] = verdict["verdict_sha256"]
    _atomic_json(experiment / "state.json", state)
    return verdict


def status(experiment: Path) -> dict[str, Any]:
    experiment = experiment.resolve(strict=True)
    plan = load_protocol(experiment)
    state = _load_object(experiment / "state.json")
    cells_present = sum(
        _checkpoint_path(experiment, label, str(case["id"])).is_file()
        and not _checkpoint_path(experiment, label, str(case["id"])).is_symlink()
        for case in _cases(plan)
        for label in ("A", "B", "C", "D")
    )
    return {
        "experiment": str(experiment),
        "state": state,
        "cells_present": cells_present,
        "cells_expected": len(_cases(plan)) * 4,
        "living_body_unchanged": (
            sha256(Path(str(plan["pins"]["living_body_path"])))
            == plan["pins"]["living_body_sha256"]
        ),
        "source_body_unchanged": (
            sha256(Path(str(plan["pins"]["source_body_path"])))
            == plan["pins"]["source_body_sha256"]
        ),
        "llama_servers": _model_processes(),
        "arm_blind": not (experiment / "verdict.json").exists(),
        "validated_run_present": _run_seal_path(experiment).is_file(),
        "audit_bundle_present": _audit_bundle_path(experiment).is_file(),
        "external_audit_present": _audit_path(experiment).is_file(),
        "evidence_frozen": (experiment / "pre-unblind.json").is_file(),
        "verdict_present": (experiment / "verdict.json").is_file(),
        "automatic_promotion": False,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    make = commands.add_parser("prepare", help="freeze all inputs, arms, cases, and gates")
    make.add_argument("--out", type=Path, required=True)
    make.add_argument("--placebo-adapter", type=Path, required=True)
    make.add_argument("--room-pointer", type=Path, default=CURRENT_ROOM)
    make.add_argument("--previous-protocol", type=Path, default=protocol.DEFAULT_PREVIOUS_PROTOCOL)
    make.add_argument(
        "--exclude-experiment",
        action="append",
        type=Path,
        default=[],
        help="complete prior run whose sealed tasks must remain unseen",
    )
    make.add_argument("--binary", type=Path, default=DEFAULT_BINARY)
    make.add_argument("--base", type=Path, default=DEFAULT_BASE)
    make.add_argument("--server", type=Path, default=DEFAULT_SERVER)
    running = commands.add_parser("run", help="run or resume sealed arm-blind blocks")
    running.add_argument("--experiment", type=Path, required=True)
    running.add_argument("--port", type=int, default=PORT)
    running.add_argument("--jobs", type=int, default=PARALLEL)
    running.add_argument("--max-blocks", type=int)
    show = commands.add_parser("status", help="report blinded progress without opening the arm key")
    show.add_argument("--experiment", type=Path, required=True)
    bundle = commands.add_parser(
        "audit-bundle", help="freeze an arm-blind bundle of machine-proved whole replies"
    )
    bundle.add_argument("--experiment", type=Path, required=True)
    imported = commands.add_parser(
        "import-audit", help="freeze one independent whole-reply veto audit"
    )
    imported.add_argument("--experiment", type=Path, required=True)
    imported.add_argument("--audit", type=Path, required=True)
    decision = commands.add_parser(
        "decide", help="freeze evidence, unblind once, and apply prospective gates"
    )
    decision.add_argument("--experiment", type=Path, required=True)
    args = parser.parse_args()

    if args.command == "prepare":
        result = prepare(
            args.out,
            args.placebo_adapter,
            room_pointer=args.room_pointer,
            previous_protocol=args.previous_protocol,
            exclude_experiments=tuple(args.exclude_experiment),
            binary=args.binary,
            base=args.base,
            server=args.server,
        )
        shown: Any = {
            "experiment": str(args.out.resolve()),
            "plan_sha256": result["plan_sha256"],
            "cases": len(result["design"]["cases"]),
            "cells": len(result["design"]["cases"]) * 4,
        }
    elif args.command == "run":
        shown = run(
            args.experiment,
            port=args.port,
            jobs=args.jobs,
            max_blocks=args.max_blocks,
        )
    elif args.command == "audit-bundle":
        result = create_audit_bundle(args.experiment)
        shown = {
            "experiment": str(args.experiment.resolve()),
            "bundle_sha256": result["bundle_sha256"],
            "entries": result["entry_count"],
            "arm_blind": True,
        }
    elif args.command == "import-audit":
        result = import_audit(args.experiment, args.audit)
        shown = {
            "experiment": str(args.experiment.resolve()),
            "audit_sha256": result["audit_sha256"],
            "decisions": result["decision_count"],
            "arm_blind": True,
        }
    elif args.command == "decide":
        shown = decide(args.experiment)
    else:
        shown = status(args.experiment)
    print(json.dumps(shown, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
