"""Ground truth for carrying through the hundreds place."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass

from fish.lab.counted_structure import assignment_truth_with_tables

START_CYCLE = 3702
KINDS = ("hundreds-carry-join", "three-column-expanded")

METHODS = {
    "hundreds-carry-join": (
        "Set HUNDREDS_PRODUCT=HUNDREDS_INPUT*MULTIPLIER, then set "
        "HUNDREDS_RAW=HUNDREDS_PRODUCT+CARRY_TO_HUNDREDS"
    ),
    "three-column-expanded": (
        "Set ONES_PRODUCT=ONES_INPUT*MULTIPLIER, OUT_ONES=ONES_PRODUCT mod 10, and "
        "CARRY_TO_TENS=ONES_PRODUCT div 10; set TENS_PRODUCT=TENS_INPUT*MULTIPLIER, "
        "TENS_RAW=TENS_PRODUCT+CARRY_TO_TENS, OUT_TENS=TENS_RAW mod 10, and "
        "CARRY_TO_HUNDREDS=TENS_RAW div 10; set "
        "HUNDREDS_PRODUCT=HUNDREDS_INPUT*MULTIPLIER, "
        "HUNDREDS_RAW=HUNDREDS_PRODUCT+CARRY_TO_HUNDREDS; then set "
        "HUNDREDS_TERM=100*HUNDREDS_RAW, TENS_TERM=10*OUT_TENS, "
        "ONES_TERM=OUT_ONES, PREFIX_SUM=HUNDREDS_TERM+TENS_TERM, and "
        "RESULT=PREFIX_SUM+ONES_TERM"
    ),
}


@dataclass(frozen=True)
class Problem:
    kind: str
    parameters: tuple[int, ...]

    @property
    def assignments(self) -> dict[str, int]:
        return states(self.kind, self.parameters)

    @property
    def method(self) -> str:
        return METHODS[self.kind]

    def _contract(self) -> str:
        return "; ".join(f"{label} = integer" for label in self.assignments)

    def prompt(self) -> str:
        return (
            f"{statement(self.kind, self.parameters)} Evaluate every assignment to a decimal "
            f"integer. Return one line with no prose: {self._contract()}."
        )

    def nudge(self) -> str:
        return (
            f"{statement(self.kind, self.parameters)} Use this relation: {self.method}. "
            f"Do not leave arithmetic operators unevaluated. Return exactly {self._contract()} "
            "and no prose."
        )

    def repair(self) -> str:
        if self.kind == "hundreds-carry-join":
            hundreds, multiplier, carry = self.parameters
            product = hundreds * multiplier
            check = (
                f"The checked product is HUNDREDS_PRODUCT={product}; add "
                f"CARRY_TO_HUNDREDS={carry} to that product"
            )
        else:
            hundreds, tens, ones, multiplier = self.parameters
            trace = states(self.kind, self.parameters)
            hundreds_term = 100 * trace["HUNDREDS_RAW"]
            tens_term = 10 * trace["OUT_TENS"]
            prefix_sum = hundreds_term + tens_term
            check = (
                f"The checked lower trace is ONES_PRODUCT={trace['ONES_PRODUCT']}, "
                f"OUT_ONES={trace['OUT_ONES']}, CARRY_TO_TENS={trace['CARRY_TO_TENS']}, "
                f"TENS_PRODUCT={trace['TENS_PRODUCT']}, TENS_RAW={trace['TENS_RAW']}, "
                f"OUT_TENS={trace['OUT_TENS']}, "
                f"CARRY_TO_HUNDREDS={trace['CARRY_TO_HUNDREDS']}, and "
                f"HUNDREDS_PRODUCT={hundreds * multiplier}. Set "
                f"HUNDREDS_RAW={trace['HUNDREDS_RAW']}, HUNDREDS_TERM={hundreds_term}, "
                f"TENS_TERM={tens_term}, ONES_TERM={trace['OUT_ONES']}, "
                f"PREFIX_SUM={prefix_sum}, and RESULT={trace['RESULT']}"
            )
        return (
            f"{statement(self.kind, self.parameters)} Your preceding values did not all "
            f"satisfy the decimal-column relations. {check}. Continue the state trace and "
            f"return exactly {self._contract()} with decimal integers and no prose."
        )

    def record(self) -> str:
        return "; ".join(f"{label} = {value}" for label, value in self.assignments.items())


def states(kind: str, parameters: tuple[int, ...]) -> dict[str, int]:
    if kind == "hundreds-carry-join":
        if len(parameters) != 3:
            raise ValueError("hundreds carry join requires three parameters")
        hundreds, multiplier, carry = parameters
        if not 1 <= hundreds <= 9 or not 2 <= multiplier <= 9 or not 1 <= carry < multiplier:
            raise ValueError("invalid hundreds carry join")
        product = hundreds * multiplier
        return {
            "HUNDREDS_PRODUCT": product,
            "HUNDREDS_RAW": product + carry,
        }
    if kind == "three-column-expanded":
        if len(parameters) != 4:
            raise ValueError("expanded three-column product requires four parameters")
        hundreds, tens, ones, multiplier = parameters
        if (
            not 1 <= hundreds <= 9
            or not 0 <= tens <= 9
            or not 0 <= ones <= 9
            or not 2 <= multiplier <= 9
        ):
            raise ValueError("invalid expanded three-column product")
        ones_product = ones * multiplier
        out_ones = ones_product % 10
        carry_to_tens = ones_product // 10
        tens_product = tens * multiplier
        tens_raw = tens_product + carry_to_tens
        out_tens = tens_raw % 10
        carry_to_hundreds = tens_raw // 10
        hundreds_product = hundreds * multiplier
        hundreds_raw = hundreds_product + carry_to_hundreds
        return {
            "ONES_PRODUCT": ones_product,
            "OUT_ONES": out_ones,
            "CARRY_TO_TENS": carry_to_tens,
            "TENS_PRODUCT": tens_product,
            "TENS_RAW": tens_raw,
            "OUT_TENS": out_tens,
            "CARRY_TO_HUNDREDS": carry_to_hundreds,
            "HUNDREDS_PRODUCT": hundreds_product,
            "HUNDREDS_RAW": hundreds_raw,
            "RESULT": hundreds_raw * 100 + out_tens * 10 + out_ones,
        }
    raise ValueError(f"unknown arithmetic place-value task: {kind}")


def statement(kind: str, parameters: tuple[int, ...]) -> str:
    if kind == "hundreds-carry-join":
        hundreds, multiplier, carry = parameters
        return (
            "Hundreds-carry-join state question: "
            f"HUNDREDS_INPUT={hundreds}, MULTIPLIER={multiplier}, "
            f"and CARRY_TO_HUNDREDS={carry}."
        )
    if kind == "three-column-expanded":
        hundreds, tens, ones, multiplier = parameters
        return (
            "Three-column-expanded state question: the multiplicand has "
            f"HUNDREDS_INPUT={hundreds}, TENS_INPUT={tens}, ONES_INPUT={ones}, "
            f"and MULTIPLIER={multiplier}."
        )
    raise ValueError(f"unknown arithmetic place-value task: {kind}")


def problem_from_prompt(prompt: str) -> Problem | None:
    carry_join = re.search(
        r"Hundreds-carry-join state question:.*HUNDREDS_INPUT=(\d+), "
        r"MULTIPLIER=(\d+), and CARRY_TO_HUNDREDS=(\d+)",
        prompt,
    )
    if carry_join is not None:
        return Problem("hundreds-carry-join", tuple(int(value) for value in carry_join.groups()))
    expanded = re.search(
        r"Three-column-expanded state question:.*HUNDREDS_INPUT=(\d+), TENS_INPUT=(\d+), "
        r"ONES_INPUT=(\d+), and MULTIPLIER=(\d+)",
        prompt,
    )
    if expanded is not None:
        return Problem("three-column-expanded", tuple(int(value) for value in expanded.groups()))
    return None


def lesson_reply_lands(prompt: str, reply: str) -> bool | None:
    problem = problem_from_prompt(prompt)
    if problem is None:
        return None
    return assignment_truth_with_tables(reply, problem.assignments)


def candidates(kind: str) -> list[tuple[int, ...]]:
    values: list[tuple[int, ...]]
    if kind == "hundreds-carry-join":
        values = [
            (hundreds, multiplier, carry)
            for hundreds in range(1, 10)
            for multiplier in range(2, 10)
            for carry in range(1, multiplier)
        ]
    elif kind == "three-column-expanded":
        values = []
        for hundreds in range(1, 10):
            for tens in range(10):
                for ones in range(10):
                    for multiplier in range(2, 10):
                        carry_to_tens = ones * multiplier // 10
                        carry_to_hundreds = (tens * multiplier + carry_to_tens) // 10
                        if carry_to_tens and carry_to_hundreds:
                            values.append((hundreds, tens, ones, multiplier))
    else:
        raise ValueError(f"unknown arithmetic place-value task: {kind}")
    values.sort(key=lambda item: hashlib.sha256(f"{kind}:{item}".encode()).digest())
    return values


def lesson_problem(cycle: int) -> tuple[Problem, int]:
    if cycle < START_CYCLE:
        raise ValueError(f"arithmetic place-value lessons begin at cycle {START_CYCLE}")
    offset = cycle - START_CYCLE
    block, position = divmod(offset, 4)
    kind = KINDS[position // 2]
    occurrence = block * 2 + position % 2
    pool = candidates(kind)
    return Problem(kind, pool[occurrence % len(pool)]), occurrence
