"""Deterministic graders and leakage checks for adaptive-evolution probes."""

from __future__ import annotations

import math
import re
import sqlite3
from pathlib import Path
from typing import Any

from fish.lab import arithmetic_curricula, arithmetic_division, exact_cancellation, exact_recurrence
from fish.lab.counted_structure import assignment_score, assignment_truth
from fish.lab.plain_register import first_pictograph


def normalized(text: str) -> str:
    return " ".join(text.casefold().split())


def is_prime(value: int) -> bool:
    if value < 2:
        return False
    if value % 2 == 0:
        return value == 2
    divisor = 3
    while divisor * divisor <= value:
        if value % divisor == 0:
            return False
        divisor += 2
    return True


def _normalize_exponents(text: str) -> str:
    superscripts = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹", "0123456789")
    return re.sub(
        r"(\d+)([⁰¹²³⁴⁵⁶⁷⁸⁹]+)",
        lambda match: f"{match.group(1)}^{match.group(2).translate(superscripts)}",
        text,
    )


def _expanded_factor(token: str) -> list[int] | None:
    match = re.fullmatch(r"(\d+)(?:\s*\^\s*(\d+))?", token.strip())
    if match is None:
        return None
    base = int(match.group(1))
    exponent = int(match.group(2) or "1")
    if exponent < 1 or exponent > 16:
        return None
    return [base] * exponent


def _factor_expression(text: str) -> list[int] | None:
    pieces = re.split(r"\s*(?:\*|×|·|[xX])\s*", text.strip())
    factors: list[int] = []
    for piece in pieces:
        expanded = _expanded_factor(piece)
        if expanded is None:
            return None
        factors.extend(expanded)
    return factors if len(factors) >= 2 else None


def _valid_factor_equality(text: str, target: int) -> bool:
    if text.count("=") != 1:
        return False
    left, right = (side.strip() for side in text.split("=", 1))
    for target_side, factor_side in ((left, right), (right, left)):
        if not target_side.isdigit() or int(target_side) != target:
            continue
        factors = _factor_expression(factor_side)
        if factors and all(is_prime(factor) for factor in factors):
            return math.prod(factors) == target
    return False


def _score_factorization(reply: str, scorer: dict[str, Any]) -> tuple[bool, bool, str]:
    target = int(scorer["target"])
    stripped = _normalize_exponents(reply.strip())
    format_ok = re.fullmatch(r"[\d\s=*×·xX^]+", stripped) is not None
    if format_ok:
        correct = _valid_factor_equality(stripped, target)
    else:
        candidates = re.findall(
            r"\d+(?:\s*(?:\*|×|·|[xX])\s*\d+(?:\s*\^\s*\d+)?)+\s*=\s*\d+|\d+\s*=\s*\d+(?:\s*(?:\*|×|·|[xX])\s*\d+(?:\s*\^\s*\d+)?)+",
            _normalize_exponents(reply),
        )
        correct = any(_valid_factor_equality(candidate, target) for candidate in candidates)
    return correct, format_ok, f"prime factors multiplying to {target}"


def _score_exact(reply: str, scorer: dict[str, Any]) -> tuple[bool, bool, str]:
    accepted = [normalized(str(value)) for value in scorer["accepted"]]
    answer = normalized(reply.strip(" \t\r\n`*"))
    format_ok = answer in accepted
    correct = format_ok or any(
        re.search(rf"(?<!\w){re.escape(value)}(?!\w)", answer) is not None for value in accepted
    )
    return correct, format_ok, " or ".join(accepted)


def _score_integer(reply: str, scorer: dict[str, Any]) -> tuple[bool, bool, str]:
    expected = int(scorer["value"])
    stripped = reply.strip()
    format_ok = re.fullmatch(r"[+-]?\d+", stripped) is not None
    values = [int(value) for value in re.findall(r"(?<![\w.])[+-]?\d+(?![\w.])", reply)]
    return expected in values, format_ok and int(stripped) == expected, str(expected)


def _score_linear(reply: str, scorer: dict[str, Any]) -> tuple[bool, bool, str]:
    variable = re.escape(str(scorer["variable"]))
    expected = int(scorer["value"])
    equation = rf"{variable}\s*=\s*{expected}"
    correct = re.search(rf"(?<!\w){equation}(?!\w)", reply, re.IGNORECASE) is not None
    format_ok = re.fullmatch(rf"\s*{equation}\s*", reply, re.IGNORECASE) is not None
    return correct, format_ok, f"{scorer['variable']} = {expected}"


def _primes_through(limit: int) -> list[int]:
    return [value for value in range(2, limit + 1) if is_prime(value)]


def _score_prime_certificate(reply: str, scorer: dict[str, Any]) -> tuple[bool, bool, str]:
    target = int(scorer["target"])
    divisors = _primes_through(math.isqrt(target))
    identity_text = rf"{target}\s*=\s*(\d+)\s*(?:\*|×|·|[xX])\s*(\d+)\s*\+\s*(\d+)"
    identity = re.compile(identity_text)
    parsed = [(int(p), int(q), int(r)) for p, q, r in identity.findall(reply)]
    by_divisor = {p: (q, r) for p, q, r in parsed}
    complete = len(parsed) == len(by_divisor) == len(divisors) and set(by_divisor) == set(divisors)
    correct = complete and all(
        q == target // p and r == target % p and 0 < r < p for p, (q, r) in by_divisor.items()
    )
    segments = reply.strip().split(";")
    format_ok = bool(segments) and all(
        re.fullmatch(identity_text, segment.strip()) is not None for segment in segments
    )
    expected = f"all nonzero quotient-remainder identities through {math.isqrt(target)}"
    return correct, format_ok, expected


def _score_assignments(reply: str, scorer: dict[str, Any]) -> tuple[bool, bool, str]:
    expected = {str(label): int(value) for label, value in scorer["values"].items()}
    correct, format_ok = assignment_score(reply, expected)
    rendered = "; ".join(f"{label} = {value}" for label, value in expected.items())
    return correct, format_ok, rendered


def _score_exact_cancellation(reply: str, scorer: dict[str, Any]) -> tuple[bool, bool, str]:
    values = [int(value) for value in scorer["parameters"]]
    if len(values) != 3:
        raise ValueError("exact-cancellation scorer needs three parameters")
    problem = exact_cancellation.Problem((values[0], values[1], values[2]))
    correct = exact_cancellation.lesson_reply_lands(problem.prompt(), reply) is True
    _, format_ok = assignment_score(reply, problem.assignments)
    return correct, format_ok, problem.record()


def _score_arithmetic_component(reply: str, scorer: dict[str, Any]) -> tuple[bool, bool, str]:
    kind = str(scorer["kind"])
    parameters = tuple(int(value) for value in scorer["parameters"])
    curriculum = arithmetic_curricula.for_kind(kind)
    problem = curriculum.Problem(kind, parameters)
    correct = curriculum.lesson_reply_lands(problem.prompt(), reply) is True
    format_grader = getattr(curriculum, "lesson_format_lands", None)
    if format_grader is None:
        _, format_ok = assignment_score(reply, problem.assignments)
    else:
        format_ok = format_grader(problem.prompt(), reply) is True
    return correct, format_ok, problem.record()


def _score_arithmetic_division(reply: str, scorer: dict[str, Any]) -> tuple[bool, bool, str]:
    kind = str(scorer["kind"])
    parameters = tuple(int(value) for value in scorer["parameters"])
    problem = arithmetic_division.Problem(kind, parameters)
    correct = arithmetic_division.lesson_reply_lands(problem.prompt(), reply) is True
    return correct, correct, problem.record()


def _score_exact_recurrence(reply: str, scorer: dict[str, Any]) -> tuple[bool, bool, str]:
    kind = str(scorer["kind"])
    parameters = tuple(int(value) for value in scorer["parameters"])
    if len(parameters) != 2:
        raise ValueError("exact-recurrence scorer needs two parameters")
    problem = exact_recurrence.Problem(kind, (parameters[0], parameters[1]))
    correct = exact_recurrence.lesson_reply_lands(problem.prompt(), reply) is True
    _, format_ok = assignment_score(reply, problem.assignments)
    return correct, format_ok, problem.record()


SCORERS = {
    "arithmetic_component": _score_arithmetic_component,
    "arithmetic_division": _score_arithmetic_division,
    "exact": _score_exact,
    "exact_cancellation": _score_exact_cancellation,
    "exact_recurrence": _score_exact_recurrence,
    "factorization": _score_factorization,
    "integer": _score_integer,
    "linear": _score_linear,
    "prime_certificate": _score_prime_certificate,
    "assignments": _score_assignments,
}


def score_reply(protocol: dict[str, Any], probe: dict[str, Any], reply: str) -> dict[str, Any]:
    scorer = probe["scorer"]
    grader = SCORERS[scorer["type"]]
    correct, format_ok, expected = grader(reply, scorer)
    rejected = [
        pattern
        for pattern in protocol["global_reject"]
        if re.search(pattern, reply, re.IGNORECASE) is not None
    ]
    semantic = correct
    if scorer["type"] == "assignments":
        expected_values = {str(label): int(value) for label, value in scorer["values"].items()}
        semantic = assignment_truth(reply, expected_values) is True
    # A reply out of the plain register earns nothing, however right its
    # arithmetic (the rule is fish/lab/plain_register.py). Reported, never
    # stripped: stripping would launder the failure into clean-looking evidence.
    mark = first_pictograph(reply)
    return {
        "task": correct and format_ok and mark is None,
        "correct": correct and mark is None,
        "semantic": semantic and mark is None,
        "format": format_ok,
        "clean": not rejected and mark is None,
        "expected": expected,
        "rejected": rejected,
        "register": None if mark is None else [mark.offset, mark.text, mark.kind],
    }


def protocol_leaks(protocol: dict[str, Any], body: Path) -> list[dict[str, Any]]:
    """Find evaluation material already present in a candidate body."""
    with sqlite3.connect(f"file:{body.resolve()}?mode=ro", uri=True) as db:
        rows = db.execute("SELECT id, you, i FROM exchanges").fetchall()
        ids = {int(row[0]) for row in rows}

    normalized_rows = [
        (int(row_id), normalized(you), normalized(reply)) for row_id, you, reply in rows
    ]
    leaks: list[dict[str, Any]] = []
    for probe in protocol["probes"]:
        prompt = normalized(probe["prompt"])
        for row_id, you, reply in normalized_rows:
            if prompt in {you, reply}:
                leaks.append({"probe": probe["id"], "kind": "exact-prompt", "row": row_id})
        for token in probe.get("novel_tokens", []):
            pattern = re.compile(rf"(?<!\w){re.escape(str(token).casefold())}(?!\w)")
            for row_id, you, reply in normalized_rows:
                if pattern.search(you) or pattern.search(reply):
                    leaks.append(
                        {"probe": probe["id"], "kind": "novel-token", "token": token, "row": row_id}
                    )
        for source_id in probe.get("source_exchange_ids", []):
            if int(source_id) not in ids:
                leaks.append(
                    {"probe": probe["id"], "kind": "missing-source", "row": int(source_id)}
                )
    return leaks


def one_sided_sign_p(gains: int, losses: int) -> float:
    comparisons = gains + losses
    if comparisons == 0:
        return 1.0
    return sum(math.comb(comparisons, k) for k in range(gains, comparisons + 1)) / (2**comparisons)


def binomial_upper(trials: int, rate: float, quantile: float = 0.99) -> int:
    """Smallest x with P(Binomial(trials, rate) <= x) >= quantile.

    The A/A null margin, shared. §7.4 registers the OFF/OFF-rep discordance as the margin an effect
    must clear, and it is applied per family in the memory arm and to the pooled contrast in
    `decisive_stats`. It lives here, beside `one_sided_sign_p`, so both channels read ONE formula:
    two copies could drift, and a margin that differs between the table and the pooled verdict is
    worse than no margin at all.
    """
    cumulative = 0.0
    for successes in range(trials + 1):
        cumulative += (
            math.comb(trials, successes) * rate**successes * (1 - rate) ** (trials - successes)
        )
        if cumulative >= quantile - 1e-12:
            return successes
    return trials
