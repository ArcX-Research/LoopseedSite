"""Ground truth for composing decimal product and carry states."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass

from fish.lab.counted_structure import assignment_truth_with_tables

START_CYCLE = 3574
CARRY_JOIN_START_CYCLE = 3638
BASE_KINDS = ("full-column", "two-column-recomposition")
CARRY_JOIN_KINDS = ("tens-carry-join", "two-column-expanded")
KINDS = BASE_KINDS + CARRY_JOIN_KINDS

METHODS = {
    "full-column": (
        "Evaluate PRODUCT=DIGIT*MULTIPLIER, then RAW=PRODUCT+INCOMING_CARRY; "
        "set OUT_DIGIT=RAW mod 10 and NEXT_CARRY=RAW div 10"
    ),
    "two-column-recomposition": (
        "Set ONES_PRODUCT=ONES_INPUT*MULTIPLIER, OUT_ONES=ONES_PRODUCT mod 10, and "
        "CARRY_TO_TENS=ONES_PRODUCT div 10; then set "
        "TENS_RAW=TENS_INPUT*MULTIPLIER+CARRY_TO_TENS and "
        "RESULT=10*TENS_RAW+OUT_ONES"
    ),
    "tens-carry-join": (
        "Set TENS_PRODUCT=TENS_INPUT*MULTIPLIER, then set TENS_RAW=TENS_PRODUCT+CARRY_TO_TENS"
    ),
    "two-column-expanded": (
        "Set ONES_PRODUCT=ONES_INPUT*MULTIPLIER, OUT_ONES=ONES_PRODUCT mod 10, and "
        "CARRY_TO_TENS=ONES_PRODUCT div 10; set TENS_PRODUCT=TENS_INPUT*MULTIPLIER, "
        "then TENS_RAW=TENS_PRODUCT+CARRY_TO_TENS and RESULT=10*TENS_RAW+OUT_ONES"
    ),
}

RETIRED_PARAMETERS = {
    "full-column": {(9, 3, 0), (7, 5, 2), (3, 9, 3), (7, 9, 4), (1, 7, 6)},
    "two-column-recomposition": {(1, 7, 2), (4, 3, 8), (9, 7, 7), (8, 6, 8)},
    "tens-carry-join": set(),
    "two-column-expanded": set(),
}


@dataclass(frozen=True)
class Problem:
    kind: str
    parameters: tuple[int, ...]

    @property
    def assignments(self) -> dict[str, int]:
        return states(self.kind, self.parameters)

    @property
    def method(self) -> str:
        return METHODS[self.kind]

    def _contract(self) -> str:
        return "; ".join(f"{label} = integer" for label in self.assignments)

    def prompt(self) -> str:
        return (
            f"{statement(self.kind, self.parameters)} Evaluate every assignment to a decimal "
            f"integer. Return one line with no prose: {self._contract()}."
        )

    def nudge(self) -> str:
        return (
            f"{statement(self.kind, self.parameters)} Use this relation: {self.method}. "
            f"Do not leave arithmetic operators unevaluated. Return exactly {self._contract()} "
            "and no prose."
        )

    def repair(self) -> str:
        if self.kind == "full-column":
            digit, multiplier, carry = self.parameters
            check = f"The checked first state is PRODUCT={digit * multiplier}"
        elif self.kind == "two-column-recomposition":
            tens, ones, multiplier = self.parameters
            ones_product = ones * multiplier
            check = (
                f"The checked ones states are ONES_PRODUCT={ones_product}, "
                f"OUT_ONES={ones_product % 10}, and CARRY_TO_TENS={ones_product // 10}"
            )
        elif self.kind == "tens-carry-join":
            tens, multiplier, carry = self.parameters
            product = tens * multiplier
            check = (
                f"The checked product is TENS_PRODUCT={product}; add "
                f"CARRY_TO_TENS={carry} to that product"
            )
        else:
            tens, ones, multiplier = self.parameters
            ones_product = ones * multiplier
            check = (
                f"The checked states are ONES_PRODUCT={ones_product}, "
                f"OUT_ONES={ones_product % 10}, CARRY_TO_TENS={ones_product // 10}, "
                f"and TENS_PRODUCT={tens * multiplier}; add the carry to TENS_PRODUCT"
            )
        return (
            f"{statement(self.kind, self.parameters)} Your preceding values did not all "
            f"satisfy the decimal-column relations. {check}. Continue the state trace and "
            f"return exactly {self._contract()} with decimal integers and no prose."
        )

    def record(self) -> str:
        return "; ".join(f"{label} = {value}" for label, value in self.assignments.items())


def states(kind: str, parameters: tuple[int, ...]) -> dict[str, int]:
    if len(parameters) != 3:
        raise ValueError("arithmetic compositions require three parameters")
    left, right, third = parameters
    if kind == "full-column":
        digit, multiplier, carry = left, right, third
        if not 0 <= digit <= 9 or not 2 <= multiplier <= 9 or not 0 <= carry < multiplier:
            raise ValueError("invalid full-column state")
        product = digit * multiplier
        raw = product + carry
        return {
            "PRODUCT": product,
            "RAW": raw,
            "OUT_DIGIT": raw % 10,
            "NEXT_CARRY": raw // 10,
        }
    if kind == "two-column-recomposition":
        tens, ones, multiplier = left, right, third
        if not 1 <= tens <= 9 or not 0 <= ones <= 9 or not 2 <= multiplier <= 9:
            raise ValueError("invalid two-column product")
        ones_product = ones * multiplier
        ones_digit = ones_product % 10
        carry = ones_product // 10
        tens_raw = tens * multiplier + carry
        return {
            "ONES_PRODUCT": ones_product,
            "OUT_ONES": ones_digit,
            "CARRY_TO_TENS": carry,
            "TENS_RAW": tens_raw,
            "RESULT": tens_raw * 10 + ones_digit,
        }
    if kind == "tens-carry-join":
        tens, multiplier, carry = left, right, third
        if not 1 <= tens <= 9 or not 2 <= multiplier <= 9 or not 1 <= carry < multiplier:
            raise ValueError("invalid tens carry join")
        product = tens * multiplier
        return {
            "TENS_PRODUCT": product,
            "TENS_RAW": product + carry,
        }
    if kind == "two-column-expanded":
        tens, ones, multiplier = left, right, third
        if not 1 <= tens <= 9 or not 0 <= ones <= 9 or not 2 <= multiplier <= 9:
            raise ValueError("invalid expanded two-column product")
        ones_product = ones * multiplier
        ones_digit = ones_product % 10
        carry = ones_product // 10
        tens_product = tens * multiplier
        tens_raw = tens_product + carry
        return {
            "ONES_PRODUCT": ones_product,
            "OUT_ONES": ones_digit,
            "CARRY_TO_TENS": carry,
            "TENS_PRODUCT": tens_product,
            "TENS_RAW": tens_raw,
            "RESULT": tens_raw * 10 + ones_digit,
        }
    raise ValueError(f"unknown arithmetic composition: {kind}")


def statement(kind: str, parameters: tuple[int, ...]) -> str:
    if kind == "full-column":
        digit, multiplier, carry = parameters
        return (
            "Full-column state question: in one right-to-left decimal column, "
            f"DIGIT={digit}, MULTIPLIER={multiplier}, and INCOMING_CARRY={carry}."
        )
    if kind == "two-column-recomposition":
        tens, ones, multiplier = parameters
        return (
            "Two-column-recomposition state question: the multiplicand has "
            f"TENS_INPUT={tens} and ONES_INPUT={ones}, and MULTIPLIER={multiplier}."
        )
    if kind == "tens-carry-join":
        tens, multiplier, carry = parameters
        return (
            "Tens-carry-join state question: "
            f"TENS_INPUT={tens}, MULTIPLIER={multiplier}, and CARRY_TO_TENS={carry}."
        )
    if kind == "two-column-expanded":
        tens, ones, multiplier = parameters
        return (
            "Two-column-expanded state question: the multiplicand has "
            f"TENS_INPUT={tens} and ONES_INPUT={ones}, and MULTIPLIER={multiplier}."
        )
    raise ValueError(f"unknown arithmetic composition: {kind}")


def problem_from_prompt(prompt: str) -> Problem | None:
    full = re.search(
        r"Full-column state question:.*DIGIT=(\d+), MULTIPLIER=(\d+), "
        r"and INCOMING_CARRY=(\d+)",
        prompt,
    )
    if full is not None:
        return Problem("full-column", tuple(int(value) for value in full.groups()))
    two_column = re.search(
        r"Two-column-recomposition state question:.*TENS_INPUT=(\d+) and ONES_INPUT=(\d+), "
        r"and MULTIPLIER=(\d+)",
        prompt,
    )
    if two_column is not None:
        return Problem(
            "two-column-recomposition", tuple(int(value) for value in two_column.groups())
        )
    carry_join = re.search(
        r"Tens-carry-join state question:.*TENS_INPUT=(\d+), MULTIPLIER=(\d+), "
        r"and CARRY_TO_TENS=(\d+)",
        prompt,
    )
    if carry_join is not None:
        return Problem("tens-carry-join", tuple(int(value) for value in carry_join.groups()))
    expanded = re.search(
        r"Two-column-expanded state question:.*TENS_INPUT=(\d+) and ONES_INPUT=(\d+), "
        r"and MULTIPLIER=(\d+)",
        prompt,
    )
    if expanded is not None:
        return Problem("two-column-expanded", tuple(int(value) for value in expanded.groups()))
    return None


def lesson_reply_lands(prompt: str, reply: str) -> bool | None:
    problem = problem_from_prompt(prompt)
    if problem is None:
        return None
    return assignment_truth_with_tables(reply, problem.assignments)


def candidates(kind: str) -> list[tuple[int, int, int]]:
    if kind == "full-column":
        values = [
            (digit, multiplier, carry)
            for digit in range(10)
            for multiplier in range(2, 10)
            for carry in range(multiplier)
            if digit * multiplier + carry >= 10
        ]
    elif kind == "two-column-recomposition":
        values = [
            (tens, ones, multiplier)
            for tens in range(1, 10)
            for ones in range(10)
            for multiplier in range(2, 10)
            if ones * multiplier >= 10
        ]
    elif kind == "tens-carry-join":
        values = [
            (tens, multiplier, carry)
            for tens in range(1, 10)
            for multiplier in range(2, 10)
            for carry in range(1, multiplier)
        ]
    elif kind == "two-column-expanded":
        earlier = set(candidates("two-column-recomposition")[:32])
        earlier.update(RETIRED_PARAMETERS["two-column-recomposition"])
        values = [
            (tens, ones, multiplier)
            for tens in range(1, 10)
            for ones in range(10)
            for multiplier in range(2, 10)
            if ones * multiplier >= 10 and (tens, ones, multiplier) not in earlier
        ]
    else:
        raise ValueError(f"unknown arithmetic composition: {kind}")
    values = [value for value in values if value not in RETIRED_PARAMETERS[kind]]
    values.sort(key=lambda item: hashlib.sha256(f"{kind}:{item}".encode()).digest())
    return values


def lesson_problem(cycle: int) -> tuple[Problem, int]:
    if cycle < START_CYCLE:
        raise ValueError(f"arithmetic-composition lessons begin at cycle {START_CYCLE}")
    if cycle < CARRY_JOIN_START_CYCLE:
        offset = cycle - START_CYCLE
        kinds = BASE_KINDS
    else:
        offset = cycle - CARRY_JOIN_START_CYCLE
        kinds = CARRY_JOIN_KINDS
    block, position = divmod(offset, 4)
    kind = kinds[position // 2]
    occurrence = block * 2 + position % 2
    pool = candidates(kind)
    return Problem(kind, pool[occurrence % len(pool)]), occurrence
