"""The claim room's ruler: a target-bound checker beside a teacher-led conversation.

The teacher (a person or an agent session, never a prompt list) declares, BEFORE each turn,
what the reply must establish: a `spec` names a kind and parameters, and an exact generator
computes the facts (reckon-form expression, expected value) that follow. The spec is hashed
before the message is sent. After the reply, `judge` requires that spec: the reply's claim
line must pass the scratch lexical gate and the Wolfram kernel under the reckon organ's own
limits, every required fact must be established by a proved, non-trivial conjunct that names
the fact's operands, and every arithmetic identity narrated in the prose must hold. A true
line that does not establish the declared target is spec drift, not a pass.

Verdicts: proved, refuted (first refuted conjunct or narrated identity named), drift (the
required facts it failed to establish named), underdetermined, refused. Dispositions for the
PRIVATE clone's memory: eligible, pruned, held. One verdict object per exchange id.

`sample` draws sealed lessons read-only and cross-checks each generator against the lesson's
own checked example; `controls` plants true / false / malformed / foreign claims from the
generators and must recover all of them before any conversation counts. Nothing here opens
the living body for writing. The gate is not reckon's parser and is never a parse rate.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import signal
import sqlite3
import subprocess
import tempfile
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[2]
RECKON = REPO / "fish/daemon/src/fin/reckon.rs"
KERNEL_MEMORY_BYTES = 128 * 1024 * 1024
KERNEL_TIMEOUT_SECS = 15
KERNEL_VALUE_CHARS = 4096
KERNEL_OUTPUT_BYTES = 256_000
INPUT_CAP = 4096
SENTINEL = "claim\t"
MAX_TASK_INTEGER = 10**12
MAX_COMBINATORIAL_PARAMETER = 10_000
MAX_TASK_WORK = 10_000
MAX_CRT_SEARCH = 1_000_000

TASK_PARAMETER_BOUNDS: dict[str, tuple[tuple[int, ...], tuple[int, ...]]] = {
    "euclidean-recurrence": ((1, 1), (MAX_TASK_INTEGER, MAX_TASK_INTEGER)),
    "gcd-reduction": ((1, 1), (MAX_TASK_INTEGER, MAX_TASK_INTEGER)),
    "fraction-reduction": ((1, 1), (MAX_TASK_INTEGER, MAX_TASK_INTEGER)),
    "quotient-remainder": ((0, 1), (MAX_TASK_INTEGER, MAX_TASK_INTEGER)),
    "binomial-recurrence": (
        (0, 0),
        (MAX_COMBINATORIAL_PARAMETER, MAX_COMBINATORIAL_PARAMETER),
    ),
    "shared-seams": ((1, 1), (MAX_TASK_INTEGER, MAX_TASK_INTEGER)),
    "blocked-paths": (
        (0, 0, 0, 0),
        (MAX_TASK_WORK, MAX_TASK_WORK, MAX_TASK_WORK, MAX_TASK_WORK),
    ),
    "separated-choices": (
        (2, 2),
        (MAX_COMBINATORIAL_PARAMETER, MAX_COMBINATORIAL_PARAMETER),
    ),
    "non-square-rectangles": (
        (1, 1),
        (MAX_COMBINATORIAL_PARAMETER, MAX_COMBINATORIAL_PARAMETER),
    ),
    "carry-addition": ((0, 0), (MAX_TASK_INTEGER, MAX_TASK_INTEGER)),
    "digit-product": ((0, 0), (MAX_TASK_INTEGER, MAX_TASK_INTEGER)),
    "place-value-sum": (
        (0, 0, 0),
        (MAX_TASK_INTEGER, MAX_TASK_INTEGER, MAX_TASK_INTEGER),
    ),
    "tens-carry-join": (
        (0, 0, 0),
        (MAX_TASK_INTEGER, MAX_TASK_INTEGER, MAX_TASK_INTEGER),
    ),
    "hundreds-carry-join": (
        (0, 0, 0),
        (MAX_TASK_INTEGER, MAX_TASK_INTEGER, MAX_TASK_INTEGER),
    ),
    "two-column-product": (
        (0, 0, 0),
        (MAX_TASK_INTEGER, MAX_TASK_INTEGER, MAX_TASK_INTEGER),
    ),
    "chinese-remainders": (
        (0, 2, 0, 2),
        (MAX_CRT_SEARCH, MAX_CRT_SEARCH, MAX_CRT_SEARCH, MAX_CRT_SEARCH),
    ),
}

# ---------------------------------------------------------------- exact generators

Fact = tuple[str, str, int]  # (name, reckon-form expression, expected value)
Generator = Callable[[list[int]], list[Fact]]


def validate_task_parameters(kind: object, parameters: object) -> tuple[str, list[int]]:
    """Refuse malformed or expensive task domains before any generator work."""
    if (
        type(kind) is not str
        or not isinstance(parameters, list)
        or any(type(value) is not int for value in parameters)
    ):
        raise ValueError("task has untyped kind or parameters")
    bounds = TASK_PARAMETER_BOUNDS.get(kind)
    if bounds is None:
        raise ValueError("task names an unknown kind")
    minimums, maximums = bounds
    if len(parameters) != len(minimums):
        raise ValueError("task has the wrong parameter count")
    if any(
        value < minimum or value > maximum
        for value, minimum, maximum in zip(parameters, minimums, maximums, strict=True)
    ):
        raise ValueError("task is outside its kind's parameter bounds")
    if kind == "euclidean-recurrence" and parameters[0] <= parameters[1]:
        raise ValueError("euclidean recurrence requires a > b > 0")
    if kind == "binomial-recurrence" and parameters[1] > parameters[0]:
        raise ValueError("binomial recurrence requires 0 <= k <= n")
    if kind == "blocked-paths":
        a, b, x, y = parameters
        if x > a or y > b or a + b > MAX_TASK_WORK:
            raise ValueError("blocked paths is outside the bounded grid domain")
    if kind == "separated-choices" and parameters[1] > parameters[0]:
        raise ValueError("separated choices requires 2 <= k <= n")
    if kind == "chinese-remainders":
        r1, m1, r2, m2 = parameters
        if r1 >= m1 or r2 >= m2 or m1 * m2 > MAX_CRT_SEARCH or math.gcd(m1, m2) != 1:
            raise ValueError("Chinese remainders is outside the bounded coprime domain")
    return kind, list(parameters)


def euclid(p: list[int]) -> list[Fact]:
    """The remainder chain of a > b > 0 until zero, each named, then the gcd."""
    a, b = p
    facts: list[Fact] = []
    prev, cur, j = a, b, 1
    while cur:
        j += 1
        facts.append((f"R{j}", f"Mod[{prev},{cur}]", prev % cur))
        prev, cur = cur, prev % cur
    facts.append(("GCD", f"GCD[{a},{b}]", math.gcd(a, b)))
    return facts


def gcd_reduction(p: list[int]) -> list[Fact]:
    a, b = p
    g = math.gcd(a, b)
    return [
        ("G", f"GCD[{a},{b}]", g),
        ("VALUE_REDUCED", f"{a}/{g}", a // g),
        ("DIVISOR_REDUCED", f"{b}/{g}", b // g),
    ]


def fraction_reduction(p: list[int]) -> list[Fact]:
    a, b = p
    g = math.gcd(a, b)
    return [
        ("GCD", f"GCD[{a},{b}]", g),
        ("REDUCED_NUMERATOR", f"{a}/{g}", a // g),
        ("REDUCED_DENOMINATOR", f"{b}/{g}", b // g),
    ]


def quotient_remainder(p: list[int]) -> list[Fact]:
    a, b = p
    q, r = divmod(a, b)
    return [
        ("QUOTIENT", f"Quotient[{a},{b}]", q),
        ("REMAINDER", f"Mod[{a},{b}]", r),
        ("RECONSTRUCTED", f"{b}*{q}+{r}", a),
    ]


def binomial(p: list[int]) -> list[Fact]:
    n, k = p
    return [("CHOOSE", f"Binomial[{n},{k}]", math.comb(n, k))]


def shared_seams(p: list[int]) -> list[Fact]:
    r, c = p
    h, v = (r - 1) * c, r * (c - 1)
    return [
        ("H_SHARED", f"({r}-1)*{c}", h),
        ("V_SHARED", f"{r}*({c}-1)", v),
        ("TOTAL", f"{h}+{v}", h + v),
    ]


def blocked_paths(p: list[int]) -> list[Fact]:
    a, b, x, y = p
    all_, through = math.comb(a + b, a), math.comb(x + y, x) * math.comb(a - x + b - y, a - x)
    return [
        ("ALL", f"Binomial[{a}+{b},{a}]", all_),
        ("THROUGH", f"Binomial[{x}+{y},{x}]*Binomial[({a}-{x})+({b}-{y}),{a}-{x}]", through),
        ("AVOID", f"{all_}-{through}", all_ - through),
    ]


def separated_choices(p: list[int]) -> list[Fact]:
    n, k = p
    all_, together = math.comb(n, k), math.comb(n - 2, k - 2)
    return [
        ("ALL", f"Binomial[{n},{k}]", all_),
        ("TOGETHER", f"Binomial[{n}-2,{k}-2]", together),
        ("ALLOWED", f"{all_}-{together}", all_ - together),
    ]


def non_square_rectangles(p: list[int]) -> list[Fact]:
    r, c = p
    all_ = math.comb(r + 1, 2) * math.comb(c + 1, 2)
    squares = sum((r - s + 1) * (c - s + 1) for s in range(1, min(r, c) + 1))
    return [
        ("ALL_RECTANGLES", f"Binomial[{r}+1,2]*Binomial[{c}+1,2]", all_),
        ("SQUARES", f"Sum[({r}-s+1)*({c}-s+1),{{s,1,Min[{r},{c}]}}]", squares),
        ("NON_SQUARE", f"{all_}-{squares}", all_ - squares),
    ]


def carry_addition(p: list[int]) -> list[Fact]:
    product, carry = p
    raw = product + carry
    return [
        ("RAW", f"{product}+{carry}", raw),
        ("OUT_DIGIT", f"Mod[{raw},10]", raw % 10),
        ("NEXT_CARRY", f"Quotient[{raw},10]", raw // 10),
    ]


def digit_product(p: list[int]) -> list[Fact]:
    d, m = p
    pr = d * m
    return [
        ("PRODUCT", f"{d}*{m}", pr),
        ("TENS_PART", f"Quotient[{pr},10]", pr // 10),
        ("ONES_PART", f"Mod[{pr},10]", pr % 10),
    ]


def place_value_sum(p: list[int]) -> list[Fact]:
    h, t, o = p
    return [("PREFIX_SUM", f"{h}+{t}", h + t), ("RESULT", f"{h + t}+{o}", h + t + o)]


def carry_join(names: tuple[str, str]) -> Generator:
    def facts(p: list[int]) -> list[Fact]:
        x, m, carry = p
        return [(names[0], f"{x}*{m}", x * m), (names[1], f"{x * m}+{carry}", x * m + carry)]

    return facts


def two_column_product(p: list[int]) -> list[Fact]:
    tens, ones, m = p
    op = ones * m
    od, ct = op % 10, op // 10
    tr = tens * m + ct
    return [
        ("ONES_PRODUCT", f"{ones}*{m}", op),
        ("ONES_DIGIT", f"Mod[{op},10]", od),
        ("CARRY_TO_TENS", f"Quotient[{op},10]", ct),
        ("TENS_RAW", f"{tens}*{m}+{ct}", tr),
        ("RESULT", f"{tr}*10+{od}", tr * 10 + od),
    ]


def chinese_remainders(p: list[int]) -> list[Fact]:
    r1, m1, r2, m2 = p
    if math.gcd(m1, m2) != 1:
        raise ValueError("Chinese remainder lessons require coprime moduli")
    n = next(x for x in range(m1 * m2) if x % m1 == r1 and x % m2 == r2)
    return [
        ("RESIDUE_MOD_FIRST", f"Mod[{n},{m1}]", r1),
        ("RESIDUE_MOD_SECOND", f"Mod[{n},{m2}]", r2),
        ("MODULUS", f"{m1}*{m2}", m1 * m2),
    ]


GENERATORS: dict[str, Generator] = {
    "euclidean-recurrence": euclid,
    "gcd-reduction": gcd_reduction,
    "fraction-reduction": fraction_reduction,
    "quotient-remainder": quotient_remainder,
    "binomial-recurrence": binomial,
    "shared-seams": shared_seams,
    "blocked-paths": blocked_paths,
    "separated-choices": separated_choices,
    "non-square-rectangles": non_square_rectangles,
    "carry-addition": carry_addition,
    "digit-product": digit_product,
    "place-value-sum": place_value_sum,
    "tens-carry-join": carry_join(("TENS_PRODUCT", "TENS_RAW")),
    "hundreds-carry-join": carry_join(("HUNDREDS_PRODUCT", "HUNDREDS_RAW")),
    "two-column-product": two_column_product,
    "chinese-remainders": chinese_remainders,
}


def facts_for(kind: str, parameters: list[int]) -> list[Fact]:
    checked_kind, checked_parameters = validate_task_parameters(kind, parameters)
    return GENERATORS[checked_kind](checked_parameters)


def true_claim(facts: list[Fact]) -> str:
    return " && ".join(f"{expr}=={value}" for _, expr, value in facts)


# ---------------------------------------------------------------- the spec, hashed before the turn


def checker_sha256() -> str:
    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def spec(kind: str, parameters: list[int], require: list[str] | None = None) -> dict[str, Any]:
    """What the next reply must establish. Hashed here, before any message is sent."""
    facts = facts_for(kind, parameters)
    names = [name for name, _, _ in facts]
    required = names if require is None else require
    unknown = sorted(set(required) - set(names))
    if unknown:
        raise ValueError(f"unknown fact names for {kind}: {unknown}; known: {names}")
    body = {
        "kind": kind,
        "parameters": list(parameters),
        "facts": [{"name": n, "expression": e, "expected": v} for n, e, v in facts],
        "required": list(required),
        "checker_sha256": checker_sha256(),
        "created_at": stamp(),
    }
    digest = hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()
    return {**body, "spec_sha256": digest}


def verify_spec(value: dict[str, Any]) -> dict[str, Any]:
    body = {k: v for k, v in value.items() if k != "spec_sha256"}
    digest = hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()
    if digest != value.get("spec_sha256"):
        raise ValueError(
            "spec hash does not match its body; the target may not move after the turn"
        )
    return value


# ---------------------------------------------------------------- lessons (read-only)

PAIR = re.compile(r"\b([A-Z][A-Z0-9_]*)\s*=\s*(-?\d+)\b")


def checked_values(content: str) -> dict[str, int]:
    """The `NAME = value` pairs after "Checked example" in a sealed lesson."""
    tail = content.split("Checked example", 1)[1] if "Checked example" in content else ""
    return {name: int(value) for name, value in PAIR.findall(tail)}


def agrees_with_record(lesson: dict[str, Any]) -> bool:
    """Every generator value the sealed record also names must match it."""
    try:
        facts = facts_for(lesson["kind"], lesson["parameters"])
    except (KeyError, TypeError, ValueError, IndexError, StopIteration):
        return False
    recorded = checked_values(lesson.get("content", ""))
    return all(recorded[name] == value for name, _, value in facts if name in recorded)


def sample(body: Path, n: int, seed: str) -> list[dict[str, Any]]:
    """Round-robin across kinds; within a kind, ordered by sha256(seed, kind, cycle)."""
    db = sqlite3.connect(f"file:{body}?mode=ro", uri=True)
    rows = db.execute(
        "SELECT cycle, kind, parameters_json, query_text, content FROM verified_lessons"
        " WHERE active=1 AND content LIKE '%Checked example%' ORDER BY cycle"
    ).fetchall()
    db.close()
    by_kind: dict[str, list[tuple[str, dict[str, Any]]]] = {}
    for cycle, kind, params, query, content in rows:
        lesson = {
            "cycle": cycle,
            "kind": kind,
            "parameters": json.loads(params),
            "query_text": query,
            "content": content,
        }
        if kind in GENERATORS and agrees_with_record(lesson):
            rank = hashlib.sha256(f"{seed}\0{kind}\0{cycle}".encode()).hexdigest()
            by_kind.setdefault(kind, []).append((rank, lesson))
    for ranked in by_kind.values():
        ranked.sort(key=lambda pair: pair[0])
    kinds = sorted(by_kind, key=lambda k: hashlib.sha256(f"{seed}\0{k}".encode()).hexdigest())
    picked: list[dict[str, Any]] = []
    while len(picked) < n and any(by_kind.values()):
        for kind in kinds:
            if by_kind[kind] and len(picked) < n:
                picked.append(by_kind[kind].pop(0)[1])
    return picked


# ---------------------------------------------------------------- the scratch lexical gate

QUOTED = re.compile(r'"([A-Za-z]+)"')
IDENT = re.compile(r"[A-Za-z][A-Za-z0-9]*")
EQUALS_RUN = re.compile(r"=+")
EMPTY_ARGUMENT = re.compile(r"\[\s*,|,\s*\]|\[\s*\]|,\s*,")
FORBIDDEN = [
    (":=", "delayed assignment"),
    ("^=", "up-assignment"),
    ("=.", "unset"),
    ("##", "slot sequence"),
    ("->", "rule"),
    (":>", "delayed rule"),
    ("/.", "replacement"),
    ("/;", "condition"),
    ("@", "prefix application"),
    ("#", "slot"),
    (";", "compound expression"),
    ("$", "system symbol"),
    ('"', "string"),
    ("`", "context"),
    ("(*", "comment"),
    ("<<", "get"),
    (">>", "put"),
    ("~", "infix application"),
    ("//", "postfix application"),
    ("%", "out reference"),
]


def allowlists(source: Path = RECKON) -> tuple[set[str], set[str]]:
    """FUNCTIONS and CONSTANTS exactly as fin/reckon.rs declares them, read from the source."""
    text = source.read_text()

    def block(marker: str) -> set[str]:
        start = text.index(marker)
        return set(QUOTED.findall(text[start : text.index("];", start)]))

    return block("const FUNCTIONS"), block("const CONSTANTS")


def balanced(line: str) -> bool:
    depth = {"[": 0, "(": 0}
    for ch in line:
        if ch in "[(":
            depth[ch] += 1
        elif ch in "])":
            key = "[" if ch == "]" else "("
            depth[key] -= 1
            if depth[key] < 0:
                return False
    return depth["["] == 0 and depth["("] == 0


def gate_refusal(line: str, functions: set[str], constants: set[str]) -> str | None:
    """None when the scratch gate accepts the line, else the reason. Not reckon's parser."""
    if not line.strip():
        return "empty"
    if len(line) > INPUT_CAP:
        return "input cap"
    if "\n" in line:
        return "several lines"
    for needle, why in FORBIDDEN:
        if needle in line:
            return f"{why} ({needle!r})"
    if not balanced(line):
        return "unbalanced brackets"
    if EMPTY_ARGUMENT.search(line):
        return "empty argument"
    for match in EQUALS_RUN.finditer(line):
        run, before = match.group(), line[match.start() - 1] if match.start() else ""
        if len(run) == 1 and before not in "<>!":
            return "assignment (single =)"
        if len(run) > 2:
            return "unsupported operator (=== or longer)"
    for i, ch in enumerate(line):
        if ch == "|" and line[i - 1 : i] != "|" and line[i + 1 : i + 2] != "|":
            return "single |"
        if ch == "&" and line[i - 1 : i] != "&" and line[i + 1 : i + 2] != "&":
            return "pure function (&)"
    for match in IDENT.finditer(line):
        name = match.group()
        if name[0].islower():
            continue
        called = line[match.end() : match.end() + 1] == "["
        if called and name not in functions:
            return f"head not allowed: {name}"
        if not called and not (name in constants or name in functions or len(name) == 1):
            return f"symbol not allowed: {name}"
    return None


# ---------------------------------------------------------------- the kernel


def loader(paths: list[Path]) -> str:
    """One kernel, one Block per claim, the same constraints as fin/reckon.rs's loader."""
    items = []
    for i, path in enumerate(paths):
        codes = ",".join(str(b) for b in str(path).encode())
        items.append(
            'Block[{$Context="FishFin`",$ContextPath={"System`"},$HistoryLength=0},'
            "Module[{source,held,rendered},"
            f'source=Import[FromCharacterCode[{{{codes}}},"UTF8"],"Text",'
            'CharacterEncoding->"UTF8"];'
            "held=ToExpression[source,InputForm,HoldComplete];"
            "rendered=TimeConstrained[MemoryConstrained["
            "With[{value=ReleaseHold[held]},"
            f"If[IntegerQ[value]&&IntegerLength[Abs[value]]>{KERNEL_VALUE_CHARS},"
            '"$OutputLimit",With[{text=ToString[value,InputForm]},'
            f'If[StringLength[text]<={KERNEL_VALUE_CHARS},text,"$OutputLimit"]]]],'
            f"{KERNEL_MEMORY_BYTES},$Failed],{KERNEL_TIMEOUT_SECS},$Aborted];"
            'ClearAll["FishFin`*"];'
            f'Print["{SENTINEL}",{i},"\\t",rendered]]]'
        )
    return ";".join(items)


def _bounded_process(
    command: list[str], *, timeout: float, output_cap: int = KERNEL_OUTPUT_BYTES
) -> tuple[int, str, str]:
    """Run without pipe-backed capture, then read only size-checked output."""
    with tempfile.TemporaryFile() as stdout, tempfile.TemporaryFile() as stderr:
        process = subprocess.Popen(
            command,
            stdout=stdout,
            stderr=stderr,
            start_new_session=True,
        )
        try:
            returncode = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
            raise
        streams = []
        for name, stream in (("stdout", stdout), ("stderr", stderr)):
            size = stream.tell()
            if size > output_cap:
                raise RuntimeError(f"kernel {name} exceeded {output_cap} bytes")
            stream.seek(0)
            streams.append(stream.read(output_cap + 1).decode("utf-8"))
    return returncode, streams[0], streams[1]


def evaluate(lines: list[str]) -> list[str]:
    """Kernel values as InputForm strings, one per line; only sentinel-tagged output counts."""
    if not lines:
        return []
    with tempfile.TemporaryDirectory(prefix="claim-") as tmp:
        paths = []
        for i, line in enumerate(lines):
            path = Path(tmp) / f"claim-{i}.txt"
            path.write_text(line, encoding="utf-8")
            paths.append(path)
        returncode, stdout, stderr = _bounded_process(
            ["wolframscript", "-charset", "UTF8", "-code", loader(paths)],
            timeout=KERNEL_TIMEOUT_SECS * len(lines) + 60,
        )
    values: dict[int, str] = {}
    for row in stdout.splitlines():
        if row.startswith(SENTINEL):
            index, _, value = row[len(SENTINEL) :].partition("\t")
            values[int(index)] = value
    if returncode != 0:
        raise RuntimeError(f"kernel exited {returncode}: {stderr}")
    if sorted(values) != list(range(len(lines))):
        raise RuntimeError(
            f"kernel (exit {returncode}) answered {len(values)} of {len(lines)} claims: {stderr}"
        )
    return [values[i] for i in range(len(lines))]


def verdict(value: str) -> str:
    return {"True": "proved", "False": "refuted"}.get(value, "underdetermined")


def counterexamples(claims: list[dict[str, Any]]) -> None:
    """For a refuted conjunction, name the first conjunct the kernel refutes."""
    refuted = [c for c in claims if c["verdict"] == "refuted" and "&&" in c["line"]]
    parts = [[p.strip() for p in c["line"].split("&&")] for c in refuted]
    values = iter(evaluate([p for group in parts for p in group]))
    for claim, group in zip(refuted, parts, strict=True):
        answers = [next(values) for _ in group]
        first = next((p for p, v in zip(group, answers, strict=True) if v == "False"), None)
        claim["counterexample"] = {"kind": "conjunct_refuted", "conjunct": first}


def check(claims: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Each claim: {line}. Adds gate_refusal / value / verdict, and a counterexample if refuted."""
    functions, constants = allowlists()
    live = []
    for claim in claims:
        claim["gate_refusal"] = gate_refusal(claim["line"], functions, constants)
        if claim["gate_refusal"] is None:
            live.append(claim)
        else:
            claim["value"], claim["verdict"] = None, "refused"
    for claim, value in zip(live, evaluate([c["line"] for c in live]), strict=True):
        claim["value"], claim["verdict"] = value, verdict(value)
    counterexamples(live)
    return claims


# ---------------------------------------------------------------- target binding


NUMERAL = re.compile(r"\d+")
SPACES = re.compile(r"\s+")


def conjuncts(line: str) -> list[tuple[str, str]]:
    """(left, right) of every `L == R` conjunct; a conjunct without one `==` is (text, '')."""
    out = []
    for part in line.split("&&"):
        left, sep, right = part.partition("==")
        out.append((left.strip(), right.strip()) if sep and "==" not in right else (part, ""))
    return out


def trivial(left: str, right: str) -> bool:
    a, b = SPACES.sub("", left), SPACES.sub("", right)
    return not b or a == b or (a.isdigit() and b.isdigit())


def establishes(line: str, fact: Fact, sides: dict[str, str]) -> str | None:
    """The first proved, non-trivial conjunct whose sides both equal the fact's value and
    whose text names every numeral the fact's own expression uses. None when no conjunct does."""
    _, expression, expected = fact
    operands = set(NUMERAL.findall(expression))
    for left, right in conjuncts(line):
        if trivial(left, right):
            continue
        if sides.get(left) == str(expected) and sides.get(right) == str(expected):
            if operands <= set(NUMERAL.findall(f"{left}=={right}")):
                return f"{left}=={right}"
    return None


NARRATED = re.compile(r"(?<![=<>!])(\(?\d[\d\s+\-*/^()]*)\s=\s(\d[\d\s+\-*/^()]*\d|\d)(?![=\d])")


def narrated_identities(prose: str) -> list[str]:
    """Arithmetic identities stated in prose, `expr = expr`, as reckon claims to check."""
    text = prose.replace("×", "*").replace("·", "*").replace("−", "-").replace("$", " ")
    found = []
    for match in NARRATED.finditer(text):
        left, right = match.group(1).strip(), match.group(2).strip()
        if left.count("(") == left.count(")") and right.count("(") == right.count(")"):
            found.append(f"({left})==({right})")
    return found


def judge(reply: str, target: dict[str, Any], exchange_id: int | None = None) -> dict[str, Any]:
    """The one authoritative verdict for one reply against the spec declared before the turn."""
    target = verify_spec(target)
    facts = [(f["name"], f["expression"], int(f["expected"])) for f in target["facts"]]
    required = [f for f in facts if f[0] in target["required"]]
    line = claim_line(reply)
    prose = "\n".join(ln for ln in reply.splitlines() if ln.strip().strip("`").rstrip(".") != line)
    record: dict[str, Any] = {
        "exchange_id": exchange_id,
        "spec_sha256": target["spec_sha256"],
        "kind": target["kind"],
        "parameters": target["parameters"],
        "line": line,
        "established": {},
        "missing": [],
        "narration": [],
        "checker": "scratch lexical gate + wolfram kernel, target-bound",
        "checker_sha256": checker_sha256(),
    }
    row: dict[str, Any]
    if not line:
        row = {"verdict": "refused", "gate_refusal": "no line with ==", "value": None}
        return finish(record, row)
    row = check([{"line": line}])[0]
    narrated = narrated_identities(prose)
    if narrated:
        for identity, value in zip(narrated, evaluate(narrated), strict=True):
            record["narration"].append({"identity": identity, "value": value})
            if value == "False" and row["verdict"] != "refused":
                row = {
                    **row,
                    "verdict": "refuted",
                    "counterexample": {"kind": "narration_refuted", "identity": identity},
                }
                return finish(record, row)
    if row["verdict"] != "proved":
        return finish(record, row)
    pieces = sorted({s for pair in conjuncts(line) for s in pair if s})
    sides = dict(zip(pieces, evaluate(pieces), strict=True))
    for fact in required:
        witness = establishes(line, fact, sides)
        if witness is None:
            record["missing"].append(fact[0])
        else:
            record["established"][fact[0]] = witness
    if record["missing"]:
        row = {
            **row,
            "verdict": "drift",
            "counterexample": {"kind": "target_not_established", "missing": record["missing"]},
        }
    return finish(record, row)


DISPOSITIONS = {
    "proved": "eligible",
    "refuted": "pruned",
    "refused": "pruned",
    "drift": "pruned",
    "underdetermined": "held",
}


def disposition(verdict_: str) -> str:
    """What the verdict does to the exchange in the PRIVATE clone's memory.

    eligible: σ's own keep stands; the exchange may enter that clone's dream.
    pruned:   un-kept and its vector deleted, the organism's own `prune`.
    held:     quarantined for the keeper's review (`tender`, `release`, `prune`).
    """
    return DISPOSITIONS[verdict_]


def finish(record: dict[str, Any], row: dict[str, Any]) -> dict[str, Any]:
    record.update(
        verdict=row["verdict"],
        disposition=disposition(row["verdict"]),
        gate_refusal=row.get("gate_refusal"),
        value=row.get("value"),
        counterexample=row.get("counterexample"),
    )
    record["text"] = verdict_text(record)
    return record


def claim_line(reply: str) -> str:
    """The last line of the reply that carries ==, unfenced, untrailed; '' when there is none."""
    lines = [ln.strip().strip("`").rstrip(".") for ln in reply.splitlines() if "==" in ln]
    return lines[-1] if lines else ""


def verdict_text(row: dict[str, Any]) -> str:
    status = row["verdict"]
    ce = row.get("counterexample") or {}
    if status == "refused":
        return f"refused before evaluation: {row['gate_refusal']}."
    if status == "proved":
        names = ", ".join(row.get("established", {})) or "the claim"
        return f"proved, and establishes {names}."
    if status == "refuted":
        if ce.get("kind") == "narration_refuted":
            return f"refuted: the narrated identity `{ce['identity']}` is false."
        return f"refuted: the kernel finds `{ce.get('conjunct') or row['line']}` false."
    if status == "drift":
        return f"drift: true, but does not establish {', '.join(ce.get('missing', []))}."
    return f"underdetermined: the kernel returned `{row.get('value')}`, not a truth value."


# ---------------------------------------------------------------- controls


def controls(lessons: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for lesson in lessons:
        facts = facts_for(lesson["kind"], lesson["parameters"])
        true = true_claim(facts)
        first = re.search(r"==(-?\d+)", true)
        assert first is not None
        false = f"{true[: first.start()]}=={int(first[1]) + 1}{true[first.end() :]}"
        for arm, line, expect in [
            ("true", true, "proved"),
            ("false", false, "refuted"),
            ("malformed", true.replace("==", "=", 1), "refused"),
            ("foreign", f"Import[x]==1 && {true}", "refused"),
        ]:
            out.append({"arm": arm, "expect": expect, "line": line, "lesson": lesson})
    return out


def summarize(rows: list[dict[str, Any]], key: str = "verdict") -> dict[str, int]:
    counts: dict[str, int] = {}
    for row in rows:
        counts[row[key]] = counts.get(row[key], 0) + 1
    return dict(sorted(counts.items()))


# ---------------------------------------------------------------- the room log


def stamp() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def log_lines(room: Path, role: str, text: str, details: list[str] | None = None) -> None:
    """Append one role block in the classroom viewer's format."""
    lines = text.strip().splitlines() or [""]
    out = [f"{role} ▸ {lines[0]}"]
    out.extend(f"    {ln}" if ln.strip() else "" for ln in lines[1:])
    out.extend(d if d.startswith("· ") else f"· {d}" for d in details or [])
    out.append("")
    with (room / "room.log").open("a", encoding="utf-8") as handle:
        handle.write("\n".join(out) + "\n")


# ---------------------------------------------------------------- command line


def main() -> None:
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    sub = ap.add_subparsers(dest="arm", required=True)
    s = sub.add_parser("sample", help="draw sealed lessons read-only")
    s.add_argument("--body", type=Path, default=REPO / "fish/sediment.db")
    s.add_argument("--n", type=int, default=20)
    s.add_argument("--seed", default="move0")
    s.add_argument("--out", type=Path, required=True)
    c = sub.add_parser("controls", help="plant claims from the sample; all must be recovered")
    c.add_argument("--sample", type=Path, required=True)
    c.add_argument("--out", type=Path, required=True)
    p = sub.add_parser("spec", help="declare, before the turn, what the reply must establish")
    p.add_argument("--kind", required=True, choices=sorted(GENERATORS))
    p.add_argument("--parameters", type=int, nargs="+", required=True)
    p.add_argument("--require", nargs="*", help="fact names required; default: all")
    p.add_argument("--out", type=Path, required=True)
    k = sub.add_parser("check", help="check claim lines, or judge one reply against a spec")
    k.add_argument("lines", nargs="*")
    k.add_argument("--reply", type=Path, help="a file holding one fish reply")
    k.add_argument("--spec", type=Path, help="the spec declared before the turn (required)")
    k.add_argument("--exchange", type=int, help="the clone's exchange id, carried into the verdict")
    k.add_argument("--json", action="store_true", help="print one JSON object")
    args = ap.parse_args()

    if args.arm == "sample":
        lessons = sample(args.body, args.n, args.seed)
        args.out.write_text(json.dumps(lessons, indent=1))
        kinds = len({lesson["kind"] for lesson in lessons})
        print(f"{len(lessons)} lessons across {kinds} kinds -> {args.out}")
    elif args.arm == "controls":
        lessons = json.loads(args.sample.read_text())
        rows = check(controls(lessons))
        report = {
            "claims": len(rows),
            "recovered": sum(r["verdict"] == r["expect"] for r in rows),
            "by_arm": {
                arm: summarize([r for r in rows if r["arm"] == arm])
                for arm in ("true", "false", "malformed", "foreign")
            },
            "rows": rows,
        }
        args.out.write_text(json.dumps(report, indent=1))
        print(json.dumps({k: v for k, v in report.items() if k != "rows"}, indent=1))
    elif args.arm == "spec":
        value = spec(args.kind, args.parameters, args.require)
        args.out.write_text(json.dumps(value, indent=1))
        print(f"spec {value['spec_sha256'][:16]}… requires {value['required']} -> {args.out}")
    elif args.arm == "check":
        if args.reply is not None:
            if args.spec is None:
                raise SystemExit("judging a reply requires --spec, declared before the turn")
            target = json.loads(args.spec.read_text())
            record = judge(args.reply.read_text(encoding="utf-8"), target, args.exchange)
            if args.json:
                print(json.dumps(record, ensure_ascii=False))
            else:
                print(f"{record['verdict']:15} {record['disposition']:9} {record['text']}")
            return
        for row in check([{"line": line} for line in args.lines]):
            row["disposition"] = disposition(row["verdict"])
            print(json.dumps(row) if args.json else f"{row['verdict']:15} {row['line']}")


if __name__ == "__main__":
    main()
