"""Ground truth for the arithmetic primitives beneath exact cancellation."""

from __future__ import annotations

import hashlib
import math
import re
from dataclasses import dataclass

from fish.lab.counted_structure import assignment_truth_with_tables

START_CYCLE = 3437
KINDS = ("gcd-reduction", "column-step")

METHODS = {
    "gcd-reduction": (
        "Set G=gcd(VALUE,DIVISOR), VALUE_REDUCED=VALUE/G, and DIVISOR_REDUCED=DIVISOR/G"
    ),
    "column-step": (
        "Set RAW=DIGIT*MULTIPLIER+INCOMING_CARRY, OUT_DIGIT=RAW mod 10, and "
        "NEXT_CARRY=RAW div 10 using integer quotient"
    ),
}


@dataclass(frozen=True)
class Problem:
    kind: str
    parameters: tuple[int, ...]

    @property
    def assignments(self) -> dict[str, int]:
        return states(self.kind, self.parameters)

    @property
    def method(self) -> str:
        return METHODS[self.kind]

    def _contract(self) -> str:
        return "; ".join(f"{label} = integer" for label in self.assignments)

    def prompt(self) -> str:
        return (
            f"{statement(self.kind, self.parameters)} Return exactly these three assignments "
            f"on one line, with no prose: {self._contract()}."
        )

    def nudge(self) -> str:
        return (
            f"{statement(self.kind, self.parameters)} Use this relation: {self.method}. "
            f"Return exactly {self._contract()} and no prose."
        )

    def repair(self) -> str:
        if self.kind == "gcd-reduction":
            value, divisor = self.parameters
            check = f"Check both identities {value}=G*VALUE_REDUCED and {divisor}=G*DIVISOR_REDUCED"
        else:
            check = "Check RAW=10*NEXT_CARRY+OUT_DIGIT and 0<=OUT_DIGIT<10"
        return (
            f"{statement(self.kind, self.parameters)} Your preceding values did not all "
            "satisfy the checked relation. "
            f"{check}. Recompute in your own mind, then return exactly "
            f"{self._contract()} and no prose."
        )

    def record(self) -> str:
        return "; ".join(f"{label} = {value}" for label, value in self.assignments.items())


def states(kind: str, parameters: tuple[int, ...]) -> dict[str, int]:
    if kind == "gcd-reduction":
        if len(parameters) != 2:
            raise ValueError("gcd reduction requires value and divisor")
        value, divisor = parameters
        if value <= 0 or divisor <= 0:
            raise ValueError("gcd reduction parameters must be positive")
        common = math.gcd(value, divisor)
        return {
            "G": common,
            "VALUE_REDUCED": value // common,
            "DIVISOR_REDUCED": divisor // common,
        }
    if kind == "column-step":
        if len(parameters) != 3:
            raise ValueError("column step requires digit, multiplier, and carry")
        digit, multiplier, carry = parameters
        if not 0 <= digit <= 9 or not 2 <= multiplier <= 9 or not 0 <= carry < multiplier:
            raise ValueError("invalid base-ten column state")
        raw = digit * multiplier + carry
        return {"RAW": raw, "OUT_DIGIT": raw % 10, "NEXT_CARRY": raw // 10}
    raise ValueError(f"unknown arithmetic component: {kind}")


def statement(kind: str, parameters: tuple[int, ...]) -> str:
    if kind == "gcd-reduction":
        value, divisor = parameters
        return (
            f"GCD-reduction state question: reduce VALUE={value} and DIVISOR={divisor} by "
            "their greatest common divisor."
        )
    if kind == "column-step":
        digit, multiplier, carry = parameters
        return (
            "Column-step state question: in one right-to-left base-ten multiplication column, "
            f"DIGIT={digit}, MULTIPLIER={multiplier}, and INCOMING_CARRY={carry}."
        )
    raise ValueError(f"unknown arithmetic component: {kind}")


def problem_from_prompt(prompt: str) -> Problem | None:
    reduction = re.search(
        r"GCD-reduction state question: reduce VALUE=(\d+) and DIVISOR=(\d+)", prompt
    )
    if reduction is not None:
        return Problem("gcd-reduction", tuple(int(value) for value in reduction.groups()))
    column = re.search(
        r"Column-step state question:.*DIGIT=(\d+), MULTIPLIER=(\d+), "
        r"and INCOMING_CARRY=(\d+)",
        prompt,
    )
    if column is not None:
        return Problem("column-step", tuple(int(value) for value in column.groups()))
    return None


def lesson_reply_lands(prompt: str, reply: str) -> bool | None:
    problem = problem_from_prompt(prompt)
    if problem is None:
        return None
    return assignment_truth_with_tables(reply, problem.assignments)


def candidates(kind: str) -> list[tuple[int, ...]]:
    values: list[tuple[int, ...]]
    if kind == "gcd-reduction":
        values = []
        for value in range(4_000, 30_001, 37):
            for divisor in range(4, 20):
                common = math.gcd(value, divisor)
                if 1 < common < divisor:
                    values.append((value, divisor))
    elif kind == "column-step":
        values = [
            (digit, multiplier, carry)
            for digit in range(10)
            for multiplier in range(2, 10)
            for carry in range(multiplier)
            if digit * multiplier + carry >= 10
        ]
    else:
        raise ValueError(f"unknown arithmetic component: {kind}")
    values.sort(key=lambda item: hashlib.sha256(f"{kind}:{item}".encode()).digest())
    return values


def lesson_problem(cycle: int) -> tuple[Problem, int]:
    if cycle < START_CYCLE:
        raise ValueError(f"arithmetic-component lessons begin at cycle {START_CYCLE}")
    offset = cycle - START_CYCLE
    block, position = divmod(offset, 4)
    kind = KINDS[position // 2]
    occurrence = block * 2 + position % 2
    pool = candidates(kind)
    return Problem(kind, pool[occurrence % len(pool)]), occurrence
