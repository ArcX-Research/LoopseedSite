# Publishing the paper for Google Scholar

Google Scholar indexes scholarly material hosted on the public web. A manually
added profile entry is separate from discovery of the full paper in search.
Official guidance: https://scholar.google.com/intl/en/scholar/inclusion.html and
https://scholar.google.com/intl/en/scholar/citations.html (checked 11 September 2026).

## Prepared publication addresses

- Paper page: https://loopseed.io/papers/dynamical-synthesis.html
- Full text: https://loopseed.io/papers/dynamical-synthesis.pdf
- Mathematical records: https://loopseed.io/papers/dynamical-synthesis-mathematics-evidence.zip
- Editable paper and figures: https://loopseed.io/papers/dynamical-synthesis-source.zip
- Citation: https://loopseed.io/papers/dynamical-synthesis.bib (RIS also available)

The HTML page contains the complete manuscript abstract without JavaScript, login,
or a click to reveal it. Its title, author, publication date and absolute PDF URL
use Scholar's supported citation meta tags. The PDF and abstract share the same
directory. The homepage contains a plain HTML link to this page before the app
loads, as well as a link in the rendered homepage. The PDF has searchable text,
embedded fonts, a title and author byline, and a References section. It is below
Scholar's 5 MB file limit.

These are the intended public URLs. Generating files locally does not publish
them and does not establish that Scholar has indexed them.

## Publication steps

1. Publish the reviewed LoopseedSite build to the domain's existing host. Confirm
   the page, PDF and evidence links return the intended files without signing in.
   Inspect both the HTML source and the PDF; a local preview is not sufficient.
2. Keep these addresses stable and accessible to Googlebot. If an address changes,
   redirect it to the corresponding paper, rather than the homepage. Scholar
   controls inclusion and timing; metadata cannot guarantee indexing.
3. In the author's Google Scholar profile, use Add articles and search for the
   title. If it is absent, Add article manually can create the profile entry.
   Use Brian Ashiundu, the full paper title, and 2026. Dilate Technologies is the
   organisation under which the research was conducted. Do not name Google
   Scholar as a journal or imply journal review or Institute sponsorship.

A suitable citation is:

> Ashiundu, B. (2026). Dynamical Synthesis: Learning through Interaction.
> Dilate Technologies. https://loopseed.io/papers/dynamical-synthesis.html

## Regeneration

Use the paper's existing LaTeX build, then run:

```sh
python3 docs/papers/dynamical-synthesis/prepare_delivery.py --site ../LoopseedSite
```

This regenerates the mathematics evidence package and the HTML/BibTeX/RIS files,
and copies the rebuilt PDF and shared figures. It does not run a model, publish
the site, update a Scholar profile or contact readers.

The full private archive remains separate. The exported mathematics files have
their own manifest and describe every transformation and known reproduction gap.
