# Evidence audit and writing decisions

Prepared 11 September 2026 for the [working manuscript](manuscript.md). This is a retrospective audit of selected archived studies. It does not constitute public preregistration, independent replication or a new experiment.

## Claim boundaries

| Proposed statement | What the present evidence permits |
| --- | --- |
| External experience can improve a learning system. | A particular response adapter improved accepted outputs on new parameter instances within trained mathematical families. |
| The full synthesis loop causes that improvement. | Unmeasured: the principal comparison disabled retrieval and other interaction mechanisms. |
| Lower validation loss means better future behaviour. | Unsupported: the private response candidate reduced validation loss but failed its behavioural adoption criteria. |
| The system preserves everything useful it has learned. | Unsupported: the private comparison includes seven losses on earlier-skill controls. Other retention assessments were at a floor. |
| Human participation guarantees alignment. | Unsupported: an input term alone imposes no constraint on objectives, action selection or resistance to unauthorized changes. |
| An input from another system is independent evidence. | Unsupported: it can repeat the learner's own output or share its data and errors. Independence must be assessed for the claim and evidence path. |
| The framework prevents echo chambers. | Untested: the selected studies do not compare circular corroboration with externally specified evidence. |
| The framework can apply beyond language models. | A design scope to specify and test in additional implementations. The selected empirical evidence concerns Fish. |
| The studies independently replicate one another. | Incorrect: they share a programme, model lineage, task families and evaluation infrastructure. |

The original phrase “ensures both parties … play a huge role” is treated as a research intention. Following the user's clarification, *You* includes input from people, the environment and other systems beyond a declared boundary. The general operational question is whether task-relevant external evidence has an appropriate, lasting influence on decisions, with human correction as one application. Neither prediction accuracy nor mathematical correctness alone establishes this property.

## E1. Implemented state and observation

Sources: [implemented retrieval state](../../../fish/daemon/src/fast/state.rs), [discrepancy measures](../../../fish/daemon/src/skin/mod.rs), [embedding implementation](../../../fish/daemon/src/ledger/embed/mod.rs) and [architectural equation notes](../../EQUATION.md). The source snapshot identifies the reviewed implementation; it is not a record of every historical binary.

The state code adds the incoming-message embedding to a scaled embedding of the actual prior reply. It validates finite, dimension-compatible vectors and normalizes the sum for cosine retrieval. The persistent rework vector and transient sum are distinct. Calling this vector the entirety of the system's intelligence would erase other relevant state, parameters and memory.

The general indexed state/action specification in the manuscript is a proposed formal account. Its external-input variable, source distinctions, adoption variable and conditional Lipschitz analysis are not reported experimental discoveries. External input can depend on previous system actions; the fixed-input bound does not establish stability of the full coupled system and environment. The additive shorthand does not itself prove computability, convergence, resistance to circular feedback, corrigibility or alignment.

The echo-chamber account in Section 2.2 is an operational proposal. No empirical circular-feedback outcome is added to the saved studies. The discussion cites [Shumailov et al.](https://www.nature.com/articles/s41586-024-07566-y) on recursive generated-data training and [Gerstgrasser et al.](https://arxiv.org/abs/2404.01413) on retaining original data while accumulating generated data. Their results concern their studied training regimes; they do not validate Fish or prove that all synthetic feedback is harmful. The [2025 author correction](https://www.nature.com/articles/s41586-025-08905-3) to Shumailov et al. was checked; it corrects a coefficient label in the theoretical setup. Distributional model collapse is distinguished from circular corroboration during interaction.

The historical cosine discrepancy and later cosine/token-loss composite are different instruments. Neither is a correctness probability. Early downward discrepancy trends are observational and can reflect changing topics, participant behaviour, context and system revisions. They are not used as causal evidence of learning. Likewise, internal “entropy” labels for average embedding distances must not be presented as Shannon entropy without a specified probability distribution.

## E2. Clean formal transfer

Primary records:

- [Contemporaneous report](../../../fish/album/2026-09-04T0043-EAT-clean-formal-claim-transfer.md).
- [Frozen protocol](../../../data/fish/labs/claim-transfer-clean-2026-09-03T170409Z/protocol.json).
- [Verdict](../../../data/fish/labs/claim-transfer-clean-2026-09-03T170409Z/verdict.json), [audit bundle](../../../data/fish/labs/claim-transfer-clean-2026-09-03T170409Z/audit-bundle.json) and [AI review](../../../data/fish/labs/claim-transfer-clean-2026-09-03T170409Z/external-audit.json).
- [Candidate dataset manifest](../../../data/fish/labs/claude-claims-2026-09-02T131808Z/dreams/accepted-clean-2026-09-03T1915-EAT/manifest.json) and [shuffled dataset manifest](../../../data/fish/labs/claude-claims-2026-09-02T131808Z/dreams/shuffled-placebo-2026-09-03T164849.819255Z/manifest.json).
- [Candidate training configuration](../../../data/fish/labs/claude-claims-2026-09-02T131808Z/body/fish/water/adapters/claim-dream-clean-2026-09-03T1920-EAT/adapter_config.json) and [training record](../../../data/fish/labs/claude-claims-2026-09-02T131808Z/body/fish/water/adapters/claim-dream-clean-2026-09-03T1920-EAT/dream.json).

The frozen harness commit is `da445bb8de772f794766ca44a944e8ffff82c09a`. The protocol pins model, adapters and manifests; the verification script checks the two manifest byte hashes against those pins. It does not rehash multi-gigabyte model files. Recorded model identities therefore remain historical provenance, rather than a new verification of installed weights.

The primary setting is **names-only / loose-v2**. There are 64 tasks, with four parameter instances per family, four adapters and four prompt/grammar combinations: 1,024 requests. The top-level arm totals in the verdict pool conditions and must not be mistaken for the primary endpoint.

Whole-reply acceptance gives candidate 43/64, base 0/64, shuffled control 0/64 and retained prediction adapter 5/64. Four Chinese-remainder candidate replies lose machine-positive status after review, reducing 47 to 43. The family breakdown is ten families at 4/4, two-column product at 3/4 and five families at 0/4. “Transfer” here means new parameter instances, with every family represented in training. It does not mean transfer to unseen families.

The script reproduces the 43 gains, zero losses and 21 ties against both principal controls; verifies the discordant case-list lengths; and independently calculates the exact one-sided probability and the conservative paired lower bound. It also records all four prompt/grammar conditions. No reply is newly scored by this audit. AI review of existing machine-positive outputs remains fallible.

For gains \(g\), losses \(l\) and \(n\) pairs, the recorded exact calculation is

\[
p=\sum_{j=g}^{g+l}{g+l\choose j}2^{-(g+l)}.
\]

The lower difference bound is a one-sided 97.5% Clopper–Pearson lower bound for \(g/n\), minus a one-sided 97.5% upper bound for \(l/n\). A union bound gives at least 95% joint coverage under the relevant binomial assumptions. This construction does not address task-family clustering, training-seed variability or the wider history of comparisons. These limitations accompany the statistics in the manuscript.

The dataset has 48 training, six validation and six test examples. “Clean” refers to regenerating prompts from sealed specifications. It must not imply that every assistant target satisfies every literal-use rule: the manifest records six assistant replies with unlicensed literals. Accepted examples are verified, selected material, not a random sample of ordinary interaction.

Fresh bodies and disabled retrieval, verified recall, ledger, mirror, tools and autonomous external-message generation isolate the adapter comparison. Task prompts remain external inputs. These conditions prevent attributing the improvement to the full recurrent architecture.

## E3. Harder speaking transfer

Sources: [report](../../../fish/album/2026-09-05T1630-EAT-formal-speaking-result.md), [plan](../../../fish/lab/formal-speaking-plan-v1.json), [verdict](../../../data/fish/labs/decisive-formal-2026-09-05T101400Z/verdict.json) and [AI review](../../../data/fish/labs/decisive-formal-2026-09-05T101400Z/external-audit.json).

There are 27 mathematics tasks, five memory controls and four unavailable-information controls, each at three seeds in three adapter conditions: 324 replies. Mathematics alone contributes 81 replies per arm. Candidate, shuffled control and retained adapter have two, two and three accepted mathematics replies respectively. The script sums saved per-probe successes, reconstructs task gains/losses/ties and recomputes sign probabilities. The primary comparison gives two gains, two losses and 23 ties, with one-sided probability 0.6875.

This is a failed transfer criterion, not evidence that the conditions are equivalent. All arms score zero on the 15 memory-control replies, leaving retention uninformative. Strict output rules and reply-length limits contribute to the endpoint. The difficulty, interface and conditions differ from E2; the cross-study contrast cannot isolate one causal explanation.

An [earlier harder-transfer attempt](../../../fish/album/2026-09-05T1210-EAT-clean-formal-hard-transfer-invalid.md) had inactive adapter routing. It is an invalid measurement and is excluded from efficacy totals, with the invalidation retained in the history.

## E4. Formal interface diagnostic

Sources: [report](../../../fish/album/2026-09-05T2123-EAT-formal-interface-result.md), [protocol](../../../data/fish/labs/formal-interface-2026-09-05T150825Z/protocol.json) and [verdict](../../../data/fish/labs/formal-interface-2026-09-05T150825Z/verdict.json).

Eight selected tasks, two adapter conditions and three output conditions produce 48 replies. Candidate acceptance is 4/8 for formal programs with grammar, the same 4/8 without grammar and 3/8 for direct answers. Control acceptance is 0/8, 0/8 and 2/8. No bare-model condition is included.

Families were selected based on previous success or failure. Equal observed formal results do not establish general equivalence of decoding methods. The evaluator performs the arithmetic for formal programs; direct answers require numerical execution by the model. Chinese-remainder direct answers also have a weaker target. These are selected diagnostic outcomes, not a clean isolation of all differences between program synthesis and direct reasoning.

## E5. Private continuation

Sources: [prospective design note](../../../fish/album/2026-09-07T0048-EAT-private-continuing-learning.md), [result report](../../../fish/album/2026-09-07T0335-EAT-private-continuing-learning-result.md), and the archived job's [plan](../../../data/fish/labs/private-learning/dreams/20260906T214327762030Z/plan.json), [probes](../../../data/fish/labs/private-learning/dreams/20260906T214327762030Z/probes.json), [comparison](../../../data/fish/labs/private-learning/dreams/20260906T214327762030Z/speaking-comparison.json) and [result](../../../data/fish/labs/private-learning/dreams/20260906T214327762030Z/result.json).

Prediction uses 96 training pairs, including 11 new pairs. Witness losses increase from 1.967 to 2.201 on three new pairs and from 1.977 to 2.676 on 16 historical pairs. The script reconstructs the failed loss criterion from those values and the saved thresholds.

Response targets are 84 teacher-derived, exactly checked solutions, split into 63 training and 21 validation examples. The plan explicitly records zero native replies used as training targets. Validation loss falls from 1.919 to 0.035, but the behavioural adoption comparison fails.

The script checks every archived measurement's condition, probe, seed, routing and transport status; verifies the complete 42-task × two-seed × two-condition grid; and pairs the existing binary correctness labels. It reproduces the full gain/loss identity lists and counts:

| Group | Pairs | Gains | Losses | Ties |
| --- | ---: | ---: | ---: | ---: |
| Transfer | 60 | 9 | 10 | 41 |
| Earlier skills | 18 | 3 | 7 | 8 |
| Unavailable information | 6 | 0 | 0 | 6 |
| Total | 84 | 12 | 17 | 55 |

Checking saved labels does not independently validate the scorer or regrade the replies. Shared task families and repeated seeds also prevent treating 84 pairs as 84 independent replications. These comparisons are used descriptively and for their recorded adoption rule.

The saved result retains the previous prediction adapter, no speaking adapter and `live_activation=false`. This is a historical result, not a claim about every current external process. The original live Fish was outside the authorized training/activation scope. No pause, stop or resume receipt is modified by this audit.

## E6. Decisive worlds, rule use and acquisition

Three completed computational-world studies use the Meridian Wasm engine to generate and check hidden-wiring trajectories. They use fixed model weights and externally supplied records in fresh contexts. The sources are:

- [Worlds report](../../../fish/album/2026-09-05T2245-EAT-decisive-worlds-result.md) and [verdict](../../../data/fish/labs/decisive-worlds-2026-09-05T192730Z/verdict.json): 90 calls; one corrected rule in eight worlds; own-record reuse 0/16; original observations 1/16; the delayed phase was not run.
- [Rule-use report](../../../fish/album/2026-09-06T0033-EAT-decisive-ruleuse-result.md) and [verdict](../../../data/fish/labs/decisive-ruleuse-2026-09-05T213200Z/verdict.json): 48 primary calls and 12 repeats. Retained thinking enabled/suppressed scores 9/12 and 2/12; candidate scores 7/12 and 2/12. The comparison changes actual computation and does not train new knowledge.
- [Acquisition report](../../../fish/album/2026-09-06T0116-EAT-decisive-acquisition-result.md) and [verdict](../../../data/fish/labs/decisive-acquisition-2026-09-05T221330Z/verdict.json): 48 calls; two correct rules in six worlds; own-record query scores 2/6 and 1/6. Reporting only the 3/4 successes conditional on correct acquisition would conceal failed acquisition. The full pipeline gate failed.

The expanded [research record](research-record.json) extracts these saved verdicts and records source-file hashes. It is used for the paper's figures and website data. These studies do not establish native memory, weight consolidation, a novel physical law or independent replication.

## E7. Repair and decisive-learning lineage

The [repair-context report](../../../fish/album/2026-09-06T0844-EAT-decisive-repair-context-observations.md) and its [descriptive reconciliation](../../../data/fish/labs/decisive-repair-context-2026-09-06T035210Z/descriptive-reconciliation.json) report all 70 allocated calls after a terminal finalization refusal. `scientific_verdict` remains null. The correct complete pipelines are 1/6 for checked repair, 0/6 for generic self-check and 2/6 for supplied rules. None of four initially incorrect or ineligible rules becomes exact under either repair. One mechanically refused completion from the preceding attempt is separate, giving 71 actual campaign completions.

Five August decisive run directories retain terminal `void.json` records. Their reasons are indexed in `earlier_decisive_voids` in the expanded record. The v9 [pool audit](../../../fish/album/2026-09-06T1341-EAT-decisive-pool-audit.md) and v10 [seal-refusal report](../../../fish/album/2026-09-06T1627-EAT-decisive-prelude-repair.md) document pre-inference feasibility failures.

The expanded-record builder reads every available pilot checkpoint in the v11 through v15 execution checkouts, checks unique condition/seed/probe identities, and sums existing outcome labels. The saved totals are 15, 130, 336, 336 and 175 respectively. V11 used the wrong seed stream. V12 ended before a token-budget change. V13 and v14 completed their pilots and calibration but refused causal allocation. V15 has an explicit user-pause receipt and no final learning verdict. Snapshot counts take precedence over earlier in-progress narrative counts; no checkpoint is edited or resumed.

The v13 report's per-condition totals reproduce as 72/89/7 and 70/90/8 for SOUND/FAIL/INVALID. The v14 saved checkpoints give 88/77/3 and 85/79/4. These labels follow the pilot instrument. Their tasks, budget history and eligibility decisions prevent treating versions as repeated estimates of one learning effect. The archive preserves copied predecessor records across worktrees, while the reported pilot series counts each selected execution once.

## E8. Earlier programme records

The data archive also includes the available interaction logs and databases, nightly training records, classroom records, speaking tests, body-evolution measurements, canaries, scaling records and exploratory laboratory work. The complete album and laboratory sources are included with their filenames and byte hashes. The [study catalogue](study-catalogue.md) indexes the album and data groups. Inclusion is not an endorsement of every historical interpretation.

An [early body-evolution report](../../../fish/album/2026-08-14T074428-EAT-body-evolution.md) reports 396 completed requests, zero measured gains/losses/interaction and no retrieved records. The zero-retrieval condition limits what it tested. Other early memory claims are recorded in [LAWS.md](../../LAWS.md), including improved recall alongside impaired judgement; they retain their original small-sample and repeated-prompt limitations. Scaling and external-input observations have their own instruments in [ROADMAP.md](../../ROADMAP.md) and the album. None is pooled with the later formal-transfer endpoint.

## E9. Observational exchange plots

Revision 0.4 adds three figures from [exchange-scores.json](exchange-scores.json), copied byte-for-byte from LoopseedSite/crates/record/data/skin.json. The export was saved on 5 September 2026; its SHA-256 is 4112a2fcbe515f69f950845bc7269576171246153f2f00e19eeca28c9933f7e3. The [exchange audit](exchange-audit.json) records aggregation rules, counts and software version. The [original exporter](exchange-export-source.py) is included as provenance, and [build_exchange_figures.py](build_exchange_figures.py) regenerates the plots without a database or model.

The regular participant has 717 scores (652 version 1, 65 version 2) in 22 sessions defined separately by version. A gap of at least 30 minutes starts a session. The first median is 0.4795, followed by a median of 0.3694 on the next UTC date; later version-1 session medians span 0.3912 to 0.5497. The paper and Results page therefore describe the variation directly, rather than treating the earlier narrative of a plateau as a fixed measured limit. The audit reconstructs participant sessions and checks their medians within the export's four-decimal rounding precision.

The plotted guest groups contain 14,685 AI-teacher scores, 2,708 external-text scores and 1,953 scores from nine teaching programmes. Fourteen further guest scores are explicitly omitted. Group, daily, source and session counts reconcile; versions are kept separate, and pooled cross-version medians are not plotted. Guest individual scores are absent from this export, so the audit cannot independently recalculate their quartiles. The original exporter uses the exclusive sample-quartile convention; bands are descriptive, not confidence intervals. Dates are UTC, daily markers are at midday and session markers are at session start.

These are repeated observations, not independent participants or controlled training comparisons. Changing content, context and configuration prevent causal attribution. The constant memory threshold shown in the figures is a reference setting, not a reconstruction of its complete time history. No raw message text is added to the source bundle.

The plot-consistency review found no difference in the underlying numeric export. It did find different presentation rules: the first paper plots connected medians across missing dates, while the website broke those lines. The revised figures preserve every recorded value, break lines across missing dates, and use separate panels with the same axes and colours on both surfaces. The website now displays the SVG exports of the paper's figures instead of drawing them with a separate implementation. Packaging checks that the paper export is byte-identical to the website's numeric source before updating the downloads.

## Earlier results and exclusions

The archive is a census of available files under its declared roots, not of every experiment ever performed. These related records remain visible in the study history:

| Record | Outcome and role |
| --- | --- |
| [3 September primary ruling](../../../fish/album/2026-09-03T0028-EAT-claim-coat-primary-ruling.md) | Candidate 94/128 versus bare 73/128; positive paired gains but a failed literal-use criterion. Different task/interface conditions; do not pool with E2. |
| [3 September formal stage 1](../../../fish/album/2026-09-03T1908-EAT-formal-claim-transfer-stage1.md) | Candidate 25/64 versus zero for both controls; the failure-conditioned negative-literal rate was 3/39, above the prescribed limit. Overall negative decision retained. |
| [Clean-prompt diagnostic](../../../fish/album/2026-09-03T1945-EAT-clean-claim-safety.md) | A selected 18-task place-value slice motivated prompt regeneration. A literal-use rule in arithmetic is not a general AI safety measure. |
| [Invalid harder run](../../../fish/album/2026-09-05T1210-EAT-clean-formal-hard-transfer-invalid.md) | Adapter routing invalid; excluded from efficacy estimates. |
| [v13 eligibility pilot](../../../fish/album/2026-09-06T2248-EAT-decisive-v13-pilot-result.md) | Feasibility and allocation work; failed eligibility does not estimate an adapter learning effect. |
| Later eligibility work | Incomplete or allocation-limited work is not promoted into a completed learning result. The latest experiment was paused by instruction and remains outside the selected efficacy tables. |

## Verification and work before submission

Run `python3 docs/papers/dynamical-synthesis/verify_evidence.py --check` from the repository to compare current source bytes and reconstructed counts with the stored [snapshot](evidence-snapshot.json). The script uses only the Python standard library and reads explicit source paths. It does not load model weights, execute generated answers, modify experimental data or contact external services.

Raw SHA-256 values hash exact file bytes. Some historical records contain a separate identifier derived from a canonical payload; that identifier can differ from a file's raw-byte hash. They are labelled separately. Hashes demonstrate identity against the stored snapshot, not provenance authenticity, public timestamping or replication.

Before submission, the manuscript needs:

1. Confirm venue-specific group membership and contribution statements, funding and competing interests. The author line and contacts are confirmed as Loopseed Team, led by Brian Ashiundu, under Dilate Technologies; the Institute correspondence email is not an affiliation.
2. A fuller related-work and novelty comparison, particularly adaptive control, interactive learning, continual learning and verified program synthesis. The initial bibliography is a starting set of primary sources.
3. A complete study inventory with frozen protocol versions, historical amendments and reasons for exclusion. Preserve failures and invalidations.
4. An inspectable evidence release with task generation, accepted/rejected targets, splits, scorers, reviewer prompts/model versions, condition mappings and exact runtime dependencies. Review participant material before public release.
5. An independently checked sample of whole replies and, if new experiments are later authorized, replications with appropriate task-family and training-seed analysis. Additional results must be reported as new studies.
6. Direct tests of external evidence versus circular corroboration before claiming resistance to echo chambers, and of human correction and intervention before an empirical alignment claim. A causal test of the synthesis loop is also needed before assigning the component learning effect to that architecture.

These are manuscript development requirements and research goals, not authorization to restart or publish anything.

## Revision 0.4 review

The two existing evidence audits still reproduce 199 and 31 source-file checks respectively; the saved result data have not changed. The manuscript now names the WolframScript calculation interface, includes the six target replies flagged by the dataset’s permitted-constant audit, explains study labels in ordinary terms, and describes incomplete collection without presenting a resource pause as a learning failure. Novelty, computational worlds and human control are proposed research directions, with no additional capability claim. The requested group author line, contacts and company/project links are included.
