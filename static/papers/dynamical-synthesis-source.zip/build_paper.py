#!/usr/bin/env python3
"""Generate editable LaTeX and a study catalogue from the paper's Markdown.

The small converter supports the constructs used in this manuscript. It fails
on missing data rather than fabricating figures or archive counts. Compile the
generated manuscript.tex with latexmk; no model runtime is imported or called.
"""

import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
INVENTORY = ROOT / "output/data/dynamical-synthesis/data-inventory.json"
CITES = {
    "evidence-audit.md#meridian-engine": "dilate2026meridian",
    "https://arxiv.org/abs/1606.03137": "hadfieldmenell2016cirl",
    "https://arxiv.org/abs/1611.08219": "hadfieldmenell2017offswitch",
    "https://arxiv.org/abs/1706.03741": "christiano2017preferences",
    "https://arxiv.org/abs/1612.00796": "kirkpatrick2017forgetting",
    "https://arxiv.org/abs/1907.00182": "lesort2019continual",
    "https://arxiv.org/abs/2106.09685": "hu2021lora",
    "https://www.itl.nist.gov/div898/software/dataplot/refman1/auxillar/mcnemar.htm": "nistmcnemar",
    "https://www.nature.com/articles/s41586-024-07566-y": "shumailov2024collapse",
    "https://arxiv.org/abs/2404.01413": "gerstgrasser2024accumulating",
    "https://futureoflife.org/data/documents/research_priorities.pdf": "russell2015priorities",
    "https://wolframphysics.org/glossary/": "wolframglossary",
    "https://www.wolframphysics.org/technical-introduction/": "wolfram2020physics",
}


def plain(text):
    for old, new in {"’": "'", "‘": "'", "“": '"', "”": '"', "–": "-", "—": "-", "·": " / ", "−": "-"}.items():
        text = text.replace(old, new)
    return "".join({"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$",
                    "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}",
                    "~": r"\textasciitilde{}", "^": r"\textasciicircum{}"}.get(c, c) for c in text)


def inline(text):
    tokens = []

    def hold(value):
        tokens.append(value)
        return "ZZTOKEN%dZZ" % (len(tokens) - 1)

    text = re.sub(r"\\\(.*?\\\)", lambda m: hold(m.group()), text)
    text = re.sub(r"`([^`]+)`", lambda m: hold(r"\texttt{" + plain(m.group(1)) + "}"), text)

    def link(match):
        label, url = match.group(1), match.group(2)
        if url in CITES:
            return hold(r"\citep{" + CITES[url] + "}")
        evidence = re.search(r"#(e[1-9])-", url)
        if evidence:
            return hold(r"\hyperref[ev:" + evidence.group(1) + "]{" + plain(label) + "}")
        if url.startswith(("http", "mailto:")):
            return hold(r"\href{" + url + "}{" + plain(label) + "}")
        return hold(r"\textit{" + plain(label) + "}")

    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", link, text)
    text = re.sub(r"\*\*(.+?)\*\*", lambda m: hold(r"\textbf{" + plain(m.group(1)) + "}"), text)
    text = re.sub(r"\*([^*]+)\*", lambda m: hold(r"\emph{" + plain(m.group(1)) + "}"), text)
    text = plain(text)
    for i, value in reversed(list(enumerate(tokens))):
        text = text.replace("ZZTOKEN%dZZ" % i, value)
    return text


FIGURES = {
    "## 3.": ('framework', "Interaction and parameter learning. (A) Inputs from environments, people or other systems enter the system; actions can affect later inputs. The current parameters govern both the state update and action selection. (B) Recorded interaction supplies selected training examples. A copy of the current parameters is trained and compared with the current version on test cases excluded from training, including earlier skills. A candidate replaces the current parameters only if it meets the specified criteria; otherwise the current parameters remain in use. The arrows describe the proposed design. The reported studies test individual parts of it."),
    "### 5.3": ('adapter-transfer', 'Accepted answers in two separate studies. (A) The main comparison uses 64 questions with new numerical values in trained problem types, checked by exact calculation and AI review of complete replies. (B) The harder mathematics study uses 27 tasks at three random seeds per model condition. Both difficulty and answer format differ, so the comparison between studies cannot isolate either effect. The counts apply to these tests; no confidence interval for a wider set of tasks is shown, and related questions must not be treated as independent.'),
    "### 5.5": ('continuation', 'The proposed updates fail the checks required for use. (A) Prediction loss increases on both evaluation sets, which were excluded from training. (B) The answer comparison records 12 gains, 17 losses and 55 ties across 84 matched task-seed pairs. Response validation loss falls from 1.919 to 0.035, but the answer test fails its zero-loss rule. Repeated seeds and shared operations are not independent repeats of the study.'),
    "### 5.6": ('world-learning', "Using supplied rules, learning rules and using saved rules are tested separately. (A) Twelve shared tasks with supplied rules, under two adapters and thinking settings. (B) Six hidden worlds: results from using the model's own records include failures to learn a rule. (C) The earlier eight-world pilot has little success predicting new sequences. All studies keep weights fixed and supply records as input. The panels show separate studies, not one learning curve."),
    "### 5.8": ('decisive-pilots', "Preparation for a controlled learning comparison. Each planned pilot schedules 336 measurements. SOUND, FAIL and INVALID are the grader's recorded labels, which differ from complete-answer acceptance in the mathematics study. Uncollected measurements have no observed result. V11 and v12 are invalid or closed; v13 and v14 have too few eligible tasks; v15 is incomplete at the data cutoff. The versions use different task selections and conditions, so the bars do not show a learning trend."),
    "### 5.9": ('interaction-participant', 'Prediction error during interaction with one regular participant. Dots are individual scores; open circles are session medians placed at session start. A gap of at least 30 minutes starts a session within each score version. The 652 version-1 and 65 version-2 scores appear separately because their scales differ. Shading marks the initial setup period. The dashed line shows the reference memory threshold \\(\\theta_m=0.35\\), not every historical change to it. Lines stop across dates without observations. Changes in tasks and settings prevent attributing the pattern to training.'),
    "### 5.10": ('interaction-sources', 'Prediction-error summaries for AI teachers and external text, shown separately by score version. Dots are session medians for each source; open circles are daily medians at midday UTC. Bands run from the first to the third quartile and are not confidence intervals. The panels contain 3,179 and 11,506 teacher scores and 2,708 external-text scores. Daily summaries give each score equal weight, so larger sessions and sources contribute more. Lines and bands connect only consecutive recorded dates. The reference threshold is \\(\\theta_m=0.35\\). Differences between groups do not establish a learning effect.'),
    "### 5.11": ('interaction-programmes', 'Nine automated mathematics teaching programmes: 1,953 prediction-error scores in 79 sessions, all using version 2. Each panel names its task and gives the counts. Dots show session medians and open circles daily medians. Lines connect only consecutive recorded dates, leaving the gap before 31 August open. Daily summaries give each score equal weight. The dashed reference is \\(\\theta_m=0.35\\). Tasks, exposure and settings vary between programmes, so these curves do not rank teaching effectiveness or show that the model learned to solve the problems.'),
}


def figure(name, caption):
    return "\n".join([
        r"\begin{figure}[htbp]", r"\centering",
        r"\includegraphics[width=\linewidth,height=.70\textheight,keepaspectratio]{figures/" + name + "}",
        r"\caption{" + inline(caption) + "}", r"\label{fig:" + name + "}", r"\end{figure}", "",
    ])


def convert(markdown):
    lines = markdown.splitlines()
    lines = lines[lines.index("## Abstract"):]
    out, paragraph, index, table_count = [], [], 0, 0
    abstract_open = False

    def flush():
        if paragraph:
            out.append(inline(" ".join(paragraph)) + "\n")
            paragraph.clear()

    while index < len(lines):
        line = lines[index]
        if not line.strip():
            flush(); index += 1; continue
        if line.startswith("#"):
            flush()
            if abstract_open:
                out.append(r"\end{abstract}"); abstract_open = False
            for prefix, entry in FIGURES.items():
                if line.startswith(prefix): out.append(figure(*entry))
            title = re.sub(r"^#+\s+(?:\d+(?:\.\d+)*\.?\s+)?", "", line)
            if title == "Abstract":
                out.append(r"\begin{abstract}"); abstract_open = True
            elif line.startswith("###"):
                out.append(r"\subsection{" + inline(title) + "}")
            elif title == "Data, code and reporting statement":
                out.append(r"\section*{" + inline(title) + "}")
            else:
                out.append(r"\section{" + inline(title) + "}")
            index += 1; continue
        if line == r"\[":
            flush(); equation = []
            index += 1
            while lines[index] != r"\]":
                equation.append(lines[index]); index += 1
            out.extend([r"\begin{equation}", *equation, r"\end{equation}"])
            index += 1; continue
        if line.startswith("|"):
            flush(); rows = []
            while index < len(lines) and lines[index].startswith("|"):
                cells = [part.strip() for part in lines[index].strip().strip("|").split("|")]
                if not all(re.fullmatch(r"[-: ]+", cell) for cell in cells): rows.append(cells)
                index += 1
            table_count += 1
            n = len(rows[0])
            caption = {
                1: "Mathematics results with new numerical values",
                2: "Prediction loss on examples excluded from training",
                3: "Answer changes after response training",
                4: "Pilot collection and recorded decisions",
            }[table_count]
            first = r"p{.36\linewidth}" if n == 5 else "X"
            specs = "@{}l r X@{}" if n == 3 else "@{}" + first + " >{\\raggedleft\\arraybackslash}X" * (n - 1) + "@{}"
            out += [r"\begin{table}[htbp]", r"\centering\small", r"\caption{" + caption + "}",
                    r"\begin{tabularx}{\linewidth}{" + specs + "}", r"\toprule"]
            out.append(" & ".join(r"\textbf{" + inline(c) + "}" for c in rows[0]) + r" \\")
            out.append(r"\midrule")
            out += [" & ".join(inline(c) for c in row) + r" \\" for row in rows[1:]]
            out += [r"\bottomrule", r"\end{tabularx}", r"\end{table}", ""]
            continue
        if re.match(r"\d+\. ", line):
            flush(); out.append(r"\begin{enumerate}[leftmargin=*,itemsep=5pt]")
            while index < len(lines) and re.match(r"\d+\. ", lines[index]):
                out.append(r"\item " + inline(re.sub(r"^\d+\. ", "", lines[index])))
                index += 1
            out.append(r"\end{enumerate}"); continue
        if line.startswith("Bibliographic entries"):
            index += 1; continue
        paragraph.append(line.strip()); index += 1
    flush()
    return "\n".join(out)


def catalogue(inventory):
    paragraphs = ["# Study catalogue and data coverage", "",
                  "Dated inventory prepared for the paper on 11 September 2026. All regular files in the declared roots are included in the companion archive. Inclusion does not establish scientific validity, independent observations or a completed study.", "",
                  "- Archive: `output/data/dynamical-synthesis/research-data.tar.gz`",
                  "- Full byte manifest: `output/data/dynamical-synthesis/file-manifest.jsonl`",
                  "- Coverage: {:,} regular files, {:.3f} GB of source bytes".format(inventory["regular_files"], inventory["source_bytes"] / 1e9), "",
                  "## Data groups", "", "| Source group | Regular files | Source MB |", "| --- | ---: | ---: |"]
    for name, group in inventory["groups"].items():
        paragraphs.append("| `{}` | {:,} | {:.2f} |".format(name, group.get("regular", 0), group.get("bytes", 0) / 1e6))
    paragraphs += ["", "## Coverage limits", ""]
    paragraphs += ["- " + line for line in inventory["limits"]]
    paragraphs += ["", "## Complete album index", "",
                   "These are original report titles, including historical terminology and provisional interpretations. Read final rulings and the paper's evidence audit before assigning a result. Copies and successive reports can describe the same observations.", ""]
    for path in sorted((ROOT / "fish/album").glob("*.md")):
        text = path.read_text()
        title = next((line.lstrip("# ") for line in text.splitlines() if line.strip()), path.name)
        paragraphs.append("- [{}](../../../fish/album/{}) - {}".format(path.name, path.name, title))
    (HERE / "study-catalogue.md").write_text("\n".join(paragraphs) + "\n")


def appendix(inventory):
    out = [r"\clearpage\appendix", r"\section{Evidence and data coverage}\label{app:records}",
           "The companion archive contains {:,} regular files ({:.3f} GB before compression) from the listed folders. A complete file list and study catalogue accompany the paper. These totals include copies and overlapping records, not independent measurements.".format(inventory["regular_files"], inventory["source_bytes"] / 1e9),
           r"\subsection{Evidence index}"]
    entries = [
        ("E1", "Implementation", "Code for state updates, prediction-error scores and text representations; design notes."),
        ("E2", "Mathematics with new numerical values", "4 September report; claim-transfer-clean-2026-09-03T170409Z protocol, verdict, data manifests and AI review."),
        ("E3", "Harder mathematics", "5 September report; decisive-formal-2026-09-05T101400Z verdict and review. The earlier inactive-adapter run remains invalid."),
        ("E4", "Answer-format test", "5 September report; formal-interface-2026-09-05T150825Z protocol and verdict."),
        ("E5", "Continued learning", "7 September report; private-learning/dreams/20260906T214327762030Z plan, test questions, 168 measurements and update decision."),
        ("E6", "Learning and using world rules", "5-6 September reports; decisive-worlds-2026-09-05T192730Z, decisive-ruleuse-2026-09-05T213200Z and decisive-acquisition-2026-09-05T221330Z verdicts."),
        ("E7", "Error correction and decisive-learning history", "Error-correction counts with an unresolved study decision; five invalid August attempts; v9-v10 preparation records; v11-v15 saved pilot results and stop records."),
        ("E8", "Earlier programme records", "Complete available research album, data roots and laboratory records; LAWS.md and ROADMAP.md for earlier observations and stage measurements."),
        ("E9", "Observational exchange plots", "Frozen numeric export from LoopseedSite/crates/record/data/skin.json, exported 5 September 2026. exchange-audit.json identifies the file contents, summary calculations, counts and limits. exchange-export-source.py preserves the exporter; build_exchange_figures.py checks the export and regenerates the figures without a database or model."),
    ]
    for ident, title, description in entries:
        out.append(r"\paragraph{" + ident + ". " + plain(title) + r"}\label{ev:" + ident.lower() + "} " + plain(description))
    out += [r"\subsection{Archive folders}", r"\small",
            r"\begin{longtable}{@{}p{.63\linewidth}rr@{}}", r"\toprule Source group & Files & MB \\\midrule\endhead"]
    for name, group in inventory["groups"].items():
        out.append(r"\path{" + name + "} & " + format(group.get("regular", 0), ",") + " & " +
                   format(group.get("bytes", 0) / 1e6, ".1f") + r" \\")
    out += [r"\bottomrule\end{longtable}\normalsize",
            "File links are recorded without copying their targets. Authentication files, operating-system metadata and generated caches are excluded. The archive preserves files available in the listed working copies. It cannot recover missing earlier copies, and its databases were not all captured at one instant.",
            r"\paragraph{Paper and figure sources.} The source bundle includes \texttt{manuscript.tex}, \texttt{references.bib}, vector figures, aggregate \texttt{research-record.json}, numeric \texttt{exchange-scores.json} and verification scripts. The raw-data archive is separate. The figure builders check their inputs and recreate the plots without training or generating model replies."]
    return "\n".join(out)


PREAMBLE = r"""\documentclass[11pt,a4paper]{article}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{amsmath}
\usepackage{newtxtext,newtxmath}
\usepackage[left=23mm,right=23mm,top=22mm,bottom=23mm]{geometry}
\usepackage{microtype,graphicx,booktabs,tabularx,longtable,array,enumitem,placeins}
\usepackage[font=small,labelfont=bf]{caption}
\usepackage[round,authoryear]{natbib}
\usepackage{xcolor,xurl}
\definecolor{linkink}{HTML}{303896}
\usepackage[colorlinks=true,allcolors=linkink,pdftitle={Dynamical Synthesis: Learning through Interaction},pdfsubject={Experimental evidence and computational framework},pdfauthor={Brian Ashiundu}]{hyperref}
\usepackage{fancyhdr}
\pagestyle{fancy}\fancyhf{}
\fancyhead[L]{\small Dynamical Synthesis}
\fancyhead[R]{\small 11 September 2026}
\fancyfoot[C]{\thepage}
\setlength{\headheight}{14pt}
\renewcommand{\headrulewidth}{.3pt}
\setlength{\parindent}{0pt}\setlength{\parskip}{4pt}
\setlength{\emergencystretch}{2em}
\setlength{\bibsep}{5pt}
\renewcommand{\arraystretch}{1.2}
\clubpenalty=10000\widowpenalty=10000
\title{\vspace{-12mm}\LARGE\bfseries Dynamical Synthesis\\[5pt]\Large Learning through Interaction}
\author{\normalsize Brian Ashiundu\thanks{Research conducted under Dilate Technologies.}\\[2pt]\small Research Fellow, Wolfram Institute\\[2pt]\small Head of Research, Dilate Technologies\\[3pt]\footnotesize\href{mailto:brianashiundu000@gmail.com}{brianashiundu000@gmail.com}\quad\href{mailto:bmboya@wolframinstitute.org}{bmboya@wolframinstitute.org}}
\date{\small 11 September 2026}
\begin{document}
\maketitle\vspace{-7mm}
"""


if __name__ == "__main__":
    inventory = json.loads(INVENTORY.read_text())
    catalogue(inventory)
    text = PREAMBLE + convert((HERE / "manuscript.md").read_text())
    text += "\n\\FloatBarrier\\clearpage\n\\begingroup\\small\\setlength{\\bibsep}{3pt}\n\\bibliographystyle{plainnat}\n\\bibliography{references}\n\\endgroup\n"
    text += appendix(inventory) + "\n\\end{document}\n"
    (HERE / "manuscript.tex").write_text(text)
    print("Generated manuscript.tex and study-catalogue.md")
