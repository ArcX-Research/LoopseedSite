#!/usr/bin/env python3
"""Generate editable LaTeX and a study catalogue from the paper's Markdown.

The small converter supports the constructs used in this manuscript. It fails
on missing data rather than fabricating figures or archive counts. Compile the
generated manuscript.tex with latexmk; no model runtime is imported or called.
"""

import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
INVENTORY = ROOT / "output/data/dynamical-synthesis/data-inventory.json"
CITES = {
    "https://arxiv.org/abs/1606.03137": "hadfieldmenell2016cirl",
    "https://arxiv.org/abs/1611.08219": "hadfieldmenell2017offswitch",
    "https://arxiv.org/abs/1706.03741": "christiano2017preferences",
    "https://arxiv.org/abs/1612.00796": "kirkpatrick2017forgetting",
    "https://arxiv.org/abs/1907.00182": "lesort2019continual",
    "https://arxiv.org/abs/2106.09685": "hu2021lora",
    "https://www.itl.nist.gov/div898/software/dataplot/refman1/auxillar/mcnemar.htm": "nistmcnemar",
    "https://www.nature.com/articles/s41586-024-07566-y": "shumailov2024collapse",
    "https://arxiv.org/abs/2404.01413": "gerstgrasser2024accumulating",
    "https://futureoflife.org/data/documents/research_priorities.pdf": "russell2015priorities",
    "https://wolframphysics.org/glossary/": "wolframglossary",
    "https://www.wolframphysics.org/technical-introduction/": "wolfram2020physics",
}


def plain(text):
    for old, new in {"’": "'", "‘": "'", "“": '"', "”": '"', "–": "-", "—": "-", "·": " / ", "−": "-"}.items():
        text = text.replace(old, new)
    return "".join({"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$",
                    "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}",
                    "~": r"\textasciitilde{}", "^": r"\textasciicircum{}"}.get(c, c) for c in text)


def inline(text):
    tokens = []

    def hold(value):
        tokens.append(value)
        return "ZZTOKEN%dZZ" % (len(tokens) - 1)

    text = re.sub(r"\\\(.*?\\\)", lambda m: hold(m.group()), text)
    text = re.sub(r"`([^`]+)`", lambda m: hold(r"\texttt{" + plain(m.group(1)) + "}"), text)

    def link(match):
        label, url = match.group(1), match.group(2)
        if url in CITES:
            return hold(r"\citep{" + CITES[url] + "}")
        evidence = re.search(r"#(e[1-9])-", url)
        if evidence:
            return hold(r"\hyperref[ev:" + evidence.group(1) + "]{" + plain(label) + "}")
        if url.startswith(("http", "mailto:")):
            return hold(r"\href{" + url + "}{" + plain(label) + "}")
        return hold(r"\textit{" + plain(label) + "}")

    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", link, text)
    text = re.sub(r"\*\*(.+?)\*\*", lambda m: hold(r"\textbf{" + plain(m.group(1)) + "}"), text)
    text = re.sub(r"\*([^*]+)\*", lambda m: hold(r"\emph{" + plain(m.group(1)) + "}"), text)
    text = plain(text)
    for i, value in reversed(list(enumerate(tokens))):
        text = text.replace("ZZTOKEN%dZZ" % i, value)
    return text


FIGURES = {
    "## 3.": ("framework", "Proposed framework and evaluation structure. External input may originate in environmental observations, people or other systems, including responses to the learner's actions. The return path can carry new evidence or dependent repetition. The lower path separates recorded experience, candidate training and adoption. This diagram states a design structure; the component studies do not causally validate the entire loop."),
    "### 5.3": ("adapter-transfer", "Accepted answers in two distinct studies. (A) The primary comparison uses 64 questions with new numerical values in trained problem types, with exact checking and AI review of complete replies. (B) The harder mathematics study uses 27 tasks at three seeds per model condition. Task difficulty and required answer formats both differ, so the contrast between studies does not isolate either effect. Counts describe these evaluations; no population confidence interval or independence across related questions is implied."),
    "### 5.5": ("continuation", "The candidate updates fail their adoption criteria. (A) Prediction loss increases on both evaluation sets excluded from training. (B) The response comparison records 12 gains, 17 losses and 55 ties across 84 task-seed pairs. Response validation loss falls from 1.919 to 0.035, but the behavioural comparison fails its zero-loss rule. Repeated seeds and shared operations are not independent replications."),
    "### 5.6": ("world-learning", "Rule use, acquisition and reuse are distinct measurements. (A) Twelve shared supplied-rule tasks under two adapters and thinking settings. (B) Six hidden worlds: own-record query results retain unsuccessful acquisitions in their denominators. (C) The earlier eight-world pilot yields little unseen-trajectory success. All studies use fixed weights and externally supplied records; the panels are separate studies, not a common learning curve."),
    "### 5.8": ("decisive-pilots", "Preparatory collection for a controlled learning comparison. Each intended pilot schedules 336 measurements. SOUND, FAIL and INVALID are the grader's labels, distinct from accepted complete answers in the mathematics study. Uncollected measurements have no observed outcome. V11 and v12 are invalid or closed; v13 and v14 fail task allocation; v15 is incomplete at the data cutoff. Different allocations and conditions prevent interpreting the bars as a learning trend."),
    "### 5.9": ("interaction-participant", r"Prediction error during interaction with one regular participant. Dots are individual scores; open circles are session medians positioned at session start. A gap of at least 30 minutes starts a session within each measurement version. The 652 version-1 and 65 version-2 scores are kept in separate panels; their scales are not interchangeable. Shading marks the initial setup period. The dashed line is the reference memory-selection threshold \(\theta_m=0.35\), not its full historical trajectory. Lines stop across missing observation dates; changing tasks and settings prevent a causal training interpretation."),
    "### 5.10": ("interaction-sources", r"Prediction-error summaries for AI teachers and an external-text stream, stratified by measurement version. Dots are per-source session medians; open circles are pooled daily medians at midday UTC. Bands span the first and third sample quartiles, not confidence intervals. The panels contain 3,179 and 11,506 teacher scores and 2,708 external-text scores. Daily summaries weight individual scores equally; sessions and sources need not contribute equally. Lines and bands connect consecutive recorded dates only. The reference threshold is \(\theta_m=0.35\). Group differences are observational and do not identify learning effects."),
    "### 5.11": ("interaction-programmes", r"Nine automated mathematics teaching programmes: 1,953 prediction-error scores in 79 sessions, all using version 2. Each panel identifies its task content and sample counts. Dots show session medians and open circles daily medians. Lines connect consecutive recorded dates only, leaving the gap before 31 August open. Daily summaries weight individual scores equally. The dashed reference is \(\theta_m=0.35\). Tasks, exposure and configurations were not held fixed across programmes, so these curves neither rank their effectiveness nor establish acquired mathematical competence."),
}


def figure(name, caption):
    return "\n".join([
        r"\begin{figure}[htbp]", r"\centering",
        r"\includegraphics[width=\linewidth,height=.70\textheight,keepaspectratio]{figures/" + name + "}",
        r"\caption{" + inline(caption) + "}", r"\label{fig:" + name + "}", r"\end{figure}", "",
    ])


def convert(markdown):
    lines = markdown.splitlines()
    lines = lines[lines.index("## Abstract"):]
    out, paragraph, index, table_count = [], [], 0, 0
    abstract_open = False

    def flush():
        if paragraph:
            out.append(inline(" ".join(paragraph)) + "\n")
            paragraph.clear()

    while index < len(lines):
        line = lines[index]
        if not line.strip():
            flush(); index += 1; continue
        if line.startswith("#"):
            flush()
            if abstract_open:
                out.append(r"\end{abstract}"); abstract_open = False
            for prefix, entry in FIGURES.items():
                if line.startswith(prefix): out.append(figure(*entry))
            title = re.sub(r"^#+\s+(?:\d+(?:\.\d+)*\.?\s+)?", "", line)
            if title == "Abstract":
                out.append(r"\begin{abstract}"); abstract_open = True
            elif line.startswith("###"):
                out.append(r"\subsection{" + inline(title) + "}")
            elif title in ("Data, code and reporting statement", "Authorship and correspondence"):
                out.append(r"\section*{" + inline(title) + "}")
            else:
                out.append(r"\section{" + inline(title) + "}")
            index += 1; continue
        if line == r"\[":
            flush(); equation = []
            index += 1
            while lines[index] != r"\]":
                equation.append(lines[index]); index += 1
            out.extend([r"\begin{equation}", *equation, r"\end{equation}"])
            index += 1; continue
        if line.startswith("|"):
            flush(); rows = []
            while index < len(lines) and lines[index].startswith("|"):
                cells = [part.strip() for part in lines[index].strip().strip("|").split("|")]
                if not all(re.fullmatch(r"[-: ]+", cell) for cell in cells): rows.append(cells)
                index += 1
            table_count += 1
            n = len(rows[0])
            caption = {
                1: "Mathematics with new numerical values: primary comparison",
                2: "Prediction loss on held-out evaluation sets",
                3: "Paired behavioural outcomes after response training",
                4: "Decisive-learning pilot status at the reviewed cutoff",
            }[table_count]
            first = r"p{.36\linewidth}" if n == 5 else "X"
            specs = "@{}l r X@{}" if n == 3 else "@{}" + first + " >{\\raggedleft\\arraybackslash}X" * (n - 1) + "@{}"
            out += [r"\begin{table}[htbp]", r"\centering\small", r"\caption{" + caption + "}",
                    r"\begin{tabularx}{\linewidth}{" + specs + "}", r"\toprule"]
            out.append(" & ".join(r"\textbf{" + inline(c) + "}" for c in rows[0]) + r" \\")
            out.append(r"\midrule")
            out += [" & ".join(inline(c) for c in row) + r" \\" for row in rows[1:]]
            out += [r"\bottomrule", r"\end{tabularx}", r"\end{table}", ""]
            continue
        if re.match(r"\d+\. ", line):
            flush(); out.append(r"\begin{enumerate}[leftmargin=*,itemsep=5pt]")
            while index < len(lines) and re.match(r"\d+\. ", lines[index]):
                out.append(r"\item " + inline(re.sub(r"^\d+\. ", "", lines[index])))
                index += 1
            out.append(r"\end{enumerate}"); continue
        if line.startswith("Bibliographic entries"):
            index += 1; continue
        paragraph.append(line.strip()); index += 1
    flush()
    return "\n".join(out)


def catalogue(inventory):
    paragraphs = ["# Study catalogue and data coverage", "",
                  "Dated inventory prepared for the working paper on 11 September 2026. All regular files in the declared roots are included in the companion archive. Inclusion does not establish scientific validity, independent observations or a completed study.", "",
                  "- Archive: `output/data/dynamical-synthesis/research-data.tar.gz`",
                  "- Full byte manifest: `output/data/dynamical-synthesis/file-manifest.jsonl`",
                  "- Coverage: {:,} regular files, {:.3f} GB of source bytes".format(inventory["regular_files"], inventory["source_bytes"] / 1e9), "",
                  "## Data groups", "", "| Source group | Regular files | Source MB |", "| --- | ---: | ---: |"]
    for name, group in inventory["groups"].items():
        paragraphs.append("| `{}` | {:,} | {:.2f} |".format(name, group.get("regular", 0), group.get("bytes", 0) / 1e6))
    paragraphs += ["", "## Coverage limits", ""]
    paragraphs += ["- " + line for line in inventory["limits"]]
    paragraphs += ["", "## Complete album index", "",
                   "These are original report titles, including historical terminology and provisional interpretations. Read final rulings and the paper's evidence audit before assigning a result. Copies and successive reports can describe the same observations.", ""]
    for path in sorted((ROOT / "fish/album").glob("*.md")):
        text = path.read_text()
        title = next((line.lstrip("# ") for line in text.splitlines() if line.strip()), path.name)
        paragraphs.append("- [{}](../../../fish/album/{}) - {}".format(path.name, path.name, title))
    (HERE / "study-catalogue.md").write_text("\n".join(paragraphs) + "\n")


def appendix(inventory):
    out = [r"\clearpage\appendix", r"\section{Evidence and data coverage}\label{app:records}",
           "The companion data archive contains {:,} regular files ({:.3f} GB before compression) from the declared roots. The full file manifest and study catalogue accompany the paper. These totals include copied and overlapping artifacts and are not counts of independent measurements.".format(inventory["regular_files"], inventory["source_bytes"] / 1e9),
           r"\subsection{Evidence index}"]
    entries = [
        ("E1", "Implementation", "State recurrence, discrepancy instruments and embedding source code; architectural notes."),
        ("E2", "Mathematics with new numerical values", "4 September report; claim-transfer-clean-2026-09-03T170409Z protocol, verdict, data manifests and AI review."),
        ("E3", "Harder mathematics", "5 September report; decisive-formal-2026-09-05T101400Z verdict and review. The earlier inactive-adapter run remains invalid."),
        ("E4", "Answer-format diagnostic", "5 September report; formal-interface-2026-09-05T150825Z protocol and verdict."),
        ("E5", "Continued learning", "7 September report; private-learning/dreams/20260906T214327762030Z plan, probes, 168 measurements and adoption result."),
        ("E6", "Worlds, rule use and acquisition", "5-6 September reports; decisive-worlds-2026-09-05T192730Z, decisive-ruleuse-2026-09-05T213200Z and decisive-acquisition-2026-09-05T221330Z verdicts."),
        ("E7", "Repair and decisive lineage", "Repair-context descriptive reconciliation; five August void records; v9-v10 preparation records; v11-v15 pilot checkpoints, refusals and pause receipts."),
        ("E8", "Earlier programme records", "Complete available research album, data roots and laboratory records; LAWS.md and ROADMAP.md for earlier observations and stage measurements."),
        ("E9", "Observational exchange plots", "Frozen numeric export from LoopseedSite/crates/record/data/skin.json, exported 5 September 2026. exchange-audit.json identifies the exact bytes, aggregation rules, counts and limitations. exchange-export-source.py preserves the exporter; build_exchange_figures.py checks the export and regenerates the figures without a database or model."),
    ]
    for ident, title, description in entries:
        out.append(r"\paragraph{" + ident + ". " + plain(title) + r"}\label{ev:" + ident.lower() + "} " + plain(description))
    out += [r"\subsection{Declared archive groups}", r"\small",
            r"\begin{longtable}{@{}p{.63\linewidth}rr@{}}", r"\toprule Source group & Files & MB \\\midrule\endhead"]
    for name, group in inventory["groups"].items():
        out.append(r"\path{" + name + "} & " + format(group.get("regular", 0), ",") + " & " +
                   format(group.get("bytes", 0) / 1e6, ".1f") + r" \\")
    out += [r"\bottomrule\end{longtable}\normalsize",
            "Symlinks are retained as dependency references, with their targets unexpanded. Authentication files, operating-system metadata and generated caches are excluded. The archive identifies bytes available in the listed checkouts; it does not recover missing historical worktrees or provide an atomic database snapshot.",
            r"\paragraph{Reproduction.} The source bundle includes \texttt{manuscript.tex}, \texttt{references.bib}, vector figures, aggregate \texttt{research-record.json}, numeric \texttt{exchange-scores.json} and verification scripts. The raw-data archive is separate. The figure builders check their inputs and regenerate the plots without training or inference."]
    return "\n".join(out)


PREAMBLE = r"""\documentclass[11pt,a4paper]{article}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{amsmath}
\usepackage{newtxtext,newtxmath}
\usepackage[left=23mm,right=23mm,top=22mm,bottom=23mm]{geometry}
\usepackage{microtype,graphicx,booktabs,tabularx,longtable,array,enumitem,placeins}
\usepackage[font=small,labelfont=bf]{caption}
\usepackage[round,authoryear]{natbib}
\usepackage{xcolor,xurl}
\definecolor{linkink}{HTML}{303896}
\usepackage[colorlinks=true,allcolors=linkink,pdftitle={Dynamical Synthesis: Learning through Interaction},pdfsubject={Archived evidence, computational framework and research goals},pdfauthor={Loopseed Team; Brian Ashiundu; Dilate Technologies}]{hyperref}
\usepackage{fancyhdr}
\pagestyle{fancy}\fancyhf{}
\fancyhead[L]{\small Dynamical Synthesis}
\fancyhead[R]{\small Working manuscript / 11 September 2026}
\fancyfoot[C]{\thepage}
\setlength{\headheight}{14pt}
\renewcommand{\headrulewidth}{.3pt}
\setlength{\parindent}{0pt}\setlength{\parskip}{4pt}
\setlength{\emergencystretch}{2em}
\setlength{\bibsep}{5pt}
\renewcommand{\arraystretch}{1.2}
\clubpenalty=10000\widowpenalty=10000
\title{\vspace{-12mm}\LARGE\bfseries Dynamical Synthesis\\[5pt]\Large Learning through Interaction}
\author{\normalsize Loopseed Team\\[2pt]\small Dilate Technologies}
\date{\small Working draft 0.4 / 11 September 2026}
\begin{document}
\maketitle\vspace{-7mm}
"""


if __name__ == "__main__":
    inventory = json.loads(INVENTORY.read_text())
    catalogue(inventory)
    text = PREAMBLE + convert((HERE / "manuscript.md").read_text())
    text += "\n\\FloatBarrier\\clearpage\n\\begingroup\\small\\setlength{\\bibsep}{3pt}\n\\bibliographystyle{plainnat}\n\\bibliography{references}\n\\endgroup\n"
    text += appendix(inventory) + "\n\\end{document}\n"
    (HERE / "manuscript.tex").write_text(text)
    print("Generated manuscript.tex and study-catalogue.md")
