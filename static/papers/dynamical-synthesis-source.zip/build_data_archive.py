#!/usr/bin/env python3
"""Package available research records without executing an experiment.

Copies regular files from the declared data roots, album and lab records.
Symlinks are inventoried as references and never followed. Authentication files
and generated build/cache directories are excluded explicitly. Source records
are opened read-only; the only writes are to the requested output directory.
"""

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
SKIP_DIRS = {".git", ".venv", "node_modules", "target", "__pycache__", ".pytest_cache", ".ruff_cache", ".mypy_cache"}
SKIP_FILES = {".DS_Store", "keeper.secret"}


class HashingReader:
    def __init__(self, stream):
        self.stream = stream
        self.digest = hashlib.sha256()

    def read(self, size=-1):
        block = self.stream.read(size)
        self.digest.update(block)
        return block


def source_roots():
    roots = [("Loopseed/data", ROOT / "data"),
             ("Loopseed/fish/album", ROOT / "fish/album"),
             ("Loopseed/fish/lab", ROOT / "fish/lab")]
    for worktree in sorted(ROOT.parent.glob("Loopseed-decisive-*-exec")):
        if (worktree / "data").is_dir():
            roots.append((worktree.name + "/data", worktree / "data"))
    return roots


def group_for(path):
    parts = path.split("/")
    if parts[0] != "Loopseed":
        return parts[0] + "/data"
    if parts[1:3] == ["fish", "album"]:
        return "Loopseed/fish/album"
    if parts[1:3] == ["fish", "lab"]:
        return "Loopseed/fish/lab"
    if parts[1:3] == ["data", "fish"] and len(parts) > 4:
        return "/".join(parts[:4])
    if len(parts) > 3:
        return "/".join(parts[:3])
    return "Loopseed/data/root"


def collect_paths(roots):
    for source_id, source in roots:
        for here, dirs, files in os.walk(str(source), followlinks=False):
            dirs.sort()
            files.sort()
            for name in list(dirs):
                path = Path(here) / name
                relative = source_id + "/" + str(path.relative_to(source))
                if name in SKIP_DIRS:
                    dirs.remove(name)
                    yield relative, path, "excluded-build-or-cache-directory"
                elif path.is_symlink():
                    dirs.remove(name)
                    yield relative, path, "symlink-reference-only"
            for name in files:
                path = Path(here) / name
                relative = source_id + "/" + str(path.relative_to(source))
                if name in SKIP_FILES or name.endswith(".secret"):
                    yield relative, path, "excluded-authentication-or-os-metadata"
                elif path.is_symlink():
                    yield relative, path, "symlink-reference-only"
                elif stat.S_ISREG(path.stat().st_mode):
                    yield relative, path, "regular"
                else:
                    yield relative, path, "nonregular-reference-only"


def add_bytes(archive, name, content):
    info = tarfile.TarInfo(name)
    info.size = len(content)
    info.mode = 0o644
    archive.addfile(info, io.BytesIO(content))


def build(destination):
    destination.mkdir(parents=True, exist_ok=True)
    final = destination / "research-data.tar.gz"
    partial = destination / "research-data.tar.gz.partial"
    roots = source_roots()
    manifest = []
    groups = defaultdict(Counter)
    total_bytes = 0
    with tarfile.open(str(partial), mode="w:gz", compresslevel=1) as archive:
        for relative, path, kind in collect_paths(roots):
            row = {"path": relative, "kind": kind}
            group = groups[group_for(relative)]
            group[kind] += 1
            if kind == "regular":
                before = path.stat()
                info = tarfile.TarInfo("sources/" + relative)
                info.size, info.mode, info.mtime = before.st_size, 0o644, int(before.st_mtime)
                with path.open("rb") as source:
                    reader = HashingReader(source)
                    archive.addfile(info, reader)
                after = path.stat()
                if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                    raise RuntimeError("Source changed while copying: " + relative)
                row.update(bytes=before.st_size, sha256=reader.digest.hexdigest())
                group["bytes"] += before.st_size
                total_bytes += before.st_size
            elif kind == "symlink-reference-only":
                row["target"] = os.readlink(str(path))
            manifest.append(row)
            if len(manifest) % 1000 == 0:
                print("Archived {} entries; {:.2f} GB of source bytes".format(len(manifest), total_bytes / 1e9),
                      file=sys.stderr, flush=True)
        manifest.sort(key=lambda row: row["path"])
        manifest_bytes = "".join(json.dumps(row, sort_keys=True, ensure_ascii=False) + "\n" for row in manifest).encode()
        summary = {
            "created_at": datetime.now(timezone.utc).isoformat(),
            "scope": [name for name, _ in roots],
            "regular_files": sum(row["kind"] == "regular" for row in manifest),
            "source_bytes": total_bytes,
            "inventory_entries": len(manifest),
            "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
            "groups": dict(sorted(groups.items())),
            "limits": [
                "Census of files available under the named roots, not of all experiments ever performed.",
                "Copies and overlapping studies are retained; file totals are not independent observations.",
                "Symlinks record dependencies without copying their targets, including model weights.",
                "Authentication material, operating-system metadata and generated caches are excluded.",
                "Individual files are checked for changes during copying; this is not an atomic database snapshot.",
                "No training, inference, experiment resumption, activation or external publication is performed.",
            ],
        }
        summary_bytes = (json.dumps(summary, indent=2, sort_keys=True) + "\n").encode()
        add_bytes(archive, "file-manifest.jsonl", manifest_bytes)
        add_bytes(archive, "data-inventory.json", summary_bytes)
    partial.replace(final)
    (destination / "file-manifest.jsonl").write_bytes(manifest_bytes)
    (destination / "data-inventory.json").write_bytes(summary_bytes)
    print(json.dumps({"archive": str(final), "archive_bytes": final.stat().st_size,
                      "regular_files": summary["regular_files"], "source_bytes": total_bytes}, sort_keys=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "output/data/dynamical-synthesis")
    build(parser.parse_args().output.resolve())
