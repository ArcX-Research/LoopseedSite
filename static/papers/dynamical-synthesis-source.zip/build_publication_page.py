#!/usr/bin/env python3
"""Generate a plain HTML paper page and citations from the current manuscript."""
import argparse
from html import escape
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
TITLE = "Dynamical Synthesis: Learning through Interaction"
AUTHOR = "Brian Ashiundu"
URL = "https://loopseed.io/papers/dynamical-synthesis.html"


def build_page(site=None):
    manuscript = (HERE / "manuscript.md").read_text()
    assert manuscript.startswith("# " + TITLE + "\n") and "**" + AUTHOR + "**" in manuscript
    assert "**11 September 2026**" in manuscript
    abstract = manuscript.split("## Abstract\n", 1)[1].split("\n## ", 1)[0].strip()
    assert "\n\n" not in abstract and "<" not in abstract
    citation = f"Ashiundu, B. (2026). {TITLE}. Dilate Technologies. {URL}"
    page = (HERE / "publication-template.html").read_text()
    for key, value in {"TITLE": TITLE, "ABSTRACT": abstract, "CITATION": citation}.items():
        page = page.replace("@@" + key + "@@", escape(value, quote=True))
    assert "@@" not in page
    bib = """@techreport{ashiundu2026dynamicalsynthesis,
  author = {Ashiundu, Brian},
  title = {Dynamical Synthesis: Learning through Interaction},
  institution = {Dilate Technologies},
  year = {2026},
  month = {September},
  url = {https://loopseed.io/papers/dynamical-synthesis.html}
}
"""
    ris = ("TY  - RPRT\nAU  - Ashiundu, Brian\nTI  - " + TITLE
           + "\nPY  - 2026\nDA  - 2026/09/11\nPB  - Dilate Technologies\nUR  - "
           + URL + "\nER  -\n")
    output = ROOT / "output/site/papers"
    output.mkdir(parents=True, exist_ok=True)
    products = {"dynamical-synthesis.html": page, "dynamical-synthesis.bib": bib,
                "dynamical-synthesis.ris": ris}
    for name, content in products.items():
        (output / name).write_text(content)
        if site:
            target = site / "static/papers" / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content)
    print("Prepared publication page, BibTeX and RIS; abstract matches the manuscript.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--site", type=Path)
    build_page(parser.parse_args().site)
