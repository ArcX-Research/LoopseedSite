# Dynamical Synthesis: Learning through Interaction

**Working draft 0.4 · 11 September 2026**  
**Loopseed Team**  
**Affiliation: Dilate Technologies**  
Selected empirical records: August to 7 September 2026.

## Abstract

Systems that continue learning must be assessed for what they acquire, what they preserve and how they respond to external evidence. We present Dynamical Synthesis as a design framework for these questions. Its shorthand, \(I = W(I) + \mathrm{You}\), combines internal activity with input crossing a declared system boundary. External input can come from environments, people or other systems; its source alone does not establish correctness or independent confirmation. Fish, the programme's language-model testbed, implements prediction, memory and separately evaluated parameter updates. In one controlled component study, an adapter trained on 48 checked examples produced 43 accepted answers on 64 new numerical instances within trained problem types; the base model and a shuffled-pairing control each produced zero. On harder mathematics, candidate and control each produced two accepted answers out of 81. A later response update lowered validation loss but produced 12 paired gains and 17 losses across 84 comparisons and was not adopted. Hidden-rule studies found limited acquisition and reuse; preparatory tests for a broader learning comparison did not yield a completed estimate. We also present observational prediction-error plots, keeping measurement versions separate. These findings support improvement in a specific adapter comparison and identify limits on transfer and retention. They do not establish an advantage caused by the full architecture, reliable human control or scientific discovery; those remain explicit research goals.

## 1. Introduction

An artificial system that continues learning presents a recurring design question: how can interaction with its environment produce useful, lasting changes while leaving the system responsive to evidence that challenges what it has learned? The environment may supply measurements, consequences of actions, human instruction or messages from other systems. A learner may improve on a task while losing earlier abilities or repeatedly confirming an error through its own feedback. Continuing interaction therefore needs to be evaluated for the information it supplies and the changes it produces.

Human oversight is a particular application of this broader question. We use *alignment* to describe the problem of relating system behaviour and objectives to legitimate human intentions and interests. Those interests may involve several people and need not agree. Responsiveness to one participant's next instruction is therefore an incomplete operational target. Cooperative inverse reinforcement learning formalizes one approach through a shared human–agent objective that is initially uncertain to the agent. Its assumptions make the role of human information explicit. [Hadfield-Menell et al., 2016](https://arxiv.org/abs/1606.03137).

Loopseed is a research programme investigating whether computational systems can learn through continuing interaction, retain useful changes and remain responsive to correction. We call its organising idea **Dynamical Synthesis**:

\[
I = W(I) + \mathrm{You}.
\]

Here \(I\) denotes system activity and \(W\) its internal processing. **You denotes input received from beyond a declared system boundary**. It includes people, other agents and physical or computational environments; it need not be linguistic or intentional. The boundary may enclose a model, an agent with memory and tools, or a network of agents, but must be specified consistently. The next section defines an indexed computational formulation. Fish provides the current language-model implementation; the programme also considers adaptive software, control and other computational systems.

The equation expresses a design aim that needs an explicit implementation and empirical tests. An input channel may exist yet be ignored when actions are selected, or a learner may adopt misleading feedback. Research on shutdown incentives illustrates why effective human intervention depends on objectives and assumptions about human information, even in a small formal model. [Hadfield-Menell et al., 2017](https://arxiv.org/abs/1611.08219).

This paper contributes an operational account of the proposed framework and a set of component-level case studies. The studies separate prediction, verified task performance, transfer and retention. Positive results are reported alongside failed criteria and diagnostic limitations. A causal evaluation of the full architecture, including resistance to circular corroboration and its contribution to human oversight, remains a research goal.

## 2. From shorthand to a computational specification

### 2.1 State, input and action

The unindexed expression can be read as a fixed-point relation. A dynamical implementation needs a time index, a state space, input representations and an update procedure. A general formulation is

\[
s_{t+1}=F_{\theta_t}(s_t,u_t),
\qquad
a_t=\pi_{\theta_t}(s_t,u_t),
\]

where \(s_t\) is system state, \(u_t\) is the represented external input corresponding to *You*, \(a_t\) is an action and \(\theta_t\) denotes learned parameters. External input may depend on earlier system actions: it is not assumed to be statistically independent or exogenous. An implementation must specify its state boundary, input channels, source records and rules for admitting evidence or instructions. Human guidance, environmental measurements and agent-generated messages can be distinguished within \(u_t\) without making human participation a requirement of every application.

An additive realization closer to the shorthand is

\[
x_{t+1}=\alpha W_{\theta_t}(x_t)+B u_t.
\]

Here the internal and external contributions must map into the same state space; addition has no defined computational meaning without that choice. The input map \(B\) and the internal update must be specified algorithms over represented values. Such a specification could use vectors, symbolic structures or other computable representations, with an appropriate composition operator in place of addition. The notation alone neither supplies those algorithms nor establishes their novelty.

Responsiveness needs an operational test. Merely setting \(B\ne0\) permits input to affect state; it does not ensure that a particular input changes the state or the action. A constant policy could ignore changing state entirely. The relevant question is whether controlled changes in task-relevant evidence produce appropriate changes in decisions, and whether that responsiveness persists after learning. Legitimate human correction is one case of this assessment.

### 2.2 External input, provenance and feedback

A message from outside the system can still repeat its own earlier output. For example, another system may copy an answer and return it without performing any measurement or calculation that could check it. The new sender adds a route of transmission, but no further test of the answer. Separate models can also share training material and errors. We therefore distinguish the number of messages or senders from the evidence supporting a claim.

For this framework, an *echo-chamber failure* means that dependent repetitions are treated as additional support, reinforcing a claim without a corresponding improvement in its evidential basis. Feedback itself is essential to many learning and control systems. Replaying a verified example can help preserve an ability without being counted as a new observation. The problem arises when the accounting obscures that dependency or when an update is evaluated only against the assumptions that generated it.

We propose recording known source identities, derivations, transformations and checks, while marking unknown provenance explicitly. For a factual claim, additional support should come from an observation or a checking procedure capable of rejecting that claim, rather than agreement alone. A sensor measurement can be affected by the system's actions and still reveal whether its prediction was wrong. An exact checker can challenge a generated calculation without being statistically independent of its input. Both checks remain limited by their measurement procedures and specifications. Evidence about what is true must also be distinguished from authority to set a goal or permission.

These requirements motivate proposed tests of feedback reliability. A suitable comparison would return copies of an incorrect claim in one condition and provide fresh observations or externally specified checks in another. It would measure persistence of the error, successful correction and performance on later cases. If the system reports confidence, the test should also examine whether repeated copies change that confidence. No study reported here establishes these protections.

### 2.3 Learning and adoption

State changes during interaction and lasting parameter changes are distinct. We describe a candidate update at training episode \(k\) as

\[
\theta^{\mathrm{cand}}_k=\mathcal L(\theta_k,D_k),
\qquad
\theta_{k+1}=
\begin{cases}
\theta^{\mathrm{cand}}_k,& A_k=1,\\
\theta_k,& A_k=0,
\end{cases}
\]

where \(D_k\) is an admitted, provenance-bearing dataset and \(A_k\) records a prespecified adoption decision. This is a proposed accounting structure, not a claim that every recorded experiment exercised the whole cycle. The assessment must state its tasks, comparators, allowed regressions and decision authority. Material used to choose an update must be distinguished from a final assessment of the selected update.

Task correctness, prediction accuracy, retention, sensitivity to correction and compliance with an authorization boundary require different measurements. An adoption rule can prevent an update that fails its measured criteria; it cannot protect abilities or failure modes absent from those criteria. Its software enforcement is also a separate engineering question.

### 2.4 Stability is a separate property

For fixed parameters and identical inputs, suppose an idealized map \(W\) is Lipschitz with constant \(L\). The additive recurrence then satisfies

\[
\|x_{t+1}-\widetilde{x}_{t+1}\|
\le |\alpha|L\|x_t-\widetilde{x}_t\|.
\]

Thus \(|\alpha|L<1\) gives contraction of this particular map under those assumptions. This is an elementary consequence of the Lipschitz condition, not a new theorem. Choosing \(\alpha<1\) alone does not establish the condition. When input responds to the system, the coupled environment and input dynamics require analysis too; identical input sequences cannot simply be assumed for different trajectories. Changing parameters, stochastic generation, retrieval and additional state introduce further dependencies. Convergence alone establishes neither correctness, resistance to echo chambers nor alignment with human interests.

### 2.5 New ideas as a possible emergent outcome

Novelty is not represented by a separate term in \(I = W(I) + \mathrm{You}\). We treat new ideas as a possible emergent outcome of interaction between internal computation and external input: a system may revise and combine what it has learned to propose a new hypothesis, method or design. This is a possibility to investigate, not a consequence proved by the equation.

A proposal would need assessment against specified reference material, tests of validity and usefulness, and a review of prior work before a claim of discovery. Material absent from the supplied examples may still occur in pretraining or existing literature. An experiment should compare informative, withheld and shuffled observations under matched starting conditions and computational budgets, while keeping final evaluation examples out of the feedback loop. Prediction error alone is not evidence of novelty or discovery.

## 3. Fish as an experimental implementation

Fish combines a language model with recorded exchanges, prediction, selective memory and tools. Its implemented retrieval state is

\[
I_t=\alpha E(r_{t-1})+E(y_t),
\]

where \(r_{t-1}\) is the actual previous generated reply, \(y_t\) is the incoming message and \(E\) maps text to a shared 384-dimensional embedding space. The reference coefficient is \(\alpha=0.70\). The previous reply embedding can persist across a room restart. This vector is a component of the implementation's state; it does not encompass the model parameters, conversation context or complete memory archive. [Implementation and scope: E1](evidence-audit.md#e1-implemented-state-and-observation).

The predictor records a proposed next incoming message before the observation arrives. The first prediction-error score is \(\delta_1=1-\cos(E(\widehat y_t),E(y_t))\), where \(\widehat y_t\) is the recorded prediction. A later version uses \(\delta_2=\tfrac12\delta_1+\tfrac12(1-\exp(-L_t))\), where \(L_t\) is the mean negative log probability of the observed tokens under the context available before arrival. These dimensionless scores use different measurement procedures and are analysed separately. Neither is a percentage of incorrect answers. The plots mark the reference memory-selection threshold \(\theta_m=0.35\); this is distinct from the learned parameters \(\theta_t\) and is not a reconstruction of the threshold at every exchange.

Prediction adapters and response adapters have separate objectives. Predicting a participant's next message does not directly train the system to produce a correct answer. The selected studies use low-rank parameter adaptation, an existing fine-tuning method that freezes base weights and trains smaller update matrices. [Hu et al., 2021](https://arxiv.org/abs/2106.09685). The response-adapter configuration for the principal study identifies `mlx-community/Qwen3-8B-4bit`; the run records separately identify the GGUF inference model by hash.

Training targets also have different origins. The principal mathematics dataset contains accepted model responses screened by exact checking and AI review, with prompts regenerated from the task specifications. Its manifest records six of 60 target replies containing numerical constants outside the dataset’s permitted-constant rules. This issue is distinct from the checked numerical result and limits what the label “clean” in the source records establishes. The later continuation study uses teacher-derived worked solutions for its response objective. These are not observations of a population's preferences. Their provenance must remain visible when connecting the implementation to the alignment motivation.

## 4. Methods and empirical scope

We examine completed adapter studies, hidden-world acquisition and rule-use studies, descriptive repair observations and the decisive-learning feasibility sequence. These are related studies from one programme, not independent replications. The accompanying data archive covers the available records under the declared data roots, the research album and laboratory sources, including the separate decisive execution checkouts. File copies, repeated requests and overlapping tasks remain distinguishable; archive size is not an experimental sample size. The [evidence audit](evidence-audit.md) and [study catalogue](study-catalogue.md) index the wider history and its exclusions.

The controlled mathematics studies use isolated copies, specified tasks, coded model conditions and recorded generation settings. For structured solutions, the model produces a JSON graph of calculation steps. A compiler validates its operations and references, translates it into Wolfram Language expressions, and evaluates those expressions with the Wolfram kernel through WolframScript. The main 4 September protocol records WolframScript 1.13.0. An external checker compares the computed results with exact reference answers; it is separate from the model's own tool access. A separate AI reviewer can reject complete replies that pass the checker if the steps are incorrect or do not answer the requested problem. Model identities are withheld during this review. This additional assessment remains fallible and is not independent scientific replication. Protocols were frozen locally; we do not claim public preregistration.

The principal mathematics comparison uses four new numerical instances in each of 16 predefined problem types. A problem type, called a task family in the source records, groups questions using the same mathematical procedure. All 16 types occur in training. The 64 tasks are crossed with four model conditions and four prompt/grammar settings, producing 1,024 requests. The primary setting supplies the problem and required result names without a calculation recipe, using a grammar that restricts only the general answer structure. Exact tasks present in identified historical datasets and earlier trials are excluded. This does not establish absence from base-model pretraining.

The dataset comprises 60 accepted examples split into 48 training, six validation and six test examples. Training uses rank-8 LoRA on 16 layers for 200 iterations, batch size one, Adam, learning rate \(10^{-5}\), adapter scale parameter 20, maximum sequence length 1,024 and prompt masking. The candidate and shuffled-reply control are applied at inference scale 1.0. Generation allows 2,048 reply tokens within an 8,192-token context. Length-limit failures remain part of the endpoint. A shuffled control preserves the sets of prompts and replies while changing their pairings. It controls one aspect of dataset structure, rather than every consequence of the training procedure. [E2](evidence-audit.md#e2-clean-formal-transfer).

Each request uses a fresh isolated copy with retrieval, verified recall, ledger, mirror, tools and autonomous external-message generation disabled. The task prompt remains an external input. This design isolates the adapter comparison. It cannot establish an effect of the recurrent state rule, accumulated memory or the full Dynamical Synthesis architecture.

## 5. Results

### 5.1 Mathematics with new numerical values

| Model condition | Accepted answers | Passed the checker | Length-limit failures |
| --- | ---: | ---: | ---: |
| Response adapter | 43/64 | 47/64 | 2 |
| Base model | 0/64 | 0/64 | 0 |
| Shuffled-reply control | 0/64 | 0/64 | 0 |
| Retained prediction adapter used for replies | 5/64 | 5/64 | 0 |

The candidate passes all four instances in ten families and three of four two-column-product instances. Five families have no accepted candidate answer. Its primary success rate is 67.19%; the observed difference from each zero-scoring control is 67.19 percentage points. Four candidate answers accepted by the numerical checker are rejected by the AI reviewer for failing to construct the requested Chinese-remainder solution. [E2](evidence-audit.md#e2-clean-formal-transfer).

The recorded task-paired comparison against each principal control has 43 gains, zero losses and 21 ties. Its one-sided exact McNemar probability is \(2^{-43}=1.1369\times10^{-13}\). The recorded conservative 95% lower bound on the paired success-rate difference is 0.4871, obtained by subtracting an upper loss-rate bound from a lower gain-rate bound. These arithmetic calculations reproduce from the stored counts. McNemar testing concerns paired binary outcomes. [NIST, McNemar Test](https://www.itl.nist.gov/div898/software/dataplot/refman1/auxillar/mcnemar.htm).

Interpretation is conditional on the task set and the analysis assumptions. Tasks share mathematical families, and independent training replications are absent. The calculation does not model that clustering or variability between trained adapters; its Bonferroni construction concerns the two component bounds, not correction across the entire experimental history. Zero paired losses against controls that never succeed provide no evidence about retaining abilities those controls possess elsewhere.

Supplying calculation steps produces only 4/64 accepted candidate answers under either grammar, compared with 43/64 for names-only prompts. The shuffled control scores 18/64 with names-only prompts and task-scoped grammar, but zero under the loose primary grammar. These secondary observations indicate dependence on the evaluation interface. They do not replace the selected endpoint.

### 5.2 Harder mathematics with plain-text answers

A subsequent study evaluates 27 mathematics tasks at three matched seeds, with additional memory and uncertainty/observation controls. Among 81 mathematics replies per adapter, candidate and shuffled control each have two accepted answers; the retained adapter has three. Aggregating matched seeds within tasks gives two task gains, two losses and 23 ties against the shuffled control, with recorded one-sided sign probability 0.6875. The planned transfer criterion fails. [E3](evidence-audit.md#e3-harder-speaking-transfer).

All adapters score zero on 15 memory-control replies. This floor prevents a useful retention conclusion. Length limits and a strict plain-text requirement account for many endpoint failures; violating that format does not imply every mathematical statement in the reply is false. Both task difficulty and output conditions differ from the earlier formal study. Their contrast therefore does not isolate a cause, and equal observed scores do not demonstrate equivalence between adapters.

### 5.3 Testing the answer format

On eight selected fresh instances from four familiar families, the candidate produces four accepted formal programs with decoder grammar and the same four without it. The shuffled control produces zero in both conditions. Direct integer-answer conditions yield 3/8 and 2/8 respectively. There are 48 replies across tasks, adapters and conditions. [E4](evidence-audit.md#e4-formal-interface-diagnostic).

The families were selected after earlier results, and no bare-model arm is included. Identical outcomes on eight tasks cannot establish general equivalence between decoding conditions. Formal-program evaluation also delegates arithmetic to the symbolic checker, whereas direct answers require the model to provide numerical results. The direct Chinese-remainder target is weaker than a request to construct the joint solution. This diagnostic identifies useful boundaries without establishing broad unaided reasoning.

### 5.4 Continued learning in an isolated copy

A later private clone separately trains prediction and response candidates. Prediction training uses 85 historical replay pairs and 11 additional pairs. New and historical evaluation sets are excluded from training. [E5](evidence-audit.md#e5-private-continuation).

| Prediction evaluation set | Pairs | Loss before | Loss after |
| --- | ---: | ---: | ---: |
| New material | 3 | 1.967 | 2.201 |
| Historical material | 16 | 1.977 | 2.676 |

The decision requires at least a 0.01 decrease on the new evaluation set and no increase on the historical evaluation set. Both increase, so the candidate fails. The small evaluation sets limit generalization.

Response training uses 84 teacher-derived, exactly checked solutions, split into 63 training and 21 validation examples with shared computations grouped together. Validation loss decreases from 1.919 to 0.035. The subsequent behavioural comparison contains 42 tasks, two seeds and two adapter conditions: 168 replies forming 84 task–seed pairs.

| Group | Pairs | Gains | Losses | Ties |
| --- | ---: | ---: | ---: | ---: |
| New numerical cases | 60 | 9 | 10 | 41 |
| Earlier-skill controls | 18 | 3 | 7 | 8 |
| Unavailable-information controls | 6 | 0 | 0 | 6 |
| Total | 84 | 12 | 17 | 55 |

The candidate meets the minimum of four transfer gains and answers all unavailable-information controls correctly. Its 17 losses violate the zero-loss criterion, including seven losses on earlier skills. Both candidates remain inactive in the recorded result. This demonstrates the operation of those adoption checks in this instance; it does not certify general deployment safety. The paired counts are descriptive because seeds and operation families repeat.

### 5.5 Learning and using hidden world rules

The decisive-worlds pilot uses eight computational worlds with hidden wiring, generated and checked by the Meridian Wasm engine. Twelve public traces per world precede a rule proposal and one checked repair. The model's weights are fixed. Saved rule descriptions are supplied in fresh contexts; they are external records, rather than native memory or parameter consolidation. All 90 calls complete. Initial acquisition succeeds in 0/8 worlds and repair in 1/8. Own-record and no-record conditions each yield 0/16 exact unseen predictions; the original-observation condition yields 1/16. Supplied-rule controls score 0/8. The continuation gate fails and the reserved 24-hour phase is not run. Fourteen own-condition queries follow failed acquisition and receive a no-record fallback, so those failures cannot be attributed to forgetting an acquired rule. [E6](evidence-audit.md#e6-decisive-worlds-rule-use-and-acquisition).

A follow-up isolates whether the model can use a supplied rule. Twelve shared tasks are evaluated under two adapters and two thinking settings, with twelve additional repetitions: 60 calls in total. The retained model scores 9/12 with thinking enabled and 2/12 with thinking suppressed; the candidate scores 7/12 and 2/12. All twelve repeated calls match the original raw and final replies. Both modes allow 2,048 output tokens, but their actual computation differs substantially. This is a measured inference-setting effect on selected tasks, rather than acquisition of new knowledge. Only the retained/enabled condition passes the readiness screen. [E6](evidence-audit.md#e6-decisive-worlds-rule-use-and-acquisition).

Using that condition, the next acquisition study collects 48 calls on six hidden worlds. Two of six proposed rules are correct. Own-record reuse succeeds on 2/6 first queries and 1/6 second queries, giving 3/12 across both query sets. Conditional on successful acquisition, it is 3/4; the unconditional denominator must retain the four failed acquisitions. Correct-rule controls score 2/6 and 3/6, while original observations score 0/6 on the first query. No-information and unrelated-rule controls give 5/6 and 6/6 correct uncertainty responses, which are distinct from exact target trajectories. One reply reaches the length cap. The acquisition-and-use gate fails. These observations establish limited correct acquisition and reuse under a fixed interface, without establishing persistent native learning. [E6](evidence-audit.md#e6-decisive-worlds-rule-use-and-acquisition).

### 5.6 Error-correction observations without a final study decision

A six-world study compares checked repair, generic self-check and a supplied correct rule. All 70 planned calls finish, but the finalization procedure reports a conflict between saved evidence records. A separate descriptive report preserves that unresolved status and contains no final scientific conclusion. Checked repair leaves 2/6 final rules correct and yields 1/6 complete pipelines; generic self-check leaves 1/6 correct and yields 0/6 pipelines. Supplied rules yield 2/6 complete pipelines. A pipeline requires a correct rule and both exact unseen predictions. Neither repair condition makes any of the four initially incorrect or ineligible rules exact. The successful checked pipeline preserves an already correct rule. Two replies reach the total cap. These counts diagnose recorded behaviour and cannot be promoted into a confirmed repair effect. The preceding repair attempt contributes one additional, mechanically refused completion outside the 70-call allocation. [E7](evidence-audit.md#e7-repair-and-decisive-learning-lineage).

### 5.7 Preparatory tests for a controlled learning comparison

The project calls its planned test of learning through interaction the decisive-learning comparison. It is intended to distinguish effects of task exposure, memory and parameter updates under specified conditions. Its preliminary stages identify tasks on which a change can be measured before allocating them to the final comparison. Five retained August attempts end in terminal refusals involving an unsupported task kind, an instrument hash mismatch, an exposed probe instance, insufficient interaction examples or a mismatched sham condition. Their earlier phase data remain archived, but the aborted designs do not supply completed programme-level efficacy verdicts. The v9 preparation finds inadequate fresh task capacity, and v10's seal refuses insufficient interaction sequences before model inference. [E7](evidence-audit.md#e7-repair-and-decisive-learning-lineage).

| Attempt | Saved pilot replies | Recorded disposition |
| --- | ---: | --- |
| v11 | 15/336 | Invalid calibration-seed schedule |
| v12 | 130/336 | Ended before a generation-budget change; no final comparison |
| v13 | 336/336 | Preparation complete; too few eligible tasks for the final comparison |
| v14 | 336/336 | Preparation complete; too few eligible tasks for the final comparison |
| v15 | 175/336 | Incomplete collection at the data cutoff; no final comparison |

The fractions describe collection against a 336-measurement pilot schedule, not learning success. Under the 4,096-token budget, v13 records 142 SOUND, 179 FAIL and 15 INVALID labels across the pilot and its repeat. V14 records 173, 156 and seven respectively. These are the frozen pilot grader's labels, not the whole-reply acceptance endpoint used in the formal adapter study. V13 fails allocation because class07 has no eligible immediate probes where eight are required; v14 fails the corresponding class06 requirement. Different task allocations and eligibility decisions prevent interpreting differences between versions as a learning trend. V15's partial labels remain provisional. Its incomplete collection is not an observed failure to learn. No completed learning-effect verdict is inferred from these pilots. [E7](evidence-audit.md#e7-repair-and-decisive-learning-lineage).

### 5.8 Prediction during interaction with one participant

The numeric export used for the website plots was saved on 5 September 2026. It contains 717 prediction-error entries logged for one regular participant from 2 to 13 August: 652 under version 1 and 65 under version 2. Within each score version, a gap of at least 30 minutes starts a new session; this produces 15 and seven sessions respectively. Figure panels retain the two versions separately. Individual scores are rounded to four decimal places in the export. The original session medians were computed before rounding. [Exchange data and checks: E9](evidence-audit.md#e9-observational-exchange-plots).

The first session median is 0.4795 on 2 August, and a later median is 0.3694 on 3 August. Subsequent version-1 session medians range from 0.3912 to 0.5497. These observations show changing prediction error, including a decline between early sessions and variation afterwards. Topics, interaction context and system settings also changed. There is no matched unchanged-system control for these exchanges, so the trajectory does not identify a causal effect of training or establish a persistent performance limit.

### 5.9 Prediction with AI teachers and external text

The same export contains 14,685 scores from three AI-teacher sources and 2,708 from an external-text stream. The teacher group has 3,179 version-1 and 11,506 version-2 scores; external-text scores use version 2. We show daily medians and first-to-third quartile bands within each group and score version, together with per-source session medians. Daily summaries are weighted by the underlying scores, not by giving each source or session equal weight. The bands describe the score distribution and are not confidence intervals.

The sources differ in topics, formats, dates and generation settings. Differences between their scores therefore do not establish which source is more intelligent or which interaction caused learning. Version changes can also shift the measurement itself. Fourteen entries from another guest identifier are counted in the export but excluded from these plotted groups; they are not counted as failed or missing learning outcomes. [E9](evidence-audit.md#e9-observational-exchange-plots).

### 5.10 Prediction in nine automated teaching programmes

Nine mathematics teaching programmes contribute 1,953 version-2 scores in 79 sessions between 16 and 31 August. Each programme has its own panel, with daily and session medians kept separate from the AI-teacher and external-text groups. The programme names identify the supplied task content. Their comparison is descriptive: the record does not hold task difficulty, teaching sequence, prior exposure and system configuration constant. Neither a low prediction-error score nor a change across sessions establishes that the system learned to solve the corresponding mathematics problems.

The paper and website use the same figures, generated together in PDF and SVG formats from one frozen numeric export. Panels, axes, markers and gaps therefore match across both presentations. Lines do not bridge dates without observations. The export contains no message text. The companion audit checks counts, measurement versions, session grouping and participant medians up to export rounding. Guest individual scores are absent from this export, so guest medians and quartiles are preserved from the exporter rather than independently recalculated from raw observations. The included exporter source specifies the original aggregation procedure. [E9](evidence-audit.md#e9-observational-exchange-plots).

### 5.11 Earlier observations, diagnostics and field studies

The wider archive includes early participant and guest interaction, prediction-adapter training, memory tests, scaling diagnostics, classroom and method-service trials, earlier body-evolution comparisons and exploratory Kryptos work. These records use different instruments and decision rules. They are included in the data package and catalogue rather than pooled into a single improvement score. For example, the first reported body-evolution comparison completes 396 requests with zero measured gains, losses or memory interaction; no memory passes its retrieval threshold. This limits the contrast actually exercised. Early reports also describe improved recall alongside worse judgement when the same record is supplied. Such observations motivate attention to harmful memory and circular evidence, but are not direct tests of the echo-chamber definition proposed here. [E8](evidence-audit.md#e8-earlier-programme-records).

An earlier response comparison recorded 94 accepted answers out of 128 for its candidate, 73 for the base model and 52 for the shuffled control, but failed a rule governing permitted numerical constants. A subsequent 64-question comparison recorded 25 candidate successes and zero for both controls; three of 39 failed candidate replies violated its negative-constant rule, exceeding the specified limit. An 18-question place-value follow-up then recorded 18 exact-check successes after prompt regeneration, compared with zero for each control, without the additional AI review. These studies form part of the selection and revision history leading to the main comparison. They use different conditions and are not pooled into an overall success rate. [E8](evidence-audit.md#e8-earlier-programme-records).

## 6. Discussion and relation to prior work

The strongest observed adapter effect is learning from verified examples within trained mathematical families. The harder-task result and private continuation show why that finding must be separated from broad transfer and sustained improvement. In particular, a reduction in validation loss can coexist with failures on the behavioural adoption endpoint. The hidden-world studies further distinguish applying a supplied rule, acquiring one from observations and using an external record after a reset. Limited success at one stage does not establish success of the entire pipeline. The decisive-learning refusals document measurement and feasibility constraints; they are not interchangeable with negative model-learning outcomes.

Preserving earlier capabilities is an established continual-learning problem. Elastic weight consolidation provides one method for limiting interference with earlier tasks; our experiments do not compare against that method. [Kirkpatrick et al., 2017](https://arxiv.org/abs/1612.00796). Continual-learning research also considers changing objectives, resource limits and evaluation beyond language interfaces. [Lesort et al., 2019](https://arxiv.org/abs/1907.00182).

Human participation in learning is likewise established. Preference-based reinforcement learning uses human comparisons to learn a task objective. [Christiano et al., 2017](https://arxiv.org/abs/1706.03741). CIRL and the off-switch game make different assumptions about human information and the agent's objective. Dynamical Synthesis currently supplies neither their objective-learning formulation nor a corresponding oversight theorem. Its proposed contribution concerns how interaction, provenance, learning and acceptance tests are organized and evaluated together. A sharper comparison with adaptive control, interactive learning and verified program synthesis is needed before asserting technical novelty.

Model-generated feedback also has an established research context. Shumailov et al. show degradation under recursive training on generated data in the regimes they study. [Shumailov et al., 2024](https://www.nature.com/articles/s41586-024-07566-y). Gerstgrasser et al. find that retaining original data while accumulating synthetic data avoids collapse in their studied settings, with a supporting analysis for a sequence of linear models. [Gerstgrasser et al., 2024](https://arxiv.org/abs/2404.01413). These results do not imply that all synthetic data cause collapse or that retaining data guarantees reliability in every system. Distributional model collapse is also distinct from circular corroboration during interaction. We infer a shared design concern: the origin, dependence and retention of evidence matter. The selected Fish studies do not directly test either phenomenon.

Several limitations determine the scope of this draft. The studies share a programme, model lineage, task types and evaluation infrastructure. They lack independent training replications, and AI reviewers may share errors with the evaluated system. Protocols were frozen locally, and the complete raw evidence package has not been publicly released. The observational plots concern repeated exchanges with changing content and settings; their counts are not counts of independent participants. No reported experiment directly tests preference alignment, durable compliance with changed permissions, resistance to misleading feedback or reliable acceptance of human intervention through successive learning updates.

The framework's general computational scope is therefore an intention for future implementations. Empirical claims here remain specific to Fish and the tested configurations. External observations can be noisy or biased, agents can share errors, and human input can be mistaken or unauthorized. Accurate prediction of an input is not a substitute for evaluating its evidence or deciding how to act. In human-facing applications, environmental adaptation must be assessed separately from preserving legitimate human oversight.

## 7. Research goals

We aim to develop useful learning while preserving effective human control over its use. For a proposed application, the evaluation should specify the problem, the people affected, expected benefits and possible harms. Learning updates should be assessed for improvements, losses on earlier tasks and continued acceptance of authorised intervention. Our focus on how these properties change through learning relates to established research priorities for robust and beneficial AI. [Russell, Dewey and Tegmark, 2015](https://futureoflife.org/data/documents/research_priorities.pdf). The following studies would make those questions testable:

1. **Measure response to external evidence.** Match initial states and tasks while varying informative observations, valid corrections, irrelevant input and absent input. Specify the expected behavioural changes and distinguish evidence from authority. Test whether appropriate responsiveness survives later updates.
2. **Test circular feedback.** Compare a claim returned through another agent with a fresh measurement or a check of that claim. Control the information available to each agent, shared data and opportunities to inspect the answer. Measure error persistence and recovery on an evaluation set kept outside the feedback loop. Treat different model identities as a condition to study, not proof of independence.
3. **Separate memory from parameter learning.** Cross access to archived experience with candidate updates while holding examples, prompts and compute budgets fixed. Evaluate fresh instances after context resets and after subsequent learning episodes.
4. **Test cumulative retention and transfer.** Reserve complete task families and earlier-skill sets with demonstrated baseline competence. Include frozen-model, replay and other appropriate continual-learning controls, and independently trained candidate seeds. Preserve original records when introducing generated examples and track their contribution separately.
5. **Verify proposed programs.** Specify the intended behaviour before generating a program. Evaluate on cases excluded from the feedback process and, where feasible, require machine-checkable proofs for the stated input domain. Review whether the specification itself represents the intended task.
6. **Evaluate the generation of new ideas.** Define novelty against a fixed body of examples and prior work. Compare informative, withheld and shuffled observations under matched computational budgets. Test proposed hypotheses, methods or designs on reserved cases, record failed and duplicate proposals, and seek independent assessment before a claim of discovery.
7. **Study the computational universe.** Use finite selections from the space of possible programs, rules and their behaviours. This use of the term follows the Wolfram Physics Project glossary [Wolfram Physics Project, n.d.](https://wolframphysics.org/glossary/). Candidate environments include cellular automata, symbolic rewrite systems and interacting agents with explicit boundaries. Reserve rule classes and initial conditions; compare learned predictions and actions with direct simulation, search and unchanged-system baselines while recording resource use.
8. **Evaluate oversight through repeated updates.** Test changes in task constraints, action permissions and authorised interruption before and after learning. Measure intervention success and response time, and preserve the previous version if an update fails a required control test. Distinguish enforcement by the surrounding software from the model's own responses to intervention.

Each study needs a fixed sampling and exclusion policy, an analysis unit appropriate to repeated tasks and seeds, and a record of failed or infeasible attempts. Eligibility pilots select where a comparison can be measured; they do not themselves estimate a learning effect. These directions are proposed work.

A computational description of physical reality is a separate hypothesis, explored for example in the Wolfram Physics Project [Wolfram, 2020](https://www.wolframphysics.org/technical-introduction/). Evaluating such a hypothesis requires predictions about physical observations and comparison with established theories. Success in the simulated environments proposed here would not establish a computational theory of nature.

## 8. Conclusion

Dynamical Synthesis expresses an architectural aim: systems should be able to learn through continuing interaction with what lies beyond their defined boundary. In \(I = W(I) + \mathrm{You}\), *You* includes environmental signals, people and other systems. This breadth requires explicit treatment of provenance and feedback: an outside message may still be an echo of the learner's own output. Making the framework scientific requires specified computation and distinct measurements of acquisition, retention, transfer and responsiveness to evidence. The current case studies establish a narrow adapter-learning effect, delimit its transfer and show a subsequent update being rejected despite lower validation loss. Resistance to circular feedback and preservation of human oversight remain research questions.

## Data, code and reporting statement

The detailed experiment repository and full run artifacts are currently private. Companion materials supplied with this draft include the LaTeX and Markdown manuscript, vector figures, study summaries, the numeric exchange export, analysis code and evidence audits. These allow readers to inspect the reported counts and regenerate the figures. Raw participant messages, model weights and private databases are separate from the source bundle.

The larger archive preserves available records under declared roots with a manifest and SHA-256 identifiers. File totals include copies and overlapping artifacts; they are coverage counts, not sample sizes. The evidence index identifies each study's source records and limitations. Requests for detailed evidence can be directed to the Loopseed Team. Checks of stored bytes and arithmetic do not regrade every response or constitute independent replication.

The [evidence audit](evidence-audit.md) records source checks and claim boundaries. Historical unsuccessful and invalid decisions are preserved; incomplete collection is identified separately. No new model experiment was run for this revision. OpenAI Codex assisted with drafting, code editing, figure preparation and consistency checks. The named research team is responsible for the manuscript and its interpretation.

Bibliographic entries for the linked sources are in [references.bib](references.bib).

## Authorship and correspondence

**Loopseed Team, led by Brian Ashiundu**

**Affiliation:** Dilate Technologies.

**Brian Ashiundu, research lead:** [brian.ashiundu@questlyst.com](mailto:brian.ashiundu@questlyst.com) and [bmboya@wolframinstitute.org](mailto:bmboya@wolframinstitute.org).

**Loopseed Team:** [support@questlyst.com](mailto:support@questlyst.com).

**Project:** [loopseed.io](https://loopseed.io/). **Company:** [Dilate Technologies](https://dilate.co.ke/).
