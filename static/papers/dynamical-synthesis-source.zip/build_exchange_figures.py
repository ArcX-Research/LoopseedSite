#!/usr/bin/env python3
"""Audit the frozen website export and draw observational exchange figures.

Reads numeric scores and summaries only. Does not access a database or model.
The guest export contains summaries, so its raw quartiles cannot be recomputed
from this public file; its counts and internal consistency can be checked.
"""

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import statistics

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

HERE = Path(__file__).resolve().parent
OUT = HERE / "figures"
SOURCE = HERE / "exchange-scores.json"
EXPECTED_SHA256 = "4112a2fcbe515f69f950845bc7269576171246153f2f00e19eeca28c9933f7e3"
DAY = 86_400
INK, BLUE, ORANGE, GRAY = "#10152c", "#4946ff", "#ad6d00", "#667080"
TITLES = {
    "class01-factor": "Prime factorization",
    "class02-fraction": "Fraction reduction",
    "class03-division": "Quotient and remainder",
    "class04-euclid": "Euclidean recurrence",
    "class05-binomial": "Binomial recurrence",
    "class06-cancel": "Exact cancellation",
    "class07-paths": "Blocked lattice paths",
    "class08-choices": "Constrained combinations",
    "class09-rectangles": "Non-square rectangles",
}


def date(t):
    return datetime.fromtimestamp(t, timezone.utc)


def span(rows):
    return [date(min(r["t"] for r in rows)).isoformat(),
            date(max(r.get("end", r["t"]) for r in rows)).isoformat()]


def audit(data):
    digest = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    assert digest == EXPECTED_SHA256, "Review a changed export before rebuilding"
    assert data["keeper_grades"] == len(data["grades"]) == 717
    assert {r["v"] for r in data["grades"]} <= {1, 2}
    assert all(0 <= r["d"] <= 2 for r in data["grades"])
    max_rounding_difference = 0.0
    for version in (1, 2):
        points = sorted((r for r in data["grades"] if r["v"] == version),
                        key=lambda r: r["t"])
        sessions = []
        for point in points:
            if sessions and point["t"] - sessions[-1][-1]["t"] < 1800:
                sessions[-1].append(point)
            else:
                sessions.append([point])
        recorded = sorted((r for r in data["windows"] if r["v"] == version),
                          key=lambda r: r["t"])
        assert len(sessions) == len(recorded)
        for rows, summary in zip(sessions, recorded):
            assert (rows[0]["t"], rows[-1]["t"], len(rows)) == (
                summary["t"], summary["end"], summary["n"])
            difference = abs(statistics.median(r["d"] for r in rows) - summary["median"])
            # Individual scores and original medians were separately rounded.
            assert difference <= 0.0001000001
            max_rounding_difference = max(max_rounding_difference, difference)
    guest = data["guests"]
    assert sum(g["grades"] for g in guest["groups"]) == 19346
    assert 19346 + guest["omitted"]["grades"] == data["guest_grades_excluded"] == 19360
    keys = [(r["g"], r["s"], r["v"], r["t"]) for r in guest["days"]]
    assert len(keys) == len(set(keys))
    assert all(0 <= r["q1"] <= r["median"] <= r["q3"] <= 2 for r in guest["days"])
    groups = {}
    for group in guest["groups"]:
        days = [r for r in guest["days"] if r["g"] == group["key"]]
        sessions = [r for r in guest["sittings"] if r["g"] == group["key"]]
        assert sum(r["n"] for r in days) == sum(r["n"] for r in sessions) == group["grades"]
        assert sum(r["grades"] for r in group["speakers"]) == group["grades"]
        for version in (1, 2):
            assert sum(r["n"] for r in days if r["v"] == version) == sum(
                r["n"] for r in sessions if r["v"] == version)
        groups[group["key"]] = {
            "scores": group["grades"], "sessions": len(sessions),
            "scores_by_version": {
                str(v): sum(r["n"] for r in sessions if r["v"] == v) for v in (1, 2)},
            "sessions_by_version": dict(Counter(str(r["v"]) for r in sessions)),
            "utc_span": span(sessions),
        }
    return {
        "review_date": "2026-09-11",
        "source": "exchange-scores.json",
        "source_sha256": digest,
        "source_exported_at": data["exported_at"],
        "source_origin": "LoopseedSite/crates/record/data/skin.json",
        "exporter_source_sha256": hashlib.sha256(
            (HERE / "exchange-export-source.py").read_bytes()).hexdigest(),
        "participant_scores": len(data["grades"]),
        "participant_scores_by_version": dict(Counter(str(r["v"]) for r in data["grades"])),
        "participant_sessions_by_version": dict(Counter(str(r["v"]) for r in data["windows"])),
        "participant_utc_span": span(data["grades"]),
        "participant_max_median_rounding_difference": max_rounding_difference,
        "guest_groups": groups,
        "omitted_guest_scores": guest["omitted"]["grades"],
        "reference_memory_threshold": data["theta"],
        "session_rule": "Within each source and score version, a gap >= 30 minutes starts a session.",
        "daily_summary_rule": "UTC days; pooled teachers, pooled external text, each teaching programme separate; score versions separate.",
        "quartile_method": "Python statistics.quantiles(n=4, method='exclusive'); one score uses that value for all quartiles.",
        "limitations": [
            "Guest individual scores are not present; guest medians and quartiles are preserved from the export, not independently recomputed.",
            "Pooled group medians that mix versions are not plotted or interpreted.",
            "The reference threshold is not a record of its value at every exchange.",
            "These are repeated observations from changing tasks and configurations, not independent participants or causal training estimates.",
        ],
        "plotting": {"matplotlib": matplotlib.__version__, "times": "UTC",
                     "daily_marker_time": "12:00 UTC", "session_marker_time": "session start",
                     "y_limits": [0, 1],
                     "svg_text": "Glyph paths preserve the paper's typography in browsers without its fonts.",
                     "daily_lines": "Connect consecutive UTC dates only; do not bridge missing dates.",
                     "session_lines": "Break when a whole UTC date without scores separates sessions.",
                     "shared_outputs": "The website displays SVG exports of the same figures included as PDF in the paper."},
    }


def frame(ax, title, theta, colour=INK):
    ax.set_title(title, loc="left", fontsize=10.5, fontweight="bold", pad=9, color=colour)
    ax.set_ylim(0, 1)
    ax.set_yticks([0, .2, .4, .6, .8, 1])
    ax.grid(axis="y", alpha=.18)
    ax.set_axisbelow(True)
    ax.spines[["top", "right"]].set_visible(False)
    ax.axhline(theta, color=GRAY, linestyle=(0, (3, 3)), linewidth=.8, zorder=1)
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b", tz=timezone.utc))
    ax.tick_params(labelsize=9)


def save(fig, name):
    OUT.mkdir(exist_ok=True)
    for extension in ("pdf", "svg", "png"):
        fig.savefig(OUT / f"{name}.{extension}", dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def dated_runs(rows, daily=False):
    """Keep all observations while preventing lines through unobserved dates."""
    runs = []
    for row in sorted(rows, key=lambda r: r["t"]):
        if runs:
            previous = runs[-1][-1]
            joins = (row["t"] - previous["t"] == DAY if daily else
                     row["t"] // DAY - previous.get("end", previous["t"]) // DAY <= 1)
            if joins:
                runs[-1].append(row)
                continue
        runs.append([row])
    return runs


def date_limits(ax, rows):
    left = min(r["t"] for r in rows) // DAY * DAY
    right = (max(r.get("end", r["t"]) for r in rows) // DAY + 1) * DAY
    ax.set_xlim(date(left), date(right))


def participant(data):
    fig, axes = plt.subplots(2, 1, figsize=(8.1, 5.0), sharex=True, layout="constrained")
    for ax, version, colour, panel in zip(axes, (1, 2), (BLUE, ORANGE), ("A", "B")):
        grades = [r for r in data["grades"] if r["v"] == version]
        sessions = sorted((r for r in data["windows"] if r["v"] == version),
                          key=lambda r: r["t"])
        frame(ax, f"{panel}  Score version {version}: {len(grades)} scores, {len(sessions)} sessions", data["theta"])
        ax.scatter([date(r["t"]) for r in grades], [r["d"] for r in grades],
                   s=7, color=colour, alpha=.25, edgecolors="none", zorder=2)
        for run in dated_runs(sessions):
            ax.plot([date(r["t"]) for r in run], [r["median"] for r in run],
                    linewidth=1.15, color=colour, marker="o", markersize=4.5,
                    markerfacecolor="white", markeredgewidth=1.1, zorder=3)
        ax.set_ylabel(r"Prediction error $\delta$")
        ax.axvspan(date(data["grades"][0]["t"]), date(data["instrumentation_end_unix"]),
                   color=GRAY, alpha=.08)
    axes[0].legend(handles=[
        Line2D([], [], marker=".", linestyle="none", color=GRAY, label="Individual score"),
        Line2D([], [], marker="o", markerfacecolor="white", color=GRAY, label="Session median"),
        Line2D([], [], color=GRAY, linestyle="--", label=r"Reference $\theta_m = 0.35$"),
    ], loc="upper right", fontsize=8.5, frameon=False, ncol=3)
    axes[-1].xaxis.set_major_locator(mdates.DayLocator(interval=2, tz=timezone.utc))
    date_limits(axes[-1], data["grades"])
    axes[-1].set_xlabel("Date (UTC, August 2026)")
    save(fig, "interaction-participant")


def draw_summaries(ax, sessions, days, colour, quartiles=True):
    ax.scatter([date(r["t"]) for r in sessions], [r["median"] for r in sessions],
               color=colour, s=10, alpha=.45, edgecolors="none", zorder=2)
    for run in dated_runs(days, daily=True):
        t = [date(r["t"] + DAY // 2) for r in run]
        if quartiles:
            if len(run) > 1:
                ax.fill_between(t, [r["q1"] for r in run], [r["q3"] for r in run],
                                color=colour, alpha=.13, linewidth=0)
            else:
                ax.vlines(t, run[0]["q1"], run[0]["q3"], color=colour, alpha=.35, linewidth=3)
        ax.plot(t, [r["median"] for r in run], color=colour, linewidth=1.15,
                marker="o", markersize=4, markerfacecolor="white", markeredgewidth=1,
                zorder=3)


def other_sources(data):
    fig, axes = plt.subplots(3, 1, figsize=(8.1, 6.6), sharex=True, layout="constrained")
    choices = [("teachers", 1, "AI teachers", BLUE),
               ("teachers", 2, "AI teachers", ORANGE),
               ("weather", 2, "External text", GRAY)]
    for ax, (group, version, title, colour), panel in zip(axes, choices, ("A", "B", "C")):
        sessions = [r for r in data["guests"]["sittings"] if r["g"] == group and r["v"] == version]
        days = [r for r in data["guests"]["days"] if r["g"] == group and r["v"] == version]
        count = sum(r["n"] for r in sessions)
        frame(ax, f"{panel}  {title}, version {version}: {count:,} scores, {len(sessions)} sessions", data["theta"])
        draw_summaries(ax, sessions, days, colour)
        ax.set_ylabel(r"Prediction error $\delta$")
    axes[0].legend(handles=[
        Line2D([], [], marker=".", linestyle="none", color=GRAY, label="Session median"),
        Line2D([], [], marker="o", markerfacecolor="white", color=GRAY, label="Daily median"),
        Patch(facecolor=GRAY, alpha=.18, label="First to third quartile"),
    ], loc="upper right", fontsize=8.5, frameon=False, ncol=3)
    axes[-1].xaxis.set_major_locator(mdates.DayLocator(interval=2, tz=timezone.utc))
    date_limits(axes[-1], [r for r in data["guests"]["sittings"] if r["g"] in ("teachers", "weather")])
    axes[-1].set_xlabel("Date (UTC, August 2026)")
    save(fig, "interaction-sources")


def teaching_programmes(data):
    fig, axes = plt.subplots(3, 3, figsize=(8.1, 6.9), sharex=True, sharey=True, layout="constrained")
    for ax, (key, title), panel in zip(axes.flat, TITLES.items(), "ABCDEFGHI"):
        sessions = [r for r in data["guests"]["sittings"] if r["speaker"] == key]
        days = [r for r in data["guests"]["days"] if r["s"] == key]
        assert {r["v"] for r in sessions + days} == {2}
        count = sum(r["n"] for r in sessions)
        frame(ax, f"{panel}  {title}\n{count} scores, {len(sessions)} sessions", data["theta"])
        ax.set_title(f"{panel}  {title}\n{count} scores, {len(sessions)} sessions",
                     fontsize=9.4, loc="left", fontweight="bold")
        draw_summaries(ax, sessions, days, BLUE, quartiles=False)
        ax.xaxis.set_major_locator(mdates.DayLocator(bymonthday=[16, 23, 30], tz=timezone.utc))
        ax.tick_params(labelsize=8.5)
    date_limits(axes.flat[-1], [r for r in data["guests"]["sittings"] if r["g"] == "classrooms"])
    fig.supxlabel("Date (UTC, August 2026)", fontsize=10)
    fig.supylabel(r"Prediction error $\delta$ (version 2)", fontsize=10)
    save(fig, "interaction-programmes")


def main():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 10,
        "text.color": INK, "axes.labelcolor": INK, "xtick.color": INK,
        "ytick.color": INK, "axes.edgecolor": "#bcc2ce",
        "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "path",
    })
    data = json.loads(SOURCE.read_text())
    report = audit(data)
    participant(data)
    other_sources(data)
    teaching_programmes(data)
    (HERE / "exchange-audit.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print("Exchange audit passed; created 3 observational figures (PDF, SVG, PNG).")


if __name__ == "__main__":
    main()
