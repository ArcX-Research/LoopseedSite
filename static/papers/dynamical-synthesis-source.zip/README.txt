Dynamical Synthesis: Learning through Interaction
11 September 2026
Brian Ashiundu
Research Fellow, Wolfram Institute
Head of Research, Dilate Technologies
Correspondence: brianashiundu000@gmail.com; bmboya@wolframinstitute.org
Research conducted under Dilate Technologies.

This bundle contains editable LaTeX, the Markdown manuscript, vector figures,
aggregate data, an evidence audit, a study catalogue and read-only audit scripts.
It reports the computational framework and component studies; it is not peer-reviewed and
makes no claim that the complete framework establishes alignment or general
continual learning.

Build the PDF from this extracted directory:
    latexmk -pdf -interaction=nonstopmode -halt-on-error manuscript.tex

Dependencies: a TeX distribution with newtx, amsmath, microtype, booktabs,
caption, tabularx, longtable, natbib, hyperref, xurl, enumitem and fancyhdr.
Edit manuscript.tex directly for a standalone LaTeX workflow. In the original
research checkout, build_paper.py generates it from manuscript.md and the data
inventory. That generator also indexes the available research album.

Regenerate the five controlled-study/framework figures:
    uv run --no-project --with matplotlib python build_figures.py

Check the frozen exchange export and regenerate its three observational figures:
    uv run --no-project --with matplotlib python build_exchange_figures.py

exchange-scores.json is the exact numeric export used by the website, saved on
5 September 2026; exchange-audit.json identifies its hash, counts and methods.
The export contains participant scores and guest summaries, without message
text. The guest quartiles cannot be independently recomputed from this file
because guest individual scores are not included. exchange-export-source.py
preserves the original exporter for inspection; using it with a raw database
requires the original LoopseedSite checkout and its connection helper.

Each figure is included as PDF (for LaTeX), SVG (for the website), and PNG.
Different studies have different endpoints; their counts must not be pooled.
The research-record.json source map and evidence-snapshot.json identify the
reviewed input bytes. These identifiers do not establish independent replication.

The verification scripts require the original source layout or the separate
private verification-records.zip. The large research-data.tar.gz archive is
separate and remains private. It preserves all regular files in declared roots;
symlink targets, authentication files and generated caches are excluded.
No model weights are provided by this source bundle.

Historical pilot and adoption decisions are preserved. Brian Ashiundu is the
sole author. The two roles identify his professional appointments.
Venue-specific funding and competing-interest declarations still require
the author's confirmation.
