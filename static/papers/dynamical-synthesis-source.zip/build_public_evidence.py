#!/usr/bin/env python3
"""Export the recorded mathematics comparison for inspection without private data.

Reads an explicit study and its two training datasets. Does not read databases,
model weights, authentication files, or participant exchanges, and runs no model.
"""
import ast
import hashlib
import json
import re
import subprocess
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
STUDY = ROOT / "data/fish/labs/claim-transfer-clean-2026-09-03T170409Z"
DATASETS = ROOT / "data/fish/labs/claude-claims-2026-09-02T131808Z/dreams"
OUT = ROOT / "output/data/dynamical-synthesis/dynamical-synthesis-mathematics-evidence.zip"
LOCAL_PATH = re.compile(r"/(?:Users|home|private|var|tmp)/[^\s\"'<>]+")
SECRET_VALUE = re.compile(rb"(?:sk-[A-Za-z0-9_-]{24,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)")


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def portable(value):
    if isinstance(value, dict):
        return {key: portable(item) for key, item in value.items()}
    if isinstance(value, list):
        return [portable(item) for item in value]
    if isinstance(value, str):
        value = re.sub(re.escape(str(ROOT)) + r"/", "Loopseed/", value, flags=re.I)
        return LOCAL_PATH.sub("[local-path]", value)
    return value


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()


def build():
    files, sources = {}, {}

    def record(path):
        assert path.is_file() and path.suffix in {".json", ".jsonl"}
        raw = path.read_bytes()
        sources[str(path.relative_to(ROOT))] = {"sha256": digest(raw), "bytes": len(raw)}
        return raw

    def export_json(path, target):
        value = json.loads(record(path))
        files[target] = json_bytes(portable(value))
        return value

    protocol = export_json(STUDY / "protocol.json", "study/protocol.json")
    for name in ("arm-key.json", "verdict.json", "audit-bundle.json", "external-audit.json"):
        export_json(STUDY / name, "study/" + name)
    cells = []
    for path in sorted((STUDY / "rows").glob("*/*.json")):
        row = json.loads(record(path))
        cell = {key: value for key, value in row["cell"].items()
                if key not in {"record", "stderr_path", "stdout_path"}}
        # The omitted database record contains internal session/lease bookkeeping.
        # Prompts are retained in the protocol; full generated replies remain here.
        clean = portable(cell)
        assert clean["reply"] == cell["reply"], "A reply contains a local path; review before export"
        cells.append({"status": row["status"], "completed_at": row["completed_at"],
                      "cell": clean, "pins": portable(row["pins"])})
    assert len(cells) == 1024
    files["study/cells.json"] = json_bytes(cells)

    for arm, dirname in (
        ("candidate", "accepted-clean-2026-09-03T1915-EAT"),
        ("shuffled-control", "shuffled-placebo-2026-09-03T164849.819255Z"),
    ):
        folder = DATASETS / dirname
        export_json(folder / "manifest.json", f"training/{arm}/manifest.json")
        for name in ("train.jsonl", "valid.jsonl", "test.jsonl"):
            raw = record(folder / name)
            assert portable(raw.decode()) == raw.decode(), "Review a training path before release"
            files[f"training/{arm}/{name}"] = raw
        records = [portable(json.loads(line)) for line in record(folder / "provenance.jsonl").splitlines()]
        files[f"training/{arm}/selection-records.json"] = json_bytes(records)

    adapters = DATASETS.parent / "body/fish/water/adapters"
    for arm, dirname in (("candidate", "claim-dream-clean-2026-09-03T1920-EAT"),
                         ("shuffled-control", "claim-shuffled-placebo-clean-2026-09-03T1949-EAT")):
        for name in ("adapter_config.json", "dream.json"):
            path = adapters / dirname / name
            if path.exists():
                export_json(path, f"training/{arm}/{name}")

    commit = protocol["pins"]["git_commit"]
    tree = set(subprocess.check_output(["git", "ls-tree", "-r", "--name-only", commit],
                                      cwd=ROOT, text=True).splitlines())
    pending = {"fish/lab/claim_transfer_experiment.py", "fish/lab/claim_transfer_protocol.py",
               "fish/lab/claim_placebo.py", "fish/lab/formal_node_language.py",
               "fish/lab/typed_ast_probe_v2.py"}
    code_hashes = {}
    while pending:
        path = pending.pop()
        if path in code_hashes:
            continue
        raw = subprocess.check_output(["git", "show", commit + ":" + path], cwd=ROOT)
        code_hashes[path] = digest(raw)
        files["code/" + path] = raw
        for node in ast.walk(ast.parse(raw)):
            modules = []
            if isinstance(node, ast.Import):
                modules = [name.name for name in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module:
                modules = [node.module] + [node.module + "." + name.name for name in node.names]
            for module in modules:
                if module == "fish" or module.startswith("fish."):
                    for candidate in (module.replace(".", "/") + ".py",
                                      module.replace(".", "/") + "/__init__.py"):
                        if candidate in tree:
                            pending.add(candidate)
    for module, pin in (("claim_transfer_experiment", "claim_transfer_experiment_sha256"),
                        ("claim_transfer_protocol", "claim_transfer_protocol_sha256"),
                        ("formal_node_language", "formal_node_language_sha256"),
                        ("typed_ast_probe_v2", "typed_ast_probe_v2_sha256"),
                        ("adaptive_evolution", "adaptive_evolution_sha256"),
                        ("claim_evolution", "claim_evolution_v1_sha256"),
                        ("claim_placebo", "claim_placebo_sha256")):
        assert code_hashes[f"fish/lab/{module}.py"] == protocol["pins"][pin], module
    for path in sorted(tree):
        if path in {"pyproject.toml", "uv.lock", "fish/daemon/Cargo.toml", "fish/daemon/Cargo.lock", "LICENSE", "LICENSE.md"} or (
                path.startswith("fish/lab/") and path.endswith(".gbnf")):
            raw = subprocess.check_output(["git", "show", commit + ":" + path], cwd=ROOT)
            files["code/" + path] = raw
            code_hashes[path] = digest(raw)
    files["verify.py"] = (HERE / "verify_public_evidence.py").read_bytes()
    files["README.md"] = (HERE / "public-evidence-readme.md").read_bytes()
    files["source-record.json"] = json_bytes({
        "study": str(STUDY.relative_to(ROOT)), "recorded_code_commit": commit,
        "original_files": sources, "recorded_code_sha256": code_hashes,
        "transformations": ["Local paths in JSON metadata are replaced with portable labels.",
                            "Cells omit internal database/session/lease records and local log paths.",
                            "Training splits, mathematical replies and recorded code retain their original bytes or text.",
                            "Stored historical hashes refer to original files, not transformed exports."],
    })
    for name, raw in files.items():
        assert not SECRET_VALUE.search(raw), f"Potential credential in {name}; review before export"
    files["manifest.json"] = json_bytes({name: {"sha256": digest(raw), "bytes": len(raw)}
                                         for name, raw in sorted(files.items())})
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(files.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 9, 11, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, raw)
    print(f"Prepared {len(cells)} cells, {len(code_hashes)} recorded code/configuration files; {OUT.stat().st_size:,} bytes")


if __name__ == "__main__":
    build()
