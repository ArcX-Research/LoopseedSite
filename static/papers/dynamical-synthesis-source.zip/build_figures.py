#!/usr/bin/env python3
"""Create vector scientific figures from the shared, archived research record."""

import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch
import numpy as np

HERE = Path(__file__).resolve().parent
DATA = json.loads((HERE / "research-record.json").read_text())
OUT = HERE / "figures"
OUT.mkdir(exist_ok=True)
INK, BLUE, GRAY, RED, GREEN = "#10152c", "#4946ff", "#8b91a2", "#ac473d", "#26766e"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 10,
    "axes.titlesize": 11, "axes.labelsize": 10, "xtick.labelsize": 9,
    "ytick.labelsize": 10, "text.color": INK, "axes.labelcolor": INK,
    "xtick.color": INK, "ytick.color": INK, "axes.edgecolor": "#c7cbd5",
    "axes.spines.top": False, "axes.spines.right": False,
    "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
    "savefig.facecolor": "white",
})


def save(fig, name):
    for extension in ("pdf", "svg", "png"):
        fig.savefig(OUT / (name + "." + extension), bbox_inches="tight", dpi=180)
    plt.close(fig)


def percent_bars(ax, labels, values, n, title, colors):
    y = np.arange(len(labels))
    ax.barh(y, [100 * v / n for v in values], color=colors, height=0.56)
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    ax.set_xlim(0, 112)
    ax.set_xticks([0, 25, 50, 75, 100])
    ax.set_xlabel("Accepted answers (%)")
    ax.set_title(title, loc="left", pad=13, fontweight="bold")
    ax.set_axisbelow(True)
    ax.grid(axis="x", alpha=0.18)
    for i, value in enumerate(values):
        ax.text(100 * value / n + 2, i, f"{value}/{n}", va="center", fontsize=10)
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", length=0)


fig, ax = plt.subplots(figsize=(8.0, 3.8))
ax.set(xlim=(0, 1), ylim=(0, 1))
ax.axis("off")

def box(x, y, text, width=0.2, face="#f1f3fa"):
    ax.text(x, y, text, ha="center", va="center", fontsize=10,
            bbox={"boxstyle": "round,pad=0.55", "facecolor": face, "edgecolor": "#bdc3d4", "linewidth": 0.9})

def arrow(start, end, text=None, color=GRAY, connection="arc3,rad=0"):
    ax.add_patch(FancyArrowPatch(start, end, arrowstyle="-|>", mutation_scale=12,
                                color=color, linewidth=1.1, connectionstyle=connection))
    if text:
        ax.text((start[0] + end[0]) / 2, (start[1] + end[1]) / 2 + 0.035,
                text, ha="center", va="bottom", fontsize=8.5,
                bbox={"facecolor": "white", "edgecolor": "none", "pad": 1.5})

box(0.13, 0.69, "External input $u_t$\nEnvironment\nPeople and other systems")
box(0.50, 0.69, "System state $s_t$\nInternal update $F_{\\theta_t}$")
box(0.85, 0.69, "Action $a_t$\nPolicy $\\pi_{\\theta_t}$")
arrow((0.29, 0.69), (0.36, 0.69))
arrow((0.64, 0.69), (0.76, 0.69))
arrow((0.85, 0.84), (0.15, 0.87), color=GRAY, connection="arc3,rad=0.13")
ax.text(0.50, 1.0, "Consequences and returned messages", ha="center", va="top", fontsize=9)
box(0.16, 0.19, "Recorded experience\nSources and checks")
box(0.51, 0.19, "Candidate update\nTraining / revision")
box(0.85, 0.19, "Evaluation\nAdopt or retain")
arrow((0.28, 0.19), (0.38, 0.19))
arrow((0.64, 0.19), (0.74, 0.19))
arrow((0.17, 0.48), (0.17, 0.32))
arrow((0.85, 0.32), (0.54, 0.54), "Accepted update", color=BLUE)
ax.text(0.39, 0.43, "Returning across the boundary\ndoes not establish new evidence", fontsize=9,
        ha="center", va="center", color=RED)
save(fig, "framework")

fig, axes = plt.subplots(1, 2, figsize=(8.1, 3.4), layout="constrained")
formal = DATA["formal"]["arms"]
percent_bars(axes[0], ["Candidate", "Base", "Shuffled control", "Prediction adapter"],
             [formal[k]["audit_accepted"] for k in ("candidate", "bare", "placebo", "retained")], 64,
             "A  New values in trained problem types", [BLUE, GRAY, RED, GREEN])
h = DATA["harder"]
percent_bars(axes[1], ["Candidate", "Shuffled control", "Prediction adapter"],
             [h["candidate_vs_placebo"]["transfer"]["candidate_accepted"],
              h["candidate_vs_placebo"]["transfer"]["comparator_accepted"],
              h["candidate_vs_retained"]["transfer"]["comparator_accepted"]], 81,
             "B  Harder mathematics, plain text", [BLUE, RED, GREEN])
save(fig, "adapter-transfer")

private = DATA["private_continuation"]
fig, axes = plt.subplots(1, 2, figsize=(8.1, 3.7), layout="constrained", gridspec_kw={"width_ratios": [1, 1.2]})
ax = axes[0]
loss = private["prediction_loss"]
x = np.arange(2)
before = [loss["before"][k] for k in ("new_witness", "retention_witness")]
after = [loss["after"][k] for k in ("new_witness", "retention_witness")]
ax.bar(x - .18, before, width=.34, color=GRAY, label="Before")
ax.bar(x + .18, after, width=.34, color=RED, label="After")
for xs, ys in ((x - .18, before), (x + .18, after)):
    for px, py in zip(xs, ys): ax.text(px, py + .06, f"{py:.3f}", ha="center", fontsize=8.5)
ax.set_xticks(x, ["New evaluation set\n3 pairs", "Historical set\n16 pairs"])
ax.set_ylim(0, 3.25)
ax.set_ylabel("Prediction loss (lower is better)")
ax.set_title("A  Prediction update", loc="left", fontweight="bold", pad=13)
ax.legend(loc="upper left", frameon=False, fontsize=9)
ax.set_axisbelow(True); ax.grid(axis="y", alpha=.15)
ax = axes[1]
names = ("transfer", "retention", "boundary")
rows = [private["speaking_groups"][name] for name in names]
y = np.arange(3)
ax.barh(y, [-row["losses"] for row in rows], color=RED, height=.5, label="Losses")
ax.barh(y, [row["gains"] for row in rows], color=BLUE, height=.5, label="Gains")
ax.axvline(0, color=INK, linewidth=.8)
ax.set_yticks(y, ["New numerical cases\n60 pairs", "Earlier skills\n18 pairs", "Unavailable info\n6 pairs"])
ax.invert_yaxis(); ax.set_xlim(-13, 13)
ax.set_xticks([-10, -5, 0, 5, 10], ["10", "5", "0", "5", "10"])
ax.set_xlabel("Losses  ←  Paired comparisons  →  Gains")
ax.set_title("B  Response update", loc="left", fontweight="bold", pad=13)
for i, row in enumerate(rows):
    if row["losses"]: ax.text(-row["losses"] - .5, i, str(row["losses"]), ha="right", va="center")
    if row["gains"]: ax.text(row["gains"] + .5, i, str(row["gains"]), ha="left", va="center")
    if not row["gains"] and not row["losses"]: ax.text(.5, i, "0 gains / 0 losses", va="center", fontsize=9)
ax.spines["left"].set_visible(False); ax.tick_params(axis="y", length=0)
save(fig, "continuation")

fig, axes = plt.subplots(3, 1, figsize=(7.5, 7.0), layout="constrained")
r = DATA["rule_use"]["conditions"]
percent_bars(axes[0], ["Retained / thinking on", "Retained / thinking off", "Candidate / thinking on", "Candidate / thinking off"],
             [r[k]["exact"] for k in ("retained-on", "retained-off", "candidate-on", "candidate-off")], 12,
             "A  Applying a supplied rule", [BLUE, GRAY, GREEN, GRAY])
a = DATA["acquisition"]["conditions"]
percent_bars(axes[1], ["Own rule / query 1", "Own rule / query 2", "Supplied / query 1", "Supplied / query 2"],
             [a[k]["exact"] for k in ("own-p1", "own-p2", "supplied-p1", "supplied-p2")], 6,
             "B  Reuse after acquisition (2/6 rules correct)", [BLUE, BLUE, GREEN, GREEN])
w = DATA["worlds"]
percent_bars(axes[2], ["Own records", "Original observations", "No records"],
             [w[k] for k in ("own", "raw", "none")], 16,
             "C  Earlier eight-world pilot", [BLUE, GREEN, GRAY])
save(fig, "world-learning")

fig, ax = plt.subplots(figsize=(8.0, 4.0), layout="constrained")
pilots = DATA["decisive_pilots"]
y = np.arange(len(pilots))
left = np.zeros(len(pilots))
for key, color, label in (("SOUND", BLUE, "SOUND"), ("FAIL", RED, "FAIL"), ("INVALID", GRAY, "INVALID")):
    values = [sum(cell[key] for cell in run["cells"].values()) for run in pilots]
    ax.barh(y, values, left=left, color=color, height=.58, label=label)
    left += values
ax.barh(y, [run["scheduled"] - run["saved"] for run in pilots], left=left,
        color="white", edgecolor="#c7cbd5", hatch="///", linewidth=.6, height=.58, label="Uncollected")
labels = ["v11 - invalid schedule", "v12 - budget change", "v13 - allocation refused", "v14 - allocation refused", "v15 - incomplete"]
ax.set_yticks(y, labels); ax.invert_yaxis()
for i, run in enumerate(pilots): ax.text(345, i, f"{run['saved']}/336", va="center", fontsize=10)
ax.set_xlim(0, 399); ax.set_xticks([0, 84, 168, 252, 336])
ax.set_xlabel("Scheduled pilot measurements")
ax.set_title("Collection and recorded grader labels", loc="left", fontweight="bold", pad=16)
ax.legend(loc="upper center", bbox_to_anchor=(.46, -.19), ncol=4, frameon=False, fontsize=9)
ax.spines["left"].set_visible(False); ax.tick_params(axis="y", length=0)
save(fig, "decisive-pilots")

print("Created 5 figures in PDF, SVG and PNG formats")
