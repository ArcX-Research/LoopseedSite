#!/usr/bin/env python3
"""Create vector scientific figures from the shared, archived research record."""

import argparse
import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
import numpy as np

HERE = Path(__file__).resolve().parent
DATA = json.loads((HERE / "research-record.json").read_text())
OUT = HERE / "figures"
OUT.mkdir(exist_ok=True)
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--only", choices=("framework", "adapter-transfer", "continuation",
                                      "world-learning", "decisive-pilots"))
selected = parser.parse_args().only
created = []
INK, BLUE, GRAY, RED, GREEN = "#10152c", "#4946ff", "#8b91a2", "#ac473d", "#26766e"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 10,
    "axes.titlesize": 11, "axes.labelsize": 10, "xtick.labelsize": 9,
    "ytick.labelsize": 10, "text.color": INK, "axes.labelcolor": INK,
    "xtick.color": INK, "ytick.color": INK, "axes.edgecolor": "#c7cbd5",
    "axes.spines.top": False, "axes.spines.right": False,
    "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
    "savefig.facecolor": "white",
})


def save(fig, name):
    if selected is not None and name != selected:
        plt.close(fig)
        return
    for extension in ("pdf", "svg", "png"):
        fig.savefig(OUT / (name + "." + extension), bbox_inches="tight", dpi=180)
    plt.close(fig)
    created.append(name)


def percent_bars(ax, labels, values, n, title, colors):
    y = np.arange(len(labels))
    ax.barh(y, [100 * v / n for v in values], color=colors, height=0.56)
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    ax.set_xlim(0, 112)
    ax.set_xticks([0, 25, 50, 75, 100])
    ax.set_xlabel("Accepted answers (%)")
    ax.set_title(title, loc="left", pad=13, fontweight="bold")
    ax.set_axisbelow(True)
    ax.grid(axis="x", alpha=0.18)
    for i, value in enumerate(values):
        ax.text(100 * value / n + 2, i, f"{value}/{n}", va="center", fontsize=10)
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", length=0)


fig, ax = plt.subplots(figsize=(8.4, 5.5))
fig.subplots_adjust(left=.015, right=.985, bottom=.025, top=.985)
ax.set(xlim=(0, 12.65), ylim=(0, 8.3))
ax.axis("off")

def box(x, y, width, height, title, lines=(), face="white", edge="#bdc3d4"):
    ax.add_patch(FancyBboxPatch((x, y), width, height,
                               boxstyle="round,pad=0,rounding_size=.13",
                               facecolor=face, edgecolor=edge, linewidth=1.0, zorder=2))
    if not lines:
        ax.text(x + width / 2, y + height / 2, title,
                ha="center", va="center", fontsize=10.3, zorder=3)
        return
    ax.text(x + width / 2, y + height - .32, title,
            ha="center", va="center", fontsize=11.2, fontweight="bold", zorder=3)
    ax.text(x + width / 2, y + (height - .55) / 2, "\n".join(lines),
            ha="center", va="center", fontsize=10.5, linespacing=1.4, zorder=3)

def arrow(points, color=GRAY):
    if len(points) > 2:
        ax.plot(*zip(*points[:-1]), color=color, linewidth=1.2,
                solid_capstyle="round", solid_joinstyle="round", zorder=1)
    ax.add_patch(FancyArrowPatch(points[-2], points[-1], arrowstyle="-|>",
                                shrinkA=0, shrinkB=0, mutation_scale=11,
                                color=color, linewidth=1.2, zorder=1))

ax.text(.2, 8.0, "A  System interaction", fontsize=12, fontweight="bold", va="center")
ax.add_patch(FancyBboxPatch((4.66, 4.65), 7.85, 2.92,
                           boxstyle="round,pad=0,rounding_size=.16",
                           facecolor="#f7f8fc", edgecolor=GRAY, linewidth=.9,
                           linestyle=(0, (4, 3)), zorder=0))
ax.text(4.93, 7.2, "System boundary", fontsize=10.5, color="#596176", va="center")
box(.2, 5.0, 2.9, 1.82, "External sources",
    ("Environment, people", "and other systems"), face="#f5f7fa")
box(5.0, 4.99, 4.38, 1.84, "State update and action",
    (r"$s_{t+1}=F_{\theta_t}(s_t,u_t)$", r"$a_t=\pi_{\theta_t}(s_t,u_t)$"))
box(10.0, 5.43, 2.22, 1.23, "Parameters", (r"Current $\theta_t$",), face="#eeedff", edge=BLUE)
arrow(((3.1, 6.24), (5.0, 6.24)))
ax.text(4.04, 6.44, r"Input $u_t$", fontsize=10.5, ha="center", va="bottom")
arrow(((5.0, 5.41), (3.1, 5.41)))
ax.text(4.04, 5.59, r"Action $a_t$", fontsize=10.5, ha="center", va="bottom")
arrow(((10.0, 5.92), (9.38, 5.92)), color=BLUE)

ax.text(.2, 4.03, "B  Parameter learning", fontsize=12, fontweight="bold", va="center")
box(.2, 1.78, 3.2, 1.35, "Recorded experience",
    ("Inputs, states, actions,", "outcomes and sources"))
box(4.0, 1.78, 3.25, 1.35, "Candidate training",
    ("Train a copy using", "selected examples"))
box(7.87, 1.78, 3.5, 1.35, "Evaluation",
    ("Reserved tests:", "new cases and earlier skills"))
arrow(((5.45, 4.99), (5.45, 3.58), (1.8, 3.58), (1.8, 3.13)))
arrow(((3.4, 2.46), (4.0, 2.46)))
arrow(((7.25, 2.46), (7.87, 2.46)))
arrow(((10.65, 3.13), (10.65, 5.43)), color=BLUE)
ax.text(10.87, 4.13, "Pass:\nuse candidate", fontsize=10.5,
        ha="left", va="center", linespacing=1.4, color=BLUE)
box(7.87, .35, 3.5, .75, "Fail: keep current parameters", face="#f5f7fa")
arrow(((9.62, 1.78), (9.62, 1.10)))
save(fig, "framework")

fig, axes = plt.subplots(1, 2, figsize=(8.1, 3.4), layout="constrained")
formal = DATA["formal"]["arms"]
percent_bars(axes[0], ["Candidate", "Base", "Shuffled control", "Prediction adapter"],
             [formal[k]["audit_accepted"] for k in ("candidate", "bare", "placebo", "retained")], 64,
             "A  New values in trained problem types", [BLUE, GRAY, RED, GREEN])
h = DATA["harder"]
percent_bars(axes[1], ["Candidate", "Shuffled control", "Prediction adapter"],
             [h["candidate_vs_placebo"]["transfer"]["candidate_accepted"],
              h["candidate_vs_placebo"]["transfer"]["comparator_accepted"],
              h["candidate_vs_retained"]["transfer"]["comparator_accepted"]], 81,
             "B  Harder mathematics, plain text", [BLUE, RED, GREEN])
save(fig, "adapter-transfer")

private = DATA["private_continuation"]
fig, axes = plt.subplots(1, 2, figsize=(8.1, 3.7), layout="constrained", gridspec_kw={"width_ratios": [1, 1.2]})
ax = axes[0]
loss = private["prediction_loss"]
x = np.arange(2)
before = [loss["before"][k] for k in ("new_witness", "retention_witness")]
after = [loss["after"][k] for k in ("new_witness", "retention_witness")]
ax.bar(x - .18, before, width=.34, color=GRAY, label="Before")
ax.bar(x + .18, after, width=.34, color=RED, label="After")
for xs, ys in ((x - .18, before), (x + .18, after)):
    for px, py in zip(xs, ys): ax.text(px, py + .06, f"{py:.3f}", ha="center", fontsize=8.5)
ax.set_xticks(x, ["New evaluation set\n3 pairs", "Historical set\n16 pairs"])
ax.set_ylim(0, 3.25)
ax.set_ylabel("Prediction loss (lower is better)")
ax.set_title("A  Prediction update", loc="left", fontweight="bold", pad=13)
ax.legend(loc="upper left", frameon=False, fontsize=9)
ax.set_axisbelow(True); ax.grid(axis="y", alpha=.15)
ax = axes[1]
names = ("transfer", "retention", "boundary")
rows = [private["speaking_groups"][name] for name in names]
y = np.arange(3)
ax.barh(y, [-row["losses"] for row in rows], color=RED, height=.5, label="Losses")
ax.barh(y, [row["gains"] for row in rows], color=BLUE, height=.5, label="Gains")
ax.axvline(0, color=INK, linewidth=.8)
ax.set_yticks(y, ["New numerical cases\n60 pairs", "Earlier skills\n18 pairs", "Unavailable info\n6 pairs"])
ax.invert_yaxis(); ax.set_xlim(-13, 13)
ax.set_xticks([-10, -5, 0, 5, 10], ["10", "5", "0", "5", "10"])
ax.set_xlabel("Losses  ←  Paired comparisons  →  Gains")
ax.set_title("B  Response update", loc="left", fontweight="bold", pad=13)
for i, row in enumerate(rows):
    if row["losses"]: ax.text(-row["losses"] - .5, i, str(row["losses"]), ha="right", va="center")
    if row["gains"]: ax.text(row["gains"] + .5, i, str(row["gains"]), ha="left", va="center")
    if not row["gains"] and not row["losses"]: ax.text(.5, i, "0 gains / 0 losses", va="center", fontsize=9)
ax.spines["left"].set_visible(False); ax.tick_params(axis="y", length=0)
save(fig, "continuation")

fig, axes = plt.subplots(3, 1, figsize=(7.5, 7.0), layout="constrained")
r = DATA["rule_use"]["conditions"]
percent_bars(axes[0], ["Retained / thinking on", "Retained / thinking off", "Candidate / thinking on", "Candidate / thinking off"],
             [r[k]["exact"] for k in ("retained-on", "retained-off", "candidate-on", "candidate-off")], 12,
             "A  Applying a supplied rule", [BLUE, GRAY, GREEN, GRAY])
a = DATA["acquisition"]["conditions"]
percent_bars(axes[1], ["Own rule / query 1", "Own rule / query 2", "Supplied / query 1", "Supplied / query 2"],
             [a[k]["exact"] for k in ("own-p1", "own-p2", "supplied-p1", "supplied-p2")], 6,
             "B  Using learned rules (2/6 rules correct)", [BLUE, BLUE, GREEN, GREEN])
w = DATA["worlds"]
percent_bars(axes[2], ["Own records", "Original observations", "No records"],
             [w[k] for k in ("own", "raw", "none")], 16,
             "C  Earlier eight-world pilot", [BLUE, GREEN, GRAY])
save(fig, "world-learning")

fig, ax = plt.subplots(figsize=(8.0, 4.0), layout="constrained")
pilots = DATA["decisive_pilots"]
y = np.arange(len(pilots))
left = np.zeros(len(pilots))
for key, color, label in (("SOUND", BLUE, "SOUND"), ("FAIL", RED, "FAIL"), ("INVALID", GRAY, "INVALID")):
    values = [sum(cell[key] for cell in run["cells"].values()) for run in pilots]
    ax.barh(y, values, left=left, color=color, height=.58, label=label)
    left += values
ax.barh(y, [run["scheduled"] - run["saved"] for run in pilots], left=left,
        color="white", edgecolor="#c7cbd5", hatch="///", linewidth=.6, height=.58, label="Uncollected")
labels = ["v11 - invalid schedule", "v12 - budget change", "v13 - too few eligible tasks", "v14 - too few eligible tasks", "v15 - incomplete"]
ax.set_yticks(y, labels); ax.invert_yaxis()
for i, run in enumerate(pilots): ax.text(345, i, f"{run['saved']}/336", va="center", fontsize=10)
ax.set_xlim(0, 399); ax.set_xticks([0, 84, 168, 252, 336])
ax.set_xlabel("Scheduled pilot measurements")
ax.set_title("Collection and recorded grader labels", loc="left", fontweight="bold", pad=16)
ax.legend(loc="upper center", bbox_to_anchor=(.46, -.19), ncol=4, frameon=False, fontsize=9)
ax.spines["left"].set_visible(False); ax.tick_params(axis="y", length=0)
save(fig, "decisive-pilots")

print(f"Created {len(created)} figures in PDF, SVG and PNG formats: {', '.join(created)}")
