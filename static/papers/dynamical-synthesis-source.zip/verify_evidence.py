#!/usr/bin/env python3
"""Read archived evidence and reproduce selected manuscript counts.

Python 3.9+, standard library only. Does not import the experiment runtime,
contact a model, write source records, or control processes. Default output is
JSON; --check compares it with the snapshot stored beside this script.
"""

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
CLEAN = "data/fish/labs/claim-transfer-clean-2026-09-03T170409Z"
HARDER = "data/fish/labs/decisive-formal-2026-09-05T101400Z"
INTERFACE = "data/fish/labs/formal-interface-2026-09-05T150825Z"
PRIVATE = "data/fish/labs/private-learning/dreams/20260906T214327762030Z"
TRAINING = ("data/fish/labs/claude-claims-2026-09-02T131808Z/body/fish/water/adapters/"
            "claim-dream-clean-2026-09-03T1920-EAT")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def binomial_upper(n, k, p):
    return math.fsum(math.comb(n, j) * p**j * (1 - p)**(n - j)
                     for j in range(k, n + 1))


def exact_one_sided(gains, losses):
    return binomial_upper(gains + losses, gains, 0.5)


def cp_lower(successes, n, alpha=0.025):
    if successes == 0:
        return 0.0
    low, high = 0.0, 1.0
    for _ in range(100):
        middle = (low + high) / 2
        if binomial_upper(n, successes, middle) < alpha:
            low = middle
        else:
            high = middle
    return (low + high) / 2


def paired_lower(gains, losses, n):
    # Union bound on two one-sided 97.5% Clopper-Pearson limits.
    return cp_lower(gains, n) - (1 - cp_lower(n - losses, n))


def close(actual, expected, label):
    require(math.isclose(actual, expected, rel_tol=1e-10, abs_tol=1e-15), label)


class Records:
    def __init__(self):
        self.files = {}

    def read(self, relative):
        path = ROOT / relative
        content = path.read_bytes()
        self.files[str(relative)] = {
            "bytes": len(content), "raw_sha256": hashlib.sha256(content).hexdigest()
        }
        return content

    def json(self, relative):
        return json.loads(self.read(relative))


def build_snapshot():
    records = Records()
    protocol = records.json(CLEAN + "/protocol.json")
    clean = records.json(CLEAN + "/verdict.json")
    training = records.json(TRAINING + "/adapter_config.json")
    training_record = records.json(TRAINING + "/dream.json")
    manifest_counts = {}
    for key in ("candidate_dream_manifest", "placebo_manifest"):
        # Historical absolute paths differ in capitalization; resolve from data/.
        relative = "data/" + protocol["pins"][key + "_path"].split("/data/", 1)[1]
        manifest = records.json(relative)
        require(records.files[relative]["raw_sha256"] == protocol["pins"][key + "_sha256"],
                key + " differs from its frozen protocol pin")
        manifest_counts[key] = manifest["counts"]

    factorial = []
    for condition in clean["factorial_diagnostics"]:
        factorial.append({
            "prompt": condition["prompt_condition"],
            "grammar": condition["grammar_condition"],
            "arms": {name: {k: arm[k] for k in
                            ("tasks", "audit_accepted", "exact_proved", "reply_cap_cuts")}
                     for name, arm in condition["arms"].items()},
        })
    primary = next(row for row in factorial
                   if row["prompt"] == "names-only" and row["grammar"] == "loose-v2")
    primary_counts = {name: arm["audit_accepted"] for name, arm in primary["arms"].items()}
    require(primary_counts == {"candidate": 43, "bare": 0, "placebo": 0, "retained": 5},
            "Clean primary counts no longer match manuscript")
    comparisons = {}
    for name, value in clean["primary_endpoint"]["comparisons"].items():
        n, gains, losses, ties = (value[k] for k in ("n", "gains", "losses", "ties"))
        require(gains + losses + ties == n, name + ": inconsistent pair count")
        require(len(value["gain_case_ids"]) == gains and len(value["loss_case_ids"]) == losses,
                name + ": inconsistent discordant case lists")
        p = exact_one_sided(gains, losses)
        lower = paired_lower(gains, losses, n)
        close(p, value["one_sided_exact_mcnemar_p"], name + ": exact p differs")
        close(lower, value["bonferroni_cp_95_lower_difference"], name + ": bound differs")
        comparisons[name] = {
            "pairs": n, "gains": gains, "losses": losses, "ties": ties,
            "recomputed_one_sided_exact_p": p,
            "recomputed_bonferroni_cp_95_lower_difference": round(lower, 12),
        }
    clean_result = {
        "training_counts": manifest_counts, "primary": primary,
        "training_configuration": {key: training[key] for key in (
            "model", "fine_tune_type", "batch_size", "iters", "learning_rate",
            "lora_parameters", "mask_prompt", "max_seq_length", "num_layers", "optimizer", "seed")},
        "training_record_counts": {key: training_record[key] for key in (
            "accepted_pairs", "trained_pairs", "validation_pairs", "test_pairs")},
        "comparisons": comparisons, "factorial": factorial,
        "requests": sum(arm["tasks"] for row in factorial for arm in row["arms"].values()),
        "frozen_harness_commit": protocol["pins"]["git_commit"],
        "recorded_protocol_identifier": clean["protocol_sha256"],
        "recorded_verdict_identifier": clean["verdict_sha256"],
        "runtime": protocol["runtime"],
    }
    require(clean_result["requests"] == 1024, "Clean request total changed")

    harder = records.json(HARDER + "/verdict.json")
    harder_result = {}
    for name in ("candidate_vs_placebo", "candidate_vs_retained"):
        domains = {}
        for domain, value in harder[name]["effect"]["domains"].items():
            rows = value["by_probe"]
            gains = sum(row["after_successes"] > row["before_successes"] for row in rows)
            losses = sum(row["after_successes"] < row["before_successes"] for row in rows)
            ties = len(rows) - gains - losses
            require((gains, losses, ties) == tuple(value[k] for k in ("gains", "losses", "ties")),
                    name + "/" + domain + ": task aggregation differs")
            p = exact_one_sided(gains, losses)
            close(p, value["one_sided_sign_p"], name + "/" + domain + ": p differs")
            domains[domain] = {
                "tasks": len(rows), "seeds": len(value["by_seed"]),
                "replies_per_arm": len(rows) * len(value["by_seed"]),
                "candidate_accepted": sum(row["after_successes"] for row in rows),
                "comparator_accepted": sum(row["before_successes"] for row in rows),
                "task_gains": gains, "task_losses": losses, "task_ties": ties,
                "recomputed_one_sided_sign_p": p,
            }
        harder_result[name] = domains

    interface = records.json(INTERFACE + "/verdict.json")
    interface_result = interface["description"]["all"]
    require(interface_result["arms"]["candidate"]["accepted"] ==
            {"direct-answer": 3, "formal-free": 4, "formal-grammar": 4},
            "Interface candidate counts changed")

    plan = records.json(PRIVATE + "/plan.json")
    result = records.json(PRIVATE + "/result.json")
    comparison = records.json(PRIVATE + "/speaking-comparison.json")
    probes = records.json(PRIVATE + "/probes.json")
    probe_map = {probe["id"]: probe["group"] for probe in probes}
    expected_keys = {(probe, seed) for probe in probe_map for seed in plan["comparison"]["seeds"]}
    measurements = {}
    for arm in ("candidate", "retained"):
        rows = {}
        for path in sorted((ROOT / PRIVATE / "measurements" / arm).rglob("result.json")):
            row = records.json(str(path.relative_to(ROOT)))
            key = (row["probe"], row["seed"])
            require(key not in rows, "Duplicate private measurement")
            require(row["arm"] == arm and row["group"] == probe_map[row["probe"]],
                    "Private measurement identity differs")
            require(isinstance(row["correct"], bool), "Missing binary correctness")
            require(row["routing_ok"] and row["transport_ok"], "Invalid private measurement")
            rows[key] = row
        require(set(rows) == expected_keys, "Incomplete private measurement grid")
        measurements[arm] = rows

    groups = {group: Counter() for group in sorted(set(probe_map.values()))}
    discordant = {"gains": set(), "losses": set()}
    for key in sorted(expected_keys):
        candidate, retained = (measurements[arm][key] for arm in ("candidate", "retained"))
        group = candidate["group"]
        delta = int(candidate["correct"]) - int(retained["correct"])
        outcome = "gains" if delta > 0 else "losses" if delta < 0 else "ties"
        groups[group]["pairs"] += 1
        groups[group][outcome] += 1
        if outcome in discordant:
            discordant[outcome].add((group, key[0], key[1]))
    for outcome, actual in discordant.items():
        recorded = {(row["group"], row["probe"], row["seed"]) for row in comparison[outcome]}
        require(len(recorded) == len(comparison[outcome]) and recorded == actual,
                "Private " + outcome + " differ from comparison verdict")
    paired = len(expected_keys)
    require(paired == comparison["paired_cells"] == 84, "Private pair total changed")
    totals = {key: sum(group[key] for group in groups.values())
              for key in ("pairs", "gains", "losses", "ties")}
    require(totals == {"pairs": 84, "gains": 12, "losses": 17, "ties": 55},
            "Private totals differ from manuscript")
    boundary_passed = all(row["correct"] for row in measurements["candidate"].values()
                          if row["group"] == "boundary")
    require(boundary_passed == comparison["candidate_boundary_all_correct"], "Boundary verdict differs")
    passed = (totals["losses"] <= plan["comparison"]["max_losses"] and
              groups["transfer"]["gains"] >= plan["comparison"]["min_transfer_gains"] and boundary_passed)
    require(passed == comparison["passed"] is False, "Speaking adoption verdict differs")
    prediction = result["losses"]["prediction"]
    new_drop = prediction["before"]["new_witness"] - prediction["after"]["new_witness"]
    retention_increase = (prediction["after"]["retention_witness"] -
                          prediction["before"]["retention_witness"])
    prediction_passed = (new_drop >= plan["comparison"]["prediction_min_new_loss_drop"] and
                         retention_increase <= plan["comparison"]["prediction_max_retention_loss_increase"])
    require(prediction_passed == prediction["loss_passed"] is False, "Prediction adoption verdict differs")
    require(result["live_activation"] is False, "Historical activation status changed")
    private_result = {
        "prediction_counts": plan["prediction"]["counts"],
        "prediction_new_training_pairs": plan["prediction"]["new_train_count"],
        "prediction_loss": {k: prediction[k] for k in ("before", "after", "loss_passed")},
        "speaking_training_counts": plan["speaking"]["counts"],
        "speaking_target_origin": plan["speaking"]["origin"],
        "speaking_loss": {k: result["losses"]["speaking"][k] for k in ("before", "after", "loss_passed")},
        "speaking_groups": {name: {k: values[k] for k in ("pairs", "gains", "losses", "ties")}
                            for name, values in groups.items()},
        "speaking_totals": totals, "speaking_passed": passed,
        "candidate_boundary_all_correct": boundary_passed,
        "historical_status": result["status"], "historical_live_activation": result["live_activation"],
        "decision_rules": plan["comparison"],
    }

    for relative in (
        "fish/daemon/src/fast/state.rs", "docs/EQUATION.md",
        "fish/daemon/src/skin/mod.rs", "fish/daemon/src/ledger/embed/mod.rs",
        "fish/lab/formal-speaking-plan-v1.json",
        CLEAN + "/audit-bundle.json", CLEAN + "/external-audit.json",
        HARDER + "/external-audit.json", INTERFACE + "/protocol.json",
        "fish/album/2026-09-03T0028-EAT-claim-coat-primary-ruling.md",
        "fish/album/2026-09-03T1908-EAT-formal-claim-transfer-stage1.md",
        "fish/album/2026-09-03T1945-EAT-clean-claim-safety.md",
        "fish/album/2026-09-04T0043-EAT-clean-formal-claim-transfer.md",
        "fish/album/2026-09-05T1210-EAT-clean-formal-hard-transfer-invalid.md",
        "fish/album/2026-09-05T1630-EAT-formal-speaking-result.md",
        "fish/album/2026-09-05T2123-EAT-formal-interface-result.md",
        "fish/album/2026-09-06T2248-EAT-decisive-v13-pilot-result.md",
        "fish/album/2026-09-07T0048-EAT-private-continuing-learning.md",
        "fish/album/2026-09-07T0335-EAT-private-continuing-learning-result.md",
    ):
        records.read(relative)

    return {
        "snapshot_version": 1,
        "scope": "Archived counts and arithmetic; no new scoring, inference or independent replication.",
        "hash_semantics": "raw_sha256 hashes exact file bytes; internal recorded identifiers may hash a canonical payload.",
        "clean_formal": clean_result, "harder_speaking": harder_result,
        "interface": interface_result, "private_continuation": private_result,
        "sources": records.files,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="Compare with the stored paper snapshot")
    args = parser.parse_args()
    snapshot = build_snapshot()
    if args.check:
        saved = json.loads((HERE / "evidence-snapshot.json").read_text())
        require(snapshot == saved, "Evidence differs from stored snapshot; inspect changes before updating it")
        print("Evidence snapshot matches: {} source files; counts and arithmetic checks passed."
              .format(len(snapshot["sources"])))
    else:
        print(json.dumps(snapshot, indent=2, sort_keys=True, ensure_ascii=False))


if __name__ == "__main__":
    main()
