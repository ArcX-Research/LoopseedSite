#!/usr/bin/env python3
"""Verify every archived regular file against the stored byte manifest."""
import hashlib
import json
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "output/data/dynamical-synthesis"


def main():
    manifest_bytes = (OUT / "file-manifest.jsonl").read_bytes()
    inventory_bytes = (OUT / "data-inventory.json").read_bytes()
    inventory = json.loads(inventory_bytes)
    assert hashlib.sha256(manifest_bytes).hexdigest() == inventory["manifest_sha256"]
    expected = {"sources/" + row["path"]: row for row in
                (json.loads(line) for line in manifest_bytes.splitlines()) if row["kind"] == "regular"}
    seen, total = set(), 0
    with tarfile.open(OUT / "research-data.tar.gz", "r|gz") as archive:
        for member in archive:
            assert member.isfile() and member.name not in seen, member.name
            assert not member.name.endswith(".secret"), "Authentication file in archive"
            stream = archive.extractfile(member)
            if member.name in ("file-manifest.jsonl", "data-inventory.json"):
                reference = manifest_bytes if member.name == "file-manifest.jsonl" else inventory_bytes
                assert stream.read() == reference
                continue
            row = expected[member.name]
            digest = hashlib.sha256()
            copied = 0
            while True:
                chunk = stream.read(1024 * 1024)
                if not chunk:
                    break
                digest.update(chunk)
                copied += len(chunk)
            assert copied == row["bytes"] == member.size, member.name
            assert digest.hexdigest() == row["sha256"], member.name
            seen.add(member.name)
            total += copied
            if len(seen) % 5000 == 0:
                print("Verified {:,} archived files".format(len(seen)), flush=True)
    assert seen == set(expected)
    assert len(seen) == inventory["regular_files"]
    assert total == inventory["source_bytes"]
    result = {"verified_regular_files": len(seen), "verified_source_bytes": total,
              "manifest_sha256": inventory["manifest_sha256"],
              "scope": "All regular-file sizes and SHA-256 hashes checked after archive creation; no scientific regrading."}
    (OUT / "archive-verification.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
