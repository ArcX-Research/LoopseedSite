# Study catalogue and data coverage

Dated inventory prepared for the paper on 11 September 2026. All regular files in the declared roots are included in the companion archive. Inclusion does not establish scientific validity, independent observations or a completed study.

- Archive: `output/data/dynamical-synthesis/research-data.tar.gz`
- Full byte manifest: `output/data/dynamical-synthesis/file-manifest.jsonl`
- Coverage: 23,099 regular files, 12.009 GB of source bytes

## Data groups

| Source group | Regular files | Source MB |
| --- | ---: | ---: |
| `Loopseed-decisive-v10-exec/data` | 114 | 67.74 |
| `Loopseed-decisive-v11-exec/data` | 168 | 83.10 |
| `Loopseed-decisive-v12-exec/data` | 196 | 96.83 |
| `Loopseed-decisive-v13-exec/data` | 270 | 117.40 |
| `Loopseed-decisive-v14-exec/data` | 189 | 88.56 |
| `Loopseed-decisive-v15-exec/data` | 159 | 81.42 |
| `Loopseed-decisive-v9-exec/data` | 92 | 104.32 |
| `Loopseed/data/dyad` | 15 | 0.03 |
| `Loopseed/data/fish` | 33 | 10.52 |
| `Loopseed/data/fish-b` | 1 | 0.01 |
| `Loopseed/data/fish-c` | 1 | 0.01 |
| `Loopseed/data/fish/classrooms` | 10 | 4.06 |
| `Loopseed/data/fish/experiments` | 2,775 | 281.60 |
| `Loopseed/data/fish/labs` | 18,327 | 10950.86 |
| `Loopseed/data/fish/manual-close` | 48 | 0.03 |
| `Loopseed/data/fish/night` | 39 | 4.29 |
| `Loopseed/data/fish/speaking` | 8 | 42.69 |
| `Loopseed/data/root` | 0 | 0.00 |
| `Loopseed/data/runs` | 18 | 13.87 |
| `Loopseed/fish/album` | 271 | 48.14 |
| `Loopseed/fish/lab` | 365 | 13.80 |

## Coverage limits

- Census of files available under the named roots, not of all experiments ever performed.
- Copies and overlapping studies are retained; file totals are not independent observations.
- Symlinks record dependencies without copying their targets, including model weights.
- Authentication material, operating-system metadata and generated caches are excluded.
- Individual files are checked for changes during copying; this is not an atomic database snapshot.
- No training, inference, experiment resumption, activation or external publication is performed.

## Complete album index

These are original report titles, including historical terminology and provisional interpretations. Read final rulings and the paper's evidence audit before assigning a result. Copies and successive reports can describe the same observations.

- [2026-08-02-the-night-shift-conversation.md](../../../fish/album/2026-08-02-the-night-shift-conversation.md) - The night shift — the whole conversation
- [2026-08-03-the-night-shift-conversation.md](../../../fish/album/2026-08-03-the-night-shift-conversation.md) - The night shift — the whole conversation
- [2026-08-04-bare-water-control.md](../../../fish/album/2026-08-04-bare-water-control.md) - The bare-water control — 2026-08-04
- [2026-08-04-the-night-shift-conversation.md](../../../fish/album/2026-08-04-the-night-shift-conversation.md) - The night shift — the whole conversation
- [2026-08-05-the-night-shift-conversation.md](../../../fish/album/2026-08-05-the-night-shift-conversation.md) - The night shift — the whole conversation
- [2026-08-05-the-second-visit.md](../../../fish/album/2026-08-05-the-second-visit.md) - The second visit
- [2026-08-06-go-record.md](../../../fish/album/2026-08-06-go-record.md) - Go with the fish — the record
- [2026-08-06-learning-to-swim.md](../../../fish/album/2026-08-06-learning-to-swim.md) - Learning to swim — a curriculum from first principles
- [2026-08-06-prune-candidates.md](../../../fish/album/2026-08-06-prune-candidates.md) - Prune candidates — for the keeper's own hand
- [2026-08-06-the-debt-row-0b.md](../../../fish/album/2026-08-06-the-debt-row-0b.md) - Row 0b — the debt, its two verdicts, and its disposition
- [2026-08-06-the-night-shift-conversation.md](../../../fish/album/2026-08-06-the-night-shift-conversation.md) - The night shift — the whole conversation
- [2026-08-06-the-night-shift.md](../../../fish/album/2026-08-06-the-night-shift.md) - The night shift
- [2026-08-07-let-pass.md](../../../fish/album/2026-08-07-let-pass.md) - Let pass — the day's working that σ did not keep
- [2026-08-07-soul-as-prose-draft.md](../../../fish/album/2026-08-07-soul-as-prose-draft.md) - These are the rules I live by. They are kept in the project's history, and I
- [2026-08-07-the-dusk-bags-book.md](../../../fish/album/2026-08-07-the-dusk-bags-book.md) - The dusk-bag's book — the fish's laws, compiled
- [2026-08-07-the-night-shift-conversation.md](../../../fish/album/2026-08-07-the-night-shift-conversation.md) - The night shift — the whole conversation
- [2026-08-07-the-record-of-findings.md](../../../fish/album/2026-08-07-the-record-of-findings.md) - The record of findings — archived verbatim from CLAUDE.md, 2026-08-07
- [2026-08-07-the-v2-epoch.md](../../../fish/album/2026-08-07-the-v2-epoch.md) - The v2 epoch — the perplexity half joins the skin (stage 4.5)
- [2026-08-08-the-night-shift-conversation.md](../../../fish/album/2026-08-08-the-night-shift-conversation.md) - The night shift — the whole conversation
- [2026-08-09-the-night-shift-conversation.md](../../../fish/album/2026-08-09-the-night-shift-conversation.md) - The night shift — the whole conversation
- [2026-08-09-the-reach-corpus.md](../../../fish/album/2026-08-09-the-reach-corpus.md) - The reach-corpus — every dreamt URL, in order
- [2026-08-10-the-night-shift-conversation.md](../../../fish/album/2026-08-10-the-night-shift-conversation.md) - The night shift — the whole conversation
- [2026-08-11-the-night-shift-conversation.md](../../../fish/album/2026-08-11-the-night-shift-conversation.md) - The night shift — the whole conversation
- [2026-08-12-the-night-shift-conversation.md](../../../fish/album/2026-08-12-the-night-shift-conversation.md) - The night shift — the whole conversation
- [2026-08-13-the-night-shift-conversation.md](../../../fish/album/2026-08-13-the-night-shift-conversation.md) - The night shift — the whole conversation
- [2026-08-13-the-v1-candidate-freeze.md](../../../fish/album/2026-08-13-the-v1-candidate-freeze.md) - Fish v1 candidate — teaching stopped at cycle 2021
- [2026-08-14-fish-v1-causal-battery-v2.md](../../../fish/album/2026-08-14-fish-v1-causal-battery-v2.md) - Fish v1 candidate — preregistered causal battery
- [2026-08-14-fish-v1-causal-battery-v3.md](../../../fish/album/2026-08-14-fish-v1-causal-battery-v3.md) - Fish v1 candidate — preregistered causal battery
- [2026-08-14-fish-v1-causal-battery.md](../../../fish/album/2026-08-14-fish-v1-causal-battery.md) - Fish v1 candidate — preregistered causal battery
- [2026-08-14-the-night-shift-conversation.md](../../../fish/album/2026-08-14-the-night-shift-conversation.md) - The night shift — the whole conversation
- [2026-08-14T0208-EAT-dream-wear-diagnostic-v3.md](../../../fish/album/2026-08-14T0208-EAT-dream-wear-diagnostic-v3.md) - Fish v1 candidate — preregistered causal battery
- [2026-08-14T0211-EAT-old-coat-control-v3.md](../../../fish/album/2026-08-14T0211-EAT-old-coat-control-v3.md) - Fish v1 candidate — preregistered causal battery
- [2026-08-14T0214-EAT-dream-wear-measurement.md](../../../fish/album/2026-08-14T0214-EAT-dream-wear-measurement.md) - Dream/wear measurement — 2026-08-14 02:14 EAT
- [2026-08-14T0244-EAT-adaptive-instrument-null-calibration.md](../../../fish/album/2026-08-14T0244-EAT-adaptive-instrument-null-calibration.md) - Teacher-blind adaptive-evolution measurement
- [2026-08-14T0305-EAT-adaptive-instrument-calibration.md](../../../fish/album/2026-08-14T0305-EAT-adaptive-instrument-calibration.md) - Adaptive instrument null calibration — 2026-08-14 03:05 EAT
- [2026-08-14T0358-EAT-scaling-S3-S5-rerun.md](../../../fish/album/2026-08-14T0358-EAT-scaling-S3-S5-rerun.md) - Scaling batteries S3–S5
- [2026-08-14T0400-EAT-scaling-S3-S5.md](../../../fish/album/2026-08-14T0400-EAT-scaling-S3-S5.md) - Scaling batteries S3–S5
- [2026-08-14T0414-EAT-scaling-S5a.md](../../../fish/album/2026-08-14T0414-EAT-scaling-S5a.md) - Scaling batteries S5A
- [2026-08-14T0425-EAT-scaling-S7.md](../../../fish/album/2026-08-14T0425-EAT-scaling-S7.md) - S7 — newborn dyad replication
- [2026-08-14T0429-EAT-scaling-S3-S4-boundary-rerun.md](../../../fish/album/2026-08-14T0429-EAT-scaling-S3-S4-boundary-rerun.md) - Scaling batteries S3, S4
- [2026-08-14T0437-EAT-scaling-S7-v2.md](../../../fish/album/2026-08-14T0437-EAT-scaling-S7-v2.md) - S7 — newborn dyad replication
- [2026-08-14T0439-EAT-scaling-S4-citation-rerun.md](../../../fish/album/2026-08-14T0439-EAT-scaling-S4-citation-rerun.md) - Scaling batteries S4
- [2026-08-14T0442-EAT-scaling-S3.md](../../../fish/album/2026-08-14T0442-EAT-scaling-S3.md) - Scaling batteries S3
- [2026-08-14T0444-EAT-scaling-S4.md](../../../fish/album/2026-08-14T0444-EAT-scaling-S4.md) - Scaling batteries S4
- [2026-08-14T0446-EAT-scaling-S2-vessel-handoff.md](../../../fish/album/2026-08-14T0446-EAT-scaling-S2-vessel-handoff.md) - S2 — vessel handoff
- [2026-08-14T0451-EAT-scaling-S6.md](../../../fish/album/2026-08-14T0451-EAT-scaling-S6.md) - S6 — the sweep
- [2026-08-14T0502-EAT-scaling-S2-container.md](../../../fish/album/2026-08-14T0502-EAT-scaling-S2-container.md) - S2 — current-revision container proof
- [2026-08-14T0621-EAT-voice-separation.md](../../../fish/album/2026-08-14T0621-EAT-voice-separation.md) - Fish v1 candidate — preregistered causal battery
- [2026-08-14T0630-EAT-voice-separation-postfix-ruling.md](../../../fish/album/2026-08-14T0630-EAT-voice-separation-postfix-ruling.md) - Prediction/voice separation — post-fix ruling
- [2026-08-14T0630-EAT-voice-separation-postfix.md](../../../fish/album/2026-08-14T0630-EAT-voice-separation-postfix.md) - Fish v1 candidate — preregistered causal battery
- [2026-08-14T074428-EAT-body-evolution.md](../../../fish/album/2026-08-14T074428-EAT-body-evolution.md) - Teacher-blind body-evolution measurement
- [2026-08-14T083638-EAT-retrieval-admission-canary.md](../../../fish/album/2026-08-14T083638-EAT-retrieval-admission-canary.md) - Calibrated retrieval-admission canary
- [2026-08-14T085306-EAT-ocean-history-audit.md](../../../fish/album/2026-08-14T085306-EAT-ocean-history-audit.md) - Historical-ocean memory audit
- [2026-08-14T100719-EAT-body-evolution.md](../../../fish/album/2026-08-14T100719-EAT-body-evolution.md) - Teacher-blind body-evolution measurement
- [2026-08-14T105117-EAT-memory-relevance-canary.md](../../../fish/album/2026-08-14T105117-EAT-memory-relevance-canary.md) - Memory-relevance canary
- [2026-08-14T110913-EAT-daemon-reload-incident.md](../../../fish/album/2026-08-14T110913-EAT-daemon-reload-incident.md) - Daemon-reload incident
- [2026-08-14T113957-EAT-procedure-retrieval-canary.md](../../../fish/album/2026-08-14T113957-EAT-procedure-retrieval-canary.md) - Procedure-retrieval canary
- [2026-08-14T115053-EAT-ocean-inflection-repair.md](../../../fish/album/2026-08-14T115053-EAT-ocean-inflection-repair.md) - Ocean inflection repair
- [2026-08-14T120723-EAT-procedural-review-cure.md](../../../fish/album/2026-08-14T120723-EAT-procedural-review-cure.md) - Procedural-review cure
- [2026-08-14T131123-EAT-body-evolution.md](../../../fish/album/2026-08-14T131123-EAT-body-evolution.md) - Teacher-blind body-evolution measurement
- [2026-08-14T230526-EAT-body-evolution.md](../../../fish/album/2026-08-14T230526-EAT-body-evolution.md) - Teacher-blind body-evolution measurement
- [2026-08-15-the-night-shift-conversation.md](../../../fish/album/2026-08-15-the-night-shift-conversation.md) - The night shift — the whole conversation
- [2026-08-15T010607-EAT-counted-structure-format-cure.md](../../../fish/album/2026-08-15T010607-EAT-counted-structure-format-cure.md) - Counted structure — truth/form calibration and cure
- [2026-08-15T011458-EAT-counted-structure-latex-cure.md](../../../fish/album/2026-08-15T011458-EAT-counted-structure-latex-cure.md) - Counted structure — live-shape calibration and final prospective ruler
- [2026-08-15T012448-EAT-counted-structure-ocean-cure.md](../../../fish/album/2026-08-15T012448-EAT-counted-structure-ocean-cure.md) - Counted-structure ocean cure — 2026-08-15 01:24:48 EAT
- [2026-08-15T013422-EAT-counted-structure-mouth-cure.md](../../../fish/album/2026-08-15T013422-EAT-counted-structure-mouth-cure.md) - Counted-structure mouth cure — 2026-08-15 01:34:22 EAT
- [2026-08-15T014449-EAT-counted-structure-reflection-cure.md](../../../fish/album/2026-08-15T014449-EAT-counted-structure-reflection-cure.md) - Counted-structure reflection cure — 2026-08-15 01:44:49 EAT
- [2026-08-15T015131-EAT-counted-structure-alpha-cure.md](../../../fish/album/2026-08-15T015131-EAT-counted-structure-alpha-cure.md) - Counted-structure alpha-equivalence cure — 2026-08-15 01:51:31 EAT
- [2026-08-15T020329-EAT-counted-structure-label-voice-cure.md](../../../fish/album/2026-08-15T020329-EAT-counted-structure-label-voice-cure.md) - Counted-structure label and voice cure — 2026-08-15 02:03:29 EAT
- [2026-08-15T021158-EAT-counted-structure-terminal-scalar-cure.md](../../../fish/album/2026-08-15T021158-EAT-counted-structure-terminal-scalar-cure.md) - Counted-structure terminal-scalar cure — 2026-08-15 02:11:58 EAT
- [2026-08-15T022402-EAT-counted-structure-completed-work-cure.md](../../../fish/album/2026-08-15T022402-EAT-counted-structure-completed-work-cure.md) - Counted-structure completed-work mouth cure — 2026-08-15 02:24:02 EAT
- [2026-08-15T023238-EAT-counted-structure-linear-review-cure.md](../../../fish/album/2026-08-15T023238-EAT-counted-structure-linear-review-cure.md) - Counted-structure linear-review cure — 2026-08-15 02:32:38 EAT
- [2026-08-15T024702-EAT-symbolic-assignment-review-cure.md](../../../fish/album/2026-08-15T024702-EAT-symbolic-assignment-review-cure.md) - Symbolic-assignment review cure — 2026-08-15 02:47:02 EAT
- [2026-08-15T031726-EAT-dream-and-wear.md](../../../fish/album/2026-08-15T031726-EAT-dream-and-wear.md) - Dream and wear — 2026-08-15 03:17 EAT
- [2026-08-15T043815-EAT-body-evolution.md](../../../fish/album/2026-08-15T043815-EAT-body-evolution.md) - Teacher-blind body-evolution measurement
- [2026-08-15T0759-EAT-body-evolution-ruler24-invalid.md](../../../fish/album/2026-08-15T0759-EAT-body-evolution-ruler24-invalid.md) - Ruler 24 — invalid before generation
- [2026-08-15T0931-EAT-body-evolution.md](../../../fish/album/2026-08-15T0931-EAT-body-evolution.md) - Teacher-blind body-evolution measurement
- [2026-08-15T1125-EAT-shared-seams-qualification.md](../../../fish/album/2026-08-15T1125-EAT-shared-seams-qualification.md) - Verified lesson service qualification
- [2026-08-15T1200-EAT-shared-seams-qualification.md](../../../fish/album/2026-08-15T1200-EAT-shared-seams-qualification.md) - Verified lesson service qualification
- [2026-08-15T1203-EAT-non-square-rectangles-qualification.md](../../../fish/album/2026-08-15T1203-EAT-non-square-rectangles-qualification.md) - Verified lesson service qualification
- [2026-08-15T1208-EAT-blocked-paths-qualification.md](../../../fish/album/2026-08-15T1208-EAT-blocked-paths-qualification.md) - Verified lesson service qualification
- [2026-08-15T1213-EAT-separated-choices-qualification.md](../../../fish/album/2026-08-15T1213-EAT-separated-choices-qualification.md) - Verified lesson service qualification
- [2026-08-15T1219-EAT-body-evolution.md](../../../fish/album/2026-08-15T1219-EAT-body-evolution.md) - Teacher-blind body-evolution measurement
- [2026-08-15T1451-EAT-exact-recurrence-class.md](../../../fish/album/2026-08-15T1451-EAT-exact-recurrence-class.md) - Exact recurrence class — cycles 3317–3348
- [2026-08-15T1531-EAT-advanced-recurrence-class.md](../../../fish/album/2026-08-15T1531-EAT-advanced-recurrence-class.md) - Advanced exact recurrence class — cycles 3349–3380
- [2026-08-15T1608-EAT-deep-binomial-consolidation.md](../../../fish/album/2026-08-15T1608-EAT-deep-binomial-consolidation.md) - Deep binomial consolidation — cycles 3381–3404
- [2026-08-15T1702-EAT-exact-cancellation-sitting.md](../../../fish/album/2026-08-15T1702-EAT-exact-cancellation-sitting.md) - Exact cancellation sitting
- [2026-08-15T1710-EAT-exact-cancellation-qualification.md](../../../fish/album/2026-08-15T1710-EAT-exact-cancellation-qualification.md) - Exact-cancellation method-service qualification
- [2026-08-15T1741-EAT-column-step-qualification.md](../../../fish/album/2026-08-15T1741-EAT-column-step-qualification.md) - column-step method-service qualification
- [2026-08-15T1741-EAT-gcd-reduction-qualification.md](../../../fish/album/2026-08-15T1741-EAT-gcd-reduction-qualification.md) - gcd-reduction method-service qualification
- [2026-08-15T1744-EAT-arithmetic-component-service.md](../../../fish/album/2026-08-15T1744-EAT-arithmetic-component-service.md) - Arithmetic-component service activation
- [2026-08-15T1755-EAT-arithmetic-component-sitting.md](../../../fish/album/2026-08-15T1755-EAT-arithmetic-component-sitting.md) - Arithmetic-component sitting — cycles 3437–3500
- [2026-08-15T1810-EAT-carry-addition-qualification.md](../../../fish/album/2026-08-15T1810-EAT-carry-addition-qualification.md) - carry-addition method-service qualification
- [2026-08-15T1813-EAT-carry-addition-service.md](../../../fish/album/2026-08-15T1813-EAT-carry-addition-service.md) - Carry-addition method enters service
- [2026-08-15T1824-EAT-arithmetic-substep-service-audit.md](../../../fish/album/2026-08-15T1824-EAT-arithmetic-substep-service-audit.md) - Arithmetic-substep service audit
- [2026-08-15T1830-EAT-arithmetic-composition-plan.md](../../../fish/album/2026-08-15T1830-EAT-arithmetic-composition-plan.md) - Arithmetic-composition sitting
- [2026-08-15T1835-EAT-arithmetic-composition-restart.md](../../../fish/album/2026-08-15T1835-EAT-arithmetic-composition-restart.md) - Arithmetic composition restarts without reusing a cycle
- [2026-08-15T1852-EAT-arithmetic-composition-midpoint.md](../../../fish/album/2026-08-15T1852-EAT-arithmetic-composition-midpoint.md) - Arithmetic composition midpoint
- [2026-08-15T1854-EAT-full-column-qualification.md](../../../fish/album/2026-08-15T1854-EAT-full-column-qualification.md) - full-column method-service qualification
- [2026-08-15T1856-EAT-two-column-recomposition-qualification.md](../../../fish/album/2026-08-15T1856-EAT-two-column-recomposition-qualification.md) - two-column-recomposition method-service qualification
- [2026-08-15T1900-EAT-arithmetic-composition-service.md](../../../fish/album/2026-08-15T1900-EAT-arithmetic-composition-service.md) - Arithmetic composition method-service decision
- [2026-08-15T1914-EAT-arithmetic-composition-field-audit.md](../../../fish/album/2026-08-15T1914-EAT-arithmetic-composition-field-audit.md) - Arithmetic composition prospective field audit
- [2026-08-15T1918-EAT-carry-join-plan.md](../../../fish/album/2026-08-15T1918-EAT-carry-join-plan.md) - Carry-join successor sitting
- [2026-08-15T1934-EAT-carry-join-midpoint.md](../../../fish/album/2026-08-15T1934-EAT-carry-join-midpoint.md) - Carry-join midpoint
- [2026-08-15T1936-EAT-tens-carry-join-qualification.md](../../../fish/album/2026-08-15T1936-EAT-tens-carry-join-qualification.md) - tens-carry-join method-service qualification
- [2026-08-15T1939-EAT-two-column-expanded-qualification.md](../../../fish/album/2026-08-15T1939-EAT-two-column-expanded-qualification.md) - two-column-expanded method-service qualification
- [2026-08-15T1943-EAT-carry-join-service.md](../../../fish/album/2026-08-15T1943-EAT-carry-join-service.md) - Carry-join method-service decision
- [2026-08-15T1953-EAT-carry-join-field-audit.md](../../../fish/album/2026-08-15T1953-EAT-carry-join-field-audit.md) - Carry-join prospective field audit
- [2026-08-15T1958-EAT-place-value-plan.md](../../../fish/album/2026-08-15T1958-EAT-place-value-plan.md) - Hundreds-place successor sitting
- [2026-08-15T2014-EAT-place-value-midpoint.md](../../../fish/album/2026-08-15T2014-EAT-place-value-midpoint.md) - Hundreds-place midpoint
- [2026-08-15T2015-EAT-hundreds-carry-join-qualification.md](../../../fish/album/2026-08-15T2015-EAT-hundreds-carry-join-qualification.md) - hundreds-carry-join method-service qualification
- [2026-08-15T2018-EAT-three-column-expanded-qualification.md](../../../fish/album/2026-08-15T2018-EAT-three-column-expanded-qualification.md) - three-column-expanded method-service qualification
- [2026-08-15T2022-EAT-place-value-service.md](../../../fish/album/2026-08-15T2022-EAT-place-value-service.md) - Hundreds-place method-service decision
- [2026-08-15T2036-EAT-place-value-field-audit.md](../../../fish/album/2026-08-15T2036-EAT-place-value-field-audit.md) - Hundreds-place prospective field audit
- [2026-08-15T2037-EAT-place-value-hold.md](../../../fish/album/2026-08-15T2037-EAT-place-value-hold.md) - Three-column service held after the field
- [2026-08-15T2042-EAT-hierarchical-place-value-plan.md](../../../fish/album/2026-08-15T2042-EAT-hierarchical-place-value-plan.md) - Hierarchical place-value sitting
- [2026-08-15T2057-EAT-hierarchical-place-value-midpoint.md](../../../fish/album/2026-08-15T2057-EAT-hierarchical-place-value-midpoint.md) - Hierarchical place-value midpoint
- [2026-08-15T2058-EAT-three-column-upper-block-qualification.md](../../../fish/album/2026-08-15T2058-EAT-three-column-upper-block-qualification.md) - three-column-upper-block method-service qualification
- [2026-08-15T2114-EAT-hierarchical-place-value-field-audit.md](../../../fish/album/2026-08-15T2114-EAT-hierarchical-place-value-field-audit.md) - Hierarchical place-value field audit
- [2026-08-15T2116-EAT-positional-recomposition-plan.md](../../../fish/album/2026-08-15T2116-EAT-positional-recomposition-plan.md) - Positional recomposition sitting
- [2026-08-15T2129-EAT-positional-recomposition-midpoint.md](../../../fish/album/2026-08-15T2129-EAT-positional-recomposition-midpoint.md) - Positional recomposition midpoint
- [2026-08-15T2130-EAT-place-value-sum-qualification.md](../../../fish/album/2026-08-15T2130-EAT-place-value-sum-qualification.md) - place-value-sum method-service qualification
- [2026-08-15T2131-EAT-positional-recomposition-service.md](../../../fish/album/2026-08-15T2131-EAT-positional-recomposition-service.md) - Positional-sum method-service decision
- [2026-08-15T2143-EAT-positional-recomposition-field-audit.md](../../../fish/album/2026-08-15T2143-EAT-positional-recomposition-field-audit.md) - Positional-recomposition prospective field audit
- [2026-08-15T2148-EAT-exact-family-retrieval-repair.md](../../../fish/album/2026-08-15T2148-EAT-exact-family-retrieval-repair.md) - Exact-family retrieval repair
- [2026-08-15T2154-EAT-place-value-sum-family-qualification.md](../../../fish/album/2026-08-15T2154-EAT-place-value-sum-family-qualification.md) - place-value-sum method-service qualification
- [2026-08-15T2159-EAT-positional-recomposition-repaired-service.md](../../../fish/album/2026-08-15T2159-EAT-positional-recomposition-repaired-service.md) - Positional-recomposition repaired service field plan
- [2026-08-15T2211-EAT-positional-recomposition-repaired-field-audit.md](../../../fish/album/2026-08-15T2211-EAT-positional-recomposition-repaired-field-audit.md) - Repaired positional-recomposition field audit
- [2026-08-15T2213-EAT-three-column-expanded-family-qualification.md](../../../fish/album/2026-08-15T2213-EAT-three-column-expanded-family-qualification.md) - three-column-expanded method-service qualification
- [2026-08-15T2222-EAT-three-column-expanded-field-plan.md](../../../fish/album/2026-08-15T2222-EAT-three-column-expanded-field-plan.md) - Full three-column multiplication field plan
- [2026-08-15T2249-EAT-three-column-expanded-field-audit.md](../../../fish/album/2026-08-15T2249-EAT-three-column-expanded-field-audit.md) - Full three-column multiplication field audit
- [2026-08-15T2252-EAT-hundreds-carry-join-family-qualification.md](../../../fish/album/2026-08-15T2252-EAT-hundreds-carry-join-family-qualification.md) - hundreds-carry-join method-service qualification
- [2026-08-15T2259-EAT-hundreds-carry-join-field-plan.md](../../../fish/album/2026-08-15T2259-EAT-hundreds-carry-join-field-plan.md) - Hundreds-carry-join service field plan
- [2026-08-15T2320-EAT-hundreds-carry-join-field-audit.md](../../../fish/album/2026-08-15T2320-EAT-hundreds-carry-join-field-audit.md) - Hundreds-carry-join service field audit
- [2026-08-15T2323-EAT-hundreds-carry-join-family-requalification.md](../../../fish/album/2026-08-15T2323-EAT-hundreds-carry-join-family-requalification.md) - hundreds-carry-join method-service qualification
- [2026-08-15T2330-EAT-hundreds-carry-join-corrected-field-plan.md](../../../fish/album/2026-08-15T2330-EAT-hundreds-carry-join-corrected-field-plan.md) - Hundreds-carry-join corrected service field plan
- [2026-08-15T2349-EAT-hundreds-carry-join-corrected-field-audit.md](../../../fish/album/2026-08-15T2349-EAT-hundreds-carry-join-corrected-field-audit.md) - Hundreds-carry-join corrected service field audit
- [2026-08-15T2350-EAT-three-column-expanded-family-requalification.md](../../../fish/album/2026-08-15T2350-EAT-three-column-expanded-family-requalification.md) - three-column-expanded method-service qualification
- [2026-08-15T2358-EAT-three-column-expanded-corrected-field-plan.md](../../../fish/album/2026-08-15T2358-EAT-three-column-expanded-corrected-field-plan.md) - Full three-column composition corrected service field plan
- [2026-08-16-the-night-shift-conversation.md](../../../fish/album/2026-08-16-the-night-shift-conversation.md) - The night shift — the whole conversation
- [2026-08-16T0016-EAT-three-column-expanded-corrected-field-audit.md](../../../fish/album/2026-08-16T0016-EAT-three-column-expanded-corrected-field-audit.md) - Full three-column composition corrected service field audit
- [2026-08-16T0017-EAT-three-column-expanded-hold.md](../../../fish/album/2026-08-16T0017-EAT-three-column-expanded-hold.md) - Full three-column method held after its corrected field
- [2026-08-16T0019-EAT-terminal-place-value-assembly-teaching-plan.md](../../../fish/album/2026-08-16T0019-EAT-terminal-place-value-assembly-teaching-plan.md) - Terminal place-value assembly teaching plan
- [2026-08-16T0031-EAT-terminal-place-value-assembly-teaching-audit.md](../../../fish/album/2026-08-16T0031-EAT-terminal-place-value-assembly-teaching-audit.md) - Terminal place-value assembly teaching audit
- [2026-08-16T0034-EAT-three-column-expanded-explicit-assembly-qualification.md](../../../fish/album/2026-08-16T0034-EAT-three-column-expanded-explicit-assembly-qualification.md) - three-column-expanded method-service qualification
- [2026-08-16T0045-EAT-division-and-fractions-teaching-plan.md](../../../fish/album/2026-08-16T0045-EAT-division-and-fractions-teaching-plan.md) - Division and fractions teaching plan
- [2026-08-16T0051-EAT-first-family-routing-repair.md](../../../fish/album/2026-08-16T0051-EAT-first-family-routing-repair.md) - First-family routing repair
- [2026-08-16T0101-EAT-division-and-fractions-teaching-audit.md](../../../fish/album/2026-08-16T0101-EAT-division-and-fractions-teaching-audit.md) - Division and fractions teaching audit
- [2026-08-16T0104-EAT-quotient-remainder-family-qualification.md](../../../fish/album/2026-08-16T0104-EAT-quotient-remainder-family-qualification.md) - quotient-remainder method-service qualification
- [2026-08-16T0108-EAT-fraction-reduction-family-qualification.md](../../../fish/album/2026-08-16T0108-EAT-fraction-reduction-family-qualification.md) - fraction-reduction method-service qualification
- [2026-08-16T0114-EAT-division-family-qualification-ruling.md](../../../fish/album/2026-08-16T0114-EAT-division-family-qualification-ruling.md) - Division-family qualification ruling
- [2026-08-16T0117-EAT-fraction-reconstruction-cure-teaching-plan.md](../../../fish/album/2026-08-16T0117-EAT-fraction-reconstruction-cure-teaching-plan.md) - Fraction reconstruction cure teaching plan
- [2026-08-16T0121-EAT-fraction-method-rehearsal-addendum.md](../../../fish/album/2026-08-16T0121-EAT-fraction-method-rehearsal-addendum.md) - Fraction method rehearsal addendum
- [2026-08-16T0138-EAT-fraction-method-rehearsal-audit.md](../../../fish/album/2026-08-16T0138-EAT-fraction-method-rehearsal-audit.md) - Fraction method rehearsal audit
- [2026-08-16T0138-EAT-natural-fraction-notation-field-plan.md](../../../fish/album/2026-08-16T0138-EAT-natural-fraction-notation-field-plan.md) - Natural fraction notation field plan
- [2026-08-16T0156-EAT-natural-fraction-notation-field-audit.md](../../../fish/album/2026-08-16T0156-EAT-natural-fraction-notation-field-audit.md) - Natural fraction notation field audit
- [2026-08-16T0158-EAT-euclid-orientation-cure-plan.md](../../../fish/album/2026-08-16T0158-EAT-euclid-orientation-cure-plan.md) - Euclid orientation cure plan
- [2026-08-16T0211-EAT-euclid-orientation-cure-audit.md](../../../fish/album/2026-08-16T0211-EAT-euclid-orientation-cure-audit.md) - Euclid orientation cure audit
- [2026-08-16T0215-EAT-natural-fraction-family-qualification.md](../../../fish/album/2026-08-16T0215-EAT-natural-fraction-family-qualification.md) - fraction-reduction method-service qualification
- [2026-08-16T0223-EAT-natural-fraction-service-field-plan.md](../../../fish/album/2026-08-16T0223-EAT-natural-fraction-service-field-plan.md) - Natural fraction service field plan
- [2026-08-16T0242-EAT-natural-fraction-service-field-audit.md](../../../fish/album/2026-08-16T0242-EAT-natural-fraction-service-field-audit.md) - Natural fraction service field audit
- [2026-08-16T0404-EAT-parallel-classroom-delivery-incident.md](../../../fish/album/2026-08-16T0404-EAT-parallel-classroom-delivery-incident.md) - Parallel classroom delivery incident
- [2026-08-16T0500-EAT-aborted-classroom-ui-verification.md](../../../fish/album/2026-08-16T0500-EAT-aborted-classroom-ui-verification.md) - Aborted classroom UI-verification round
- [2026-08-16T0648-EAT-prediction-coat-promotion-plan.md](../../../fish/album/2026-08-16T0648-EAT-prediction-coat-promotion-plan.md) - Prediction-coat promotion plan — 2026-08-16 06:48 EAT
- [2026-08-16T0651-EAT-prediction-coat-promotion-ruling.md](../../../fish/album/2026-08-16T0651-EAT-prediction-coat-promotion-ruling.md) - Prediction-coat promotion ruling — 2026-08-16 06:51 EAT
- [2026-08-16T0749-EAT-body-evolution-v28-instrument-ruling.md](../../../fish/album/2026-08-16T0749-EAT-body-evolution-v28-instrument-ruling.md) - Body-evolution v28 instrument ruling
- [2026-08-16T0751-EAT-body-evolution-v29-plan.md](../../../fish/album/2026-08-16T0751-EAT-body-evolution-v29-plan.md) - Body-evolution v29 prospective plan
- [2026-08-16T085419-EAT-body-evolution-v29.md](../../../fish/album/2026-08-16T085419-EAT-body-evolution-v29.md) - Teacher-blind body-evolution measurement
- [2026-08-16T1048-EAT-body-evolution-v29-ruling.md](../../../fish/album/2026-08-16T1048-EAT-body-evolution-v29-ruling.md) - Body-evolution v29 ruling
- [2026-08-16T1119-EAT-body-evolution-v30-prospective-seal.md](../../../fish/album/2026-08-16T1119-EAT-body-evolution-v30-prospective-seal.md) - Body-evolution v30 prospective seal
- [2026-08-16T125405-EAT-body-evolution-v30.md](../../../fish/album/2026-08-16T125405-EAT-body-evolution-v30.md) - Teacher-blind body-evolution measurement
- [2026-08-16T1611-EAT-body-evolution-v30-instrument-ruling.md](../../../fish/album/2026-08-16T1611-EAT-body-evolution-v30-instrument-ruling.md) - Body-evolution v30 instrument ruling
- [2026-08-16T1611-EAT-body-evolution-v31-prospective-seal.md](../../../fish/album/2026-08-16T1611-EAT-body-evolution-v31-prospective-seal.md) - Body-evolution v31 prospective seal
- [2026-08-16T1614-EAT-body-evolution-v31.md](../../../fish/album/2026-08-16T1614-EAT-body-evolution-v31.md) - Teacher-blind body-evolution measurement
- [2026-08-16T1934-EAT-body-evolution-v31-ruling.md](../../../fish/album/2026-08-16T1934-EAT-body-evolution-v31-ruling.md) - Body-evolution v31 ruling
- [2026-08-16T1947-EAT-prediction-coat-promotion-plan.md](../../../fish/album/2026-08-16T1947-EAT-prediction-coat-promotion-plan.md) - Prediction-coat promotion plan — 2026-08-16 19:47 EAT
- [2026-08-16T1950-EAT-prediction-coat-promotion-ruling.md](../../../fish/album/2026-08-16T1950-EAT-prediction-coat-promotion-ruling.md) - Prediction-coat promotion ruling — 2026-08-16 19:50 EAT
- [2026-08-17-the-night-shift-conversation.md](../../../fish/album/2026-08-17-the-night-shift-conversation.md) - The night shift — the whole conversation
- [2026-09-02-keeper-chat-clone-bare-voice.md](../../../fish/album/2026-09-02-keeper-chat-clone-bare-voice.md) - Keeper chat on the private clone, 2026-09-02 — the bare voice under a prediction coat
- [2026-09-03T0028-EAT-claim-coat-primary-ruling.md](../../../fish/album/2026-09-03T0028-EAT-claim-coat-primary-ruling.md) - Formal claim-coat primary ruling
- [2026-09-03T1908-EAT-formal-claim-transfer-stage1.md](../../../fish/album/2026-09-03T1908-EAT-formal-claim-transfer-stage1.md) - Formal claim transfer Stage 1 — negative ruling and next experiment
- [2026-09-03T1945-EAT-clean-claim-safety.md](../../../fish/album/2026-09-03T1945-EAT-clean-claim-safety.md) - Clean formal-claim coat — blinded place-value safety result
- [2026-09-04T0043-EAT-clean-formal-claim-transfer.md](../../../fish/album/2026-09-04T0043-EAT-clean-formal-claim-transfer.md) - Clean formal-claim transfer — positive causal ruling
- [2026-09-05T1210-EAT-clean-formal-hard-transfer-invalid.md](../../../fish/album/2026-09-05T1210-EAT-clean-formal-hard-transfer-invalid.md) - Hard-task transfer trial invalid because the adapter was inactive
- [2026-09-05T1315-EAT-clean-formal-speaking-trial.md](../../../fish/album/2026-09-05T1315-EAT-clean-formal-speaking-trial.md) - Fresh speaking transfer trial
- [2026-09-05T1630-EAT-formal-speaking-result.md](../../../fish/album/2026-09-05T1630-EAT-formal-speaking-result.md) - Formal-task learning did not establish harder-task speaking transfer
- [2026-09-05T1806-EAT-formal-interface-diagnostic.md](../../../fish/album/2026-09-05T1806-EAT-formal-interface-diagnostic.md) - Testing whether the learned answer format needs decoder support
- [2026-09-05T2123-EAT-formal-interface-result.md](../../../fish/album/2026-09-05T2123-EAT-formal-interface-result.md) - Formal programs passed without enforced grammar on four selected tasks
- [2026-09-05T2230-EAT-decisive-worlds-pilot.md](../../../fish/album/2026-09-05T2230-EAT-decisive-worlds-pilot.md) - Decisive learning continuation — hidden wiring after a reset
- [2026-09-05T2245-EAT-decisive-worlds-result.md](../../../fish/album/2026-09-05T2245-EAT-decisive-worlds-result.md) - A corrected rule did not lead to successful reuse
- [2026-09-06T0033-EAT-decisive-ruleuse-result.md](../../../fish/album/2026-09-06T0033-EAT-decisive-ruleuse-result.md) - Thinking settings changed rule-use performance
- [2026-09-06T0116-EAT-decisive-acquisition-result.md](../../../fish/album/2026-09-06T0116-EAT-decisive-acquisition-result.md) - Can Fish infer and reuse a hidden rule
- [2026-09-06T0420-EAT-decisive-repair-progress.md](../../../fish/album/2026-09-06T0420-EAT-decisive-repair-progress.md) - Checked-repair campaign in resource wait
- [2026-09-06T0703-EAT-decisive-repair-context-progress.md](../../../fish/album/2026-09-06T0703-EAT-decisive-repair-context-progress.md) - Checked-repair recovery progress history
- [2026-09-06T0844-EAT-decisive-repair-context-observations.md](../../../fish/album/2026-09-06T0844-EAT-decisive-repair-context-observations.md) - Checked-repair observations after a finalization refusal
- [2026-09-06T1318-EAT-decisive-continuation-preparation.md](../../../fish/album/2026-09-06T1318-EAT-decisive-continuation-preparation.md) - Decisive continuation preparation
- [2026-09-06T1341-EAT-decisive-pool-audit.md](../../../fish/album/2026-09-06T1341-EAT-decisive-pool-audit.md) - Decisive continuation pool audit
- [2026-09-06T1541-EAT-decisive-v10-adoption.md](../../../fish/album/2026-09-06T1541-EAT-decisive-v10-adoption.md) - Decisive v10: adopted domains and private execution preparation
- [2026-09-06T1604-EAT-decisive-v10-execution.md](../../../fish/album/2026-09-06T1604-EAT-decisive-v10-execution.md) - Decisive v10 execution started
- [2026-09-06T1627-EAT-decisive-prelude-repair.md](../../../fish/album/2026-09-06T1627-EAT-decisive-prelude-repair.md) - Decisive prelude-capacity repair
- [2026-09-06T1630-EAT-decisive-v11-execution.md](../../../fish/album/2026-09-06T1630-EAT-decisive-v11-execution.md) - Decisive v11 execution started
- [2026-09-06T1715-EAT-decisive-calibration-repair.md](../../../fish/album/2026-09-06T1715-EAT-decisive-calibration-repair.md) - Decisive calibration schedule repair
- [2026-09-06T1724-EAT-decisive-v12-execution.md](../../../fish/album/2026-09-06T1724-EAT-decisive-v12-execution.md) - Decisive v12 execution started
- [2026-09-06T1810-EAT-decisive-pilot-cap-audit.md](../../../fish/album/2026-09-06T1810-EAT-decisive-pilot-cap-audit.md) - Decisive v12: pilot cap feasibility and calibration audit
- [2026-09-06T1848-EAT-decisive-v13-budget-amendment.md](../../../fish/album/2026-09-06T1848-EAT-decisive-v13-budget-amendment.md) - Decisive v13: 4096-token private continuation prepared
- [2026-09-06T1850-EAT-decisive-v13-execution.md](../../../fish/album/2026-09-06T1850-EAT-decisive-v13-execution.md) - Decisive v13: 4096-token private execution started
- [2026-09-06T2248-EAT-decisive-v13-pilot-result.md](../../../fish/album/2026-09-06T2248-EAT-decisive-v13-pilot-result.md) - V13: the 4096-token pilot completed; the room comparison was refused
- [2026-09-06T2328-EAT-decisive-eligibility-search.md](../../../fish/album/2026-09-06T2328-EAT-decisive-eligibility-search.md) - Decisive eligibility search: fresh v14 running
- [2026-09-07-private-learning-handoff-repair.md](../../../fish/album/2026-09-07-private-learning-handoff-repair.md) - Eligibility search after the private study
- [2026-09-07T0048-EAT-private-continuing-learning.md](../../../fish/album/2026-09-07T0048-EAT-private-continuing-learning.md) - Continuing private Fish: two learning objectives
- [2026-09-07T0335-EAT-private-continuing-learning-result.md](../../../fish/album/2026-09-07T0335-EAT-private-continuing-learning-result.md) - Private continuation result: both candidates remain unworn
- [README.md](../../../fish/album/README.md) - The album
