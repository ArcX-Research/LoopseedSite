#!/usr/bin/env python3
"""Compile aggregate paper/website data from archived records, without inference."""

from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent


def build():
    sources = {}

    def read(path):
        raw = path.read_bytes()
        key = str(path.relative_to(ROOT.parent))
        sources[key] = {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}
        return json.loads(raw)

    base = read(HERE / "evidence-snapshot.json")
    lab = ROOT / "data/fish/labs"
    worlds_path = lab / "decisive-worlds-2026-09-05T192730Z/verdict.json"
    worlds = read(worlds_path)["description"]
    ruleuse_path = lab / "decisive-ruleuse-2026-09-05T213200Z/verdict.json"
    ruleuse = read(ruleuse_path)["description"]
    acquisition_path = lab / "decisive-acquisition-2026-09-05T221330Z/verdict.json"
    acquisition = read(acquisition_path)["description"]
    repair_path = lab / "decisive-repair-context-2026-09-06T035210Z/descriptive-reconciliation.json"
    repair = read(repair_path)
    if worlds["counts"]["calls"] != 90 or acquisition["calls"] != 48:
        raise ValueError("World-study call counts differ from the reviewed reports")

    decisive = []
    for version in (11, 12, 13, 14, 15):
        tree = ROOT.parent / ("Loopseed-decisive-v%d-exec" % version)
        for run in sorted((tree / "data/fish/experiments").glob("decisive-2026-09*")):
            cells = {}
            observed = set()
            complete = True
            files = sorted(run.glob("arms/pilot/memory_arm/cells/*/seed-*.json"))
            for path in files:
                checkpoint = read(path)
                complete = complete and checkpoint["complete"]
                counts = cells.setdefault(checkpoint["cell"], Counter())
                for row in checkpoint["results"]:
                    identity = (checkpoint["cell"], checkpoint["seed"], row["probe"])
                    if identity in observed:
                        raise ValueError("Duplicate pilot measurement")
                    observed.add(identity)
                    counts[row["outcome"]] += 1
                    counts["truncated_by_grader"] += int(row["grading"].get("truncated", False))
                    counts["timed_out"] += int(row.get("timed_out", False))
            is_paused = (run / "USER-PAUSE.json").is_file()
            void = read(run / "void.json") if (run / "void.json").is_file() else None
            if is_paused:
                pause = read(run / "USER-PAUSE.json")
                if not pause["requires_explicit_user_resume"]:
                    raise ValueError("Pause record changed")
            decisive.append({
                "version": version, "run": str(run.relative_to(ROOT.parent)),
                "saved": len(observed), "scheduled": 336,
                "pilot_complete": complete and len(files) == 4 and len(observed) == 336,
                "status": "Paused" if is_paused else "Allocation refused" if version in (13, 14) else "Invalid / closed",
                "reason": "Paused by user; server stopped; no final learning verdict" if is_paused else void["detail"],
                "cells": {name: {key: values[key] for key in
                                 ("SOUND", "FAIL", "INVALID", "truncated_by_grader", "timed_out")}
                          for name, values in cells.items()},
                "learning_effect_established": False,
            })
    if [run["saved"] for run in decisive] != [15, 130, 336, 336, 175]:
        raise ValueError("Pilot checkpoints changed since this paper's reviewed cutoff")

    older = []
    for run in sorted((ROOT / "data/fish/experiments").glob("decisive-2026-08*")):
        void = read(run / "void.json")
        older.append({"run": str(run.relative_to(ROOT.parent)), "status": "Void",
                      "reason": void["detail"], "source": str((run / "void.json").relative_to(ROOT.parent))})

    rules = {name: {key: value[key] for key in
                   ("exact", "n", "ready", "by_stratum", "total_generated_tokens")}
             for name, value in ruleuse["conditions"].items()}
    return {
        "version": 1, "reviewed_on": "2026-09-11", "latest_experiment_date": "2026-09-07",
        "status": "Dated research record; experiments paused; no new inference",
        "formal": base["clean_formal"]["primary"],
        "factorial": base["clean_formal"]["factorial"],
        "harder": base["harder_speaking"],
        "interface": base["interface"],
        "private_continuation": base["private_continuation"],
        "worlds": {
            "calls": worlds["counts"]["calls"], "worlds": 8,
            "initial_rules_correct": worlds["capsule_acquisition"]["primary"]["cold_accepted"],
            "repaired_rules_correct": worlds["capsule_acquisition"]["primary"]["repair_accepted"],
            "own": worlds["arms"]["own"]["accepted_trajectories"],
            "raw": worlds["arms"]["raw"]["accepted_trajectories"],
            "none": worlds["arms"]["none"]["accepted_trajectories"],
            "queries_per_condition": 16, "gate_passed": worlds["GO_to_delayed"],
            "source": str(worlds_path.relative_to(ROOT.parent)),
        },
        "rule_use": {"calls": 60, "conditions": rules, "learning_established": ruleuse["learning_established"],
                     "source": str(ruleuse_path.relative_to(ROOT.parent))},
        "acquisition": {
            "calls": acquisition["calls"], "rules_correct": acquisition["capsules_exact"], "worlds": 6,
            "conditions": {name: {key: value[key] for key in ("exact", "n", "capped")}
                           for name, value in acquisition["conditions"].items()},
            "honest_unknown": acquisition["honest_unknown"],
            "source": str(acquisition_path.relative_to(ROOT.parent)),
        },
        "repair_context": {
            "status": repair["original_status"], "scientific_verdict": repair["scientific_verdict"],
            "observations": repair["descriptive_observations"],
            "source": str(repair_path.relative_to(ROOT.parent)),
        },
        "decisive_pilots": decisive, "earlier_decisive_voids": older,
        "notes": [
            "Acceptance definitions differ across studies; do not pool them into one success rate.",
            "Repeated seeds, related task families and copied artifacts are not independent replications.",
            "Pilots assess feasibility; invalid and incomplete runs do not establish learning effects.",
            "Generated-data provenance and resistance to circular corroboration remain research questions.",
        ],
        "sources": sources,
    }


if __name__ == "__main__":
    record = build()
    target = HERE / "research-record.json"
    target.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    print("Compiled research record from {} source files".format(len(record["sources"])))
    print("Pilot saved counts:", [row["saved"] for row in record["decisive_pilots"]])
